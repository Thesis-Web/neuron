# Neuron: Experience as Executable Structure

## A thesis of the Neuron system within Cortex

A research synthesis of the owner's recorded explanations, architectural corrections, and experimental record

Prepared October 15, 2026

Conceptual authorship belongs to the project owner. This manuscript is an original synthesis written by Codex from the Cortex record. It is not a transcript, an impersonation of the owner, or a claim that the proposed system has been completed.

## Abstract

Neuron proposes that a machine's acquired knowledge, memory, and executable behavior can inhabit a common mathematical structure. A neuron is conceived as a location identified by an expression. Its local relationships determine how an arriving run continues. Runs compose those relationships into processes; receipts preserve the processes actually taken; memories connect their content and outcomes to occurrences in time. Learning changes the structure through which later activity proceeds. The central architectural claim is that the graph itself can constitute the machine's code, including progressively more of the code by which the machine learns.

The project begins with a distinction between developing a capability and using a capability already developed. Expensive discovery should leave behind reusable structure. Familiar work can then proceed through established relationships, substitutions, and shortcuts. When a remembered process does not quite fit, its retained derivation can be reopened: the system can move backward to a relevant choice, examine applicable local alternatives, and construct a different continuation. A memory is consequently more than a stored answer. It is potential material for a new act of reasoning.

Language supplies an early interface to this architecture. Words are external forms associated with internal locations; their meanings are constrained by relationships, definitions, experience, and context. A location can be partially understood before its name is known. A sentence can lead to an answer, an information-gathering process, an action, or a question. The same structure is intended eventually to support tools, compilation, self-revision, and internally initiated activity. Later proposals add selective consolidation during idle periods and small local predictive models whose outputs remain explicitly marked as guesses.

This thesis develops the conceptual system and its research implications from the owner's prose. It also examines the boundary between the intended architecture and the recorded implementation. The archive contains bounded demonstrations, supplied procedures, failed interpretations, incomplete integrations, and unresolved hypotheses. It does not establish a completed autonomous cognitive organism, equivalence to a human brain, or the predicted performance at enormous scale. The resulting account is a thesis of a research program: intelligence is proposed as the continuing conversion of situated experience into executable, revisable structure.

## Reading this manuscript

The chapters present one connected account of Neuron, moving from its purpose through its mechanisms to its proposed developmental life. They are written primarily in paragraphs so the system can be read as an argument rather than as a software checklist. The final chapters assess the experimental record and explain what would constitute a convincing realization of the thesis. A reference lexicon and source register follow the main text.

The account uses the project owner's explanations as the principal authority for intended behavior. Assistant interpretations are useful secondary material, especially where they record a correction or an experiment, but their presence in Cortex does not turn them into the owner's claims. Likewise, a stored report of a successful run is evidence that the report exists; it is not a fresh reproduction of that run.

The source corpus for this edition concentrates on the neuron-v2 book, which contains the V16 and V16.2 discussions despite its name. The principal material dates from September 24 through October 11, 2026. Earlier design is discussed where it is explicitly carried into those records. The account does not claim to exhaust every conversation in Cortex. It brings together the substantial owner prose recovered for this task, including the major later corrections and extensions, rather than presenting a search result as an exhaustive archive.

Bracketed source labels refer to the register at the end. The accompanying sources folder preserves the retrieved Cortex text with its location identifiers and continuation markers. These are retrieval copies, not substitutes for the immutable originals or their recorded hashes. No developmental experiment was run to produce this manuscript.

## Contents

1. The problem Neuron is trying to solve
2. The graph as a computational medium
3. Mathematical identity, location, and relationship
4. DNA, arrival, and the structure of a run
5. Birth, propagation, and the edge of knowledge
6. Learning, execution, and the meaning of a shortcut
7. Receipts, memories, and the continuity of experience
8. Time, state, and the difference between knowing and having known
9. Meaning before a name
10. Language as organized activity
11. Reasoning as the composition of processes
12. Questions as instruments of thought
13. Recursive adaptation and the recovery of alternatives
14. Recall, relevance, and the feeling pattern
15. Guessing, evidence, and revisable truth
16. Context, answer locations, and practical judgment
17. The sixth sense and the possibility of epiphany
18. Sleep, consolidation, and local prediction
19. Development and independence from the mother
20. A computer built in its own language
21. Memory economy and the physical cost of the thesis
22. What the experimental record establishes
23. The research method implied by the system
24. Conclusion: the proposed unity of knowledge and action
Appendix A. A reference lexicon
Appendix B. Source register and interpretive boundaries

## 1. The problem Neuron is trying to solve

The immediate problem behind Neuron is continuity. The owner describes a recurring experience of developing increasingly complicated systems with language-model assistants: a worker can perform a local task while losing the larger reason for that task. It can repeat the project description accurately and still make a decision inconsistent with it. A new component may function in isolation while moving the whole project away from its intended form. As the scope grows, the owner must repeatedly reconstruct that form for the workers. The effort of maintaining the project begins to compete with the effort of building it.

Cortex addresses part of this problem by preserving project evidence outside a single conversation. It supplies a place to recover intent, previous attempts, corrections, observations, and unfinished work. Yet the owner's experience distinguishes preservation from effective use. The existence of a record does not ensure that a worker retrieves it, interprets it correctly, or allows it to constrain the next action. A memory system can retain a design that its users repeatedly violate. The practical question therefore becomes how to make past experience operative in future behavior.

Neuron approaches that question at the level of the machine's organization. What would it mean for a system's experience to become part of the structure that actually selects and performs its actions? What would it mean for a correction to change the next relevant decision, rather than simply add another paragraph to an archive? The proposed answer is to make acquired relationships, remembered processes, and executable continuations belong to the same developing structure.

The desired system should recognize a familiar problem, retrieve relevant experience, assess whether an old process applies, and use or revise that process. It should preserve where its knowledge came from and where its uncertainty begins. When it discovers that an earlier approach failed, the failure should become a usable constraint on later investigation. When it encounters a related problem, it should carry forward the work that remains valid. These are demands for cumulative capability.

Conversation is an important early demonstration because language exposes many of these demands at once. An apparently simple question requires identifying what is being asked, distinguishing remembered information from missing information, selecting a response, and often deciding whether a question should be asked in return. The owner's later shopping and diagnostic examples make clear that fluent wording alone is insufficient. The machine must connect an utterance to a useful process under the actual circumstances.

The long-term aspiration extends beyond conversation. The owner imagines a substrate able to support tools, memories, compilers, logical operations, and the procedures by which further capability is acquired. Neuron is intended to become part of Cortex and might eventually replace much of its machinery, depending on what the experiment achieves. Cortex is presently the evidence and continuity system for the project; Neuron is the proposed computational organism being developed within that wider undertaking.

The personal origin of the theory matters without becoming a scientific proof. The owner repeatedly explains the proposal through accounts of remembering, diagnosing, deciding, and revising. The ambition is to translate a perceived organization of thought into a machine that can operate with the speed and capacity of computation. This supplies the research intuition. It does not establish that all human cognition has the proposed form, but it gives the project a definite question: can experience become durable computational structure that increasingly directs its own use and development? [S08, S11, S12, S20]

## 2. The graph as a computational medium

The central statement of Neuron is that the graph is the code. To understand the statement, it is necessary to take seriously the distinction between storing a description of a process and embodying the process in executable structure. A conventional-looking graph can store the fact that two things are related while an outside program decides how to interpret that relationship. Neuron's intended graph contains the relationships, conditions, transitions, and continuations through which the work itself happens.

A location is therefore potentially an entry into behavior. What that behavior accomplishes depends on the surrounding structure and on how a run arrives. A sequence of local transitions can read, compare, select, carry a result forward, or enter another process. A larger structure can combine these operations. In the owner's account, there is no categorical division by which a neuron may represent a word but cannot represent a compiler, a memory operation, or a tool. Each must be realized as an appropriate arrangement of the same computational medium.

This does not mean that naming a location after an operation makes the operation exist. A location called search acquires no searching ability from its label. The structure reached from that location must perform the relevant matching, progression, selection, and return. The owner's repeated objection to external Python helpers is directed at precisely this gap. A graph can appear to perform a task while an outside routine supplies the decisive work. Such a demonstration may produce the desired output while failing to investigate the proposed architecture.

The objection is ultimately about ownership of behavior, rather than the spelling of a programming language. Later owner prose explicitly extends it to shell scripts. Replacing a Python helper with a shell helper does not transfer the capability into Neuron. Conversely, the existence of an external workbench used by researchers to inspect evidence or prepare a lesson does not establish that the brain itself depends on that workbench for the cognitive operation being claimed. The boundary must be understood in terms of what chooses and performs the work.

The project acknowledges a developmental difficulty here. A young structure cannot already contain every capability required to construct its mature form. Early support may supply teaching, storage access, and execution machinery. The intended direction is for learned or taught graph procedures to assume increasing responsibility. The owner's stronger hypothesis is that much of what initially appears to require external structural machinery may later be expressed through Neuron's own code. That is a bootstrapping ambition whose extent must be demonstrated.

A useful way to state the thesis is that the machine's operative organization should be inspectable in the graph. If a decision changes because the system learned something, the relevant changed relationship, procedure, or selection condition should exist there. If a procedure is reused, the reusable structure should exist there. If a process can revise another process, the revising capability should have an executable account within the same medium. This makes the location of capability a central experimental question.

The word graph should consequently evoke more than a diagram of concepts. It denotes the realized portion of an active mathematical organization. Relationships constrain identity, and traversals realize behavior. Learning alters that organization. Memory makes previous organization and previous activity available to later activity. The proposed unity is structural: the machine knows through arrangements that also determine what it can do. [S02, S05, S07, S20, S23]

## 3. Mathematical identity, location, and relationship

Neuron assigns a foundational role to mathematical identity. The early registration contract separates the identity of a result from the identifier used to store it. A database row number is a bookkeeping fact. A mathematical expression is intended to identify the location itself. This distinction prevents the architecture from becoming a collection of arbitrary identifiers with mathematical descriptions attached afterward.

The original example concerns a fraction. A result such as one half can exist as a terminal location even when no further applicable relationship is known. Later learning may establish that several expressions arrive at that same mathematical result. The expressions that produced it remain significant because they preserve different derivations. Convergence therefore does not require erasing the routes by which convergence was reached.

The later V16 prose develops the idea into a space of expression locations. Expressions such as X, a reciprocal of X, or an offset involving another variable illustrate distinct structural identities. Their role is not necessarily to demand numerical evaluation during every act of use. An expression can identify a destination and the relations by which it is reached. The graph becomes the materialized part of a mathematical organization that the learner has so far established.

Relationships constrain where a new location belongs. The owner's recurring image is triangulation: one known relationship provides a partial constraint; additional relationships restrict the possibilities further. A concept that participates in several families must fit the combined structure. Learning more about a concept can therefore refine its placement. An early placement may be useful and provisional, while later evidence requires movement or a change in the relation that placed it.

The word triangulation is an analogy for converging constraints. It should not be read as a declaration that all meanings occupy literal points in ordinary three-dimensional space. The owner also describes many planes and levels, using spatial imagery to communicate interconnection. The research obligation is to determine what the dimensions and relations mean in the actual representation. A drawing in three dimensions would not by itself establish the semantic adequacy of that representation.

The most important interpretive correction is that the owner's equations are pseudocode unless explicitly established otherwise. A reciprocal used to illustrate an opposition does not commit the system to reciprocals as the universal mathematics of opposition. A power used to illustrate emphasis does not establish exponentiation as the semantics of an exclamation mark. The examples communicate transformations and relationships whose mathematical realization remains part of the research.

This distinction preserves both the clarity and the openness of the project. The owner is asserting that there is an organized process to discover, not supplying a completed table of equations for every word. Assistant-produced candidate formulas in the archive are hypotheses of a different kind: they propose particular implementations that can be checked. Their algebraic consistency must not be confused with evidence that they correctly represent language or cognition.

Mathematical convergence also creates a practical question. Two routes may legitimately reach the same identity, but accidental collisions can merge things that need to remain distinct. The archive records concerns about apparently different roles sharing a formula or a gate. Such cases are informative because they expose the difference between obtaining a consistent expression and obtaining a useful cognitive distinction. A mature system must preserve the distinctions required by its learned relationships and contexts.

The thesis thus combines exactness with revisability. A realized location should have a definite identity under the representation in use. The interpretation and placement that produced it can still be corrected. Exact structure is not a declaration of infallible knowledge; it is what makes the consequences of a proposed understanding concrete enough to inspect, reuse, and revise. [S01, S02, S03, S06, S10]

## 4. DNA, arrival, and the structure of a run

The project's term DNA refers to local executable relationships and continuations associated with a neuron. It is an architectural metaphor, not a claim that the machine reproduces molecular biology. A shard of DNA records how a relevant arrival can proceed: what relationship or operation applies, where the next step leads, and what work remains. The neuron is a location; its local structure makes that location participate in different processes.

Arrival is essential because a destination alone does not tell the whole story of a computation. Two runs can reach the same location with different histories, bindings, questions, or unfinished work. Their next useful steps may differ. The owner's examples repeatedly insist that how a run arrived helps determine which shard applies. The location is therefore not a context-free instruction that always emits the same next location.

A run is the organized activity that follows these relationships. At a simple level, it is a sequence of transitions. At a more developed level, it may enter a subrun, carry a result back, follow a conditional alternative, or compose several subordinate processes. The owner's later formulation makes the identification explicit: the runs are the formulas. A complicated formula can be a run whose parts are themselves formulas, including formulas that select which other formulas to use.

This gives a precise role to remaining work. A process can arrive at a point with one part completed and another part still unresolved. The continuation must preserve enough context to distinguish that state from other uses of the same point. The architecture must also preserve bindings when several branches use the same value or when an intermediate result becomes an input to a larger process. These requirements are consequences of the owner's process examples, even where the final implementation schema remains unsettled.

The original walkthrough of memory formation illustrates this continuity. An input traverses several gates through selected DNA. A receipt represents the route. The process then continues into memory, takes or associates a clock snapshot, records an occurrence on the timeline, and reaches output. The owner describes output as a mailbox observed by the decoder. The whole sequence is intended as work expressed through the brain, rather than a collection of after-the-fact operations secretly coordinated outside it.

It is useful to distinguish three things within this account. The location identifies where the activity is. The applicable DNA identifies how activity can proceed there. The receipt identifies what actually happened in a particular realized process. These distinctions permit a common destination to participate in several derivations without losing their differences. They also make later explanation and adaptation possible.

The exact definition of an arrival key, a receipt encoding, or a storage row is an implementation matter that changed during the project. This manuscript does not promote an early schema into permanent law. The stable principle is that executable continuations must be sensitive to the distinctions required by their processes, and the system must retain enough of the actual route to recover those distinctions later.

A neuronal run is therefore both an act and a potential object of future thought. It performs a process now, while leaving a structure that can later be recalled, compared, shortened, reopened, or revised. That double role is the connection between execution and experience on which much of the rest of the system depends. [S02, S04, S09, S11]

## 5. Birth, propagation, and the edge of knowledge

The system's development begins at the boundary of what has already been realized. A mathematical location can exist without a known continuation. The absence of further knowledge does not make the location invalid; it establishes the current limit of what the structure can do there. Learning changes that limit by supplying or discovering another applicable relationship.

Birth has more than one context in the records. A newly established mathematical result may require a new location. A completed receipt may require a memory location if that receipt is not already represented. A new occurrence of an existing process may require another historical record without requiring a new identity for the shared process. These should not be collapsed into a single undifferentiated instruction to create a neuron whenever something happens.

The owner's initial contract emphasizes propagation. A new mathematical capability may apply to previously realized structures. Applying it can produce new results, and those results can make older capabilities newly applicable. Development may consequently proceed through a succession of local consequences. A new lesson need not remain attached only to the one example through which it was introduced.

The later term back-population describes this application of newly available relationships to relevant existing structure. The important word is relevant. The owner repeatedly rejects a routine that applies every learned formula to every labeled gate. A relation about memory need not apply to every word; a relation about a class of forms need not apply to every process. Applicability is itself a substantive requirement, not an inconvenience to remove by scanning everything.

This creates a developmental picture in which knowledge grows along established connections. A new word should be taught through relations to what the system already knows. Where several relations converge, the placement becomes more constrained. The owner asks for learning at the edge because the edge provides contact between the unknown and the existing structure. Simply importing a vocabulary into arbitrary disconnected locations would not investigate that method of growth.

The archive also exposes a real limit to the idea. Mathematical possibility can be enormous or unbounded. A rule that applies again to its own output may generate an indefinitely extensible sequence. The original statement that propagation stops where learned mathematics no longer applies describes a desired natural boundary, but it is not a general termination theorem. The V16 discussions explicitly acknowledge unresolved fan-out: when should a mathematically possible destination be realized, and when should it remain a possibility?

The correct response is to retain that question within the thesis. Selectivity, applicability, evidence, and resource limits all matter, but a candidate policy must be identified as a policy rather than quietly attributed to the owner. The project's claim is that useful development can exploit the consequences of acquired structure. It does not establish that unconstrained closure over all conceivable relationships is desirable or feasible.

The edge of knowledge is also an epistemic boundary. A location can have a partial definition, uncertain placement, or a missing relation. Its incomplete state should remain available as such. The system is meant to grow through those incompletions, not conceal them with fabricated names or final answers. A well-represented unknown is already useful structure because it tells later learning where new evidence may matter. [S01, S02, S03, S06, S12]

## 6. Learning, execution, and the meaning of a shortcut

The owner's distinction between learning and execution is one of the project's organizing ideas. Learning performs the work required to establish a useful process. Execution uses the process once it exists. If every later use must rediscover the relationships that made the first use possible, the system has failed to capture much of the value of learning.

This distinction is expressed in the archive through long and short forms of a run. The long form exposes the internal steps by which a result is reached. A shortcut permits established work to be reused at a higher level. An input can be bound to a known process, a known relation can be followed, and a previously established subresult can be used without rederiving its justification on every occasion.

There are several kinds of reuse within this idea. Recalling an answer to the same stable question is one. Applying an established relationship to a suitable input is another. Executing a parameterized process with changed bindings is a third. They offer different savings and support different claims. A system that remembers a particular result has not thereby demonstrated a general procedure for all new inputs; a system that applies a supplied procedure has not thereby discovered that procedure.

The owner sometimes describes ordinary use as traversal without computation, or with very little computation. The strongest coherent reading is that familiar use avoids repeating the expensive work of discovery. Traversal, substitution, comparison, and memory access still perform work. The architectural hypothesis concerns how much work can be prepared and reused, and how little of the original derivation needs to be repeated. It should not be weakened into a claim that all computation vanishes.

The illustrative reduction of a very deep run to a small number of formula-level hops communicates this ambition. It is not a measured universal speedup. Whether a shortcut is useful depends on what it preserves, how its inputs are bound, whether the needed result is already available, and how expensive its supporting representation is. The thesis predicts opportunities for cheap familiar use; the actual scale of those opportunities requires measurement.

The long form remains essential because reuse is conditional. A process may have depended on an assumption that is now false, on evidence that has been withdrawn, or on a distinction that was previously ignored. If the shortcut becomes an opaque answer with no recoverable support, the system loses the material it needs for correction. The owner therefore retains both the established route and the ability to reopen it.

A shortcut's receipt must also represent the work that actually occurred. If a run used a stored result or a shorter process, its record should not falsely claim that the full derivation happened again. The supporting long route can remain linked as the basis for reuse. This preserves the distinction between present execution and historical justification.

The more ambitious form of reuse is developmental. A similar problem can be approached through an old process, with a useful internal choice changed and the remaining structure retained. This is not merely faster execution; it is a proposal for cheaper learning. The next new process begins from the organized consequences of prior experience. Neuron's shortcuts therefore serve both immediate efficiency and cumulative invention. [S05, S07, S08, S09, S11]

## 7. Receipts, memories, and the continuity of experience

A run receipt is the system's record of a realized process. In the owner's conception it is central to memory identity: the run becomes an expression or structured identity at which the experience can be retained. The receipt is not merely a human-readable log message stating that something succeeded. It represents the route through which something happened.

The original walkthrough connects a completed run to a memory neuron. If the corresponding memory identity is absent, it is created; if it is already present, a further occurrence can be associated with it. The process then enters the timeline with a clock-related record and continues toward output. The arithmetic used to illustrate this mechanism is pseudocode, but the functional distinctions are clear: content can recur, occurrences differ, and historical placement must remain recoverable.

A useful memory includes more than its final answer. To support the owner's proposed reasoning, it must make relevant inputs, conditions, choices, outcomes, and sources accessible. The system needs to ask not only whether something happened before, but what was done, whether it worked, and why the earlier case might apply now. If all that survives is the final output, much of the experience has been discarded.

The concept also broadens memory beyond autobiography. A dictionary entry can be a run whose receipt preserves the definition. A tool can be represented by the structure of its executable process. A learned relation can have a history of supporting and contradicting observations. In this architecture, knowledge and memory overlap because both are available through realized structure. Their roles still differ: a general procedure is not identical to every occasion on which it was used.

That distinction becomes especially important for repetition. A process may remain the same across many occurrences while the speaker, time, expectation, or outcome changes. Sharing the process does not justify merging those events into one event. Conversely, preserving distinct events does not require copying the entire procedure into each occurrence. The conceptual model makes room for shared structure and differentiated history.

Memory also carries the system's failures. A trial that did not work is valuable if the conditions and reason for failure remain accessible. The owner's recurring question is whether something now known might change the significance of an earlier failed attempt. This makes failed experience a potential starting point for later learning. The system should neither repeat it blindly nor exclude it forever without considering changed conditions.

A receipt can become an explanation when it supports a faithful account of how a result was reached. Yet explanation has two forms here. One traces the actual present run. Another explains the historical discovery or evidence that made an available shortcut trustworthy. Both may matter, and the system should be able to distinguish them. A shortcut can have a short execution history and a substantial supporting history.

The continuity Neuron seeks is consequently active continuity. Past experience remains connected to present choice through reusable, inspectable, revisable structure. A memory is something the machine can do work with: enter, compare, adapt, challenge, and use to select a next action. The project succeeds at this level only when the preserved experience changes later behavior in the intended way. [S04, S06, S07, S09, S16, S18]


## 8. Time, state, and the difference between knowing and having known

Time gives the system a way to distinguish an experience from its later interpretation. A relation may have been accepted yesterday and questioned today. A prediction may have been made before its outcome was available. A process may have failed under conditions that subsequently changed. Without temporal structure, these differences collapse into a collection of statements whose order and significance are difficult to recover.

The owner's emphasis on timeline is therefore more substantial than a demand for timestamps. A clock can label an event, but a useful history must connect the event to the state in which it occurred. What did the system know then? Which assumptions did it use? What was it trying to accomplish? What evidence became available afterward? These questions make time part of reasoning.

Consider the distinction between hearing a claim and observing the event described by the claim. In the owner's example, another person reports that a cat sat down. The listener may judge the statement plausible from previous experience and may have reasons to trust the speaker. Those are real grounds for a provisional belief. They are not the same event as directly observing the cat sit. The system must retain the source of its information rather than flatten all routes into a single undifferentiated fact.

The example is a conceptual model of evidence, not a claim that direct observation is infallible. Its importance is that different grounds can support different judgments and later revisions. If the report is contradicted, the system can investigate the report, its interpretation, or the speaker's reliability without erasing the fact that the report was received. What happened to the machine and what happened in the world are related records, not automatically identical records.

State also includes the conditions that make a familiar procedure applicable. An instruction can be appropriate under one goal and inappropriate under another. A remembered answer can be accurate for an earlier time and stale now. An earlier failure can be decisive under unchanged assumptions but less informative after a new capability has been acquired. Neuron is intended to use these distinctions when deciding whether to reuse or reopen a process.

A particularly important temporal relation connects a guess to its later evaluation. The guess must be preserved as a guess made with the evidence available at the time. A later confirmation should not rewrite the original event as certain knowledge. A later refutation should not erase the fact that the system had a reason to investigate it. The historical sequence explains how the machine learned.

This leads to a model of correction that preserves rather than destroys continuity. The old representation remains part of the system's history, while the operative structure changes. A new interpretation of an old event is itself a new event. The system can then distinguish what was believed, what changed, and what consequences followed from the change.

The archive does not supply a completed solution to storing every relevant state economically. A full snapshot of everything at every moment would be a different and much more expensive commitment than retaining the dependencies necessary to interpret an occurrence. The thesis establishes the need for recoverable historical distinctions; the storage design must determine how to preserve them without treating every event as a complete copy of the brain. [S04, S06, S08, S11, S18]

## 9. Meaning before a name

One of Neuron's most distinctive proposals is that the system can know something about a concept before knowing its word. Relationships may constrain a location whose external form has not been taught. The machine may know how that location differs from a known concept, resembles another, or participates in a familiar structure. A missing label is not necessarily a total absence of meaning.

The owner's challenge involving the word little clarifies this idea. A system was reported as producing the expected word after an inference. The owner asked how the decoder knew that word if the concept was supposedly unknown. If the label had already been supplied through teaching or encoding, printing it could not establish that the system had discovered a previously unknown word. The experiment had to distinguish relation inference, concept formation, and naming.

The intended alternative is more informative. The system can report that it does not know the word while describing the relationships that constrain the unnamed location. It can state a partial definition, identify what is inferred, and ask whether a proposed name or correction is appropriate. Success would lie in the supported structure of the description, not in the accidental production of a familiar string.

This makes definitions part of the working architecture. The owner rejects a bare grammatical label as an adequate definition. A full entry should contain enough information to distinguish senses, uses, relationships, and examples. The exact schema may vary by language and by the kind of thing being defined. The definition is itself represented as a run, and its receipt becomes accessible from the location.

The later requirement for an updatable Relationships section develops the idea further. As relationships reach a point, the definition should gain usable information about them. A definition is consequently not a fixed paragraph inserted once and forgotten. It is a growing account of what the system can currently establish about that location, with revisions that can be connected to their sources and circumstances.

This creates a reciprocal relation between definition and placement. Relationships help place a concept, while a definition helps determine whether a proposed placement makes sense. If a new mathematical route leads to a location whose known definition is incompatible with the proposed interpretation, that mismatch is evidence worth investigating. The system may have selected the wrong sense, proposed an unsuitable formula, or discovered that an earlier placement was inadequate.

Meaning must also remain sensitive to context. Several uses of one written word may require distinct internal treatment. Several external forms may express closely related or overlapping meanings. The archive's candidate mappings do not establish a universal rule that every spelling corresponds to one indivisible meaning. The demand for full definitions and sense-specific relationships points toward a richer organization.

The larger thesis is that understanding can grow through constraints before it becomes fluent naming. A machine that says an unknown expression occupies a certain relational role may know more than one that confidently prints a label supplied by a teacher. The appropriate test is whether the partially understood structure supports useful new distinctions and predictions, and whether later teaching can refine it without pretending that the name was known all along. [S10, S11, S12, S13, S15, S16]

## 10. Language as organized activity

Language enters Neuron through an encoder and leaves through a decoder. The owner's central boundary is that external words are forms associated with internal expression locations. The cognitive graph should not depend on English labels as the identities of its operations. A readable name helps humans communicate with and inspect the machine, but the internal work must follow the relationships represented there.

The encoder is also conceived as a sensor. It brings information about the occurrence of an input: who supplied it, when it arrived, and through what channel or circumstances it was obtained. That surrounding information matters because the same string can have different significance depending on its source, time, and purpose. Language without such context cannot carry the full situated meaning the owner intends.

The project treats the components of written expression broadly. Punctuation, grouping symbols, spacing or formatting actions where relevant, and special keys such as Enter are to have representations in the neuronal medium. The owner's objection to a tokenizer is a rejection of using an external semantic preparation stage to perform work attributed to the brain. It is an architectural requirement about how forms are represented and used, rather than a demonstrated solution to all segmentation problems.

A sentence then becomes an organized run through locations whose roles affect its composition. The distinction between a statement and a question cannot be reduced to noticing that both contain the same words. Their conditions of use and required continuations differ. A question may direct the system toward a missing value, a verification, a procedure, or a request for evidence. Grammar and punctuation help express these differences, but the actual operators remain to be discovered or taught.

The owner's illustrative equations for punctuation should be read at this level. An exponent can stand in the explanation for a transformation of an entire utterance. It is not a claim that exclamation literally means exponentiation. The research question concerns how an operation changes the interpretation and continuation of a run. Several kinds of mathematical structure may be needed to express those changes.

Tense adds another layer. A statement about what happened, a question about what is happening, and a plan for what should happen invoke different relations to time and evidence. A useful representation must preserve the event being discussed and its temporal role. Simply attaching a past-tense label to a present claim would not establish the required relation to remembered occurrences.

The later owner discussion of keywords provides a more focused hypothesis about interpretation. Words such as how, know, decide, and memory can help identify the kind of work requested and the part of the system likely to contain relevant processes. A conjunction may indicate multiple linked obligations. Negation may change what would count as a satisfying result. Such cues can route interpretation without requiring a search through every available reasoning procedure.

The proposal is not that one surface word always selects one fixed operation. Context and combinations matter. A question about how something was done may require historical recall, whereas a question about how something could be done may require constructing a procedure. The same visible cue can participate in different tasks. The owner explicitly returns to subject, predicate, context, and combinations of words when refining this hypothesis.

Language is thus treated as an entry into action. Understanding a sentence means identifying what process it calls for under the circumstances. The eventual output may be another sentence, but it can also be an investigation, a tool use, a plan, or a question that resolves a missing dependency. A mature answer is the result of organized activity, and the language used to express it should remain connected to that activity. [S02, S04, S07, S09, S11, S20]

## 11. Reasoning as the composition of processes

The owner's account of reasoning begins from a practical observation: a person does not usually approach a familiar problem by testing every possible explanation in an arbitrary order. Experience suggests what to examine first. A pattern in the present situation recalls an earlier case. That case supplies a possible process, a remembered outcome, and a set of questions whose answers may determine whether the process applies.

The air-conditioning example is especially useful because it makes reasoning concrete. The owner describes recognizing features of a malfunction, recalling comparable cases, selecting a relevant observation or measurement, and using the result to narrow or change the investigation. The value of the example lies in the organization of inquiry. It is not presented here as a repair procedure or as validation of the transcript's informal electrical arithmetic.

A larger problem can contain many unknowns, but they need not all be resolved at once. Some are accessible through observations. Others can be inferred once their dependencies are available. A result may become the input to another process. A surprising result may change the question entirely. The investigator can move from asking why a system does not work to asking why a particular component or relation behaves unexpectedly.

Neuron expresses this organization through formulas composed of other formulas. A parent process depends on subordinate results. Those results may require their own processes, and the choice of subordinate processes can itself be computed from context. The repeated word formula in the owner's prose covers several roles: a relation, a procedure, a test, a selection rule, and a composition of those elements. Later vocabulary work attempts to separate such roles without losing their common representation.

The analogy to an equation is useful because it identifies dependencies. A known relation plus sufficient known variables can determine a missing variable. More generally, knowing what would resolve the problem tells the system what it needs to establish next. Yet the proposed reasoning process is broader than substituting numbers into a fixed equation. It includes discovering which relation applies, deciding which variable can be obtained, and changing the frame when the evidence no longer fits.

The owner also emphasizes that a reasoning process can have a different shape in different cases. A short case may need only a few established steps. A difficult case may need several kinds of reasoning, nested investigations, or a comparison among alternative models. There is no requirement that every question traverse a universal fixed sequence. The content of the problem helps select the relevant composition.

Analogy is important because it supplies a starting structure across domains. The owner uses a familiar diagnostic process to explain a less familiar computational problem. The shared feature is a pattern of dependencies and tests, not the physical identity of the objects. A useful machine analogue would preserve the relation that transfers while checking the parts that do not.

This model also explains why reasoning and learning overlap. If the system already has a suitable process and all required information, it can execute. If some necessary relation or value is missing, it must investigate. A successful investigation can leave behind a new process or a revised relation. The answer to the present question becomes part of what makes the next related question easier.

The proposed unity is not established by declaring every mental activity to be a formula. It becomes meaningful when particular processes can be represented, selected, executed, compared with outcomes, and revised. The owner's prose supplies a coherent pattern for those operations. The research task is to show that the pattern can develop into useful, transferable behavior within Neuron itself. [S06, S08, S09, S20, S25]

## 12. Questions as instruments of thought

A question is an operation aimed at a gap. Its purpose is not exhausted by its grammar. It asks for information that would resolve a dependency, discriminate between alternatives, establish a cause, recover a method, or determine whether the system should act. In Neuron, the ability to choose a useful question is therefore part of the cognitive capability being sought.

The owner repeatedly asks how the brain knows what to ask. This is a deeper problem than generating a well-formed interrogative sentence. A machine can ask a fluent question that does not help. It can also possess a relevant fact while failing to recognize that the fact answers the current uncertainty. Question selection connects the present problem to the structure of knowledge and the means of obtaining more.

The diagnostic example illustrates the connection. A process requires an unknown property. The system may know an observation that would reveal it, or a relation that would infer it from other available properties. The useful next question depends on which route is available and how much the answer would change the investigation. In the owner's terms, there are formulas for obtaining variables and formulas for deciding which variables matter next.

The archive contains assistant hypotheses that assign special roles to question words, including distinctions between missing causes and missing routes. Those proposals are interpretations of particular monologues. They should not be elevated into a final psychology of why and how. The later owner prose adds more cues and emphasizes context, historical knowledge, and the task implied by a sentence.

An operational account should therefore distinguish the source of a question from its wording. A discrepancy between expected and observed outcomes may produce a causal question. A known goal with no known route may produce a procedural question. An uncertain report may produce a request for evidence. A conflict between two plausible interpretations may produce a discriminating question. These are explanatory categories for the thesis, not a claim that the archive implemented a complete classifier for them.

Questions can also address the system's own history. Have I tried this? Under what conditions? What happened? What did I know at the time? What has changed since? Such questions make memory useful to reasoning. Without them, the archive is merely available; with them, prior experience becomes a directed resource.

The owner expects the developing brain eventually to return questions that were not explicitly taught as the answers to particular prompts. A teacher should be able to see why the question follows from the student's state. This would provide evidence that the system is selecting its next information need, rather than reciting a lesson. The distinction is especially important when the teacher is itself capable of supplying sophisticated reasoning.

A question can thus be both an output and a continuation. It suspends one process while seeking what that process needs. The returned information must then enter the original context, alter the relevant state, and allow work to continue. Producing the question without this return path would leave the developmental loop incomplete.

The mature proposal treats inquiry as reusable structure. A successful way of resolving a kind of uncertainty becomes available for later cases. A poorly chosen question leaves evidence about why it failed to discriminate or advance the task. The system learns not only answers, but ways of becoming less ignorant about the questions it cannot yet answer. [S06, S08, S11, S20, S21]

## 13. Recursive adaptation and the recovery of alternatives

The owner's explanation of recursive shortcuts extends reuse into a method of invention. A remembered process may be close to what the present problem needs without being exactly suitable. Instead of beginning from nothing, the system can start with the old outcome and move backward through the receipt to a point where a different continuation might help.

At that point, the search is local. The owner explicitly rejects stepping backward once and then searching the entire corpus, repeating the same expensive search at each earlier step. The relevant alternatives are found in the structure associated with the reached location. More specifically, the October 1 explanation limits the comparison to DNA associated with the same completed arrival. Alternatives that arose under incompatible conditions are not interchangeable merely because they occupy the same neuron.

The comparison asks two questions. Does an alternative reach the desired outcome? If it does not, does it improve on the current outcome relative to that goal? A useful alternative can be followed and examined further. If the examined alternatives do not improve the result, the process can move farther back. A nested shortcut may itself be reopened, allowing a change within a subordinate process to affect the containing process.

This is the conceptual significance of retaining the long route. The route contains decisions that remain useful when the original final answer is no longer sufficient. A shortcut without recoverable internals saves time but offers little basis for this kind of adaptation. A shortcut with its supporting structure preserves a compressed working process and a path back into the choices from which it was made.

Several subtleties follow. A shard's immediate next destination is not necessarily the completed outcome of the continuation it begins. Comparing useful alternatives may require access to remembered outcomes or to a bounded way of evaluating them. Likewise, equal endpoint identities do not establish identical arrivals. The system needs the context and dependencies that make an alternative eligible.

The meaning of improvement is also task-dependent. A numerical distance can serve a small arithmetic experiment. It cannot automatically decide whether an explanation is more accurate, a plan more durable, or a question more useful. The owner's mind-map record includes qualities such as completeness, efficiency, durability, and energy. A real adaptation process must use criteria appropriate to its present goal.

The proposed method should not be mistaken for a proof that a sequence of locally improving steps always reaches a satisfactory solution. Some problems may require exploring an uncertain or temporarily worse route. Some may require changing the original frame. The owner's broader accounts include both missing-variable repair and moving into a different tree of interpretation. Exhausting the currently known alternatives shows a boundary of available knowledge, not the impossibility of any better approach.

An important later extension is to test the new process against other remembered cases. A change invented for the present problem may resolve a previous unknown or improve an earlier result. The system should ask where else the new relationship applies. This connects recursive adaptation to back-population: a local discovery can alter the possibilities available elsewhere without requiring a blind recomputation of everything.

The archive reports bounded early step-back demonstrations, but these should be read at their actual scope. They do not establish the full recursive method for arbitrary processes. The thesis lies in the larger continuity: old experience can supply the internal working material from which a new process is constructed. [S09, S11, S14, S23]

## 14. Recall, relevance, and the feeling pattern

Neuron's account of recall begins with a rejection of indiscriminate search. The owner does not imagine a brain considering every memory or every formula whenever it faces a problem. The present situation should provide structure that directs attention toward a much smaller relevant region. Remembering is an act of access organized by what is being recognized.

The first question is often whether the system has encountered a similar pattern. The pattern may concern a problem, a sequence of actions, an outcome, a relationship, or an experience. It need not be a match of literal words. Two situations in different domains can share a useful process, while two sentences with similar wording can require different processes.

The owner describes rejecting a candidate memory as soon as a decisive mismatch appears. This is a useful principle for inspecting candidates, but it is not a complete account of finding them. A system that rejects each memory quickly can still visit every memory. The approved scope records preserve this distinction: the pattern must help route the system to plausible candidates, and then the candidates can be examined efficiently.

The proposed access routes are multiple. A memory may be found through time, through a definition, through the outcome of a process, through a recurring problem, or through the relationships embodied in its receipt. These routes need not compete as exclusive accounts of memory. A process can enter through one cue and then inspect other features to determine whether the retrieved experience applies.

The owner's feeling-pattern explanation adds a particularly personal route. The account describes a composition of bodily and internal features rather than a simple category such as happy or sad. A situation has a recognizable overall pattern. That pattern can bring similar experiences into reach before a more deliberate examination of their procedures and outcomes.

The numerical feeling factor used in the monologue is pseudocode. It does not establish a scalar measurement of emotion, a known biological mechanism, or an implemented Neuron encoding. The essential point is the composition: after a candidate experience is reached, the system checks whether the pattern was produced in a relevant way. Two experiences that seem similar at first may differ in precisely the feature that matters now.

This distinction prevents feeling from becoming a substitute for evidence. The cue can guide access without determining the final answer. A recalled experience may provide a promising starting point, an irrelevant association, or a warning that the present problem has been framed badly. Its practical value depends on the subsequent comparison.

The owner's contrast between personal feeling-based access and another person's more chronological recollection also discourages a universal claim. The source is a report of how the owner experiences recall. For Neuron it supplies a research hypothesis about composed internal state as an index. The machine would need an explicit account of the represented features, their construction, their use in retrieval, and their correction through experience.

The larger architectural principle remains consistent with the rest of the thesis. Relevance should be learned and represented, not repeatedly supplied by an omniscient outside search routine. The route from a present problem to a useful memory is itself a capability. Neuron must eventually be able to acquire, use, and revise that route within its own structure. [S06, S08, S09, S11, S23]


## 15. Guessing, evidence, and revisable truth

The owner does not prohibit guessing. The objection is to losing the fact that a guess was made. A hypothesis can be essential to discovering a new relationship, choosing a trial, or proceeding under incomplete information. It becomes dangerous to the integrity of the system when later activity treats it as established knowledge merely because it has been stored or repeated.

Neuron is therefore intended to preserve uncertainty through use. A guessed relation should remain identifiable when recalled, when combined with other relations, and when it contributes to a new answer. The system must be able to distinguish what it knows from what it currently suspects. If a conclusion depends on an uncertain premise, that dependency matters even when the conclusion is expressed fluently.

The proposed record of a guess includes its origin and grounds. What suggested it? Which observations or relationships support it? Under what conditions is it expected to hold? What result would count against it? These questions convert a guess from a disposable utterance into an investigable object. They also let the system recognize when it is repeating an old hypothesis whose failure is already known.

Confirmation changes the standing of a hypothesis without changing its history. A relationship that began as a guess may become well supported within a particular scope. Its earlier uncertainty remains part of the record. Likewise, a once-useful relation may later require qualification or replacement. The system's current working view can change while preserving how that view developed.

The owner's account of truth is consequently operational and revisable. The machine can adopt a relationship because the available evidence supports using it. Adoption does not establish absolute certainty. A successful outcome supports a process under the observed conditions; broader use requires attention to the differences between those conditions and the present case.

The archive also warns against an overly rigid notion of wrongness. An answer can fail to match a predetermined expected string while revealing a valid alternative relation or a useful partial understanding. This does not make every unexpected output correct. It means the experiment must examine what the output actually demonstrates. A failure to match the teacher's preferred answer can be either a genuine error or evidence that the evaluation omitted a meaningful possibility.

There is a complementary danger in excessive flexibility. If every outcome can be redescribed as progress, the experiment becomes incapable of failing. Neuron's method needs criteria that permit both discovery of unexpected structure and rejection of unsupported claims. The process that produced an answer, its applicability, and its consequences help make that distinction.

Numerical confidence introduces another layer. A number attached to a guess can summarize support, frequency, a policy, or a learned prediction. These are different meanings. The later audit finds supplied scoring policies and support ratios in particular components; it does not establish a calibrated probability of correctness for the whole system. A confidence value must be interpreted through how it was produced.

The system must also avoid manufacturing evidence from its own repetitions. Hearing the same stored claim again is not an independent observation. Agreement with an existing belief does not by itself establish that belief's truth. A prediction needs to be compared with an outcome acquired through an appropriate channel, and the relationship between the evidence and the claim must remain visible.

The thesis's epistemic ambition is that uncertainty becomes part of the executable structure. It should affect whether a process is reused, whether an answer is qualified, whether another question is asked, and whether an adopted relation is reconsidered. A guess label printed once is an initial interface feature. Persistent uncertainty that changes later decisions is the deeper capability. [S06, S08, S11, S12, S19, S21]

## 16. Context, answer locations, and practical judgment

An answer location need not contain one final sentence. In the owner's model it can contain or lead to a process for finding an answer, together with memories of different answers that were appropriate in different circumstances. The identity of a question may remain recognizable while the useful response changes with time, state, and the person asking.

The shopping example makes this concrete. A request for a nearby store may be about speed, cost, quality, an immediate need, or a special occasion. A useful response depends on what the person intends, where they are, what is currently available, and which preferences or constraints are actually known. The owner's named people, places, and preferences are illustrations of that dependency, not facts to be inserted into the system as personal knowledge.

The sentence therefore identifies a problem whose solution must be situated. The machine may already know a relevant answer. It may know a method for obtaining current information. It may lack a crucial constraint and need to ask. It may possess an old answer whose freshness is uncertain. Each case calls for a different continuation.

This is where definitions, memory, timeline, and reasoning converge. Definitions help interpret what the request concerns. Memory supplies relevant prior interactions and procedures. Time helps judge whether remembered information remains useful. Reasoning selects what to do with these resources. The answer is a product of their coordinated use.

The owner's running example adds another dimension. A system that remembers previous conversations about an activity might notice relationships between enjoyment and circumstances. It might also remember that a potentially important concern was already raised and answered. A useful conversational continuation depends both on the present input and on the history of what has already been discussed.

The example illustrates adaptive selection rather than a script. The machine should not ask about the same concern indefinitely merely because it once appeared in a memory. It should retain whether the question was asked, what the answer was, and whether a later event changes its relevance. The ability to stop asking a resolved question is part of the same continuity that makes a good follow-up possible.

Context-sensitive behavior also requires restraint. A correlation in memory can suggest a question without establishing a fact about the present event. The machine might suspect that a circumstance contributed to an outcome, but it must distinguish that suspicion from something observed. Otherwise personalization becomes invention.

External interfaces fit naturally into this account. A map service, a calendar, a search engine, or a language model can provide information or perform a bounded task. The cognitive question is why the system selects that source, what it asks for, how it evaluates the result, and how the result changes the ongoing process. Merely connecting an external tool does not supply these capabilities.

The later owner prose explicitly allows a future arrangement in which Neuron chooses to consult a language model. This refines the earlier independence requirement. The issue is whether the external model secretly supplies every missing decision, or whether Neuron has acquired the process that recognizes a need, selects a tool, frames a request, and uses the result. An independent system can still use instruments.

Practical judgment is the desired outcome of this coordination. The response should fit the real problem and its conditions, not merely resemble an answer associated with similar wording. This is why the owner treats becoming better than a fancy chatbot as a developmental milestone rather than the final purpose of Neuron. [S04, S08, S11, S20]

## 17. The sixth sense and the possibility of epiphany

The sixth sense is the owner's name for the brain's own input. A system that acts only when an external prompt arrives remains dependent on an outside source to initiate every cognitive episode. The proposed next stage is for unresolved needs, discrepancies, remembered commitments, or new consequences of learning to generate activity from within the system.

This does not require inventing a mysterious source of intention. The records suggest concrete origins. An earlier question may remain unresolved. A newly learned relationship may conflict with an adopted belief. A result may fail to match what was expected. A time-related condition may become relevant. Each can create a reason for another process to begin, provided the system has represented the condition and learned or acquired a way to respond.

The owner's epiphany proposal is especially revealing. While working on one problem, the system may produce a formula or outcome that does not solve that problem but does fit another unresolved need. If the other need remains available in a suitable form, the result can be recognized as useful elsewhere. The apparent surprise is a connection between new work and an older open structure.

The machine would need more than a list of forgotten questions. Each unresolved task must retain enough information about its desired outcome and constraints to make later recognition possible. A new result must have a way to reach relevant unresolved tasks without requiring a perpetual scan of every problem ever encountered. The same locality requirement that governs recall and back-population applies here.

This proposal connects unexpected discovery to ordinary mechanisms. A formula developed in one context becomes available for comparison in another. A pattern supplies an access route. An outcome comparator determines whether the result is useful. A new occurrence records the connection. The significance of the result changes because the machine recognizes another problem to which it applies.

Self-generated input also raises questions of selection. Several unresolved needs can compete for attention. Some may be important but presently unanswerable; others may be easy but irrelevant. Repeating the same failed investigation indefinitely is not autonomous learning. The system needs a way to assess whether new information or a new process justifies another attempt.

Stopping is equally important. A process can finish, become blocked, exhaust its current useful alternatives, or yield to something more urgent. An autonomous loop that lacks these distinctions can consume resources without improving its knowledge. The owner's emphasis on progress, preserved failures, and changed conditions supplies the conceptual basis for a more selective form of persistence.

The archive contains work described as sixth-sense mechanisms and later audits of their connections. A switch being enabled is not sufficient evidence that meaningful autonomous work occurs. The relevant proof must trace an internally detected condition through selection, action, evidence gathering, and an effect on later behavior. Otherwise the system may contain dormant components or loops whose activity has little cognitive consequence.

The sixth sense therefore names a developmental transition rather than one feature flag. The system begins to organize its own unfinished business. Epiphany becomes one possible event within that organization: a new piece of structure unexpectedly satisfies an old need because the need was preserved in a form the machine could still use. [S08, S11, S12, S21, S23]

## 18. Sleep, consolidation, and local prediction

The later sleep proposal adds a distinct idea to the architecture. The owner asks whether a period of reduced outward activity could be used to update the parts of the system touched by recent experience. The analogy is to sleep and dreams, but the computational proposal is selective maintenance and learning over changed or recently used structure.

The owner's distinction between back-population and back-propagation matters. Back-population concerns applying newly available relationships to relevant existing structure. The later proposal uses back-propagation to suggest updating predictive weights in local models. These operations may interact, but they are not the same process merely because both revisit prior material.

The imagined predictive models are small and local. A tree, route, or related region could contain a model useful when established knowledge ends and a guess is required. The machine would activate that model for a targeted uncertainty rather than relying on one undifferentiated predictor for every task. Recent outcomes and changes in the region would inform its later adjustment.

The sleep period would focus on what was touched, changed, or invalidated. If a familiar process continued to work under unchanged conditions, there might be little reason to revise it. A changed relationship, a relocated concept, or a refuted expectation would create a stronger reason. This preserves the project's broader commitment to work directed by relevant structure.

The proposal is explicitly uncertain in the owner's source. The owner asks whether the idea would work and acknowledges not knowing enough about the internal organization of predictive models to settle the question. Claims in the monologue about human sleep, transformer activity, or energy use should be read as motivating analogies and conjectures. They are not experimental findings established by the Neuron record.

Attention, probability, and learning also need to remain distinct. A way to emphasize relevant inputs is not by itself a rule for improving a predictor from outcomes. A set of counts is not automatically a transformer. A numerical score is not automatically calibrated confidence. The archive's later audit makes this separation explicit because local predictive machinery can otherwise appear more developed than its actual update process.

The strongest part of the proposal is its integration with known uncertainty. A predictive continuation should announce the boundary between established knowledge and the guessed extension. The system should retain which local model produced the guess, what evidence it used, and how later outcomes affected it. The owner insists that the machine, other machines, and human readers all remain able to identify the output as a guess.

Dream-like internal trials would require a related distinction. A simulated outcome can help explore a hypothesis, but it is produced by the system's current model. It cannot be silently counted as independent evidence about the external world. Simulation may reveal inconsistency or a promising candidate; validation still depends on the kind of claim being made.

Selective consolidation also connects to memory economy. Repeated experience may support a compact reusable pattern while individual occurrences remain available at an appropriate level of detail. The exact balance between retention, summarization, and accessible history is unresolved. The concept of sleep supplies a possible time and mode for that work; it does not remove the need for a defensible retention policy.

Within the thesis, sleep represents a separation of immediate use from reflective maintenance. The machine can act using its present structure, then revisit recent experience to improve that structure. The proposed benefit is cumulative adaptation with bounded local work. Demonstrating that benefit requires outcome-based improvement, preserved uncertainty, and measured resource costs rather than resemblance to the vocabulary of biological sleep. [S18, S19, S21, S25]

## 19. Development and independence from the mother

The mother-to-student metaphor describes a dependency that is meant to change over time. Early in development, a teacher supplies experiences, lessons, corrections, and support. The student initially lacks many of the processes needed to learn effectively. The project's central concern is that this temporary arrangement can become permanent if every new difficulty is solved by adding intelligence to the surrounding machinery.

The early registration contract describes a deterministic mathematical teacher. It holds an ordered curriculum, receives the structure's returned state, and supplies the next small lesson. That contract is an important historical foundation, but it is not the entire later design. Subsequent records include language teaching, human instruction, assistant-authored graph procedures, and experiments aimed at more independent selection and learning.

Across these changes, the stable requirement is transfer of capability. A lesson can legitimately supply a process, but the claim must say that the process was supplied. A teacher can correct an error, but the student's later behavior must change in a way the student can retain and use. A worker can design a learning procedure, but the machine has not independently invented that procedure merely because it executes it.

The owner describes an early ask-then-show teaching pattern. The learner is first given an opportunity to expose what it can do at the edge of its knowledge. The teacher then provides a name, definition, example, or correction. Further questions can test whether relationships beyond the exact taught line are available. This method is intended to keep the teaching intervention distinguishable from what the learner subsequently derives.

Definitions are particularly important during this stage. A word introduced without usable meaning can improve surface vocabulary while leaving interpretation shallow. A definition provides relations and distinctions that later processes can use. Yet even a rich teacher-supplied definition is supplied knowledge. Its existence does not prove that the student can infer comparable definitions on its own.

The developmental criterion becomes more demanding as the system grows. Can it select a relevant process without the teacher naming it? Can it form a question that exposes a useful missing variable? Can it apply a newly acquired relation to a case withheld during teaching? Can it discover that a previously successful procedure no longer applies? Each is a concrete way to examine whether responsibility has moved inward.

Disconnection is a powerful test of that transfer. If the claimed capability stops working when the corresponding external helper is disabled, the capability may still belong to the helper. The test must be specific: removing all sensory input or all physical execution would be a different intervention. What matters is whether the external source of the claimed cognitive decision remains necessary.

The later possibility of consulting a language model is consistent with this distinction. A mature student can ask an external source for information while owning the decision to ask and the process for evaluating the answer. The teacher's disappearance as an indispensable internal decision-maker does not require the disappearance of every external tool.

Development also requires continuity of the living structure. The owner repeatedly asks for additive work, retained experience, and experiments on copies before changes are integrated. A succession of clean demonstrations in freshly reset systems cannot substitute for showing that a persistent learner continues to work as it acquires and revises knowledge. Accumulated state is part of the object being studied.

The ultimate aspiration is that the system acquires enough learning capability to participate in its own further development. This is stronger than executing stored procedures and stronger than selecting among them. It asks whether experience can improve the processes that turn further experience into capability. The archive supplies steps toward that question and many warnings about falsely claiming to have answered it. [S01, S06, S08, S11, S20, S21]

## 20. A computer built in its own language

The owner frequently describes Neuron as its own computer. This characterization follows from the breadth of the graph-as-code claim. If the structure can express reading, comparison, selection, writing, composition, and continuation, then tools can be built from those operations. More complex processes can be built from the tools, and procedures for constructing processes can themselves become part of the structure.

The examples of grep, cat, and sed are best understood as descriptions of work. The request is not to store the name of an existing utility at a node and then invoke an external implementation. It is to determine what the operation does and realize that behavior through neuronal runs. Finding a match, returning stored content, or replacing a selected structure are different operations that require actual executable organization.

The same principle applies when a needed capability appears to be missing from the primitive vocabulary. The owner's standard fix is to ask what the proposed external helper would actually do, identify the simpler operations it needs, and build the missing behavior in Neuron code where possible. The obstacle becomes an opportunity to expand the system's own code base.

This method requires careful separation between irreducible substrate operations and higher-level procedures. Merely declaring a complicated behavior to be primitive can hide the same external intelligence under a new name. Conversely, refusing every generic execution primitive would make it impossible to describe a physical implementation at all. The substantive question is whether the primitive boundary is explicit and whether the claimed reasoning, selection, and learning reside above it in the graph.

Compilation is a natural long-term consequence of the proposal. A process that constructs another executable process can make the graph increasingly capable of extending itself. The output of one run may become the structure through which a later run proceeds. A correction can alter a procedure rather than merely annotate it. This is the point at which the distinction between stored knowledge and program construction becomes especially thin.

The thesis does not assume that a graph capable of some arithmetic has thereby demonstrated a general compiler or universal computation. Such claims require particular expressive mechanisms and evidence. The archive includes supplied arithmetic and NAND-based programs, but their existence establishes only the capabilities actually demonstrated. The broader computer remains an architectural destination.

The mathematical repertoire contemplated by the project is correspondingly broad. An owner request to expand a narrow search space led to an assistant catalog of 73 candidate families. It ranged across algebraic transformations, symbolic composition, constraints, uncertainty, causal reasoning, language structure, memory, inquiry, and program verification. The catalog matters as evidence that the project was seeking reusable mathematical ingredients rather than one universal operator assigned to every relationship. It does not establish that those ingredients were installed or that their proposed Neuron applications were correct. [S22]

Several jobs must remain distinct within that repertoire. A mathematical form used to locate a concept has a different role from a procedure used to search for an applicable relation, and both differ from a method used to assess evidence for the relation. All might be represented in the same medium without becoming interchangeable. The unified architecture needs these distinctions precisely because it asks the same medium to perform many kinds of work.

The project's evolving vocabulary also matters here. Words such as read, copy, infer, learn, and understand can conceal several distinct operations. A worker may believe it has implemented learning when it has implemented storage, or believe it has implemented understanding when it has selected a canned response. The later cognitive vocabulary attempts to assign explicit meanings, operands, and evidence requirements to such operations.

That glossary is assistant-authored and is not itself executable Neuron code. Its value is methodological: it gives people a more precise way to describe what a process must accomplish. It helps prevent a broad label from standing in for missing behavior. The machine still needs the corresponding executable structure.

A mature Neuron language would therefore need two kinds of clarity. Internally, its structures must have definite operational consequences. Externally, its explanations must distinguish what was received, stored, inferred, predicted, tested, and changed. The first makes the machine run. The second makes its development intelligible enough to evaluate.

The proposed computer is unusual in its ambition to unify these layers through experience. Programs are not only artifacts written by a developer; they are intended to become retained products of learning. Their use leaves receipts, their failures supply evidence, and their internal decisions remain available for adaptation. The machine's code base would be a growing history of things it has learned how to do. [S02, S05, S07, S08, S23, S25]

## 21. Memory economy and the physical cost of the thesis

The promise of inexpensive familiar execution depends on how experience is represented physically. A mathematical identity does not guarantee a compact encoding, and a short conceptual route does not guarantee cheap storage access. The system must preserve the structure required by its theory without expanding every reused process into a fresh copy of all its internals.

The archive contains a concrete storage diagnosis that illustrates the issue. An October 3 report attributed most of the measured database allocation to gate expressions and their unique index. Receipt representations embedded child expression text recursively. The report identified a particularly large receipt whose expanded expression occupied more than a megabyte even though its immediate child references were much smaller.

The significance is structural amplification. If several parent receipts each embed the same large child expression, sharing exists conceptually but is defeated by serialization. Repetition then increases storage far beyond the amount of genuinely new experience. The proposed repair was to retain shared child references while preserving exact identity and reconstructability.

The small size of immediate references does not mean that the whole memory can be represented in those few bytes. The referenced children still require storage, as do the rules and data needed to interpret them. The valid saving comes from storing shared structure once and referring to it, not from pretending the supporting structure has disappeared.

Exact identity must also survive compact representation. A short fingerprint can help locate candidates, but an accidental collision must not merge distinct receipts. The thesis requires recoverable distinctions between processes, arrivals, and outcomes. Compression that destroys those distinctions may improve a size metric while weakening the cognitive model.

A second issue is the distinction between representation and retention. Sharing repeated structure solves one kind of waste. Deciding how long to retain an occurrence solves another. The owner asks about working memory, recent memory, and compressed accessible long-term memory. These categories suggest different access and detail requirements, but the archive presents their mature policy as unfinished.

Common symbols expose the difficulty sharply. If every use of a period produces a full independent memory directly under the period neuron, that location can become an enormous historical bottleneck. The owner explicitly raises this problem. The requirement that punctuation have a representation does not imply that every occurrence must duplicate every associated sentence in one local collection.

Back-population and shortcut invalidation add update costs. A newly corrected relationship may affect many dependent processes. Selective propagation must find the affected region and preserve enough dependency information to avoid stale reuse. This costs storage and work, but omitting it would make the shortcut unreliable when the knowledge on which it depends changes.

The same accounting applies to local predictive models and internally generated work. Many small models can still become a large total system. A collection of unresolved tasks can still consume unbounded resources if nothing retires, consolidates, or becomes dormant. Locality is a design principle whose aggregate consequences must be measured.

The strongest performance claim available at the conceptual level is therefore conditional. Neuron may make frequently reused processes inexpensive by preparing structure during learning and preserving efficient access routes. The benefit depends on reuse, representation, locality, validity maintenance, and the cost of updates. The owner's numerical visions of enormous neuronal populations and very low energy remain aspirations rather than measured properties.

This does not reduce memory economy to an implementation detail. It is part of the thesis itself. Experience becomes a useful computational resource only if the machine can retain, reach, and revise it at a cost compatible with continued development. A system that grows incapable of using its own history has lost the continuity it was designed to obtain. [S03, S07, S11, S18, S19, S21]


## 22. What the experimental record establishes

The Cortex record documents a research trajectory rather than one stable completed machine. It contains early registration contracts, architecture discussions, owner corrections, implementation reports, audits, and staged work awaiting integration. Reading these as if they all describe one simultaneously verified state would produce a misleading account. Their dates and the kinds of claims they make are essential.

The September 24 registration establishes the initial mathematical experiment and its authority. It identifies exact V1 evidence and separates mathematical gate identity from storage identity as an early implementation target. Registration itself does not implement the proposed organism. The source expressly marks the first implementation task as pending. Its value to the thesis is the clear statement of identity, retained derivations, and propagation through applicable learned mathematics.

The September 29 V16 material develops the graph-as-math architecture and includes the owner's governing spoken explanation. It records the attempt to locate related forms through mathematical relationships, and it raises collisions and disconnected islands as practical difficulties. The owner's instruction requires new teaching to connect to known structure. These records support the account of the design problem; they do not prove that a chosen set of candidate formulas constitutes a general semantics.

The September 30 and October 1 reports contain bounded demonstrations involving vocabulary, relationships, definitions, and supplied graph programs. The October 2 scope lists several earlier results, including successful probes, guesses about relationships among known words, and arithmetic through supplied NAND-based procedures. The same scope insists that such claims be reexamined under the owner's test for prior exposure. The correct reading preserves both the observed usefulness and the narrower category of achievement.

The little incident is the clearest example. A later audit reports a chronology in which a location and derived grammatical information preceded the label, while the label and explicit definition were taught before the disputed later response. The audit identifies events reported as 287, 589, and 1256, while carefully stating that these were assertions read from archived reports rather than newly verified database events. The defensible claim is a bounded relation inference and confirmation, not the later discovery of an entirely unknown word.

The distinction does not make the experiment worthless. A system can infer a new relationship among known concepts, and that can be a meaningful capability. The error lies in expanding the description beyond the evidence. Neuron's own theory demands that naming, definition, relation inference, and concept formation be separated. Its evaluation must observe the same distinctions.

By October 2, a report describes a full teacher-supplied definition of coolness represented through graph runs, with a current receipt and a link to a previous version. The bounded definition work was reported as merged. The associated relationship-history mechanism was reported as verified on a sandbox but not yet merged in that record. Its functions included retaining status and evidence, preserving history, and identifying changed or missing relationships as stale. Those results illustrate workable pieces of the larger architecture while preserving a crucial deployment boundary.

The same date includes a comparator and early step-back work. The report gives copy tests for numerical comparison and examples of selecting one- and two-step relation alternatives. It also identifies missing access to the route information required for the fuller design. These are concrete advances in executable graph procedures. They are not evidence that recursive adaptation over arbitrary remembered reasoning had been completed.

The memory-size audit of October 3 supplies a different kind of result: a diagnosis of a representation that undermined sharing. It reports measured allocation and recursively expanded receipt text, then proposes a lossless reference-based representation experiment. The diagnosis is evidence of a real engineering constraint. The proposed repair is not a completed result merely because its rationale is convincing.

The October 4 local-prediction and sleep record is an owner hypothesis deliberately preserved for future work. The page explicitly says nothing had been built from that proposal at the time. Its inclusion in the thesis is warranted because it extends the intended system, but it must not be represented as an implemented transformer architecture.

The October 6 reasoning discussion shows that the owner still regarded the system as insufficiently independent. The complaint is that it largely repeats supplied material and does not yet return the self-directed questions and reasons that would demonstrate the desired progress. The proposed experiment holds context constant, changes candidate reasoning structures, and records whether the behavior improves. It is a renewed research direction, not a report of general reasoning already obtained.

The October 7 learning audit is particularly useful because it separates graph residence from a complete learning cycle. It reports graph-resident configuration and executable bodies, bounded procedural adaptation, supplied scoring policies, and disconnected or incomplete producer-to-consumer paths. It finds no inspected end-to-end evidence for sustained autonomous general learning. That is a scoped audit conclusion, not a proof that no uninspected component could work.

The audit also identifies why seemingly promising components can fail to add up. An adopted belief may not be available in the representation consumed by another reasoning path. A learner may have no reachable source of new observations. A question-selection API may exist without being connected to ordinary input. A configuration may be mutable without any outcome-driven process updating it. Such failures are failures of the developmental cycle, even when the individual routines execute without faults.

The latest project page retrieved through the wake record is dated October 11. It reports question-shape and contract-row work proven on fresh snapshots and staged for an observer's integration process. It describes replay results and specific limits, including further work on contracts, pronouns, and answer forms. The record is evidence of staged bounded progress. It does not establish that those changes were subsequently landed or that the system was live in the same state on October 15.

The resulting conclusion is neither total absence of achievement nor completion of the thesis. The archive contains substantial conceptual development and reported bounded capabilities. It also records repeated overstatement, external ownership of important behavior, integration gaps, and unresolved learning mechanisms. The central autonomous cycle remains the decisive object of research. A faithful thesis must preserve the work already done while refusing to use it as evidence for capabilities it did not demonstrate. [S01, S02, S11, S13, S15, S16, S18, S19, S20, S21, S23, S24]

## 23. The research method implied by the system

Neuron's theory implies a demanding experimental method because the same output can be produced by very different mechanisms. A student may recall a taught answer, execute a supplied rule, compose known relations, or discover a new relation. An external teacher may supply the decisive step while the graph records the result. Evaluation must identify which of these actually occurred.

The first requirement is an inventory of what was supplied before the test. Relevant vocabulary, decoder mappings, definitions, procedures, examples, and prior observations all matter. Without that inventory, a new-looking answer can be mistaken for new knowledge. The little incident demonstrates why the source of the answer must be traced across every route by which it could have entered.

The second requirement is to define the desired behavior before implementing the demonstration. A test that merely checks whether code follows its own design can establish consistency with that design while saying little about the owner's intended outcome. The experiment needs a concrete problem, observable consequences, and conditions under which the candidate explanation would fail.

The third requirement is to use the real boundary through which the capability is supposed to operate. If ordinary input cannot reach a learner, an internal API demonstration does not establish ordinary learning. If a question is generated but its answer does not return to the process that needed it, the inquiry loop is incomplete. End-to-end evidence matters because the thesis concerns coordinated development, not a museum of individually functioning components.

The owner's copy-first method protects the accumulated structure while making changes reviewable. A fresh copy preserves the starting state. The intervention can be recorded, the resulting behavior observed, and the tested change integrated without replacing intervening work in the living system. This is an experimental discipline as well as a practical response to the value of persistent experience.

Useful comparisons isolate what learning contributes. A system with adaptation enabled can be compared with an otherwise identical system whose learned state remains fixed, and with one that only recalls prior cases. New combinations, changed conditions, and later contradictions can expose whether the system has acquired a transferable process. These comparisons are proposals from the audit, not experiments performed for this manuscript.

Mechanistic evidence must accompany performance. A successful response is more convincing when the receipt shows which graph structures selected and performed the work, what external help remained, and what changed afterward. A system that changes an internal parameter should show how the change follows from relevant evidence and how it affects a later case. Mutability alone is not learning.

Resource measures are also part of the test. Preparation time, execution work, memory growth, update cost, and the extent of structure visited should be measured separately. An apparently fast answer can depend on an expensive earlier sweep; a compact immediate output can leave a large persistent expansion. The owner's claims about shortcuts and locality require accounting across the whole process.

Generalization should be described at the level actually tested. A relation inferred across known words is different from a nameless concept inferred before labeling. A procedure that survives a restart is different from one that survives removal of its external decision-maker. A successful local repair is different from general self-revision. Precise categories allow progress to accumulate without turning every result into a claim about complete cognition.

Finally, the research method must remain corrigible. An unexpected answer may expose a faulty test, an overlooked sense, or a useful new relation. A passing result may expose hidden teaching when examined more carefully. The point of the record is to preserve enough evidence that these interpretations can change. Neuron asks the machine to learn from its history; the research program must do the same. [S10, S11, S13, S15, S21, S25]

## 24. Conclusion: the proposed unity of knowledge and action

The deepest claim in Neuron is that knowledge can become the organization of action. An experience is not only stored as content that a separate intelligence must later interpret. It leaves relations, routes, conditions, and outcomes that can participate in future computation. A learned process becomes something the system can enter and use. A failed process becomes something it can examine. A corrected relation becomes a change in what later runs can do.

This gives the project a coherent account of familiarity. A familiar problem is one for which the machine has already acquired relevant structure. The work of learning has left behind a usable route, a known relation, or a parameterized process. Familiar execution can be cheap because the system does not need to rediscover everything that made the process possible.

It also gives the project an account of novelty. A new problem need not be wholly unlike every earlier problem. It may differ at one decision, one missing relation, one condition, or one assumption. The retained derivation makes those differences accessible. Recursive adaptation proposes that the machine can reopen the relevant part while preserving the work that still applies.

Memory, in this view, is the bridge between the two. It preserves the experience from which familiar processes were formed and the internal structure from which unfamiliar processes may be constructed. Timeline and state make that bridge historically meaningful. They distinguish what was known from what was learned later, what was predicted from what was observed, and what happened once from what can be expected again.

Language connects the system to people and to recorded knowledge, but its role is broader than producing text. An utterance points toward work. A definition supplies constraints. A question seeks a missing dependency. A response can express the outcome of an investigation or begin another one. The machine's understanding is to be judged by the processes these forms reliably engage.

Uncertainty is equally structural. A guess must remain a guess wherever it is used until evidence changes its standing. A known relation must retain its scope. A disagreement must remain available for investigation. This makes trustworthiness part of the learning mechanism rather than a decorative qualification added to the final sentence.

The sixth sense extends the architecture from responding to organizing its own unfinished work. A preserved unknown can become a reason to act when new evidence or a new process appears. Epiphany is then a possible relation between current activity and an earlier need. Sleep and local prediction add a proposed mode for consolidating recent experience and preparing explicitly uncertain continuations.

The mother-to-student transition unifies the developmental ambition. At first, the environment supplies much of the work. Over time, the student's structure should take responsibility for selection, execution, inquiry, evaluation, and revision. The decisive question is whether this transfer actually happens. Adding capability to the surrounding teacher can make the demonstration more impressive while leaving the student unchanged.

The archive's failures illuminate this criterion. Supplied answers mistaken for discoveries, outside helpers mistaken for graph-owned cognition, and isolated components mistaken for a closed learning cycle all obscure the location of capability. The owner's repeated corrections insist that the machine's own structure must carry the explanatory burden.

The research record does not yet establish the strongest vision. It does not prove that Neuron reproduces the human brain, possesses subjective experience, or will achieve the anticipated scale and efficiency. Those ambitions cannot be settled by the simplicity of the verbal model or by the owner's confidence in it. They require mechanisms and observations that remain open.

What the record does preserve is a substantive architectural thesis. A cognitive system is proposed as a persistent, developing organization in which relationships locate knowledge, runs perform work, receipts preserve experience, and later processes transform that experience into further capability. The distinctiveness lies in the intended integration: memory is recoverable computation; code is reusable experience; inquiry is a process the system can acquire; and learning changes the structures through which learning itself proceeds.

The central experiment can therefore be stated without reducing the project to a chatbot or inflating it into a completed brain. An experience enters the system. The system interprets it through its existing structure, identifies or investigates what is missing, and changes that structure on the basis of an outcome. The change persists. When a relevant new situation arrives, the system acts differently for reasons recoverable in its own history. Eventually, it should also recognize when to begin that cycle itself.

If that cycle becomes reliable, transferable, and increasingly independent, the thesis gains substance. Its significance would be the conversion of experience into an enduring capacity to act, question, and revise. That is the Neuron system the owner's prose describes, and that is the standard by which its realization should be understood. [S02, S04, S06, S08, S09, S11, S19, S20, S21, S23]

## Appendix A. A reference lexicon

The definitions below summarize usage in this manuscript. They are editorial explanations of the source material, not new primitive instructions, a ratified storage schema, or a replacement for the project's versioned vocabulary.

### Neuron and gate

A neuron is a realized location in the mathematical structure. Gate emphasizes its identity as a place a run can enter. A storage identifier may refer to the neuron without being its mathematical identity. What happens there depends on its executable relationships and the arriving process.

### Expression and formula

An expression can identify a location or represent a composed result. Formula has broader use in the owner's prose: it can describe a relationship, a process, a test, a selection method, or a composition of other formulas. The intended work should be specified whenever the broad word risks concealing an unresolved operation.

### Relationship and placement

A relationship constrains how locations are connected or transformed under stated conditions. Placement is the assignment or discovery of a location consistent with relevant relationships. Placement can be provisional and later revised. A convenient algebraic fit does not by itself validate a semantic relationship.

### DNA and shard

DNA denotes local executable relationships and continuation structure. A shard is an individually selectable part of that structure. The metaphor communicates locally retained operational information; it does not assert a molecular implementation.

### Arrival and remainder

Arrival is the relevant state and path context by which a run reaches a location. Remainder is the still-pending portion of the work. Their exact encodings are implementation questions. Their conceptual purpose is to prevent distinct uses of the same location from being treated as identical.

### Run and receipt

A run is an execution through neuronal structure. A receipt preserves the realized process in a form that supports identity, recall, and further use. A receipt of a shortcut should record the shortcut actually used while retaining access to its supporting derivation.

### Memory and occurrence

Memory is retained experience or content accessible through the system's structure. An occurrence is a particular happening in time. Several occurrences can share a process or receipt identity while differing in source, conditions, expectations, or outcomes.

### Timeline and state

Timeline organizes occurrences and their temporal relations. State is the relevant configuration of knowledge, assumptions, ongoing work, and circumstances at a time. A timestamp alone does not capture all the state required to interpret an event.

### Definition and Relationships section

A definition is usable descriptive structure associated with a location, potentially including senses, examples, grammatical roles, and other distinctions. The Relationships section is the owner's requirement that definitions gain an updatable account of relations arriving at the location. Provenance and revision fields discussed in the archive include assistant proposals and bounded implementations.

### Nameless concept

A nameless concept is an unnamed but relationally constrained location. Its partial meaning can be investigated before a surface word is taught. The ability to output an already supplied word does not by itself demonstrate this capability.

### Back-population

Back-population applies newly available relationships or corrections to relevant preexisting structure. Its scope is determined by applicability and dependencies. It is distinct from an indiscriminate full-corpus sweep and from the later proposal for updating predictive weights.

### Shortcut and long route

A shortcut reuses established work without repeating all of its internal derivation. The long route preserves the working structure and support that make correction and adaptation possible. Both are part of the intended architecture.

### Step-back and recursive adaptation

Step-back follows a retained process toward earlier choices and examines eligible local alternatives. Recursive adaptation can reopen a nested process, alter a useful decision, and return the new result to the containing process. The owner's examples do not establish that local improvement alone guarantees a solution.

### Pattern and feeling pattern

A pattern is a relevant organization of relations, features, or processes that can guide access and comparison. A feeling pattern is the owner's proposed composite of bodily and internal features used as an initial memory cue. Its numerical examples are illustrative; no fixed encoding is assumed here.

### Question and answer location

A question seeks information required by an ongoing or proposed process. An answer location may contain an available answer, several context-dependent possibilities, or a process for obtaining what is needed. The question's wording and the operation it serves must remain distinguishable.

### Guess and adopted belief

A guess is a proposed continuation, relation, explanation, or result whose uncertainty is retained. An adopted belief is something the system currently accepts for use within a scope. Adoption does not erase provenance or establish absolute truth.

### Progress and outcome

An outcome is a result or effect of a process. Progress is improvement relative to a goal and its constraints. Speed, confidence, reduced uncertainty, and familiar-looking output are not automatically equivalent to progress.

### Sixth sense and epiphany

The sixth sense is internally generated input or task initiation. Epiphany is the proposed recognition that a new result or process satisfies another preserved unresolved need. Both require mechanisms for relevance, selection, and stopping.

### Sleep and local predictor

Sleep names a proposed mode of selective consolidation and revision over recently used or changed structure. A local predictor is a bounded model associated with a relevant region and used to produce an explicitly identified guess. These are proposals in the recovered owner text, not evidence of a completed sleeping or dreaming organism.

### Mother, teacher, and student

Mother names the developmental support outside the learner. Teacher names the source of lessons or feedback. Student names the developing neuronal system. The intended transition is increasing ownership of cognitive processes by the student, while allowing legitimate sensory input and tool use.

### Cortex and brain

Cortex is the persistent project-memory and evidence system used to recover the material for this thesis. Brain refers to the experimental Neuron structure. Historical use of the filename cortex.db for a brain database does not make the two systems identical.

## Appendix B. Source register and interpretive boundaries

### How to retrieve the sources

Each source label identifies an exact Cortex location or a closely specified project record. For a page location, use Cortex fetch with that identifier, then follow its continuation offsets until the end. The accompanying sources folder contains the retrieved page text, including retrieval headers. The sources are grouped below by their role in the argument rather than by the order in which they were retrieved.

The manuscript does not claim that every passage in an owner-supplied message was authored by the owner. Several messages paste assistant responses, catalogs, or proposed architectures. The source pages often distinguish these explicitly. Those distinctions govern the attribution here.

### S01. Initial mathematical-development contract

Cortex pages a0da4c14-a and 2f7fda36-9, September 24, 2026. Registration contract, owner-intent text, and alias addendum. Principal support: mathematical identity distinct from storage identity; retained derivations; terminal results; propagation through applicable mathematics; early deterministic teacher. Registration and pending implementation are explicitly separated.

### S02. Governing spoken V16 explanation and candidate-group instruction

Cortex page b483c7b2-a, September 29, 2026. Contains the owner's spoken explanation, followed by pasted candidate mappings and a growth instruction. Principal support: the node as code; expressions as locations; external forms at the encoder and decoder; developmental learning; relational placement; sensory metadata; connected growth. Candidate equations in the pasted material are not established linguistic laws.

### S03. V16 architecture and addendum

Cortex page bb22e936-b, September 29, 2026. Explicitly identified on the page as LLM architecture text and an LLM addendum. Used as secondary architectural material, especially for distinctions among locations, transforms, convergence, possible materialization, and unresolved fan-out. The owner's governing explanation takes precedence over this interpretation.

### S04. Receipt, memory, timeline, and output walkthrough

Cortex page faf55255-d, September 30, 2026. Contains owner messages 01–08 and pasted audits or plans. Owner message 02 supplies the receipt-to-memory-to-clock-to-timeline-to-output example and contextual running conversation. Its arithmetic and sample dialogue are pseudocode. Later sections include assistant interpretations and are not treated as fresh experimental verification.

### S05. Graph ownership, tool behavior, and additive development

Cortex page 1863c8a8-8, September 30, 2026. Contains owner messages 09–12 and a pasted exchange. Principal support: the graph physically embodying code, the distinction between an operation and an external helper, definitions inferred from relationships, useful unexpected answers, and the request for additive work. External literature discussed inside the pasted assistant exchange was not independently reviewed for this manuscript and is not used as proof of Neuron.

### S06. Reasoning, triangulation, and diagnostic experience

Cortex page 1c79d4a9-b, October 1, 2026. Contains owner texts 53 and 54, including a pasted research catalog. Owner text 54 is a principal source for relational placement, formulas composed of formulas, context-dependent selection, the diagnostic example, observations and testimony, memory, and development. Informal electrical examples are treated as illustrations of inquiry, not technical instructions.

### S07. Definitions, keyboard symbols, shortcuts, and bounded search

Cortex page df23b5bc-1, October 1, 2026. Reproduces owner texts 56–62. Principal support: full definitions as runs, every keyboard and special key having a neuronal representation, the unresolved common-punctuation memory problem, tools as neuron code, long and short execution, movable placements, and searching relevant memories and processes.

### S08. Foundational monologue on the whole system

Cortex page 57823c3e-9, October 1, 2026. Reproduces owner text 64 and then a separately labeled assistant analysis. Principal support: mother-to-student independence, learning versus execution, recall by pattern, persistent guess status, questions, progress, and internally generated input. Owner source hash recorded on the page begins ccb55532d7ab5769. The assistant's candidate formulas remain hypotheses.

### S09. Recursive shortcuts, arrival-matched alternatives, and feeling patterns

Cortex page aa0c7fd5-9, October 1, 2026. Reproduces the owner's new text from message 66 and a subsequent assistant synthesis. Principal support: starting from an old outcome, reopening local choices, recursive adaptation, checking completed-arrival compatibility, and composite feeling-based memory access. The page corrects an earlier account of the independence of the assistant analyses.

### S10. Explicit pseudocode correction and scope contribution

Cortex page 47c23c52-d, October 2, 2026. Assistant-authored scope contribution containing the owner's explicit correction that illustrative formulas and placements are pseudocode describing a process. Used for that correction and for carefully distinguished evidence categories. It is not treated as a sole final merged specification.

### S11. Approved scope perspectives and their placement record

Cortex page 08da0f2e-2, October 2, 2026. Contains the owner's placement instruction, change record, and placed Claude and Codex scope texts. These are assistant-authored perspectives recorded as owner-approved; their status tables are dated October 1 and are not current verification. The page says the longer browser perspective is in its raw record and on disk; this edition did not recover that entire 61,000-character browser document through the page interface.

### S12. Owner-pinned task structure and project relationship

Cortex page 0ce15058-2, October 2, 2026. Contains owner messages 70 and 71 and a checklist with quotations pinned to owner source numbers. Principal support: prohibiting hidden external cognitive helpers; definitions, memories, recall, questions, context, and targeted propagation; the intention for Neuron eventually to join or replace much of Cortex. Checklist statuses are historical.

### S13. The little objection

Cortex page 9a40db66-b, September 30, 2026. Contains owner message 51 asking how the decoder could produce an allegedly unknown word and calling for a derived partial definition instead. Principal support: separating naming, supplied vocabulary, relation inference, and unknown-concept discovery.

### S14. Mind-map account of misfit and reframing

Cortex page 68b79e93-f. An assistant-authored Q8 analysis of an owner response, with the raw answer identified elsewhere in the record. Used as a secondary source for local repair versus changing the problem tree, back-populating a revised decision, and evaluating solutions by more than immediate success. No date absent from the retrieved page is invented here.

### S15. Audit of the little chronology and scope

Cortex page 6dfe407e-e, October 2, 2026. Reports archived assertions about the sequence of location, label, definition, and later relation response. It explicitly distinguishes reading those assertions from independently observing the original database events. Also notes a later owner correction numbered 74; this manuscript does not reconstruct that correction from an unavailable verbatim text.

### S16. Definition and relationship-history implementation report

Cortex page bf6f821a-9, October 2, 2026. Reports the bounded coolness definition work as merged and the relationship-history package as sandbox-verified but not merged at that point. Principal support: definition receipts, history, relationship status, evidence, and stale relationships. Later integration is not inferred from this page.

### S17. Bounded step-back work and exceptional backfill

Cortex page f2b88193-b, October 2, 2026. Reports numerical comparison and early step-back work and reproduces owner words concerning a one-time approval-key override to repair missing definitions. The exceptional repair does not revoke the general requirement for targeted search.

### S18. Receipt-storage measurement and memory-lifecycle proposal

Cortex page fe84132b-b, October 3, 2026. A read-only size diagnosis and a separately labeled proposal. Principal support: recursive text expansion, shared child references, exact identity, and the distinction between representation repair and retention policy. It does not report completion of the proposed storage change.

### S19. Owner hypothesis on sleep and local prediction

Cortex page 89772d1a-3, recorded October 3, 2026, with owner source 135 timestamped October 4 in UTC. Principal support: selective overnight updating, touched trees, small local predictive models, and persistent guess labeling. The page explicitly states that the idea had not been built from this record. Biological and transformer analogies remain owner hypotheses.

### S20. Later reasoning and keyword-selection discussion

Cortex page 434b4795-7, October 6, 2026. Reproduces owner texts 240 and 242. Principal support: context and keywords selecting relevant process libraries; knowledge versus historical memory; useful unprompted questions; future use of language models as tools; and a controlled reasoning experiment. Owner assessments of the contemporary system are preserved as assessments.

### S21. Learning-closure audit

Cortex page 592cf97a-c, October 7, 2026. Assistant-authored read-only research audit with dated measurements and source excerpts. Principal support: distinctions among mutable state, supplied policy, actual adaptation, and outcome-based learning; incomplete integration; independent outcome evidence; and proposed bounded experiments. Its findings are scoped to inspected paths. External papers listed by the audit were not independently reread for this edition.

### S22. Mathematical research catalog

Cortex page 58205378-0, September 30, 2026. Contains the owner's request to broaden the mathematical search and a pasted assistant catalog of 73 candidate families. Used to establish that the project considered a broad mathematical repertoire. The catalog is a research inventory, not a list of installed capabilities or established formulas of cognition.

### S23. Search ladder, epiphany, and comparator/step-back report

Cortex page 302ce980-e, October 2, 2026. Reproduces owner texts 72 and 73 and reports bounded comparison and step-back results. Principal support: escalating targeted search; building missing operations through neuron code; comparing progress; and matching new results to other unresolved desired outcomes. Later correction records supersede parts of its proposed implementation direction.

### S24. Latest retrieved staged-work record

Cortex page ef7b0c72-4, October 11, 2026. Reports question-shape and contract-row work on fresh snapshots, with staged files and an observer-controlled landing step. Used only as a dated record of bounded work and pending integration, not as a claim about the machine's live state on October 15.

### S25. Cognitive-operation vocabulary

Cortex page e973f0f6-d, October 7, 2026. Assistant-authored Neuron cognitive vocabulary v1, with 57 operation identifiers and explicit evidence boundaries. The page says it installs no primitive and is not separately ratified in every definition. Used for the importance of distinguishing storage, observation, inference, prediction, evaluation, and revision.

### Coverage and limits of this edition

This edition preserves the major conceptual strands recovered from the owner prose: mathematical identity; the graph as code; local DNA and arrival; developmental birth and propagation; receipts; memory, time, and state; definitions and nameless concepts; language and contextual action; composed reasoning; questions; recursive shortcuts; pattern and feeling recall; durable uncertainty; the sixth sense and epiphany; sleep and local prediction; maternal independence; and memory economy.

It synthesizes these strands rather than reproducing the owner's monologues or writing in the owner's voice. Explanatory connections made by the manuscript are interpretations of the cited material. They do not create new owner requirements or settle missing formulas.

The manuscript does not claim exhaustive retrieval of Cortex, completion of every referenced historical experiment, or fresh validation of archived runtime reports. The recovered source pages include duplicate passages, assistant proposals, and descriptions of files not available at their former local paths. Those limits are why source type, date, and implementation status remain explicit.

The finished document is a readable reference to the system's thesis and its research boundary. The source copies make it possible to challenge the synthesis against the material from which it was written. That recoverability is part of the same principle the project asks of Neuron: retain the path by which a conclusion was reached so it can be examined and improved.




