#!/bin/bash
# learn : X, the whole check in one go: the 17.2 told block, dog's source rows, the runs (17.2 and the 17.1 control), the readback.
set -e
S=/tmp/claude-1000/-home-exnulla-neuron-v1/9853484c-3767-41c2-a2dc-7feaf44f9efd/scratchpad
cd $S/t23
python3 -I gen172_patch.py
python3 -I gen_physics172.py physics172.json B
python3 -I - <<'EOF'
import json
a=json.load(open('physics17.json'))['statements']; b=json.load(open('physics172.json'))['statements']
new=[s for s in b if s not in set(a)]; gone=[s for s in a if s not in set(b)]
print('17.2 told block:', len(b), 'statements; new or changed:', len(new), '; replaced:', len(gone))
for s in new: print('  NEW', s[:150].replace('\n', ' '))
EOF
mkdir -p raw-dict && python3 -I fetch_dog.py sat17.json sat172.json raw-dict
echo '["learn : store", "learn : dog", "learn : zork"]' > learn_lines.json
echo '["learn : store"]' > learn_ctl.json
timeout 900 node --stack-size=7800 teach_run.js $S/b17/v16 $S/b17/sqljs/sql-asm-memory-growth.js physics172.json sat172.json learn_lines.json learn172.json 2>&1 | grep -v randomDevice | tail -2
timeout 900 node --stack-size=7800 teach_run.js $S/b17/v16 $S/b17/sqljs/sql-asm-memory-growth.js physics17.json sat172.json learn_ctl.json learn17ctl.json 2>&1 | grep -v randomDevice | tail -2
