// 17.1 check in a real headless Chromium: the teaching sheet's lines, put in the prompt by clicking them and run with the run
// button, teach define and place; the brain writes places into its own place table; the stage draws them; 16.4's parts and 17's
// lab view still work. usage: node shot171.js <html> <shot prefix> <expect17.json>
const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
const fs = require('fs');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const errs = [], R = { lines: [] }, X = JSON.parse(fs.readFileSync(process.argv[4], 'utf8'));
  const page = await browser.newPage({ viewport: { width: 1600, height: 950 } });
  page.on('pageerror', e => errs.push(e.message)); page.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text()); });
  await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.startsWith('data:') || u.includes('cdnjs.cloudflare.com') ? r.continue() : r.abort(); });
  await page.goto('file://' + process.argv[2]); await page.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 180000 }); await page.waitForTimeout(2000);
  R.presetButtons = await page.evaluate(() => document.querySelectorAll('#presets button').length);
  await page.click('#tabm'); await page.waitForTimeout(500);
  R.sheetRows = await page.evaluate(() => document.querySelectorAll('#tsheet [data-t]').length);
  const runSheet = async (i) => {
    await page.evaluate((i) => document.querySelector('#tsheet [data-t="' + i + '"]').click(), i);
    const typed = await page.inputValue('#line'); const t = Date.now();
    await page.click('#run'); await page.waitForTimeout(300);
    await page.waitForFunction(() => !window.__poc.busy(), null, { timeout: 600000 }); await page.waitForTimeout(500);
    fs.writeFileSync(process.argv[3] + '-partial.json', JSON.stringify(R));
    R.lines.push({ line: typed.slice(0, 40), s: +((Date.now() - t) / 1000).toFixed(1), said: (await page.evaluate(() => window.__poc.lastOutput())) || '', busyText: (await page.evaluate(() => document.getElementById('busy').textContent)).slice(0, 90) });
  };
  const sheet = await page.evaluate(() => SHEET.map(r => r[1]));
  const want = sheet.map((l, i) => i).filter(i => i < 18 || ['learn : store', 'define : store', 'find meaning : store', 'learn : INSERT', 'run backpop'].includes(sheet[i]));
  for (const i of want) await runSheet(i);
  R.brainPlaces = await page.evaluate(() => window.__poc.lab.brainPlaces());
  await page.evaluate(() => { document.getElementById('mview').checked = true; document.getElementById('mview').dispatchEvent(new Event('change')); });
  await page.evaluate(() => window.__poc.lab.setFrom('brain')); await page.waitForTimeout(2500);
  R.drawnBrain = await page.evaluate(() => window.__poc.lab.drawn());
  R.labelsBrain = await page.evaluate(() => window.__poc.lab.labels());
  R.summaryBrain = await page.evaluate(() => document.getElementById('msum').innerText);
  const xy = await page.evaluate(() => { const ms = window.__poc.lab.drawn(); return null; });
  await page.waitForTimeout(6000); await page.screenshot({ path: process.argv[3] + '-brain.png' });
  // the lab view still matches node
  await page.evaluate(() => window.__poc.lab.setFrom('lab')); await page.click('#mall');
  await page.waitForFunction(() => { const s = window.__poc.lab.state(); return s.ready && !s.busy; }, null, { timeout: 60000 }); await page.waitForTimeout(800);
  const rows = await page.evaluate(() => window.__poc.lab.places()); let md = 0; rows.forEach(r => { const w = X.off[r[0]]; if (w) md = Math.max(md, Math.abs(r[1] - w[0]), Math.abs(r[2] - w[1]), Math.abs(r[3] - w[2])); });
  R.labStill = { points: rows.length, maxDiff: md };
  R.overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  const phone = await browser.newPage({ viewport: { width: 400, height: 860 }, deviceScaleFactor: 2 });
  await phone.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.startsWith('data:') || u.includes('cdnjs.cloudflare.com') ? r.continue() : r.abort(); });
  await phone.goto('file://' + process.argv[2]); await phone.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 180000 }); await phone.click('#tabm'); await phone.waitForTimeout(800);
  R.phoneOverflow = await phone.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  R.errors = errs; console.log(JSON.stringify(R, null, 1)); await browser.close();
})();
