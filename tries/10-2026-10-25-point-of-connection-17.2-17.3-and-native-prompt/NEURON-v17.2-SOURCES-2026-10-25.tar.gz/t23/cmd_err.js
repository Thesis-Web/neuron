// one command, typed straight into the brain object (no worker restore), to see the real error
const fs = require('fs'), vm = require('vm'); const [D, ASM, TOLDF, SATF, SHEETF, LINE] = process.argv.slice(2);
const src = fs.readFileSync(ASM, 'utf8') + '\n' + fs.readFileSync(D + '/host15.js', 'utf8') + '\n' + fs.readFileSync(D + '/shared15.js', 'utf8') + '\n' + fs.readFileSync(D + '/worker16.js', 'utf8');
const ctx = { console, setTimeout, Uint8Array, Int8Array, Int16Array, Int32Array, Uint16Array, Uint32Array, Float32Array, Float64Array, ArrayBuffer, DataView, WebAssembly, TextDecoder, TextEncoder, performance, Date, Math, JSON };
ctx.self = ctx; let inbox = []; ctx.postMessage = (m) => inbox.push(m); vm.createContext(ctx); vm.runInContext(src, ctx);
(async () => {
  ctx.onmessage({ data: { type: 'init', told: JSON.parse(fs.readFileSync(TOLDF, 'utf8')), sat: JSON.parse(fs.readFileSync(SATF, 'utf8')) } });
  for (let i = 0; i < 400 && !inbox.some(m => m.type === 'ready'); i++) await new Promise(r => setTimeout(r, 50));
  const sheet = JSON.parse(fs.readFileSync(SHEETF, 'utf8')).filter(s => /^(teach|bind)/.test(s[0]));
  const b = vm.runInContext('brain', ctx);
  for (const s of sheet) b.type(s[1]);
  try { console.log('said:', b.type(LINE)); }
  catch (e) { console.log('ERROR message:', JSON.stringify(e.message), '| name:', e.name, '\nstack:', String(e.stack).split('\n').slice(0, 8).join('\n')); }
  const q = (sql) => b.q(sql);
  console.log('last events:', JSON.stringify(q('SELECT kind, gate, substr(text, 1, 110) FROM event ORDER BY id DESC LIMIT 12').reverse(), null, 0));
})();
