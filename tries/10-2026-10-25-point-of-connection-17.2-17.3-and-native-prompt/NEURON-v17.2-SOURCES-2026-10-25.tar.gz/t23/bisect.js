// setup lines, then one line, straight into the brain object; prints what it said or the error. usage: node bisect.js <v16> <asm> <told> <sat> <setup.json> <line>
const fs = require('fs'), vm = require('vm'); const [D, ASM, TOLDF, SATF, SETUPF, LINE] = process.argv.slice(2);
const src = fs.readFileSync(ASM, 'utf8') + '\n' + fs.readFileSync(D + '/host15.js', 'utf8') + '\n' + fs.readFileSync(D + '/shared15.js', 'utf8') + '\n' + fs.readFileSync(D + '/worker16.js', 'utf8');
const ctx = { console: { log() {}, warn() {}, error() {} }, setTimeout, Uint8Array, Int8Array, Int16Array, Int32Array, Uint16Array, Uint32Array, Float32Array, Float64Array, ArrayBuffer, DataView, WebAssembly, TextDecoder, TextEncoder, performance, Date, Math, JSON };
ctx.self = ctx; let inbox = []; ctx.postMessage = (m) => inbox.push(m); vm.createContext(ctx); vm.runInContext(src, ctx);
(async () => {
  ctx.onmessage({ data: { type: 'init', told: JSON.parse(fs.readFileSync(TOLDF, 'utf8')), sat: JSON.parse(fs.readFileSync(SATF, 'utf8')) } });
  for (let i = 0; i < 400 && !inbox.some(m => m.type === 'ready'); i++) await new Promise(r => setTimeout(r, 50));
  const b = vm.runInContext('brain', ctx);
  for (const l of JSON.parse(fs.readFileSync(SETUPF, 'utf8'))) { try { b.type(l); } catch (e) { console.log('SETUP FAILED', l.slice(0, 40), e.message); } }
  try { process.stdout.write('said: ' + JSON.stringify(b.type(LINE)) + '\n'); } catch (e) { process.stdout.write('ERROR ' + JSON.stringify(e.message) + '\n'); }
})();
