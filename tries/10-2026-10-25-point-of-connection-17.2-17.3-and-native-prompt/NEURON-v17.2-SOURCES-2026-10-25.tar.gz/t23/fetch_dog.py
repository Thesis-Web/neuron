# dog's entries from dict.org (WordNet 3.0, GCIDE = Webster 1913, Moby thesaurus) into the stand-in sources, one row per sense,
# in the stand-ins' row format [word, hw, text, words]: words = the text in small letters, letters only, brackets removed.
# usage: fetch_dog.py <sat in.json> <sat out.json> <raw dir>
import json, re, subprocess, sys
SAT_IN, SAT_OUT, RAW = sys.argv[1:]
def dict_org(word, db):
    out = subprocess.run(['curl', '-s', '--max-time', '30', f'dict://dict.org/d:{word}:{db}'], capture_output=True, text=True).stdout
    open(f'{RAW}/{word}.{db}.txt', 'w').write(out)
    entries, cur, head = [], None, None
    for line in out.splitlines():
        if line.startswith('151 '): cur = []; head = line; continue
        if cur is not None and line.strip() == '.': entries.append((head, cur)); cur = None; continue
        if cur is not None: cur.append(line)
    return entries
def words(t): return ' '.join(re.findall(r'[a-z]+', re.sub(r'\([^)]*\)|\[[^\]]*\]|\{|\}', ' ', t).lower()))
rows = {'wn': [], 'gcide': [], 'moby': []}
# WordNet: each numbered sense; the gloss without its [syn: ...] list
for head, body in dict_org('dog', 'wn'):
    text = ' '.join(l.strip() for l in body[1:]); senses = re.split(r'\s(?=(?:[nvar] )?\d+: )', ' ' + text)
    for s in senses:
        m = re.match(r'\s*(?:[nvar] )?\d+: (.*)', s)
        if m: g = re.sub(r'\[syn:.*?\]', '', m.group(1)).strip(); rows['wn'].append(['dog', 'dog', g, words(g)])
# GCIDE: only entries whose headword is Dog; each numbered sense
for head, body in dict_org('dog', 'gcide'):
    first = next((l for l in body if l.strip()), '')
    if not re.match(r'Dog \\', first): continue   # the entry's own headword (dict.org's 151 line names the word asked, not the entry)
    text = ' '.join(l.strip() for l in body)
    for m in re.finditer(r'(?:^|\s)(\d+)\. (.*?)(?=\s\d+\. |\[1913 Webster\]|$)', text):
        g = re.sub(r'\s+', ' ', m.group(2)).strip()
        if len(g) > 12: rows['gcide'].append(['dog', 'dog', g, words(g)])   # lowercase, as every other stand-in row is stored
# Moby thesaurus: its word list, in rows of 25 words
for head, body in dict_org('dog', 'moby-thesaurus'):
    syn = [w.strip() for w in ' '.join(l.strip() for l in body[1:]).split(',') if w.strip()]
    for i in range(0, len(syn), 25): t = ', '.join(syn[i:i + 25]); rows['moby'].append(['dog', 'dog', t, words(t)])
sat = json.load(open(SAT_IN))
for k, v in rows.items(): sat[k] = [r for r in sat[k] if str(r[0]).lower() != 'dog'] + v
json.dump(sat, open(SAT_OUT, 'w'))
print({k: len(v) for k, v in rows.items()}); [print(' ', k, '|', v[0][2][:110]) for k, v in rows.items() if v]
