// After the learn lines: what the brain holds. Runs the lines again in a fresh brain (same told block and sources) and reads its tables.
// usage: node learn_read.js <v16 dir> <sql-asm.js> <told.json> <sat.json> <lines.json>
const fs = require('fs'), vm = require('vm'); const [D, ASM, TOLDF, SATF, LINESF] = process.argv.slice(2);
const src = fs.readFileSync(ASM, 'utf8') + '\n' + fs.readFileSync(D + '/host15.js', 'utf8') + '\n' + fs.readFileSync(D + '/shared15.js', 'utf8') + '\n' + fs.readFileSync(D + '/worker16.js', 'utf8');
const ctx = { console: { log() {}, warn() {}, error() {} }, setTimeout, Uint8Array, Int8Array, Int16Array, Int32Array, Uint16Array, Uint32Array, Float32Array, Float64Array, ArrayBuffer, DataView, WebAssembly, TextDecoder, TextEncoder, performance, Date, Math, JSON };
ctx.self = ctx; let inbox = []; ctx.postMessage = (m) => inbox.push(m); vm.createContext(ctx); vm.runInContext(src, ctx);
const send = (m) => { inbox = []; ctx.onmessage({ data: m }); return inbox; }; const q = (sql) => send({ type: 'query', id: 1, sql })[0].rows;
(async () => {
  send({ type: 'init', told: JSON.parse(fs.readFileSync(TOLDF, 'utf8')), sat: JSON.parse(fs.readFileSync(SATF, 'utf8')) });
  for (let i = 0; i < 400 && !inbox.some(m => m.type === 'ready'); i++) await new Promise(r => setTimeout(r, 50));
  for (const l of JSON.parse(fs.readFileSync(LINESF, 'utf8'))) {
    const r = send({ type: 'lines', lines: [l] }), last = r[r.length - 1];
    const run = q("SELECT id FROM run WHERE kind = 'line' ORDER BY id DESC LIMIT 1")[0][0];
    console.log('\n== ' + l + '  -> said ' + JSON.stringify(last.output) + (last.type !== 'done' ? '  (' + last.type + ': ' + last.error + ')' : ''));
    console.log('definition rows held, by source:', JSON.stringify(q("SELECT src, count(*) FROM definition WHERE src <> 'node' AND word = " + JSON.stringify(l.split(' ').pop()).replace(/"/g, "'") + " GROUP BY src")));
    const rets = q("SELECT id, line FROM run WHERE kind = 'defrow' AND parent = " + run + " ORDER BY id");
    console.log('return runs of this line:', rets.length); rets.slice(0, 3).forEach(r => console.log('   run ' + r[0] + ': ' + String(r[1]).slice(0, 120)));
    console.log('definition memories:', JSON.stringify(q("SELECT id, mark, substr(receipt, 1, 40) FROM memory WHERE run IN (SELECT id FROM run WHERE kind = 'defrow' AND parent = " + run + ")")));
    console.log('cells in the primary run\'s data sheet (src = return):', JSON.stringify(q("SELECT name, value FROM var WHERE run = " + run + " AND src = 'return'")));
    console.log('other cells in the primary run:', JSON.stringify(q("SELECT name, value FROM var WHERE run = " + run + " AND coalesce(src, '') <> 'return'").slice(0, 10)));
    console.log('gaps:', JSON.stringify(q("SELECT DISTINCT need FROM gap WHERE run = " + run).slice(0, 6)));
  }
  console.log('\nsource formula fired inside a return run:', q("SELECT count(*) FROM run WHERE kind = 'formula' AND word = 'source' AND parent IN (SELECT id FROM run WHERE kind = 'defrow')")[0][0]);
  console.log('formulas fired inside return runs:', JSON.stringify(q("SELECT word, count(*) FROM run WHERE kind = 'formula' AND parent IN (SELECT id FROM run WHERE kind = 'defrow') GROUP BY word")));
})();
