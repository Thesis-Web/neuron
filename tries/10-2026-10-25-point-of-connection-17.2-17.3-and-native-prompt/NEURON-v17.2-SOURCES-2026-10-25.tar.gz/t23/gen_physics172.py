# 17.2 (2026-10-25): 17.1 plus the owner's learn : X design: a source's answer comes back as a run headed by modifier gates
# (return from <the line> from <source> /build <definition>), and its end writes the word's definition memory and a cell in
# the primary run's data sheet. 17.1 (2026-10-24): 16.4's told block plus two told changes the owner asked for: a 3D place table with its own trigger, and the
# 'measured' source brain (steps 2 and 3's measured numbers and lines). Everything else is 16.4's, byte for byte.
# Writes physics15.sql: the told block. Hand-laid gates, the sixteen physics tables and their triggers, the ports.
# Everything that decides is a trigger here. The host only writes typed lines into input, is mother, and reads output.
import json, sys
DECIDE = (sys.argv[2] if len(sys.argv) > 2 else 'B').upper()   # E9: C as v15, A my told rule, B the owner's way (history of being wrong)
DQ = '"'

PHYSICS = ['input', 'encoder', 'decide', 'lay', 'born', 'source', 'agree', 'end', 'sense', 'memory', 'timeline', 'say', 'BUILD', 'formula', 'var', 'state']
ACTIONS = ['READ', 'WRITE', 'COMPARE', 'ADD', 'SUBTRACT', 'MOVE', 'FIND', 'SPLIT', 'JOIN', 'CLOCK', 'HEAR', 'SAY', 'CALL', 'SPAWN']
SQLROOTS = ['SELECT', 'FROM', 'WHERE', 'INSERT', 'INTO', 'VALUES', 'UPDATE', 'SET', 'DELETE', 'CREATE', 'TABLE', 'AS', 'AND', 'OR', 'NOT', 'IN', 'LIKE', 'EXISTS', 'LIMIT', 'ORDER', 'BY', 'NULL', 'CAST', 'INTEGER', 'WITH', 'instr', 'count', 'max', 'group_concat', 'IS', 'DESC', '=', '(', ')', ',', ';', '*', '>', '<', '||']
ARRIVALS = ['heard', 'said', 'start']
SATS = ['wn', 'gcide', 'mw', 'mwt', 'moby', 'map', 'sqldoc', 'measured']
PORTS = ['output to sources', 'secondary input', 'OUTPUT', 'mother', 'SQL prompt']
VERBS = "('SELECT','INSERT','UPDATE','DELETE','CREATE','WITH')"

def lit(s):
    return "'" + s.replace("'", "''") + "'"

NOW = "(SELECT coalesce(max(id), 0) FROM event)"
def FW(x):  # first word of a text
    return f"substr(trim({x}) || ' ', 1, instr(trim({x}) || ' ', ' ') - 1)"
def RW(x):  # the words after the first
    return f"trim(substr(trim({x}) || ' ', instr(trim({x}) || ' ', ' ') + 1))"
def W(g):   # the word of a gate
    return f"(SELECT word FROM encoder WHERE gate = {g})"
def G(w):   # the gate of a word
    return f"(SELECT gate FROM encoder WHERE word = {w})"
def prev_of(r):  # the gates of the line that came before run r
    return f"(SELECT gates FROM run WHERE kind = 'line' AND id < {r} ORDER BY id DESC LIMIT 1)"
def decide_extra():
    """E9: one more reason to run a remembered line again the long way. C: none. A: my told rule. B: decide's own DNA row, laid from the history of being wrong."""
    cur = prev_of('NEW.run'); mem = "(SELECT prevgates FROM memory WHERE id = run.memid)"
    if DECIDE == 'A':
        return ("UPDATE run SET reopen = 1 WHERE id = NEW.run AND memid IS NOT NULL AND reopen = 0 AND EXISTS (SELECT 1 FROM receipt rr JOIN run x ON x.id = rr.run "
                "WHERE x.root = (SELECT run FROM memory WHERE id = run.memid) AND rr.gate = " + G("':prev'") + f") AND coalesce({mem}, '') <> coalesce({cur}, '');")
    if DECIDE == 'B':
        first = "CAST(" + FW('run.gates') + " AS INTEGER)"
        return (f"UPDATE run SET reopen = 1 WHERE id = NEW.run AND memid IS NOT NULL AND reopen = 0 AND EXISTS (SELECT 1 FROM g{DECIDE_GATE} WHERE arrival = {first} AND trigger = " + G("':prev'") + ") "
                f"AND coalesce({mem}, '') <> coalesce({cur}, '');")
    return ''
def EV(kind, gate, run, rowgate, text, roots='', where=None, a='NULL', b='NULL'):
    if where is None:
        return f"INSERT INTO event (kind, gate, run, rowgate, text, roots, a, b) VALUES ({lit(kind)}, {gate}, {run}, {rowgate}, {text}, {lit(roots)}, {a}, {b});"
    return f"INSERT INTO event (kind, gate, run, rowgate, text, roots, a, b) SELECT {lit(kind)}, {gate}, {run}, {rowgate}, {text}, {lit(roots)}, {a}, {b} WHERE {where};"
def HOLE(run, name):  # a hole's value: the cell of this run, else its parent's, else its root's
    return (f"coalesce((SELECT value FROM var WHERE run = {run} AND name = {name} ORDER BY id DESC LIMIT 1), "
            f"(SELECT value FROM var WHERE run = (SELECT parent FROM run WHERE id = {run}) AND name = {name} ORDER BY id DESC LIMIT 1), "
            f"(SELECT value FROM var WHERE run = (SELECT root FROM run WHERE id = {run}) AND name = {name} ORDER BY id DESC LIMIT 1))")

def gate_objects(k):
    """The three objects that make a neuron: its DNA table, its gate (the view a run is inserted into), and its miss trigger."""
    return [f"CREATE TABLE g{k} (shard INTEGER PRIMARY KEY, arrival INTEGER, remainder INTEGER, trigger INTEGER, op TEXT, times INTEGER DEFAULT 0, first INTEGER, last INTEGER)",
            f"CREATE VIEW land_{k} AS SELECT arrival, remainder, NULL AS run, NULL AS rest FROM g{k}",
            f"CREATE TRIGGER miss_{k} INSTEAD OF INSERT ON land_{k} WHEN NOT EXISTS (SELECT 1 FROM g{k} WHERE arrival = NEW.arrival AND remainder IS NEW.remainder) BEGIN INSERT INTO lay (gate, arrival, remainder, run, rest) VALUES ({k}, NEW.arrival, NEW.remainder, NEW.run, NEW.rest); END"]

# The same three objects as SQL text the brain builds itself, by value, for a born word, and hands to mother one statement at a time.
def born_texts(idexpr):
    return [f"'CREATE TABLE g' || {idexpr} || ' (shard INTEGER PRIMARY KEY, arrival INTEGER, remainder INTEGER, trigger INTEGER, op TEXT, times INTEGER DEFAULT 0, first INTEGER, last INTEGER)'",
            f"'CREATE VIEW land_' || {idexpr} || ' AS SELECT arrival, remainder, NULL AS run, NULL AS rest FROM g' || {idexpr}",
            f"'CREATE TRIGGER miss_' || {idexpr} || ' INSTEAD OF INSERT ON land_' || {idexpr} || ' WHEN NOT EXISTS (SELECT 1 FROM g' || {idexpr} || ' WHERE arrival = NEW.arrival AND remainder IS NEW.remainder) BEGIN INSERT INTO lay (gate, arrival, remainder, run, rest) VALUES (' || {idexpr} || ', NEW.arrival, NEW.remainder, NEW.run, NEW.rest); END'"]

# The decode of a statement at ";": the words the formula run passed since its statement began, holes filled with their values, quoted.
def DECODE(run, semi):
    prev = f"coalesce((SELECT max(id) FROM receipt WHERE run = {run} AND gate = {semi} AND id < (SELECT max(id) FROM receipt WHERE run = {run})), 0)"
    start = f"(SELECT min(r2.id) FROM receipt r2 JOIN encoder e2 ON e2.gate = r2.gate WHERE r2.run = {run} AND e2.word IN {VERBS} AND r2.id > {prev})"
    hole = HOLE(run, "e.word")
    return (f"(SELECT group_concat(w, ' ') FROM (SELECT CASE WHEN e.role = 'var' THEN quote({hole}) ELSE e.word END AS w "
            f"FROM receipt r JOIN encoder e ON e.gate = r.gate WHERE r.run = {run} AND r.id >= {start} ORDER BY r.id))")

SEMI_ID = 1 + 16 + 14 + ['SELECT', 'FROM', 'WHERE', 'INSERT', 'INTO', 'VALUES', 'UPDATE', 'SET', 'DELETE', 'CREATE', 'TABLE', 'AS', 'AND', 'OR', 'NOT', 'IN', 'LIKE', 'EXISTS', 'LIMIT', 'ORDER', 'BY', 'NULL', 'CAST', 'INTEGER', 'WITH', 'instr', 'count', 'max', 'group_concat', 'IS', 'DESC', '=', '(', ')', ',', ';', '*', '>', '<', '||'].index(';')
def hop_text():
    """The SQL text of one DNA row's own hop trigger, built by value inside the lay trigger. Baked in: its gate, its shard,
    its arrival, its remainder (so the next gate's view is named statically). The ';' gate also ends a statement."""
    g, s, a, r = "NEW.gate", "(SELECT shard FROM lay WHERE id = NEW.id)", "NEW.arrival", "NEW.remainder"
    semi = G("';'")
    parts = [
        f"'CREATE TRIGGER hop_' || {g} || '_' || {s} || ' INSTEAD OF INSERT ON land_' || {g} || ' WHEN NEW.arrival = ' || {a} || ' AND NEW.remainder IS ' || coalesce({r}, 'NULL') || ' BEGIN '",
        f"'UPDATE g' || {g} || ' SET times = times + 1, last = (SELECT coalesce(max(id), 0) FROM event) WHERE shard = ' || {s} || '; '",
        f"'INSERT INTO receipt (run, gate, shard) VALUES (NEW.run, ' || {g} || ', ' || {s} || '); '",
        "'INSERT INTO event (kind, gate, run, rowgate, text, roots) VALUES (''hit'', ' || quote(" + W(g) + ") || ', NEW.run, ' || quote(" + W(g) + ") || ', ' || quote(" + W(g) + " || ': row (' || coalesce(" + W(a) + ", '?') || ', ' || coalesce(" + W(r) + ", 'end') || ') hit; its own hop trigger carries the run on') || ', ''COMPARE WRITE''); '",
        # the ';' gate ends a statement: decode the statement and put it in output to sources
        f"CASE WHEN {g} = {semi} THEN " + lit("INSERT INTO stmt (run, text) SELECT NEW.run, " + DECODE("NEW.run", str(SEMI_ID)) + " WHERE (SELECT kind FROM run WHERE id = NEW.run) = 'formula'; ") + " ELSE '' END",
        f"'INSERT INTO fire (run, gate, shard, trig, rest) VALUES (NEW.run, ' || {g} || ', ' || {s} || ', (SELECT trigger FROM g' || {g} || ' WHERE shard = ' || {s} || '), trim(' || quote(coalesce(" + W(r) + ", '')) || ' || '' '' || coalesce(NEW.rest, ''''))); '",
        f"CASE WHEN {r} IS NULL THEN 'INSERT INTO \"end\" (run) VALUES (NEW.run); ' ELSE 'INSERT INTO land_' || {r} || ' (arrival, remainder, run, rest) VALUES (' || {g} || ', (SELECT gate FROM encoder WHERE word = substr(trim(NEW.rest) || '' '', 1, instr(trim(NEW.rest) || '' '', '' '') - 1)), NEW.run, trim(substr(trim(NEW.rest) || '' '', instr(trim(NEW.rest) || '' '', '' '') + 1))); ' END",
        "'END'"]
    return " || ".join(parts)

def build(sat_names):
    out = ["PRAGMA recursive_triggers = ON"]
    T = out.append
    # ---- tables
    T("CREATE TABLE event (id INTEGER PRIMARY KEY, kind TEXT, gate TEXT, run INTEGER, rowgate TEXT, text TEXT, roots TEXT, a TEXT, b TEXT)")
    T("CREATE TABLE encoder (gate INTEGER PRIMARY KEY, word TEXT UNIQUE COLLATE NOCASE, role TEXT, born INTEGER, sourced INTEGER DEFAULT 0)")
    T("CREATE TABLE input (id INTEGER PRIMARY KEY, line TEXT, direction TEXT DEFAULT 'heard', parent INTEGER, kind TEXT DEFAULT 'line', subject TEXT, word TEXT, fgate INTEGER, fshard INTEGER, rest TEXT, before TEXT)")
    T("CREATE TABLE run (id INTEGER PRIMARY KEY, input INTEGER, line TEXT, gates TEXT DEFAULT '', direction TEXT, expected TEXT, parent INTEGER, root INTEGER, kind TEXT, subject TEXT, word TEXT, fgate INTEGER, fshard INTEGER, output TEXT, mark TEXT, memid INTEGER, reopen INTEGER DEFAULT 0, recalled INTEGER DEFAULT 0, failed INTEGER DEFAULT 0, build INTEGER DEFAULT 0, t0 INTEGER, t1 INTEGER)")
    T("CREATE TABLE encode (id INTEGER PRIMARY KEY, run INTEGER, text TEXT)")
    T("CREATE TABLE decide (id INTEGER PRIMARY KEY, run INTEGER)")
    T("CREATE TABLE lay (id INTEGER PRIMARY KEY, gate INTEGER, arrival INTEGER, remainder INTEGER, run INTEGER, rest TEXT, trig INTEGER, shard INTEGER)")
    T("CREATE TABLE born (id INTEGER PRIMARY KEY, word TEXT COLLATE NOCASE, run INTEGER, why TEXT)")
    T("CREATE TABLE source (id INTEGER PRIMARY KEY, word TEXT COLLATE NOCASE, run INTEGER)")
    T("CREATE TABLE agree (id INTEGER PRIMARY KEY, word TEXT COLLATE NOCASE, run INTEGER)")
    T('CREATE TABLE "end" (id INTEGER PRIMARY KEY, run INTEGER)')
    T("CREATE TABLE sense (id INTEGER PRIMARY KEY, run INTEGER, stmt INTEGER, src TEXT, word TEXT, kept INTEGER, aside INTEGER, total INTEGER, asked TEXT, needed TEXT, wrong TEXT, setaside TEXT, ok INTEGER)")
    T("CREATE TABLE memory (id INTEGER PRIMARY KEY, list TEXT, line TEXT, direction TEXT, receipt TEXT, output TEXT, answer TEXT, mark TEXT, times INTEGER DEFAULT 1, first INTEGER, last INTEGER, run INTEGER, ended INTEGER DEFAULT 0, prevgates TEXT)")
    # the history of being wrong: a memory that answered wrong, the line that came before it then, what it gave, what was right
    T("CREATE TABLE memwrong (id INTEGER PRIMARY KEY, memid INTEGER, run INTEGER, first INTEGER, prevgates TEXT, given TEXT, expected TEXT)")
    T("CREATE TABLE timeline (id INTEGER PRIMARY KEY, t INTEGER, mem INTEGER, run INTEGER)")
    T("CREATE TABLE say (id INTEGER PRIMARY KEY, run INTEGER, text TEXT)")
    T('CREATE TABLE "BUILD" (id INTEGER PRIMARY KEY, run INTEGER, text TEXT)')
    # a formula row holds a pointer to the run through the neurons that made it (its receipt rows are the path), never the words as text
    T("CREATE TABLE formula (id INTEGER PRIMARY KEY, word TEXT COLLATE NOCASE, run INTEGER, origin TEXT DEFAULT 'told', t INTEGER, ended INTEGER DEFAULT 0)")
    T("CREATE TABLE var (id INTEGER PRIMARY KEY, run INTEGER, name TEXT, value TEXT, src TEXT, t INTEGER, sense INTEGER)")
    T("CREATE TABLE state (id INTEGER PRIMARY KEY, key TEXT, value TEXT, t INTEGER)")
    # working tables the physics needs, named for what they hold
    T("CREATE TABLE receipt (id INTEGER PRIMARY KEY, run INTEGER, gate INTEGER, shard INTEGER)")
    T("CREATE TABLE fire (id INTEGER PRIMARY KEY, run INTEGER, gate INTEGER, shard INTEGER, trig INTEGER, rest TEXT, subject TEXT, word TEXT)")
    T("CREATE TABLE stmt (id INTEGER PRIMARY KEY, run INTEGER, text TEXT)")
    T("CREATE TABLE secondary (id INTEGER PRIMARY KEY, run INTEGER, stmt INTEGER, src TEXT, word TEXT, hw TEXT, value TEXT, words TEXT, cols TEXT, n INTEGER, err TEXT, changes INTEGER, waiting INTEGER DEFAULT 0, last INTEGER DEFAULT 0)")
    T("CREATE TABLE output (id INTEGER PRIMARY KEY, run INTEGER, text TEXT)")
    T("CREATE TABLE envelope (id INTEGER PRIMARY KEY, arrival INTEGER, remainder INTEGER, run INTEGER, rest TEXT)")
    T("CREATE TABLE gap (id INTEGER PRIMARY KEY, run INTEGER, need TEXT, fill TEXT, who TEXT, word TEXT COLLATE NOCASE, kind TEXT)")
    T("CREATE TABLE relation (id INTEGER PRIMARY KEY, a TEXT COLLATE NOCASE, rel TEXT, b TEXT COLLATE NOCASE, trust REAL DEFAULT 0.6)")
    T("CREATE TABLE definition (id INTEGER PRIMARY KEY, word TEXT COLLATE NOCASE, src TEXT, hw TEXT, text TEXT, words TEXT)")
    T("CREATE TABLE defword (id INTEGER PRIMARY KEY, def INTEGER, word TEXT COLLATE NOCASE, src TEXT, w TEXT COLLATE NOCASE, rest TEXT)")
    T("CREATE TABLE need (w TEXT PRIMARY KEY COLLATE NOCASE, n INTEGER)")
    T("CREATE TABLE proc (word TEXT PRIMARY KEY COLLATE NOCASE, status TEXT, uses INTEGER DEFAULT 0, right INTEGER DEFAULT 0, wrong INTEGER DEFAULT 0)")
    T("CREATE TABLE procrun (id INTEGER PRIMARY KEY, word TEXT COLLATE NOCASE, receipt TEXT)")
    # 17.1: where a meaning sits in the graph, as the brain's own rows (owner, 10-24: "positions exist in the db"). x, y, z in brain
    # units; t is the brain's clock (the count of log rows); a new place of a word ends its old one, which is kept as history.
    T("CREATE TABLE place (id INTEGER PRIMARY KEY, word TEXT COLLATE NOCASE, x REAL, y REAL, z REAL, t INTEGER, ended INTEGER DEFAULT 0)")

    # ---- hand-laid gates: each has its DNA table, its view, its miss trigger; ports, mother and the source brains are names only
    k = 0; told = set()
    for role, words in [('physics', PHYSICS), ('root', ACTIONS), ('sqlroot', SQLROOTS), ('arrival', ARRIVALS), ('word', ['origin'])]:
        for w in words:
            if w.lower() in told: continue
            told.add(w.lower())
            k += 1; T(f"INSERT INTO encoder (gate, word, role, born) VALUES ({k}, {lit(w)}, {lit(role)}, 0)")
            for s in gate_objects(k): T(s)
            if w == 'decide':
                global DECIDE_GATE
                DECIDE_GATE = k   # decide's own neuron: its DNA rows are read when a remembered line arrives
            if w == ';':
                global SEMI_ID
                SEMI_ID = k   # the gate of ';' as laid here, never assumed from a list's order
    for role, words in [('port', PORTS), ('sat', sat_names)]:
        for w in words:
            k += 1; T(f"INSERT INTO encoder (gate, word, role, born) VALUES ({k}, {lit(w)}, {lit(role)}, 0)")
            if role == 'sat':
                for s2 in gate_objects(k): T(s2)   # 17.2: a source is a neuron too, so a returned answer's run can land on it

    # ---- input: a told line writes a formula; a bound line lays a row; anything else runs
    TEACH = "NEW.kind = 'line' AND instr(NEW.line, ' = ') > 1 AND instr(NEW.line, '=>') = 0 AND instr(substr(NEW.line, 1, instr(NEW.line, ' = ') - 1), ' ') = 0 AND NEW.line NOT LIKE 'BUILD %'"
    BIND = "NEW.kind = 'line' AND instr(NEW.line, ' -> ') > 0"
    T(f"""CREATE TRIGGER input_teach AFTER INSERT ON input WHEN {TEACH} BEGIN
      INSERT INTO born (word, run, why) SELECT substr(NEW.line, 1, instr(NEW.line, ' = ') - 1), NULL, 'a word given a formula'
        WHERE NOT EXISTS (SELECT 1 FROM encoder WHERE word = substr(NEW.line, 1, instr(NEW.line, ' = ') - 1));
      INSERT INTO run (input, line, kind, word, t0, direction) VALUES (NEW.id, trim(substr(NEW.line, instr(NEW.line, ' = ') + 3)), 'teach', substr(NEW.line, 1, instr(NEW.line, ' = ') - 1), {NOW}, 'start');
      {EV('input', "'input'", "(SELECT max(id) FROM run)", "'input'", "'primary input: " + DQ + "' || NEW.line || '" + DQ + ": a told line. Its words run through the neurons from start; when the run ends, the formula row points at that run.'", 'HEAR WRITE')}
    END""")
    T(f"""CREATE TRIGGER input_bind AFTER INSERT ON input WHEN {BIND} BEGIN
      INSERT INTO bindq (words, f, input) VALUES (trim(substr(NEW.line, 1, instr(NEW.line, ' -> ') - 1)), trim(substr(NEW.line, instr(NEW.line, ' -> ') + 4)), NEW.id);
      INSERT INTO run (input, line, kind, t0, direction) VALUES (NEW.id, replace(NEW.line, ' -> ', ' '), 'bind', {NOW}, 'heard');
    END""")
    T(f"""CREATE TRIGGER input_run AFTER INSERT ON input WHEN NOT ({TEACH}) AND NOT ({BIND}) BEGIN
      INSERT INTO run (input, line, expected, direction, parent, kind, subject, word, fgate, fshard, t0, build)
        VALUES (NEW.id, trim(CASE WHEN instr(NEW.line, ' => ') > 0 THEN substr(NEW.line, 1, instr(NEW.line, ' => ') - 1) ELSE NEW.line END),
                CASE WHEN instr(NEW.line, ' => ') > 0 THEN trim(substr(NEW.line, instr(NEW.line, ' => ') + 4)) END,
                NEW.direction, NEW.parent, NEW.kind, NEW.subject, NEW.word, NEW.fgate, NEW.fshard, {NOW}, (NEW.line LIKE 'BUILD % BUILD'));
    END""")
    T("CREATE TABLE bindq (id INTEGER PRIMARY KEY, words TEXT, f TEXT, input INTEGER)")

    # ---- run: set its root, give a formula run its mechanical holes, then hand its words to the encoder
    T(f"""CREATE TRIGGER run_go AFTER INSERT ON run BEGIN
      UPDATE run SET root = CASE WHEN NEW.kind IN ('defrow', 'test') THEN NEW.id ELSE coalesce((SELECT root FROM run WHERE id = NEW.parent), NEW.id) END WHERE id = NEW.id;
      INSERT INTO var (run, name, value, src, t) SELECT NEW.id, ':head', {W('NEW.fgate')}, 'the run', {NOW} WHERE NEW.kind = 'formula';
      INSERT INTO var (run, name, value, src, t) SELECT NEW.id, ':after', (SELECT rest FROM input WHERE id = NEW.input), 'the run', {NOW} WHERE NEW.kind = 'formula';
      INSERT INTO var (run, name, value, src, t) SELECT NEW.id, ':before', (SELECT before FROM input WHERE id = NEW.input), 'the run', {NOW} WHERE NEW.kind = 'formula';
      INSERT INTO var (run, name, value, src, t) SELECT NEW.id, ':subject', NEW.subject, 'the run', {NOW} WHERE NEW.kind = 'formula' AND NEW.subject IS NOT NULL;
      INSERT INTO var (run, name, value, src, t) SELECT NEW.id, ':line', (SELECT line FROM run WHERE id = (SELECT root FROM run WHERE id = NEW.id)), 'the run', {NOW} WHERE NEW.kind = 'formula';
      INSERT INTO var (run, name, value, src, t) SELECT NEW.id, ':run', (SELECT root FROM run WHERE id = NEW.id), 'the run', {NOW} WHERE NEW.kind = 'formula';
      INSERT INTO var (run, name, value, src, t) SELECT NEW.id, ':prev', (SELECT max(id) FROM run WHERE kind = 'line' AND id < (SELECT root FROM run WHERE id = NEW.id)), 'the run', {NOW} WHERE NEW.kind = 'formula';
      INSERT INTO var (run, name, value, src, t) SELECT NEW.id, ':speaker', CASE (SELECT direction FROM run WHERE id = (SELECT root FROM run WHERE id = NEW.id)) WHEN 'said' THEN 'self' ELSE 'user' END, 'the run', {NOW} WHERE NEW.kind = 'formula';
      INSERT INTO encode (run, text) VALUES (NEW.id, NEW.line);
    END""")
    # a run's input event, written once its root is known
    T(f"""CREATE TRIGGER run_said AFTER UPDATE OF root ON run WHEN OLD.root IS NULL BEGIN
      {EV('input', "CASE WHEN NEW.kind = 'formula' THEN NEW.word ELSE 'input' END", 'NEW.id', "CASE WHEN NEW.kind IN ('line', 'teach', 'bind') THEN 'input' ELSE NULL END",
          "CASE NEW.kind WHEN 'line' THEN (CASE NEW.direction WHEN 'said' THEN 'said back: " + DQ + "' || NEW.line || '" + DQ + ": the brain''s own words fed to its ear; the first row arrives from said' ELSE 'primary input: " + DQ + "' || NEW.line || '" + DQ + "' || coalesce(' with expected output " + DQ + "' || NEW.expected || '" + DQ + "', '') || '. The first row arrives from heard.' END) WHEN 'formula' THEN NEW.word || ' fires: its formula runs as a branch of run ' || NEW.parent || ': ' || NEW.line WHEN 'defrow' THEN 'a definition row of ' || NEW.subject || ' runs like any line, with ' || NEW.subject || ' as its subject: ' || NEW.line WHEN 'teach' THEN 'the words of a told line get their gates' ELSE NEW.line END", 'HEAR WRITE')}
    END""")

    # ---- encoder: word by word, by its own recursive trigger; a word with no gate is born; a word never looked up is looked up when a typed line needs it
    w = FW("NEW.text")
    T(f"""CREATE TRIGGER encode_word AFTER INSERT ON encode WHEN trim(NEW.text) <> '' BEGIN
      INSERT INTO born (word, run, why) SELECT {w}, NEW.run, CASE (SELECT kind FROM run WHERE id = NEW.run) WHEN 'line' THEN NULL WHEN 'defrow' THEN 'named in a definition row of ' || (SELECT subject FROM run WHERE id = NEW.run) || '; not looked up until a line needs it' ELSE 'a word in a formula' END
        WHERE NOT EXISTS (SELECT 1 FROM encoder WHERE word = {w});
      INSERT INTO source (word, run) SELECT {w}, NEW.run FROM encoder e WHERE e.word = {w} AND e.role IN ('word', 'sqlroot', 'root', 'physics') AND e.sourced = 0 AND (SELECT kind FROM run WHERE id = NEW.run) = 'line' AND NOT EXISTS (SELECT 1 FROM formula WHERE word = {w} AND ended = 0) AND (SELECT build FROM run WHERE id = NEW.run) = 0;
      UPDATE run SET gates = trim(gates || ' ' || (SELECT gate FROM encoder WHERE word = {w})) WHERE id = NEW.run;
      INSERT INTO encode (run, text) VALUES (NEW.run, {RW('NEW.text')});
    END""")
    T(f"""CREATE TRIGGER encode_done AFTER INSERT ON encode WHEN trim(NEW.text) = '' BEGIN
      {EV('encode', "'encoder'", 'NEW.run', "'encoder'", "'encoder: ' || (SELECT line FROM run WHERE id = NEW.run) || ' = gates ' || (SELECT gates FROM run WHERE id = NEW.run)", 'READ FIND')}
      INSERT INTO decide (run) SELECT NEW.run WHERE (SELECT kind FROM run WHERE id = NEW.run) <> 'bind';
      INSERT INTO bindgo (run) SELECT NEW.run WHERE (SELECT kind FROM run WHERE id = NEW.run) = 'bind' AND EXISTS (SELECT 1 FROM bindq WHERE input = (SELECT input FROM run WHERE id = NEW.run));
    END""")

    # ---- born: mother makes the neuron's table, its gate and its miss trigger; a blank definition node; then source, for a word a typed line brought
    T(f"""CREATE TRIGGER born_go AFTER INSERT ON born BEGIN
      INSERT INTO encoder (word, role, born) VALUES (NEW.word, CASE WHEN NEW.word LIKE ':%' THEN 'var' WHEN NEW.word GLOB '[0-9]*' OR NEW.word LIKE '''%' OR NEW.word LIKE '%''' THEN 'literal' ELSE 'word' END, {NOW});
      SELECT mother({born_texts("(SELECT gate FROM encoder WHERE word = NEW.word)")[0]}, NULL, NULL);
      SELECT mother({born_texts("(SELECT gate FROM encoder WHERE word = NEW.word)")[1]}, NULL, NULL);
      SELECT mother({born_texts("(SELECT gate FROM encoder WHERE word = NEW.word)")[2]}, NULL, NULL);
      INSERT INTO definition (word, src) VALUES (NEW.word, 'node');
      {EV('born', 'NEW.word', 'NEW.run', "'mother'", "'born ' || NEW.word || ' (gate ' || (SELECT gate FROM encoder WHERE word = NEW.word) || '): mother makes its table, its gate and its trigger, and a blank definition node' || coalesce('. ' || NEW.why, '')", 'SPAWN WRITE CALL')}
      INSERT INTO source (word, run) SELECT NEW.word, NEW.run WHERE NEW.why IS NULL AND (SELECT role FROM encoder WHERE word = NEW.word) = 'word';
    END""")

    # ---- decide: one indexed look at memory; found and clean: hop to it; else mother carries the run to its first gate
    reopen_cond = ("EXISTS (SELECT 1 FROM gap g WHERE g.run = (SELECT run FROM memory WHERE id = r.memid) AND ("
                   "(g.kind = 'word' AND EXISTS (SELECT 1 FROM formula f WHERE f.word = g.word AND f.ended = 0)) OR "
                   "(g.kind = 'source' AND EXISTS (SELECT 1 FROM formula f WHERE f.word = 'source' AND f.ended = 0)) OR "
                   "(g.kind = 'defrows' AND EXISTS (SELECT 1 FROM formula f WHERE f.word IN ('like', 'opposite', 'kind') AND f.ended = 0))))")
    T(f"""CREATE TRIGGER decide_go AFTER INSERT ON decide BEGIN
      UPDATE run SET memid = (SELECT m.id FROM memory m WHERE m.list = run.gates AND m.direction = run.direction AND m.ended = 0 ORDER BY m.id DESC LIMIT 1) WHERE id = NEW.run AND kind = 'line' AND build = 0;
      UPDATE run SET reopen = 1 WHERE id = NEW.run AND memid IS NOT NULL AND (SELECT answer FROM memory WHERE id = run.memid) IS NULL AND (SELECT {reopen_cond} FROM run r WHERE r.id = NEW.run);
      {decide_extra()}
      INSERT INTO memhit (run) SELECT NEW.run FROM run WHERE id = NEW.run AND memid IS NOT NULL AND reopen = 0;
      {EV('decide', "'decide'", 'NEW.run', "'decide'", "CASE WHEN (SELECT reopen FROM run WHERE id = NEW.run) = 1 THEN 'decide: this line is in memory, but that memory was written with gaps and something it lacked now exists. It runs again the long way.' ELSE 'decide: not in memory. The line runs from its first word; each landing fires its row.' END", 'FIND COMPARE', where='EXISTS (SELECT 1 FROM run WHERE id = NEW.run AND (memid IS NULL OR reopen = 1))')}
      INSERT INTO envelope (arrival, remainder, run, rest) SELECT {G('r.direction')}, {G(FW(RW('r.line')))}, r.id, {RW(RW('r.line'))} FROM run r WHERE r.id = NEW.run AND (r.memid IS NULL OR r.reopen = 1);
      SELECT mother('INSERT INTO land_' || {G(FW('r.line'))} || ' (arrival, remainder, run, rest) SELECT arrival, remainder, run, rest FROM envelope WHERE id = (SELECT max(id) FROM envelope)', NULL, NULL) FROM run r WHERE r.id = NEW.run AND (r.memid IS NULL OR r.reopen = 1);
      DELETE FROM envelope WHERE id = (SELECT max(id) FROM envelope) AND run = NEW.run;
    END""")
    T("CREATE TABLE memhit (id INTEGER PRIMARY KEY, run INTEGER)")
    if DECIDE == 'B':
        MEMHIT_CORRECTION = ("INSERT INTO memwrong (memid, run, first, prevgates, given, expected) SELECT r.memid, r.id, CAST(" + FW('r.gates') + " AS INTEGER), " + prev_of('r.id') + ", "
                             "(SELECT coalesce(answer, output) FROM memory WHERE id = r.memid), r.expected FROM run r WHERE r.id = NEW.run AND r.expected IS NOT NULL "
                             "AND r.expected IS NOT (SELECT coalesce(answer, output) FROM memory WHERE id = r.memid);")
    else:
        MEMHIT_CORRECTION = """UPDATE memory SET output = (SELECT expected FROM run WHERE id = NEW.run), answer = (SELECT expected FROM run WHERE id = NEW.run), mark = 'corrected' WHERE id = (SELECT memid FROM run WHERE id = NEW.run) AND (SELECT expected FROM run WHERE id = NEW.run) IS NOT NULL AND (SELECT expected FROM run WHERE id = NEW.run) IS NOT coalesce(answer, output);""".format()
    T(f"""CREATE TRIGGER memhit_go AFTER INSERT ON memhit BEGIN
      UPDATE memory SET times = times + 1, last = {NOW} WHERE id = (SELECT memid FROM run WHERE id = NEW.run);
      {MEMHIT_CORRECTION}
      UPDATE run SET recalled = 1, output = (SELECT coalesce(answer, output) FROM memory WHERE id = run.memid), t1 = {NOW} WHERE id = NEW.run;
      {EV('memhit', "'memory'", 'NEW.run', "'memory'", "'decide: this line is in memory (receipt ' || (SELECT receipt FROM memory WHERE id = (SELECT memid FROM run WHERE id = NEW.run)) || '). Do I know this? Yes: one hop to it, times ' || (SELECT times FROM memory WHERE id = (SELECT memid FROM run WHERE id = NEW.run)) || '. No rows fire, no lay, no mother.'", 'FIND COMPARE WRITE', a='(SELECT line FROM run WHERE id = NEW.run)', b='(SELECT memid FROM run WHERE id = NEW.run)')}
      INSERT INTO timeline (t, mem, run) VALUES ({NOW}, (SELECT memid FROM run WHERE id = NEW.run), NEW.run);
      {EV('timeline', "'timeline'", 'NEW.run', "'timeline'", "'timeline: row ' || (SELECT max(id) FROM timeline) || ' (memory ' || (SELECT memid FROM run WHERE id = NEW.run) || ')'", 'CLOCK WRITE')}
      INSERT INTO output (run, text) VALUES (NEW.run, (SELECT output FROM run WHERE id = NEW.run));
      {EV('say', "'say'", 'NEW.run', "'OUTPUT'", "'say: ' || coalesce((SELECT output FROM run WHERE id = NEW.run), '')", 'READ SAY')}
    END""")

    if DECIDE == 'B':
        T(f"""CREATE TRIGGER memwrong_go AFTER INSERT ON memwrong WHEN {G("':prev'")} IS NOT NULL BEGIN
      SELECT mother('INSERT INTO g{DECIDE_GATE} (arrival, remainder, trigger, times, first, last) SELECT ' || NEW.first || ', NULL, ' || {G("':prev'")} || ', 0, ' || {NOW} || ', ' || {NOW} ||
        ' WHERE NOT EXISTS (SELECT 1 FROM g{DECIDE_GATE} WHERE arrival = ' || NEW.first || ' AND trigger = ' || {G("':prev'")} || ')', NULL, NULL);
      {EV('learned', "'decide'", 'NEW.run', "'decide'", "'decide was wrong: memory ' || NEW.memid || ' answered ' || quote(substr(NEW.given, 1, 60)) || ' where ' || quote(substr(NEW.expected, 1, 60)) || ' was right. Kept as history, not overwritten. The line before differed from the one before that memory, so decide''s row for a line arriving from ' || " + W('NEW.first') + " || ' now points at :prev: the line before matters'", 'COMPARE WRITE')}
    END""")

    # ---- lay: write the missing DNA row, then its own hop trigger, both through mother; then retry the landing through mother
    T(f"""CREATE TRIGGER lay_go AFTER INSERT ON lay BEGIN
      UPDATE lay SET shard = mother('INSERT INTO g' || NEW.gate || ' (arrival, remainder, trigger, times, first, last) VALUES (' || NEW.arrival || ', ' || coalesce(NEW.remainder, 'NULL') || ', ' || coalesce(NEW.trig, 'NULL') || ', 0, ' || {NOW} || ', ' || {NOW} || ')', NULL, NULL) WHERE id = NEW.id;
      SELECT mother({hop_text()}, NULL, NULL);
      {EV('lay', W('NEW.gate'), 'NEW.run', W('NEW.gate'), W('NEW.gate') + " || ': no row for (' || coalesce(" + W('NEW.arrival') + ", '?') || ', ' || coalesce(" + W('NEW.remainder') + ", 'end') || '). lay writes row s' || (SELECT shard FROM lay WHERE id = NEW.id) || ' and mother lays its own hop trigger' || CASE WHEN NEW.trig IS NOT NULL THEN ', trigger column ' || " + W('NEW.trig') + " ELSE '' END || CASE WHEN NEW.run IS NOT NULL THEN '; the landing is retried through mother' ELSE '' END", 'WRITE SPAWN CALL', a=W('NEW.remainder'), b="(SELECT shard FROM lay WHERE id = NEW.id)")}
      INSERT INTO envelope (arrival, remainder, run, rest) SELECT NEW.arrival, NEW.remainder, NEW.run, NEW.rest WHERE NEW.run IS NOT NULL;
      SELECT mother('INSERT INTO land_' || NEW.gate || ' (arrival, remainder, run, rest) SELECT arrival, remainder, run, rest FROM envelope WHERE id = (SELECT max(id) FROM envelope)', NULL, NULL) WHERE NEW.run IS NOT NULL;
      DELETE FROM envelope WHERE id = (SELECT max(id) FROM envelope) AND run = NEW.run;
    END""")
    # a bound line: lay the row (or set its trigger column) in the first word's neuron
    T("CREATE TABLE bindgo (id INTEGER PRIMARY KEY, run INTEGER)")
    bw = "(SELECT words FROM bindq WHERE input = (SELECT input FROM run WHERE id = NEW.run))"
    three = f"(instr({RW(bw)}, ' ') > 0)"
    T(f"""CREATE TRIGGER bind_go AFTER INSERT ON bindgo BEGIN
      INSERT INTO bindrow (gate, arrival, remainder, trig, run) SELECT
        CASE WHEN {three} THEN {G(FW(RW(bw)))} ELSE {G(FW(bw))} END,
        CASE WHEN {three} THEN {G(FW(bw))} ELSE {G("'heard'")} END,
        CASE WHEN {three} THEN {G(FW(RW(RW(bw))))} ELSE {G(FW(RW(bw)))} END,
        {G("(SELECT f FROM bindq WHERE input = (SELECT input FROM run WHERE id = NEW.run))")}, NEW.run;
    END""")
    T("CREATE TABLE bindrow (id INTEGER PRIMARY KEY, gate INTEGER, arrival INTEGER, remainder INTEGER, trig INTEGER, run INTEGER, found INTEGER)")
    T(f"""CREATE TRIGGER bindrow_go AFTER INSERT ON bindrow BEGIN
      UPDATE bindrow SET found = mother('SELECT shard FROM g' || NEW.gate || ' WHERE arrival = ' || NEW.arrival || ' AND remainder IS ' || coalesce(NEW.remainder, 'NULL'), NULL, NULL) WHERE id = NEW.id;
      SELECT mother('UPDATE g' || NEW.gate || ' SET trigger = ' || NEW.trig || ' WHERE shard = ' || (SELECT found FROM bindrow WHERE id = NEW.id), NULL, NULL) WHERE (SELECT found FROM bindrow WHERE id = NEW.id) IS NOT NULL;
      {EV('lay', W('NEW.gate'), 'NEW.run', W('NEW.gate'), W('NEW.gate') + " || ': its row (' || " + W('NEW.arrival') + " || ', ' || coalesce(" + W('NEW.remainder') + ", 'end') || ') already exists; its trigger column is set to ' || " + W('NEW.trig'), 'WRITE', where='(SELECT found FROM bindrow WHERE id = NEW.id) IS NOT NULL')}
      INSERT INTO lay (gate, arrival, remainder, run, rest, trig) SELECT NEW.gate, NEW.arrival, NEW.remainder, NULL, NULL, NEW.trig WHERE (SELECT found FROM bindrow WHERE id = NEW.id) IS NULL;
    END""")

    # ---- fire: a hit row whose trigger column names a word, or a word that has its own formula, starts a branch run of that formula
    inside_stmt = (f"EXISTS (SELECT 1 FROM receipt r JOIN encoder e ON e.gate = r.gate WHERE r.run = NEW.run AND e.word IN {VERBS} "
                   f"AND r.id > coalesce((SELECT max(id) FROM receipt WHERE run = NEW.run AND gate = {G(lit(';'))}), 0))")
    fw = "(SELECT word FROM fire WHERE id = NEW.id)"
    T(f"""CREATE TRIGGER fire_go AFTER INSERT ON fire BEGIN
      UPDATE fire SET word = coalesce(CASE WHEN (SELECT kind FROM run WHERE id = NEW.run) = 'defrow' THEN NULL ELSE {W('NEW.trig')} END, CASE WHEN EXISTS (SELECT 1 FROM formula WHERE word = {W('NEW.gate')} AND ended = 0) THEN {W('NEW.gate')} END)
        WHERE id = NEW.id AND NOT ({inside_stmt}) AND (SELECT kind FROM run WHERE id = NEW.run) <> 'teach'
          AND coalesce({W('NEW.trig')}, {W('NEW.gate')}) IS NOT (SELECT word FROM run WHERE id = NEW.run)
          AND coalesce({W('NEW.trig')}, {W('NEW.gate')}) IS NOT (SELECT word FROM run WHERE id = (SELECT parent FROM run WHERE id = NEW.run))
          AND (SELECT count(*) FROM run a WHERE a.id IN (NEW.run, (SELECT parent FROM run WHERE id = NEW.run), (SELECT parent FROM run WHERE id = (SELECT parent FROM run WHERE id = NEW.run))) AND a.kind = 'formula') < 3;
      INSERT INTO gap (run, need, fill, who, word, kind) SELECT (SELECT root FROM run WHERE id = NEW.run), 'a formula for ' || {W('NEW.trig')}, 'the row points at it; teach "' || {W('NEW.trig')} || ' = ..."', 'us, once', {W('NEW.trig')}, 'word'
        WHERE NEW.trig IS NOT NULL AND NOT EXISTS (SELECT 1 FROM formula WHERE word = {W('NEW.trig')} AND ended = 0) AND (SELECT kind FROM run WHERE id = NEW.run) <> 'defrow';
      INSERT INTO input (line, direction, parent, kind, word, fgate, fshard, subject, rest, before)
        SELECT (SELECT group_concat(w, ' ') FROM (SELECT e.word AS w FROM receipt r JOIN encoder e ON e.gate = r.gate WHERE r.run = f.run ORDER BY r.id)), 'start', NEW.run, 'formula', f.word, NEW.gate, NEW.shard, coalesce(NEW.subject, (SELECT subject FROM run WHERE id = NEW.run)), NEW.rest,
          (SELECT group_concat(w, ' ') FROM (SELECT e.word AS w FROM receipt r JOIN encoder e ON e.gate = r.gate WHERE r.run = NEW.run AND r.id < (SELECT max(id) FROM receipt WHERE run = NEW.run) ORDER BY r.id))
        FROM formula f WHERE f.word = {fw} AND f.ended = 0;
    END""")

    # ---- output to sources: the statement leaves; mother carries it and writes the reply into secondary input
    T(f"""CREATE TRIGGER stmt_go AFTER INSERT ON stmt BEGIN
      {EV('out', "'output to sources'", 'NEW.run', "'output to sources'", "'output to sources: the gates the run passed decode to " + DQ + "' || NEW.text || '" + DQ + ". Mother picks it up.'", 'READ SAY')}
      SELECT mother(NEW.text, NEW.run, NEW.id);
    END""")

    # ---- secondary input: every return is checked. Is this what I asked for? Is it what I needed? Did I ask wrong?
    base = "(CASE WHEN instr(s.hw, ':') > 0 THEN substr(s.hw, 1, instr(s.hw, ':') - 1) ELSE s.hw END)"
    rows = "secondary s WHERE s.stmt = NEW.stmt AND s.src = NEW.src AND s.last = 0"
    T(f"""CREATE TRIGGER secondary_refused AFTER INSERT ON secondary WHEN NEW.last = 1 AND NEW.src <> 'sql' AND NEW.err IS NOT NULL BEGIN
      {EV('refused', 'NEW.src', 'NEW.run', 'NEW.src', "NEW.src || ': the ask never reached its inbox. The SQL prompt refused it: ' || NEW.err", 'COMPARE')}
      INSERT INTO gap (run, need, fill, who, word, kind) VALUES ((SELECT root FROM run WHERE id = NEW.run), 'an ask ' || NEW.src || ' could take', 'the statement was refused: ' || NEW.err, 'the brain by another row; else us', NULL, 'refused');
      UPDATE run SET failed = 1 WHERE id = NEW.run;
    END""")
    T(f"""CREATE TRIGGER secondary_ask AFTER INSERT ON secondary WHEN NEW.last = 1 AND NEW.src <> 'sql' AND NEW.waiting = 0 AND NEW.err IS NULL BEGIN
      INSERT INTO sense (run, stmt, src, word, kept, aside, total) VALUES (NEW.run, NEW.stmt, NEW.src, NEW.word,
        (SELECT count(*) FROM {rows} AND {base} = NEW.word), (SELECT count(*) FROM {rows} AND {base} <> NEW.word), (SELECT count(*) FROM {rows}));
    END""")
    T(f"""CREATE TRIGGER secondary_sql AFTER INSERT ON secondary WHEN NEW.last = 1 AND NEW.src = 'sql' BEGIN
      {EV('secondary', "'secondary input'", 'NEW.run', "'secondary input'", "'secondary input: ' || CASE WHEN NEW.err IS NOT NULL THEN 'the SQL prompt refused it: ' || NEW.err WHEN NEW.n > 0 THEN '" + DQ + "' || NEW.value || '" + DQ + "' ELSE coalesce(NEW.changes, 0) || ' change(s), no rows' END || ' comes back as a sub-input of run ' || NEW.run || ', not a new run'", 'HEAR WRITE')}
      INSERT INTO sense (run, stmt, src, word, kept, aside, total, asked, needed, wrong, ok) VALUES (NEW.run, NEW.stmt, 'sql', NULL, NEW.n, 0, NEW.n,
        CASE WHEN NEW.err IS NOT NULL THEN 'no: refused: ' || NEW.err ELSE 'yes: the reply answers the statement that was sent' END,
        CASE WHEN NEW.err IS NOT NULL THEN 'no: nothing came back' WHEN (SELECT text FROM stmt WHERE id = NEW.stmt) LIKE 'SELECT%' OR (SELECT text FROM stmt WHERE id = NEW.stmt) LIKE 'WITH%' THEN (CASE WHEN NEW.n > 0 THEN 'yes: ' || NEW.n || ' row(s) fill the cell' ELSE 'no: no row came back; the brain does not hold this' END) ELSE (CASE WHEN coalesce(NEW.changes, 0) > 0 THEN 'yes: ' || NEW.changes || ' change(s) made' ELSE 'no: the statement changed nothing' END) END,
        NULL, NULL);
    END""")
    T(f"""CREATE TRIGGER secondary_wait AFTER INSERT ON secondary WHEN NEW.waiting = 1 BEGIN
      {EV('waiting', 'NEW.src', 'NEW.run', 'NEW.src', "NEW.src || ': the ask sits in its inbox. Its outbox has not said it is populated, so mother has nothing to pick up. The cell waits; no timer fills it.'", '')}
      INSERT INTO var (run, name, value, src, t) VALUES (NEW.run, (SELECT text FROM stmt WHERE id = NEW.stmt), NULL, NULL, {NOW});
      INSERT INTO gap (run, need, fill, who, word, kind) VALUES ((SELECT root FROM run WHERE id = NEW.run), 'a reply from ' || NEW.src, 'the ask was delivered and nothing has populated the outbox; waiting is the answer until it does', NEW.src, NULL, 'wait');
      UPDATE run SET failed = 1 WHERE id = NEW.run;
    END""")
    # sense: the three answers, then the cell, the definition rows, and a failed ask marked for the step back
    T(f"""CREATE TRIGGER sense_ask AFTER INSERT ON sense WHEN NEW.src <> 'sql' BEGIN
      UPDATE sense SET
        asked = CASE WHEN NEW.total = 0 THEN 'no: nothing came back to compare with the ask' WHEN NEW.aside = 0 THEN 'yes: every row is about ' || NEW.word || ', the word asked' WHEN NEW.kept > 0 THEN 'partly: ' || NEW.kept || ' row(s) about ' || NEW.word || ', ' || NEW.aside || ' about other words, set aside' ELSE 'no: every row is about another word' END,
        needed = CASE WHEN NEW.kept > 0 THEN 'yes: ' || NEW.kept || ' row(s) fill the definition of ' || NEW.word || '; whether they are what the run needs is asked again when the run ends' ELSE 'no: ' || CASE WHEN NEW.total = 0 THEN NEW.src || ' sent back nothing for ' || NEW.word ELSE 'nothing that was asked for came back' END END,
        wrong = CASE WHEN NEW.kept > 0 AND NEW.aside = 0 THEN 'no: the ask got what it asked for' WHEN NEW.kept > 0 THEN 'partly: the ask was answered, and also for other words; the brain keeps only its own word' ELSE 'maybe I asked wrong: the data may not be there, the place may be wrong, or the word asked in the wrong form' END,
        setaside = (SELECT group_concat(s.hw || ' (' || CASE WHEN lower({base}) = lower(NEW.word) THEN 'same letters, different case' WHEN instr({base}, NEW.word) > 0 THEN 'a longer form that holds ' || NEW.word ELSE 'a different word' END || ')', '; ') FROM {rows.replace('NEW.stmt', 'NEW.stmt').replace('NEW.src', 'NEW.src')} AND {base} <> NEW.word),
        ok = (NEW.kept > 0) WHERE id = NEW.id;
      {EV('secondary', "'secondary input'", 'NEW.run', "'secondary input'", "'secondary input: ' || NEW.total || ' row(s) from ' || NEW.src || ' for " + DQ + "' || NEW.word || '" + DQ + " come back as a sub-input of run ' || NEW.run || ', not a new run'", 'HEAR WRITE')}
      {EV('check', "'sense'", 'NEW.run', "'sense'", "'check the return from ' || NEW.src || ' for ' || NEW.word || '. Asked for? ' || (SELECT asked FROM sense WHERE id = NEW.id) || '. Needed? ' || (SELECT needed FROM sense WHERE id = NEW.id) || '. Asked wrong? ' || (SELECT wrong FROM sense WHERE id = NEW.id) || coalesce('. Set aside: ' || (SELECT setaside FROM sense WHERE id = NEW.id), '')", 'COMPARE FIND')}
      INSERT INTO var (run, name, value, src, t, sense) VALUES (NEW.run, NEW.src || ': ' || NEW.word, CASE WHEN NEW.kept > 0 THEN NEW.kept || ' row(s)' END, NEW.src, {NOW}, NEW.id);
      INSERT INTO definition (word, src, hw, text, words) SELECT s.word, s.src, s.hw, s.value, s.words FROM {rows} AND {base} = NEW.word;
      INSERT INTO gap (run, need, fill, who, word, kind) SELECT (SELECT root FROM run WHERE id = NEW.run), 'an answer from ' || NEW.src || ' for ' || NEW.word, 'did I ask wrong? The data may not be there, the place may be wrong, or the word in the wrong form', 'the brain by another row; else us', NEW.word, 'ask' WHERE NEW.kept = 0;
      UPDATE run SET failed = 1 WHERE id = NEW.run AND NEW.kept = 0;
    END""")
    T(f"""CREATE TRIGGER sense_sql AFTER INSERT ON sense WHEN NEW.src = 'sql' BEGIN
      UPDATE sense SET ok = (NEW.needed LIKE 'yes%'), wrong = CASE WHEN NEW.needed LIKE 'yes%' THEN 'no: the ask got what it asked for' ELSE 'maybe I asked wrong: the data may not be there, it may be held somewhere else, or the question went to the wrong table' END WHERE id = NEW.id;
      {EV('check', "'sense'", 'NEW.run', "'sense'", "'check the return. Asked for? ' || NEW.asked || '. Needed? ' || NEW.needed || '. Asked wrong? ' || (SELECT wrong FROM sense WHERE id = NEW.id)", 'COMPARE FIND')}
      INSERT INTO var (run, name, value, src, t, sense) VALUES (NEW.run, (SELECT text FROM stmt WHERE id = NEW.stmt), CASE WHEN NEW.needed LIKE 'yes%' THEN coalesce((SELECT value FROM secondary WHERE stmt = NEW.stmt AND last = 1 AND n > 0), 'ok, ' || (SELECT changes FROM secondary WHERE stmt = NEW.stmt AND last = 1) || ' change(s)') END, 'mother', {NOW}, NEW.id);
      INSERT INTO var (run, name, value, src, t) SELECT NEW.run, ':found', (SELECT value FROM secondary WHERE stmt = NEW.stmt AND last = 1), 'mother', {NOW} WHERE (SELECT n FROM secondary WHERE stmt = NEW.stmt AND last = 1) > 0;
      UPDATE run SET failed = 1 WHERE id = NEW.run AND NEW.needed NOT LIKE 'yes%';
    END""")
    # a definition row is split into its words, for agree
    T("""CREATE TRIGGER definition_split AFTER INSERT ON definition WHEN NEW.src <> 'node' AND NEW.words IS NOT NULL BEGIN
      INSERT INTO defword (def, word, src, w, rest) VALUES (NEW.id, NEW.word, NEW.src, NULL, NEW.words);
    END""")
    T(f"""CREATE TRIGGER defword_next AFTER INSERT ON defword WHEN trim(NEW.rest) <> '' BEGIN
      INSERT INTO defword (def, word, src, w, rest) VALUES (NEW.def, NEW.word, NEW.src, {FW('NEW.rest')}, {RW('NEW.rest')});
    END""")

    # ---- say: a formula's answer for its root run
    T(f"""CREATE TRIGGER say_go AFTER INSERT ON say BEGIN
      INSERT INTO var (run, name, value, src, t) VALUES ((SELECT root FROM run WHERE id = NEW.run), 'output', NEW.text, 'say', {NOW});
      {EV('op', "'say'", 'NEW.run', "'OUTPUT'", "'say: " + DQ + "' || coalesce(NEW.text, '') || '" + DQ + " goes to output to use'", 'SAY')}
    END""")
    # ---- relation: its own trigger draws the line
    T(f"""CREATE TRIGGER relation_drawn AFTER INSERT ON relation BEGIN
      {EV('rel', 'NEW.a', '(SELECT max(id) FROM run)', 'NULL', "'relation row ' || NEW.a || ' ' || NEW.rel || ' ' || NEW.b || ' (trust ' || NEW.trust || '): the relation table''s own trigger draws the line and the points pull'", 'WRITE')}
      UPDATE event SET a = NEW.b, b = NEW.rel || '|' || NEW.trust WHERE id = (SELECT max(id) FROM event);
    END""")
    # ---- formula rows: told or found by the brain
    T(f"""CREATE TRIGGER formula_written AFTER INSERT ON formula BEGIN
      INSERT INTO proc (word, status) VALUES (NEW.word, CASE WHEN NEW.origin = 'told' THEN 'taught' ELSE 'derived' END)
        ON CONFLICT(word) DO UPDATE SET status = CASE WHEN NEW.origin = 'told' THEN 'taught' ELSE 'derived' END;
      {EV('taught', 'NEW.word', '(SELECT max(id) FROM run)', "'formula'", "CASE WHEN NEW.origin = 'told' THEN NEW.word || ' = ' || coalesce((SELECT group_concat(w, ' ') FROM (SELECT e.word AS w FROM receipt r JOIN encoder e ON e.gate = r.gate WHERE r.run = NEW.run ORDER BY r.id)), '') || ' (read back from the run that taught it). What it is made of is that run; what it does is measured when it runs.' || CASE WHEN (SELECT count(*) FROM formula WHERE word = NEW.word) > 1 THEN ' A truth shift: the old row is ended, not erased.' ELSE '' END ELSE NEW.word || ' now has a formula the brain found itself, marked ' || NEW.origin || ', a guess until tested: ' || coalesce((SELECT group_concat(w, ' ') FROM (SELECT e.word AS w FROM receipt r JOIN encoder e ON e.gate = r.gate WHERE r.run = NEW.run ORDER BY r.id)), '') END", 'WRITE')}
      UPDATE event SET kind = 'derived' WHERE id = (SELECT max(id) FROM event) AND NEW.origin <> 'told';
    END""")

    # ---- source: fire the brain's own formula for where to look; then agree; then the definition rows run; then derive and deduce
    T(f"""CREATE TRIGGER source_go AFTER INSERT ON source BEGIN
      UPDATE encoder SET sourced = 1 WHERE word = NEW.word;
      INSERT INTO gap (run, need, fill, who, word, kind) SELECT (SELECT root FROM run WHERE id = NEW.run), 'where to look for a definition of ' || NEW.word, 'no formula says where to look: teach source', 'us, once; then the brain', NEW.word, 'source' WHERE NOT EXISTS (SELECT 1 FROM formula WHERE word = 'source' AND ended = 0);
      INSERT INTO fire (run, gate, shard, trig, rest, subject) SELECT NEW.run, {G("'source'")}, NULL, {G("'source'")}, NEW.word, NEW.word WHERE EXISTS (SELECT 1 FROM formula WHERE word = 'source' AND ended = 0);
      INSERT INTO agree (word, run) VALUES (NEW.word, NEW.run);
      INSERT INTO input (line, direction, parent, kind, subject) SELECT 'return from ' || coalesce((SELECT line FROM run WHERE id = NEW.run), NEW.word) || ' from ' || d.src || ' /build ' || d.words, NEW.word, NEW.run, 'defrow', NEW.word FROM definition d WHERE d.word = NEW.word AND d.src <> 'node' AND trim(coalesce(d.words, '')) <> '' LIMIT 8;
      INSERT INTO gap (run, need, fill, who, word, kind) SELECT (SELECT root FROM run WHERE id = NEW.run), 'formulas for the words in the definition rows (like, opposite, kind)', 'teach them; then the rows write relations', 'us, once', NULL, 'defrows'
        WHERE EXISTS (SELECT 1 FROM definition WHERE word = NEW.word AND src <> 'node') AND NOT EXISTS (SELECT 1 FROM formula WHERE word IN ('like', 'opposite', 'kind') AND ended = 0);
      INSERT INTO fire (run, gate, shard, trig, rest, subject) SELECT NEW.run, {G("'born'")}, NULL, {G("'derive'")}, NEW.word, NEW.word WHERE EXISTS (SELECT 1 FROM formula WHERE word = 'derive' AND ended = 0) AND NOT EXISTS (SELECT 1 FROM formula WHERE word = NEW.word AND ended = 0);
      INSERT INTO fire (run, gate, shard, trig, rest, subject) SELECT NEW.run, {G("'born'")}, NULL, {G("'deduce'")}, NEW.word, NEW.word WHERE EXISTS (SELECT 1 FROM formula WHERE word = 'deduce' AND ended = 0) AND NOT EXISTS (SELECT 1 FROM formula WHERE word = NEW.word AND ended = 0);
    END""")
    T(f"""CREATE TRIGGER agree_go AFTER INSERT ON agree BEGIN
      INSERT INTO need (w, n) SELECT w, 1 FROM defword WHERE word = NEW.word AND w IS NOT NULL AND w <> NEW.word AND length(w) > 1 GROUP BY w HAVING count(DISTINCT src) >= 2 AND NOT EXISTS (SELECT 1 FROM formula WHERE word = w AND ended = 0)
        ON CONFLICT(w) DO UPDATE SET n = n + 1;
      {EV('agree', 'NEW.word', 'NEW.run', "'agree'", "'agree: defining words two or more sources share for ' || NEW.word || ': ' || coalesce((SELECT group_concat(w, ', ') FROM (SELECT w FROM defword WHERE word = NEW.word AND w IS NOT NULL AND w <> NEW.word AND length(w) > 1 GROUP BY w HAVING count(DISTINCT src) >= 2 LIMIT 14)), 'none')", 'READ COMPARE WRITE', where="EXISTS (SELECT 1 FROM definition WHERE word = NEW.word AND src <> 'node')")}
    END""")
    # derive and deduce fired at born need a formula row named as the word, and gates for them; the trig gate must exist
    # (created on first teach; until then the fire row names a gate that is NULL and nothing fires)

    # ---- end: a branch hands back to the run that fired it; a line writes its receipt, makes sense, memory, timeline, say
    proc_receipt = "(SELECT group_concat(x, ' ') FROM (SELECT r.gate || ':s' || r.shard AS x FROM receipt r WHERE r.run = NEW.run ORDER BY r.id))"
    alt = (f"mother('SELECT trigger FROM g' || (SELECT fgate FROM run WHERE id = NEW.run) || ' WHERE trigger IS NOT NULL AND trigger <> ' || "
           f"{G('(SELECT word FROM run WHERE id = NEW.run)')} || ' AND shard IS NOT ' || coalesce((SELECT fshard FROM run WHERE id = NEW.run), 'NULL') || ' LIMIT 1', NULL, NULL)")
    T(f"""CREATE TRIGGER end_branch AFTER INSERT ON "end" WHEN (SELECT kind FROM run WHERE id = NEW.run) = 'formula' BEGIN
      UPDATE run SET t1 = {NOW} WHERE id = NEW.run;
      {EV('substitute', '(SELECT word FROM run WHERE id = NEW.run)', 'NEW.run', 'NULL', "'substitution: the cells plug into ' || (SELECT word FROM run WHERE id = NEW.run) || '''s formula and it ran. ' || CASE WHEN (SELECT failed FROM run WHERE id = NEW.run) = 1 THEN 'An ask came back without what it needed.' ELSE 'Every ask came back with what it asked for.' END", 'READ WRITE')}
      INSERT INTO procrun (word, receipt) VALUES ((SELECT word FROM run WHERE id = NEW.run), {proc_receipt});
      UPDATE proc SET uses = uses + 1, status = CASE WHEN status = 'taught' AND (SELECT count(*) FROM procrun p WHERE p.word = proc.word AND p.receipt = {proc_receipt}) >= 3 THEN 'learned' WHEN status = 'learned' THEN 'automated' ELSE status END WHERE word = (SELECT word FROM run WHERE id = NEW.run);
      INSERT INTO stepq (run, alt) SELECT NEW.run, {alt} WHERE (SELECT failed FROM run WHERE id = NEW.run) = 1 AND (SELECT fgate FROM run WHERE id = NEW.run) IS NOT NULL AND (SELECT fshard FROM run WHERE id = NEW.run) IS NOT NULL;
    END""")
    T("CREATE TABLE stepq (id INTEGER PRIMARY KEY, run INTEGER, alt INTEGER)")
    T(f"""CREATE TRIGGER step_back AFTER INSERT ON stepq BEGIN
      {EV('stepback', W('(SELECT fgate FROM run WHERE id = NEW.run)'), '(SELECT parent FROM run WHERE id = NEW.run)', W('(SELECT fgate FROM run WHERE id = NEW.run)'), "'step back: ' || (SELECT word FROM run WHERE id = NEW.run) || ' asked and the check failed. The run steps back to ' || " + W('(SELECT fgate FROM run WHERE id = NEW.run)') + " || ' and takes its other row, whose trigger is ' || " + W('NEW.alt'), 'FIND COMPARE MOVE', where='NEW.alt IS NOT NULL')}
      INSERT INTO fire (run, gate, shard, trig, rest) SELECT (SELECT parent FROM run WHERE id = NEW.run), (SELECT fgate FROM run WHERE id = NEW.run), NULL, NEW.alt, (SELECT rest FROM input WHERE id = (SELECT input FROM run WHERE id = NEW.run)) WHERE NEW.alt IS NOT NULL;
      INSERT INTO gap (run, need, fill, who, word, kind) SELECT (SELECT root FROM run WHERE id = NEW.run), 'another way to ask what ' || (SELECT word FROM run WHERE id = NEW.run) || ' asked', {W('(SELECT fgate FROM run WHERE id = NEW.run)')} || ' has no other row with a trigger', 'us, or the brain once it learns one', NULL, 'stepback' WHERE NEW.alt IS NULL;
    END""")
    # the end of a teaching run: the old row of that word is ended, a new row points at this run; its receipt is kept as a memory
    T(f"""CREATE TRIGGER end_teach AFTER INSERT ON "end" WHEN (SELECT kind FROM run WHERE id = NEW.run) = 'teach' BEGIN
      UPDATE run SET t1 = {NOW} WHERE id = NEW.run;
      UPDATE formula SET ended = 1 WHERE word = (SELECT word FROM run WHERE id = NEW.run) AND ended = 0;
      INSERT INTO memory (list, line, direction, receipt, output, answer, mark, first, last, run) SELECT gates, line, direction, {proc_receipt}, NULL, NULL, 'told', {NOW}, {NOW}, NEW.run FROM run WHERE id = NEW.run;
      UPDATE run SET memid = (SELECT max(id) FROM memory) WHERE id = NEW.run;
      INSERT INTO formula (word, run, origin, t) VALUES ((SELECT word FROM run WHERE id = NEW.run), NEW.run, 'told', {NOW});
    END""")
    # 17.2: a returned definition's end. The source is the one source gate its own run passed (read from its receipt).
    src_of = "(SELECT e.word FROM receipt r JOIN encoder e ON e.gate = r.gate WHERE r.run = NEW.run AND e.role = 'sat' ORDER BY r.id LIMIT 1)"
    T(f"""CREATE TRIGGER end_return AFTER INSERT ON "end" WHEN (SELECT kind FROM run WHERE id = NEW.run) = 'defrow' BEGIN
      UPDATE run SET t1 = {NOW} WHERE id = NEW.run;
      INSERT INTO memory (list, line, direction, receipt, output, answer, mark, first, last, run) SELECT gates, line, direction, {proc_receipt}, NULL, NULL, 'definition from ' || coalesce({src_of}, '?'), {NOW}, {NOW}, NEW.run FROM run WHERE id = NEW.run;
      UPDATE run SET memid = (SELECT max(id) FROM memory) WHERE id = NEW.run;
      INSERT INTO var (run, name, value, src, t) SELECT parent, coalesce({src_of}, '?') || ' ' || coalesce(subject, ''), (SELECT max(id) FROM memory), 'return', {NOW} FROM run WHERE id = NEW.run AND parent IS NOT NULL;
      {EV('memory', "'memory'", 'NEW.run', "'memory'", "'memory: new row ' || (SELECT max(id) FROM memory) || ', the definition of ' || coalesce((SELECT subject FROM run WHERE id = NEW.run), '?') || ' from ' || coalesce(" + src_of + ", '?') || '; the run that asked holds a cell pointing at it'", '', a='(SELECT line FROM run WHERE id = NEW.run)', b='(SELECT max(id) FROM memory)')}
    END""")
    # a line's end
    outq = ("(SELECT group_concat(x, ' ') FROM (SELECT e.word || CASE WHEN e.role IN ('word', 'literal') AND NOT EXISTS (SELECT 1 FROM formula WHERE word = e.word AND ended = 0) AND e.word <> '?' THEN '?' ELSE '' END AS x "
            "FROM receipt r JOIN encoder e ON e.gate = r.gate WHERE r.run = NEW.run ORDER BY r.id))")
    answer = "(SELECT value FROM var WHERE run = NEW.run AND name = 'output' ORDER BY id DESC LIMIT 1)"
    T(f"""CREATE TRIGGER end_line AFTER INSERT ON "end" WHEN (SELECT kind FROM run WHERE id = NEW.run) = 'line' BEGIN
      {EV('end', "'end'", 'NEW.run', "'end'", "'end: receipt ' || coalesce(" + proc_receipt + ", '') || '. ' || (SELECT count(*) FROM run WHERE parent = NEW.run) || ' branch run(s) wrote against this run.'", 'READ JOIN WRITE')}
      INSERT INTO "BUILD" (run, text) SELECT NEW.run, trim(substr(line, 7, length(line) - 12)) FROM run WHERE id = NEW.run AND build = 1;
      UPDATE run SET output = CASE WHEN build = 1 THEN coalesce((SELECT CASE WHEN s.err IS NOT NULL THEN 'error: ' || s.err WHEN s.n > 0 THEN s.value ELSE 'ok' END FROM secondary s WHERE s.run = NEW.run AND s.last = 1 ORDER BY s.id DESC LIMIT 1), 'ok') ELSE coalesce({answer}, {outq}) END WHERE id = NEW.run;
      UPDATE run SET mark = CASE WHEN expected IS NOT NULL THEN (CASE WHEN output = expected THEN 'right' ELSE 'wrong' END)
        WHEN EXISTS (SELECT 1 FROM memory WHERE list = run.gates AND direction = run.direction) THEN (CASE WHEN (SELECT output FROM memory WHERE list = run.gates AND direction = run.direction ORDER BY id DESC LIMIT 1) = output THEN 'balanced' ELSE 'shift' END) ELSE 'unchecked' END WHERE id = NEW.run;
      UPDATE proc SET right = right + ((SELECT mark FROM run WHERE id = NEW.run) = 'right'), wrong = wrong + ((SELECT mark FROM run WHERE id = NEW.run) = 'wrong') WHERE (SELECT expected FROM run WHERE id = NEW.run) IS NOT NULL AND word IN (SELECT word FROM run WHERE root = NEW.run AND kind = 'formula');
      UPDATE var SET src = src || '; the run came out wrong, so this may not have been what was needed' WHERE sense IS NOT NULL AND run IN (SELECT id FROM run WHERE root = NEW.run) AND (SELECT mark FROM run WHERE id = NEW.run) = 'wrong';
      {EV('sense', "'sense'", 'NEW.run', "'sense'", "'makes sense: proposed " + DQ + "' || (SELECT output FROM run WHERE id = NEW.run) || '" + DQ + ". ' || CASE WHEN (SELECT expected FROM run WHERE id = NEW.run) IS NOT NULL THEN 'expected " + DQ + "' || (SELECT expected FROM run WHERE id = NEW.run) || '" + DQ + ": ' ELSE '' END || (SELECT mark FROM run WHERE id = NEW.run) || CASE WHEN (SELECT mark FROM run WHERE id = NEW.run) = 'wrong' THEN '. The failed try stays in memory as wrong; the expected output is kept with it, so next time the hop answers it.' ELSE '' END", 'COMPARE FIND')}
      UPDATE memory SET ended = 1 WHERE list = (SELECT gates FROM run WHERE id = NEW.run) AND direction = (SELECT direction FROM run WHERE id = NEW.run) AND ended = 0 AND (SELECT build FROM run WHERE id = NEW.run) = 0;
      INSERT INTO memory (list, line, direction, receipt, output, answer, mark, first, last, run, prevgates) SELECT gates, line, direction, {proc_receipt}, CASE WHEN mark = 'wrong' THEN expected ELSE output END, expected, mark, {NOW}, {NOW}, NEW.run, {prev_of('NEW.run')} FROM run WHERE id = NEW.run AND build = 0;
      UPDATE run SET memid = (SELECT max(id) FROM memory), t1 = {NOW} WHERE id = NEW.run AND build = 0;
      {EV('memory', "'memory'", 'NEW.run', "'memory'", "'memory: new row ' || (SELECT max(id) FROM memory) || ' (' || (SELECT mark FROM run WHERE id = NEW.run) || ')'", 'FIND COMPARE WRITE', where='(SELECT build FROM run WHERE id = NEW.run) = 0', a='(SELECT line FROM run WHERE id = NEW.run)', b='(SELECT max(id) FROM memory)')}
      INSERT INTO timeline (t, mem, run) SELECT {NOW}, (SELECT memid FROM run WHERE id = NEW.run), NEW.run WHERE (SELECT build FROM run WHERE id = NEW.run) = 0;
      {EV('timeline', "'timeline'", 'NEW.run', "'timeline'", "'timeline: row ' || (SELECT max(id) FROM timeline) || ' (memory ' || (SELECT memid FROM run WHERE id = NEW.run) || ')'", 'CLOCK WRITE', where='(SELECT build FROM run WHERE id = NEW.run) = 0', a='(SELECT memid FROM run WHERE id = NEW.run)')}
      INSERT INTO output (run, text) VALUES (NEW.run, (SELECT output FROM run WHERE id = NEW.run));
      {EV('say', "'say'", 'NEW.run', "'OUTPUT'", "'say: ' || coalesce((SELECT output FROM run WHERE id = NEW.run), '') || CASE WHEN (SELECT mark FROM run WHERE id = NEW.run) = 'wrong' THEN ' (corrected to " + DQ + "' || (SELECT expected FROM run WHERE id = NEW.run) || '" + DQ + " for next time)' ELSE '' END", 'READ SAY')}
      {EV('gaps', "'gaps'", 'NEW.run', 'NULL', "'this run needed ' || (SELECT count(*) FROM gap WHERE run = NEW.run) || ' thing(s) it did not have'", '', where='EXISTS (SELECT 1 FROM gap WHERE run = NEW.run)')}
    END""")
    # 17.2: a test's end: what it said, against what the brain remembers saying for the same line (balanced, shift, no memory)
    T(f"""CREATE TRIGGER end_test AFTER INSERT ON "end" WHEN (SELECT kind FROM run WHERE id = NEW.run) = 'test' BEGIN
      UPDATE run SET t1 = {NOW}, output = coalesce({answer}, {outq}) WHERE id = NEW.run;
      INSERT INTO var (run, name, value, src, t) SELECT coalesce((SELECT root FROM run WHERE id = r.parent), r.parent), ':test', CASE WHEN m.id IS NULL THEN 'no memory' WHEN coalesce(m.output, '') = coalesce(r.output, '') THEN 'balanced' ELSE 'shift' END || ': ' || coalesce(r.output, ''), 'test', {NOW}
        FROM run r LEFT JOIN memory m ON m.id = (SELECT max(id) FROM memory WHERE list = r.gates AND direction = 'heard' AND ended = 0 AND mark <> 'told') WHERE r.id = NEW.run AND r.parent IS NOT NULL;
      {EV('test', "'test'", 'NEW.run', "'test'", "'test: ' || (SELECT line FROM run WHERE id = NEW.run) || ' ran again the long way and said ' || coalesce(quote((SELECT output FROM run WHERE id = NEW.run)), 'nothing')", '')}
    END""")
    # a word in a line that the run passes and that has no formula: the run needed it (a hop trigger writes the hit; this notes the gap once per run)
    T(f"""CREATE TRIGGER receipt_gap AFTER INSERT ON receipt WHEN (SELECT kind FROM run WHERE id = NEW.run) = 'line' AND (SELECT role FROM encoder WHERE gate = NEW.gate) = 'word'
        AND NOT EXISTS (SELECT 1 FROM formula WHERE word = {W('NEW.gate')} AND ended = 0) AND NOT EXISTS (SELECT 1 FROM gap WHERE run = NEW.run AND word = {W('NEW.gate')} AND kind = 'word') BEGIN
      INSERT INTO gap (run, need, fill, who, word, kind) VALUES (NEW.run, 'a meaning for ' || {W('NEW.gate')}, 'it does nothing when a run passes it. A formula: typed, or found by the brain through derive', 'the brain through derive; else us', {W('NEW.gate')}, 'word');
      {EV('gap', W('NEW.gate'), 'NEW.run', 'NULL', W('NEW.gate') + " || ': the run passes it and nothing happens. No formula. A broken word.'", '')}
    END""")
    # BUILD: the words between hand their SQL to mother, through output to sources
    T("""CREATE TRIGGER build_go AFTER INSERT ON "BUILD" BEGIN
      INSERT INTO stmt (run, text) VALUES (NEW.run, NEW.text);
    END""")
    T(f"""CREATE TRIGGER state_written AFTER INSERT ON state BEGIN
      {EV('state', "'state'", '(SELECT max(id) FROM run)', "'state'", "'state: ' || coalesce(NEW.key, 'NULL') || ' = ' || coalesce(quote(NEW.value), 'NULL') || '. A formula wrote it; the brain holds it now.'", 'WRITE', a='NEW.key')}
    END""")
    T(f"""CREATE TRIGGER place_written AFTER INSERT ON place BEGIN
      UPDATE place SET ended = 1 WHERE word = NEW.word AND id < NEW.id AND ended = 0;
      {EV('place', 'NEW.word', '(SELECT max(id) FROM run)', "'place'", "'place: ' || NEW.word || ' at ' || NEW.x || ', ' || NEW.y || ', ' || NEW.z || '. An older place of this word, if any, is kept as history.'", '', a='NEW.word', b="NEW.x || ',' || NEW.y || ',' || NEW.z")}
    END""")
    T(f"""CREATE TRIGGER proc_status AFTER UPDATE OF status ON proc WHEN NEW.status <> OLD.status BEGIN
      {EV('learned', 'NEW.word', '(SELECT max(id) FROM run)', "'formula'", "NEW.word || CASE NEW.status WHEN 'learned' THEN ' has three memories of the same receipt: learned.' WHEN 'automated' THEN ' ran again after learned: automated.' ELSE ' is ' || NEW.status END", 'COMPARE WRITE', a='NEW.status')}
    END""")
    # ---- the source neuron's told formula: every connected source (owner, NOW spec: every source we can think of is connected in turn one)
    body = ' '.join(f"INSERT INTO {s}.inbox ( word ) VALUES ( :subject ) ;" for s in sat_names)
    T(f"INSERT INTO input (line, direction) VALUES ({lit('source = ' + body)}, 'heard')")
    return out

if __name__ == '__main__':
    stmts = build(SATS)
    open(sys.argv[1], 'w').write(json.dumps({'statements': stmts, 'physics': PHYSICS, 'actions': ACTIONS, 'sqlroots': SQLROOTS, 'arrivals': ARRIVALS, 'ports': PORTS, 'sats': SATS}))
    print(len(stmts), 'statements in the told block')
