# Point Of Connection 17.2 = 17.1 with the 17.2 told block (returned answers as runs headed by modifiers, filling the asking run's data
# sheet; definition memories; test runs; sources as neurons; no command fires inside a returned answer) and the command sheet.
# 17.1 = 17 (16.4 with the measured tab) + the 17.1 told block (a 3D place table, the measured source), the
# rebuilt SQL docs source, and a teaching sheet. 17 = 16.4 with one tab added to the left sidebar ("measured"). Every change below is an exact replacement
# on a copy of 16.4's sources, checked to match once; nothing of 16.4 is removed. usage: make17.py <16.4 sources root> <t23 dir>
import json, os, shutil, subprocess, sys, hashlib
R, T = sys.argv[1], sys.argv[2]
D16, D17 = R + '/v16', R + '/v172'
if os.path.exists(D17): shutil.rmtree(D17)
shutil.copytree(D16, D17)
shutil.copy(T + '/physics172.json', D17 + '/physics16.json'); shutil.copy(T + '/sat172.json', D17 + '/sat15.json')   # 17.2's told block and sources
def patch(name, pairs):
    p = D17 + '/' + name; s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        assert s.count(old) == 1, (name, old[:80], s.count(old)); s = s.replace(old, new)
    open(p, 'w', encoding='utf-8').write(s)

# ---- head: styles for the tabs and the measured panel
patch('head15.html', [('</style>', """  .tabs { position: sticky; top: 0; z-index: 2; display: flex; gap: 4px; padding: 8px 14px 0; background: var(--panel); border-bottom: 1px solid var(--line); }
  .tabs button { border-bottom-left-radius: 0; border-bottom-right-radius: 0; margin-bottom: -1px; }
  .tabs button[aria-selected="true"] { background: var(--bg); color: var(--accent); border-bottom-color: var(--bg); }
  .inner[hidden] { display: none; }
  .mkinds { display: grid; grid-template-columns: auto 10px minmax(0, 1fr) auto; gap: 6px 7px; align-items: center; font-size: .8rem; }
  .mkinds .sw { width: 10px; height: 10px; border-radius: 2px; } .mkinds .n { color: var(--muted); text-align: right; font-variant-numeric: tabular-nums; } .mkinds .m, .maxes .m, #mlast .m, #msum .m { color: var(--muted); font-size: .74rem; }
  .maxes { display: grid; grid-template-columns: auto minmax(0, 1fr); gap: 5px 8px; align-items: center; font-size: .8rem; } .maxes select { min-width: 0; max-width: 100%; }
  .mlist { font-family: var(--mono); font-size: .72rem; max-height: 220px; overflow-y: auto; overscroll-behavior: contain; border: 1px solid var(--line); border-radius: 5px; background: var(--bg); }
  .mlist div { padding: 3px 7px; border-bottom: 1px solid var(--line); display: grid; grid-template-columns: 2.2em minmax(0, 1fr) auto; gap: 6px; cursor: pointer; } .mlist div.last { background: var(--panel2); } .mlist .m { color: var(--muted); }
  #mlast, #msum { font-size: .8rem; line-height: 1.45; overflow-wrap: anywhere; }
  #panelm select { max-width: 100%; min-width: 0; }
</style>""")])

# ---- body: the header, the tabs, the measured panel, the table of measured points
MEASURED = """  </div>
  <div class="inner" id="panelm" hidden>
    <section>
      <h2>Measured: the bare core</h2>
      <label class="chk"><input type="checkbox" id="mview"> show the measured view on the stage</label>
      <div class="row"><label for="mfrom" class="note">places from</label><select id="mfrom"><option value="lab" selected>the lab (measured outside the brain)</option><option value="brain">the brain's own place table</option></select></div>
      <p class="note">The stage then shows only origin and the SQL words you add, each placed by numbers measured in SQLite. Turn it off and the 16.4 view is back, as it was. Runs are drawn in the 16.4 view; the brain is not changed by anything here.</p>
      <div class="row"><button id="madd" type="button">add the next word</button><button id="mall" type="button">add all</button><button id="mback" type="button">take the last off</button><button id="mnone" type="button">none</button><button id="mfit" type="button">fit</button></div>
      <label class="chk"><input type="checkbox" id="mnottold"> also the words that are not told (DROP, substr, &lt;&gt;, !=, &gt;=, &lt;=, +, -, /, EXCEPT)</label>
      <div id="msum" class="note"></div>
      <div id="mlast"></div>
      <div class="mlist" id="mlist"></div>
      <p class="note">Words come in the told block's own order. A spelling that measured two different jobs is two points (AS, INTEGER, =, *), as one meaning is one gate.</p>
    </section>
    <section>
      <h2>Axes: what each line through origin measures</h2>
      <div class="maxes"><label for="max">x</label><select id="max"></select><label for="may">y</label><select id="may"></select><label for="maz">z</label><select id="maz"></select></div>
      <p class="note">rows, structure and text are measured by running the word's line: a row written or removed, a table made or destroyed, text joined (longer, holding what went in) or cut (shorter). Each pair undoes the other. read, test, number, gather and write count the steps of SQLite's program the word adds over the same line without it; they have one end only. One unit of a number is 10 brain units.</p>
    </section>
    <section>
      <h2>Lines between words: each kind a test</h2>
      <div class="mkinds" id="mkinds"></div>
      <div class="row"><label for="mrule" class="note">a point with lines sits</label><select id="mrule"><option value="share" selected>in proportion</option><option value="sum">each line pulls 1 (tried first)</option></select></div>
      <div class="row"><label for="mpull" class="note">how much its lines pull</label><input type="range" id="mpull" min="0" max="0.95" step="0.05" value="0.5" aria-label="how much its lines pull"><span class="n" id="mpullv">0.50</span></div>
      <p class="note">With every kind off, a point's place is its measured numbers, read straight off the axes. Turn a kind on and the points it ties are drawn together: in proportion, a point keeps (1 - pull) of its own place and its lines share the rest equally, however many it has. Each line pulls the same; no numbers of mine are in the lines. Nothing else moves a point: no random start, no spacing push, no step cap, no compass directions, no across rule. The answer is the same whatever the start.</p>
    </section>
    <section>
      <h2>Teaching sheet: type these at the prompt, in order</h2>
      <p class="note">Click a line and it goes into the prompt on the right; press run. First nine taught formulas (learn:, define:, run:, test:, build:, meaning:, print:, backpop:, place:), then nine binds: each command fires only on the row its key lands on ("learn : -> learn:" fires learn: when a line starts "learn :"), so the word learn anywhere else fires nothing. Then the commands. What each command does is the builder's reading of your names; every one is a taught line you can retype. A source's answer comes back as a run "return from (the line) from (source) /build (definition)"; its end writes the word's definition memory and a cell in the asking run's data sheet. A line typed a second time is answered from memory. Learning is slow: a command line can take a minute.</p>
      <div class="mlist" id="tsheet"></div>
      <p class="note">Then choose "the brain's own place table" above: the stage shows the places the brain wrote, each by its own run.</p>
    </section>
    <section>
      <h2>Where it lives</h2>
      <p class="note">In SQLite: a lab database of its own beside the brain, in the same worker (tables point, effect, line, axis, added, place, and the view own). The page solves the places with the rule above and writes them into place; the stage, the table and Selected read them back from SQLite. The brain's told block and tables are unchanged. The numbers and lines were measured by rel.js in this same SQLite (3.39.3) on 2026-10-24; the files say how to run it again.</p>
      <div class="row"><button id="mtable" type="button">table of the measured points</button></div>
    </section>
  </div></aside>"""
patch('body16.html', [
  ("""<p>A new model beside the old ones, which are unchanged so you can diff them: <a href="https://claude.ai/artifact/28rFWxBVwbet45wsBvL3FY" target="_blank" rel="noopener">version 15</a>, <a href="https://claude.ai/artifact/9KFJZ47mfN7paofdBRNFNx" target="_blank" rel="noopener">version 14</a>, <a href="https://claude.ai/artifact/F2G46EYz84HMbzUY6Zkt4C" target="_blank" rel="noopener">version 13.1</a>. The one placed point is origin, at the center; every other point sits only where its relationship lines pull it. A formula is a pointer to the run that taught it, never stored text.</p>""",
   """<p>Built from <a href="https://claude.ai/artifact/Sq4JLW46oPHRfVtH52qJn6" target="_blank" rel="noopener">version 16.4</a>, which is unchanged so you can diff them; everything of 16.4 is here as it was (<a href="https://claude.ai/artifact/FFMoNrSYyPM5c246xny4nM" target="_blank" rel="noopener">16.9</a> holds the pull layouts). New in 17.2: the commands learn, define, run, test, build, find meaning, print run, run backpop (teaching sheet, measured tab); a source's answer comes back to the brain as a run that fills the asking run's data sheet. New in 17: the <b>measured</b> tab on the left. New in 17.1: a 3D place table in the brain, a measured source and a rebuilt SQL docs source, and a teaching sheet: the brain is taught to define and place words at the prompt, and writes their places itself. The one told place is origin.</p>"""),
  ("""  <aside class="left" aria-label="Graph lines"><div class="inner">""",
   """  <aside class="left" aria-label="Graph lines"><div class="tabs" role="tablist"><button type="button" role="tab" id="tabg" aria-selected="true">graph (16.4)</button><button type="button" role="tab" id="tabm" aria-selected="false">measured</button></div><div class="inner" id="panelg">"""),
  ("""      </ul>
    </section>
  </div></aside>""", """      </ul>
    </section>
""" + MEASURED),
  ("""    <div class="hud" id="hud">""", """    <div class="atlas" id="labt" hidden>
      <div class="atop"><b>The measured points: numbers, lines and places, read from SQLite</b><input type="text" id="lfind" placeholder="find a label" autocomplete="off" spellcheck="false"><span class="m" id="lshown"></span><button id="lclose" type="button">close</button></div>
      <div class="asum" id="lsum"></div>
      <div class="atw"><table id="ltable"></table></div>
    </div>
    <div class="hud" id="hud">"""),
  ("""var TOLD = /*TOLD*/null, SAT = /*SAT*/null, SLICE = /*SLICE*/null, READINGS = /*READINGS*/null, MAP = /*MAPFULL*/null;""",
   """var TOLD = /*TOLD*/null, SAT = /*SAT*/null, SLICE = /*SLICE*/null, READINGS = /*READINGS*/null, MAP = /*MAPFULL*/null, LAB = /*LABDATA*/null, SHEET = /*SHEET*/null;""")])

# ---- worker: the lab database, its own, beside the brain
patch('worker16.js', [
  ("var brain = null, TOLD = null, SAT = null, LINES = [], SNAPS = [], lastEvent = 0, KEEP = 24;", "var brain = null, TOLD = null, SAT = null, LINES = [], SNAPS = [], lastEvent = 0, KEEP = 24, LABDB = null;"),
  ("""    } else if (d.type === 'restart') {""", """    } else if (d.type === 'lab') {
      // the lab (17): its own SQLite database beside the brain, never attached to it, so the brain's snapshots and restarts leave it alone
      if (!LABDB) LABDB = new SQLMOD.Database();
      var outl = d.ops.map(function (o) {
        if (o[2] === 'many') { var st = LABDB.prepare(o[0]); o[1].forEach(function (p) { st.run(p); }); st.free(); return []; }
        var r = LABDB.exec(o[0], o[1]); return r.length ? r[r.length - 1].values : [];
      });
      postMessage({ type: 'answer', id: d.id, rows: outl });
    } else if (d.type === 'restart') {""")])

# ---- main: the measured block, and four small hooks in 16.4's drawing
ui = open(T + '/lab-ui171.js', encoding='utf-8').read()
patch('main16.js', [
  ("""    if (d.type === 'ready') { absorb(d.bundle); ready = true; fitLeft = 240; setBusy(''); if (d.restarted) { clearScene(); } render(EV.length - 1); return; }""",
   """    if (d.type === 'ready') { absorb(d.bundle); ready = true; fitLeft = 240; setBusy(''); if (d.restarted) { clearScene(); } render(EV.length - 1); labInit(); return; }"""),
  ("""    var r = 30; Object.keys(NODE).forEach(function (w) { var n = NODE[w]; if (n.mesh && n.mesh.visible) r = Math.max(r, n.pos.length()); });""",
   """    var r = 30; if (MVIEW) r = Math.max(10, labMaxR()); else Object.keys(NODE).forEach(function (w) { var n = NODE[w]; if (n.mesh && n.mesh.visible) r = Math.max(r, n.pos.length()); });"""),
  ("""      [['+' + ax[2], L], ['-' + ax[2], -L]].forEach(function (lb) { var s = makeLabel(lb[0], col, 14, true);""",
   """      [[axName(ax[2], 1), L], [axName(ax[2], -1), -L]].forEach(function (lb) { var s = makeLabel(lb[0], col, 14, true); s.userData.text = lb[0];"""),
  ("""flash.geometry = flashGeo; flash.visible = fp.length > 0;""", """flash.geometry = flashGeo; flash.visible = fp.length > 0 && !MVIEW;"""),
  ("""      busy = false; setBusy((d.of > 1 ?""", """      if (MVIEW && LFROM === 'brain') labUpdate();
      busy = false; setBusy((d.of > 1 ?"""),
  ("""  var SATNAME = { wn: 'WordNet', gcide: 'Webster 1913', mw: 'MW Collegiate', mwt: 'MW thesaurus', moby: 'Moby', map: 'your map', sqldoc: 'SQLite docs' };""", """  var SATNAME = { wn: 'WordNet', gcide: 'Webster 1913', mw: 'MW Collegiate', mwt: 'MW thesaurus', moby: 'Moby', map: 'your map', sqldoc: 'SQLite docs', measured: 'measured (steps 2, 3)' };"""),
  ("""  // ---- camera, pointer, frame""", ui + """
  // ---- camera, pointer, frame"""),
  ("""  if (hasGL) {
    var canvas = $('c'), ptrs = {}""", """  window.__poc.lab = LABHOOK;
  if (hasGL) {
    var canvas = $('c'), ptrs = {}"""),
  ("""ray.setFromCamera(v, camera); var hit = ray.intersectObjects(dotGroup.children.filter(function (m) { return m.visible; }), false);""",
   """ray.setFromCamera(v, camera); if (MVIEW) { var lh = ray.intersectObjects(labGroup.children.filter(function (m) { return m.visible && m.type === 'Mesh'; }), false); if (lh.length) { showLab(lh[0].object.userData.lab); return; } clearSel(); return; } var hit = ray.intersectObjects(dotGroup.children.filter(function (m) { return m.visible; }), false);"""),
  ("""var rs = []; Object.keys(NODE).forEach(function (w) { var n = NODE[w]; if (n.mesh && n.mesh.visible) rs.push(n.pos.length() * SP); });""",
   """var rs = []; if (MVIEW) rs = labRadii(); else Object.keys(NODE).forEach(function (w) { var n = NODE[w]; if (n.mesh && n.mesh.visible) rs.push(n.pos.length() * SP); });"""),
  ("""redrawLines(); drawAxes(false);""", """redrawLines(); labFrame(); drawAxes(false);""")])

# ---- build with 16.4's own build script, then put the lab's data and the place rule in
out = subprocess.run([sys.executable, '-I', D17 + '/build16.py', D17, R, '17.2'], capture_output=True, text=True); print(out.stdout.strip(), out.stderr.strip())
page = D17 + '/point-of-connection-17.2.html'; h = open(page, encoding='utf-8').read()
lab = open(T + '/lab.json', encoding='utf-8').read(); place = open(T + '/lab17.js', encoding='utf-8').read().replace("if (typeof module !== 'undefined') module.exports = LabPlace;", '')
for bad in ('</script', '<!--'): assert bad not in lab and bad not in place and bad not in ui, bad
sheet = open(T + '/sheet172.json', encoding='utf-8').read(); assert '</script' not in sheet
assert h.count('/*LABDATA*/null') == 1 and h.count('  /*LABPLACE*/') == 1 and h.count('/*SHEET*/null') == 1
h = h.replace('/*LABDATA*/null', lab, 1).replace('  /*LABPLACE*/', place, 1).replace('/*SHEET*/null', sheet, 1)
open(page, 'w', encoding='utf-8').write(h)
print('17.2:', len(h.encode()), 'bytes; sha', hashlib.sha256(h.encode()).hexdigest()[:12])
