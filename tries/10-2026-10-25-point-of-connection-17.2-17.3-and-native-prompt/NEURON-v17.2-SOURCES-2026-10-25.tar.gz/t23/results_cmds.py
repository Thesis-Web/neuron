import json
E = lambda s: str(s).replace('|', '\\|')
a = json.load(open('cmds172.json')); b = json.load(open('cmds172b.json')); B = json.load(open('shot172.out.json')); sheet = json.load(open('sheet172.json'))
cmd = lambda d: [l for l in d['lines'] if not l['label'].startswith(('teach', 'bind'))]
L = ['# Commands results: learn, define, run, test, build, find meaning, print run, run backpop (2026-10-25)',
 'Predictions frozen at 01:37 before any run: NEURON-COMMANDS-EXPECT-2026-10-25.md (sha256 7608171ab907...); learn : X predictions written at 01:07: NEURON-LEARN-EXPECT-2026-10-25.md (5fa24157dcdc...).',
 'Run in node on the page\'s real brain code (worker16.js, host15.js, sql.js 3.39.3): run 1 as built, run 2 after two fixes. Then typed through the page 17.2 prompt in a real browser.', '',
 '## The 17.2 told block (5 changes over 17.1; every change is in TOLD-BLOCK-17.2.sql)',
 '1. A returned definition runs as a line headed by modifier gates: "return from <the asking line> from <source> /build <definition>".',
 '2. Its end writes the word\'s definition memory ("definition from <source>") and a cell "<source> <word>" = that memory\'s id in the asking run\'s data sheet.',
 '3. A run of kind test is its own root, runs the long way, and its end writes ":test" = balanced / shift / no memory into the asking run\'s sheet.',
 '4. The source gates are neurons (table, view, miss trigger). Found in testing: the header put a source\'s gate in the run, and the sources were names only ("no such table: land_79"); every line failed until this.',
 '5. Inside a returned answer\'s run, a row\'s trigger column does not fire (returned information is not a command). Added after run 1, where print: and meaning: fired 8 times each inside returns.', '',
 '## Run 1 and run 2 (node), command lines', '', '| Line | Predicted | Run 1 said | Run 2 said |', '|---|---|---|---|']
P = {'learn : store': '8', 'print run :': 'the path and the data sheet', 'define : store': "WordNet's first sense", 'build : store': '16', 'find meaning : store': 'store place none definitions 16 formula none',
 'learn : dog': 'count (<= 8)', 'define : dog': "WordNet's first sense", 'learn : INSERT': '2', 'learn : DELETE': '2', 'run backpop': '2 (INSERT, DELETE placed)', 'find meaning : INSERT': 'INSERT place 10,0,0 definitions 2 formula none',
 'test : define : store': 'balanced: (the definition)', 'run : define : store': 'the definition (from memory)', 'learn : zork': '0'}
for x, y in zip(cmd(a), cmd(b)):
    L.append(f"| `{E(x['label'])}` | {E(P.get(x['label'], ''))} | {E(str(x['said'])[:70])} | {E(str(y['said'])[:70])}{' (memory)' if y.get('recalled') else ''} |")
L += ['', '### Against the predictions',
 '- Held: learn : store (8), print run :, define : store, find meaning : store, learn : dog (8), define : dog, learn : DELETE (2), run backpop (2 places: INSERT 10,0,0 and DELETE -10,0,0), find meaning : INSERT (place 10,0,0), test : define : store (balanced), learn : zork (0).',
 '- build : store: run 1 said nothing; it had computed 16 but the line stopped after the formula. Cause: the formula fires in the middle of the line\'s hop and spawns return runs whose header ("return from build : store") laid the DNA row the line needed next; a trigger laid mid-run fires only for a later statement (the reference\'s Appendix B, fact 4), so the line found the row and could not see its hop trigger. Fixed in build:\'s taught line (its header leaves out the ":"); run 2 said 16.',
 '- learn : INSERT said 5, not 2: your relation map source holds 3 rows for INSERT. My prediction missed that source.',
 '- run : define : store said "run? : define? : store?", not the definition: the sub-line was answered from memory, but its answer does not carry up to the line that asked. Open: should a sub-line\'s answer be the asking line\'s answer?',
 '- L5 (no command fires inside a returned answer): failed in run 1 (print: 8, meaning: 8: a three-word key matches its own row inside the header that copies the asking line); held in run 2 after change 5. The told source formula still fired once inside a return, because a definition contained the word "source" (16.4\'s rule: a word\'s own formula fires in definition rows). Yours to decide.',
 '- Not predicted: the command words themselves (learn, define, run, test, meaning, print) were looked up in the dictionaries the first time they were typed, as the told rule does for every new word in a typed line; each now holds 8 English definition memories.', '',
 '## In the page (real browser, typed through the prompt)', '', '| Line | Seconds | The brain said |', '|---|---|---|']
for l in B['lines'][18:]: L.append(f"| `{E(l['line'][:30])}` | {l['s']} | {E(l['said'][:80])} |")
L += ['', f"The 9 formulas and 9 binds were typed the same way (3 to 35 s each). Places in the brain's own place table: " + '; '.join(f"{E(r[0])} {r[1]},{r[2]},{r[3]}" for r in B['brainPlaces']) + ' (only INSERT held measured rows in this pass); the stage drew it from that table.', '',
 '## The taught lines (the teaching sheet; what each command does is the builder\'s reading of the owner\'s names)', '```'] + [r[1] for r in sheet[:18]] + ['```', '',
 '## What this shows, and what it does not',
 '- Shows: commands typed at the prompt, each firing only on the row its key lands on; a source\'s answer coming back as a run headed by the owner\'s modifiers, filling the asking run\'s data sheet with pointers to the word\'s definition memories; the brain reading its own rows to define, print its last run, report a word\'s meaning, re-test a line against memory, build the definitions the told limit skipped, and back-populate places.',
 '- Does not show: understanding or learning in the owner\'s sense. Places still come from the measured source (ours). define says a definition\'s words; it does not reason over them.',
 '- Learning is slow: 6.6 minutes for the 14 command lines in node; a command line takes 20 to 90 s in the page.']
open('RESULTS-CMDS.md', 'w').write('\n'.join(L) + '\n'); print(len(L), 'lines')
