# 17.2 told block = 17.1's plus the two changes in EXPECT-LEARN.md (the owner's learn : X design). Writes gen_physics172.py.
s = open('gen_physics17.py').read()
def rep(old, new):
    global s
    assert s.count(old) == 1, old[:90]; s = s.replace(old, new)
rep("# 17.1 (2026-10-24): 16.4's told block plus two told changes", "# 17.2 (2026-10-25): 17.1 plus the owner's learn : X design: a source's answer comes back as a run headed by modifier gates\n# (return from <the line> from <source> /build <definition>), and its end writes the word's definition memory and a cell in\n# the primary run's data sheet. 17.1 (2026-10-24): 16.4's told block plus two told changes")
# change 1: the returned definition runs as a line headed by the owner's modifiers
rep("""      INSERT INTO input (line, direction, parent, kind, subject) SELECT d.words, NEW.word, NEW.run, 'defrow', NEW.word FROM definition d WHERE d.word = NEW.word AND d.src <> 'node' AND trim(coalesce(d.words, '')) <> '' LIMIT 8;""",
    """      INSERT INTO input (line, direction, parent, kind, subject) SELECT 'return from ' || coalesce((SELECT line FROM run WHERE id = NEW.run), NEW.word) || ' from ' || d.src || ' /build ' || d.words, NEW.word, NEW.run, 'defrow', NEW.word FROM definition d WHERE d.word = NEW.word AND d.src <> 'node' AND trim(coalesce(d.words, '')) <> '' LIMIT 8;""")
# change 2: a return run's end: the word's definition memory, and a pointer to it in the primary run's data sheet
rep("""    # a line's end
    outq = (""", """    # 17.2: a returned definition's end. The source is the one source gate its own run passed (read from its receipt).
    src_of = "(SELECT e.word FROM receipt r JOIN encoder e ON e.gate = r.gate WHERE r.run = NEW.run AND e.role = 'sat' ORDER BY r.id LIMIT 1)"
    T(f\"\"\"CREATE TRIGGER end_return AFTER INSERT ON "end" WHEN (SELECT kind FROM run WHERE id = NEW.run) = 'defrow' BEGIN
      UPDATE run SET t1 = {NOW} WHERE id = NEW.run;
      INSERT INTO memory (list, line, direction, receipt, output, answer, mark, first, last, run) SELECT gates, line, direction, {proc_receipt}, NULL, NULL, 'definition from ' || coalesce({src_of}, '?'), {NOW}, {NOW}, NEW.run FROM run WHERE id = NEW.run;
      UPDATE run SET memid = (SELECT max(id) FROM memory) WHERE id = NEW.run;
      INSERT INTO var (run, name, value, src, t) SELECT parent, coalesce({src_of}, '?') || ' ' || coalesce(subject, ''), (SELECT max(id) FROM memory), 'return', {NOW} FROM run WHERE id = NEW.run AND parent IS NOT NULL;
      {EV('memory', "'memory'", 'NEW.run', "'memory'", "'memory: new row ' || (SELECT max(id) FROM memory) || ', the definition of ' || coalesce((SELECT subject FROM run WHERE id = NEW.run), '?') || ' from ' || coalesce(" + src_of + ", '?') || '; the run that asked holds a cell pointing at it'", '', a='(SELECT line FROM run WHERE id = NEW.run)', b='(SELECT max(id) FROM memory)')}
    END\"\"\")
    # a line's end
    outq = (""")
# change 4: the source gates become neurons (table, view, miss trigger), so a returned answer's run can land on them
rep("""    for role, words in [('port', PORTS), ('sat', sat_names)]:
        for w in words:
            k += 1; T(f"INSERT INTO encoder (gate, word, role, born) VALUES ({k}, {lit(w)}, {lit(role)}, 0)")
""", """    for role, words in [('port', PORTS), ('sat', sat_names)]:
        for w in words:
            k += 1; T(f"INSERT INTO encoder (gate, word, role, born) VALUES ({k}, {lit(w)}, {lit(role)}, 0)")
            if role == 'sat':
                for s2 in gate_objects(k): T(s2)   # 17.2: a source is a neuron too, so a returned answer's run can land on it
""")
# change 5: inside a returned answer's run (defrow), a row's trigger column does not fire: returned information is not a command
rep("""      UPDATE fire SET word = coalesce({W('NEW.trig')}, CASE WHEN""", """      UPDATE fire SET word = coalesce(CASE WHEN (SELECT kind FROM run WHERE id = NEW.run) = 'defrow' THEN NULL ELSE {W('NEW.trig')} END, CASE WHEN""")
rep("""        WHERE NEW.trig IS NOT NULL AND NOT EXISTS (SELECT 1 FROM formula WHERE word = {W('NEW.trig')} AND ended = 0);""", """        WHERE NEW.trig IS NOT NULL AND NOT EXISTS (SELECT 1 FROM formula WHERE word = {W('NEW.trig')} AND ended = 0) AND (SELECT kind FROM run WHERE id = NEW.run) <> 'defrow';""")
# change 3: a test run is its own root, runs the long way (decide checks memory only for typed lines), and its end compares
rep("UPDATE run SET root = CASE WHEN NEW.kind = 'defrow' THEN NEW.id ELSE", "UPDATE run SET root = CASE WHEN NEW.kind IN ('defrow', 'test') THEN NEW.id ELSE")
rep("""    # a word in a line that the run passes and that has no formula""", """    # 17.2: a test's end: what it said, against what the brain remembers saying for the same line (balanced, shift, no memory)
    T(f\"\"\"CREATE TRIGGER end_test AFTER INSERT ON "end" WHEN (SELECT kind FROM run WHERE id = NEW.run) = 'test' BEGIN
      UPDATE run SET t1 = {NOW}, output = coalesce({answer}, {outq}) WHERE id = NEW.run;
      INSERT INTO var (run, name, value, src, t) SELECT coalesce((SELECT root FROM run WHERE id = r.parent), r.parent), ':test', CASE WHEN m.id IS NULL THEN 'no memory' WHEN coalesce(m.output, '') = coalesce(r.output, '') THEN 'balanced' ELSE 'shift' END || ': ' || coalesce(r.output, ''), 'test', {NOW}
        FROM run r LEFT JOIN memory m ON m.id = (SELECT max(id) FROM memory WHERE list = r.gates AND direction = 'heard' AND ended = 0 AND mark <> 'told') WHERE r.id = NEW.run AND r.parent IS NOT NULL;
      {EV('test', "'test'", 'NEW.run', "'test'", "'test: ' || (SELECT line FROM run WHERE id = NEW.run) || ' ran again the long way and said ' || coalesce(quote((SELECT output FROM run WHERE id = NEW.run)), 'nothing')", '')}
    END\"\"\")
    # a word in a line that the run passes and that has no formula""")
open('gen_physics172.py', 'w').write(s)
print('gen_physics172.py written')
