// Types the command sheet into the page's real brain code (node), one line at a time, and reads back what the brain holds.
// usage: node cmds_run.js <v16 dir> <sql-asm.js> <told.json> <sat.json> <sheet.json> <out.json>
const fs = require('fs'), vm = require('vm'); const [D, ASM, TOLDF, SATF, SHEETF, OUTF] = process.argv.slice(2);
const src = fs.readFileSync(ASM, 'utf8') + '\n' + fs.readFileSync(D + '/host15.js', 'utf8') + '\n' + fs.readFileSync(D + '/shared15.js', 'utf8') + '\n' + fs.readFileSync(D + '/worker16.js', 'utf8');
const ctx = { console: { log() {}, warn() {}, error() {} }, setTimeout, Uint8Array, Int8Array, Int16Array, Int32Array, Uint16Array, Uint32Array, Float32Array, Float64Array, ArrayBuffer, DataView, WebAssembly, TextDecoder, TextEncoder, performance, Date, Math, JSON };
ctx.self = ctx; let inbox = []; ctx.postMessage = (m) => inbox.push(m); vm.createContext(ctx); vm.runInContext(src, ctx);
const send = (m) => { inbox = []; ctx.onmessage({ data: m }); return inbox; }; const q = (sql) => send({ type: 'query', id: 1, sql })[0].rows;
(async () => {
  send({ type: 'init', told: JSON.parse(fs.readFileSync(TOLDF, 'utf8')), sat: JSON.parse(fs.readFileSync(SATF, 'utf8')) });
  for (let i = 0; i < 400 && !inbox.some(m => m.type === 'ready'); i++) await new Promise(r => setTimeout(r, 50));
  const out = { lines: [] };
  for (const [label, line] of JSON.parse(fs.readFileSync(SHEETF, 'utf8'))) {
    const t = Date.now(), r = send({ type: 'lines', lines: [line] }), last = r[r.length - 1];
    const run = q("SELECT id, recalled FROM run WHERE kind IN ('line', 'teach', 'bind') ORDER BY id DESC LIMIT 1")[0];
    const rec = { label, ms: Date.now() - t, type: last.type, said: last.output === undefined ? null : last.output, error: last.error || null, recalled: run ? run[1] : null };
    if (!/^(teach|bind)/.test(label)) {
      rec.returns = q("SELECT count(*) FROM run WHERE kind = 'defrow' AND parent = " + run[0])[0][0];
      rec.returnCells = q("SELECT name, value FROM var WHERE run = " + run[0] + " AND src = 'return'");
      rec.formulaRuns = q("SELECT word, count(*) FROM run WHERE kind = 'formula' AND root = " + run[0] + " GROUP BY word");
    }
    out.lines.push(rec);
  }
  out.defMemories = q("SELECT r.subject, count(*) FROM memory m JOIN run r ON r.id = m.run WHERE m.mark LIKE 'definition%' GROUP BY r.subject");
  out.firstReturn = q("SELECT line FROM run WHERE kind = 'defrow' ORDER BY id LIMIT 1");
  out.place = q('SELECT word, x, y, z, ended FROM place ORDER BY id');
  out.commandsInsideReturns = q("SELECT f.word, count(*) FROM run f WHERE f.kind = 'formula' AND f.root IN (SELECT id FROM run WHERE kind = 'defrow') GROUP BY f.word");
  out.binds = q("SELECT e.word, (SELECT word FROM encoder WHERE gate = b.arrival), (SELECT word FROM encoder WHERE gate = b.remainder), (SELECT word FROM encoder WHERE gate = b.trig), b.found FROM bindrow b JOIN encoder e ON e.gate = b.gate");
  out.formulas = q('SELECT word FROM formula WHERE ended = 0');
  out.triggers = q("SELECT count(*) FROM sqlite_master WHERE type = 'trigger'")[0][0];
  fs.writeFileSync(OUTF, JSON.stringify(out, null, 1));
  out.lines.forEach(l => console.log(`${l.label.slice(0, 26).padEnd(26)} ${String(l.type).padEnd(5)} ${(l.ms / 1000).toFixed(1).padStart(5)} s` + (l.recalled ? ' (memory)' : '') + (l.error ? ' ERROR ' + l.error.slice(0, 80) : '') + (l.label.startsWith('teach') || l.label.startsWith('bind') ? '' : `  returns ${l.returns}  said: ${JSON.stringify(l.said).slice(0, 150)}`)));
  console.log('definition memories by word:', JSON.stringify(out.defMemories)); console.log('first return run:', JSON.stringify(out.firstReturn).slice(0, 200));
  console.log('place rows:', JSON.stringify(out.place)); console.log('command formulas run inside return runs:', JSON.stringify(out.commandsInsideReturns));
  console.log('binds:', JSON.stringify(out.binds)); console.log('triggers in the brain:', out.triggers);
})();
