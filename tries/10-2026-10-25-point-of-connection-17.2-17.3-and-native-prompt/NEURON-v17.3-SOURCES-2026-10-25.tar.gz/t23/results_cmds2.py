import json
E = lambda s: str(s).replace('|', '\\|')
first = json.load(open('cmds173.json')); fixed = json.load(open('cmds173b.json')); ctl = json.load(open('cmds173ctl.json')); B = json.load(open('shot173.out.json')); sheet = json.load(open('sheet173.json'))
cmd = lambda d: [l for l in d['lines'] if not l['label'].startswith(('teach', 'bind', 're-teach'))]
P = {'learn : store': '8', 'find : memory last': 'the memory of "learn : store" = 8', 'find memory "store"': 'up to 5 memories holding store', 'find formula last': 'the last formula and its path',
     'find formula "learn:"': 'learn: and its path', 'apply : store': '3 (like shop, outlet, mart)', 'find relation store': 'those three', 'apply : learn like study': '1', 'run backpop': '0 formulas 1 rows',
     'study : cat': 'learn: fires: cat\'s count', 'define : store': 'WordNet sense 1 (first time); sense 2 (after redefine)', 'redefine : store': 'marks sense 1 wrong; says sense 2', 'find definition store': 'the memories, the first marked wrong'}
L = ['# Second command results: find, apply, redefine, backpop redone (2026-10-25)',
 'Predictions frozen at 02:53 before any run: NEURON-COMMANDS2-EXPECT-2026-10-25.md (sha256 d04761d1280a...). Told block 17.2, unchanged. Node runs on the page\'s real brain code, then the page 17.3 in a real browser.', '',
 '## What the first run showed, and the fixes (taught lines only)',
 '- find: never existed: its teach line failed ("no such table: land_76"). Its formula used the column name output, which the brain reads as the told port OUTPUT, a name with no neuron table. Fix: the column is written m.output. Whether ports become neurons is a told change, yours.',
 '- "update definition : x" cannot fire under the told rules: UPDATE is an SQL verb, and nothing fires after an SQL verb in a line (the words after it are a statement). The command is keyed "redefine : x" instead (my choice of name).',
 '- After a definition was marked wrong, "define : store" was answered from memory with the old definition. redefine now also ends the remembered answers of typed lines that mention the word (kept, no longer current), so the next define runs the long way.',
 '- Unchanged from the first run: apply, backpop and the backpop control.', '',
 '## The fixed run (node)', '', '| Line | Predicted | Said |', '|---|---|---|']
for l in cmd(fixed): L.append(f"| `{E(l['label'])}` | {E(P.get(l['label'], ''))} | {E(str(l['said'])[:110])}{' (memory)' if l.get('recalled') else ''} |")
c = {l['label']: l['said'] for l in cmd(ctl)}
L += ['', f"Control, no backpop: \"study : cat\" said {json.dumps(c.get('study : cat'))}: study fired nothing. With backpop it fired learn: through the row backpop laid in study's table.", '',
 '## In the page (real browser, typed through the prompt)', '', '| Line | Seconds | Said | The page\'s status |', '|---|---|---|---|']
for l in B['lines'][31:]: L.append(f"| `{E(l['line'][:28])}` | {l['s']} | {E(l['said'][:70])} | {E(l['busyText'][:70])} |")
L += ['', '## The new taught lines', '```'] + [r[1] for r in sheet if r[0].startswith(('teach find', 'teach apply', 'teach redefine', 're-teach'))] + [r[1] for r in sheet if r[0].startswith('bind') and ('find' in r[1] or 'apply' in r[1] or 'redefine' in r[1])] + ['```']
open('RESULTS-CMDS2.md', 'w').write('\n'.join(L) + '\n'); print(len(L), 'lines')
