import sys, json, time, threading, re
sys.path.insert(0, '.'); from host18 import Brain
sys.setrecursionlimit(200000); threading.stack_size(1 << 29)
def main():
    b = Brain('physics18.json', sat=json.load(open(sys.argv[1])))
    born = json.load(open('sheet18.json'))[0][1]; body = born[len('born = '):]
    b.type(born)
    b.type('origin = ' + body)   # lay the 'origin' teaching once so later replays hop over existing shards
    hopgo = b.q("SELECT sql FROM sqlite_master WHERE name = 'hop_go'")[0][0]
    stm = [s.strip() for s in hopgo[hopgo.index('BEGIN') + 5: hopgo.rindex('END')].split(';\n')]
    def timed(label):
        t = time.time(); b.type('origin = ' + body); print(f'{label:60} {time.time() - t:5.2f} s', flush=True)
    timed('all of hop_go')
    for i, s in enumerate(stm):
        if not s.strip() or s.startswith('INSERT INTO receipt') or s.startswith('INSERT INTO envelope') or s.startswith('UPDATE envelope') or s.startswith('DELETE FROM hop') or s.startswith('INSERT INTO "end"'): continue
        b.con.execute('DROP TRIGGER hop_go'); b.con.execute(hopgo.replace(s + ';', '', 1))
        timed('without: ' + s[:50].replace('\n', ' '))
        b.con.execute('DROP TRIGGER hop_go'); b.con.execute(hopgo)
    print('length of the line replayed:', len(body), 'characters')
th = threading.Thread(target=main); th.start(); th.join()
