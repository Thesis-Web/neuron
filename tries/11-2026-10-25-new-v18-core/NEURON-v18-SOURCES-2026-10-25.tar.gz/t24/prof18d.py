import sys, json, time, threading
sys.path.insert(0, '.'); from host18 import Brain
sys.setrecursionlimit(200000); threading.stack_size(1 << 29)
def main():
    b = Brain('physics18.json', sat=json.load(open(sys.argv[1])))
    born = json.load(open('sheet18.json'))[0][1]; body = born[len('born = '):]
    b.type(born)
    for frac in (0.125, 0.25, 0.5, 1.0):
        part = body[:int(len(body) * frac)]
        b.type('origin = ' + part)      # first time: lays the last shard
        t = time.time(); b.type('origin = ' + part); dt = time.time() - t
        n = b.q("SELECT count(*) FROM receipt WHERE run = (SELECT max(id) FROM run)")[0][0]
        print(f'{n:4} hops nested: {dt:5.2f} s, {dt / n * 1000:.2f} ms per hop', flush=True)
th = threading.Thread(target=main); th.start(); th.join()
