import sys, json, threading
sys.path.insert(0, '.'); from host18 import Brain
sys.setrecursionlimit(200000); threading.stack_size(1 << 29)
def main():
    b = Brain('physics18.json', sat=json.load(open(sys.argv[1])))
    for k, l in json.load(open('sheet18.json'))[:1]: b.type(l)
    b.type('zebra')
    g = b.q("SELECT gate FROM label WHERE word = 'zebra'")[0][0]
    print('zebra gate', g, '| its objects:', b.q("SELECT type, name FROM sqlite_master WHERE name IN (?, ?, ?, ?)", ('g%d' % g, 'land_%d' % g, 'miss_%d' % g, 'g%d' % (g + 1))))
    print('its DNA rows:', b.q("SELECT * FROM g%d" % g), '| definition node gate', b.q("SELECT gate, word FROM label WHERE gate = ?", (g + 1,)))
    print('the born run said to mother (its BUILD text, from its receipt):')
    r = b.q("SELECT id FROM run WHERE kind = 'formula' ORDER BY id DESC LIMIT 1")[0][0]
    print('  replies:', b.q("SELECT value FROM sheet WHERE run = ? AND name = 'BUILD'", (r,)))
    sh = [x[0] for x in b.q("SELECT shard FROM (" + " UNION ALL ".join("SELECT shard FROM %s" % n for (n,) in b.q("SELECT name FROM sqlite_master WHERE type = 'table' AND name GLOB 'g[0-9]*' AND sql LIKE '%arrival%'")) + ") ORDER BY shard")]
    print('shards:', len(sh), 'first', sh[:3], 'last', sh[-3:], '| gaps or repeats:', sh != list(range(1, len(sh) + 1)), '| counter', b.q("SELECT n FROM shards")[0][0])
th = threading.Thread(target=main); th.start(); th.join()
