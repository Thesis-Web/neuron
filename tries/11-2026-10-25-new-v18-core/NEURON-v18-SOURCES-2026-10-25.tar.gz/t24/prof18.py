import sys, json, time, threading, resource
sys.path.insert(0, '.'); from host18 import Brain
sys.setrecursionlimit(200000); threading.stack_size(1 << 29)
def main():
    b = Brain('physics18.json', sat=json.load(open(sys.argv[1])))
    calls = {'motherp': 0, 'mother': 0}; tm = {'motherp': 0.0}
    orig = b.motherp
    def mp(text):
        calls['motherp'] += 1; return orig(text)
    b.con.create_function('motherp', 1, mp)
    t = time.time(); b.type(json.load(open('sheet18.json'))[0][1]); print('teach born', round(time.time() - t, 1), 's', calls, flush=True)
    sp = b.q("SELECT gate FROM label WHERE word = ' '")[0][0]
    print('triggers:', b.q("SELECT count(*) FROM sqlite_master WHERE type = 'trigger'")[0][0], '| on the space neuron:', b.q("SELECT count(*) FROM sqlite_master WHERE type = 'trigger' AND tbl_name = ?", ('land_%d' % sp,))[0][0])
    for i in range(2):
        t = time.time(); n = len(b.q(f"EXPLAIN INSERT INTO land_{sp} (arrival, remainder, run, rest) VALUES (1, 2, 3, '')")); print('compile one landing into the space neuron:', round(time.time() - t, 3), 's,', n, 'opcodes', flush=True)
    for w in ['zebra', 'yak', 'gnu']:
        calls['motherp'] = 0; t = time.time(); b.type(w); print('birth of', w, round(time.time() - t, 2), 's; motherp calls', calls['motherp'], '| max rss MB', resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024, flush=True)
    r = b.q("SELECT id FROM run WHERE kind = 'formula' ORDER BY id DESC LIMIT 1")[0][0]
    print('born run receipt rows:', b.q("SELECT count(*) FROM receipt WHERE run = ?", (r,))[0][0])
    # one static hop chain only: replay the born run's line as a plain heard line would cost; time a landing chain without births
    t = time.time(); b.con.execute("PRAGMA recursive_triggers = ON"); print()
th = threading.Thread(target=main); th.start(); th.join()
