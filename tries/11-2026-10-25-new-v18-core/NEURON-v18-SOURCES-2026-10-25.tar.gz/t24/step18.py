# types lines into a fresh v18 brain on native SQLite and shows what happened; usage: step18.py <n sheet lines> <line>...
import sys, json, time, threading
sys.path.insert(0, sys.argv[1]); from host18 import Brain
sys.setrecursionlimit(200000); threading.stack_size(1 << 29)
def main():
    sheet = json.load(open('sheet18.json')); sat = json.load(open(sys.argv[2]))
    b = Brain('physics18.json', sat=sat)
    for k, l in sheet[:int(sys.argv[3])]:
        t = time.time(); out = b.type(l); print(f'[{time.time()-t:6.1f} s] {k}: said {out!r}', flush=True)
        err = b.q("SELECT run, value FROM sheet WHERE name = 'BUILD' AND value LIKE 'error%' ORDER BY id DESC LIMIT 3")
        if err: print('   BUILD errors:', err)
    for l in sys.argv[4:]:
        t = time.time(); out = b.type(l); print(f'[{time.time()-t:6.1f} s] {l!r}: said {out!r}', flush=True)
        err = b.q("SELECT run, value FROM sheet WHERE name = 'BUILD' AND value LIKE 'error%' ORDER BY id DESC LIMIT 3")
        if err: print('   BUILD errors:', err)
    print('formulas:', b.q("SELECT l.word, f.run FROM formula f JOIN label l ON l.gate = f.gate WHERE ended = 0"))
    print('labels:', b.q("SELECT count(*) FROM label")[0][0], '| shards counter:', b.q("SELECT n FROM shards")[0][0], '| runs:', b.q("SELECT kind, count(*) FROM run GROUP BY kind"))
    globals()['B'] = b
th = threading.Thread(target=main); th.start(); th.join()
