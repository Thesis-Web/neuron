# The v18 test (EXPECT-v18.md, frozen 10:13): a fresh brain, the four teaching lines typed at the prompt, then the lines.
# usage: test18.py <sat.json> <out.json> <brain.db to save>
import sys, json, time, threading, re
sys.path.insert(0, '.'); from host18 import Brain
sys.setrecursionlimit(200000); threading.stack_size(1 << 29)
R = {'lines': [], 'checks': {}}
def main():
    sat = json.load(open(sys.argv[1])); told = json.load(open('physics18.json'))
    b = Brain('physics18.json', sat=sat)
    def say(line):
        n0 = b.q("SELECT count(*) FROM secondary")[0][0]
        t = time.time(); out = b.type(line); dt = time.time() - t
        errs = b.q("SELECT value FROM sheet WHERE name = 'BUILD' AND value LIKE 'error%' AND id > ?", (R.get('lastsheet', 0),))
        R['lastsheet'] = b.q("SELECT coalesce(max(id), 0) FROM sheet")[0][0]
        rec = {'line': line[:60], 'said': out, 's': round(dt, 1), 'asks_back': b.q("SELECT count(*) FROM secondary")[0][0] - n0, 'errors': [e[0] for e in errs][:5]}
        R['lines'].append(rec); print(json.dumps(rec)[:400], flush=True); return out
    for k, l in json.load(open('sheet18.json')): say(l)
    # T1: what is hand-laid
    text = ' '.join(told['statements'])
    gone = {'LIMIT 8': 'LIMIT 8' in text, 'agree': ' agree' in text, 'SQL-verb rule': "'UPDATE','DELETE'" in text, 'expected': 'expected' in text,
            'decide': 'decide' in text, 'memory hop': 'memhit' in text, 'gap': ' gap ' in text, 'proc': ' proc ' in text, 'step back': 'stepq' in text,
            'derive': 'derive' in text, 'times counter': 'times' in text, '? echo': "'?'" in text}
    kinds = {}
    for s in told['statements']:
        m = re.match(r'(CREATE TABLE|CREATE VIEW|CREATE TRIGGER|CREATE INDEX|INSERT INTO|UPDATE|PRAGMA)', s); kinds[m.group(1) if m else s[:20]] = kinds.get(m.group(1) if m else s[:20], 0) + 1
    R['checks']['T1'] = {'statements': len(told['statements']), 'kinds': kinds, 'hand-laid neurons': len(told['handlaid']),
                         'deleted rules still present (all should be false)': gone,
                         'working triggers': [re.match(r'CREATE TRIGGER (\w+)', s).group(1) for s in told['statements'] if s.startswith('CREATE TRIGGER') and not s.startswith('CREATE TRIGGER miss_')]}
    say('BUILD SELECT 1 + 1 BUILD')
    R['checks']['T4'] = R['lines'][-1]['said'] == '2'
    d1 = say('define : dog')
    g = b.q("SELECT gate FROM label WHERE word = 'dog'")
    T5 = {'dog gate': g}
    if g:
        g = g[0][0]
        first = b.q(f"SELECT shard, trigger FROM g{g} ORDER BY shard LIMIT 1")[0]
        dn = first[1]
        rows = b.q(f"SELECT d.id, l.word, d.run, round(d.score, 3) FROM g{dn} d JOIN label l ON l.gate = d.source ORDER BY d.id")
        T5['born by'] = b.q("SELECT r.kind, (SELECT word FROM label WHERE gate = (SELECT gate FROM formula WHERE run = (SELECT id FROM run WHERE id = r.id))) FROM born x JOIN run r ON r.id = x.run WHERE x.word = 'dog'")
        T5['first shard -> definition node'] = [first, b.q("SELECT word FROM label WHERE gate = ?", (dn,))]
        T5['return runs'] = b.q("SELECT word, count(*) FROM run WHERE kind = 'defrow' AND subject = ? GROUP BY word", (g,))
        T5['definition node rows'] = len(rows)
        def text_of(run):
            return b.q("SELECT trim(group_concat(w, '')) FROM (SELECT l.word AS w FROM receipt x JOIN label l ON l.gate = x.gate WHERE x.run = ? AND x.id > (SELECT min(id) FROM receipt WHERE run = ? AND gate = (SELECT gate FROM label WHERE word = 'build')) ORDER BY x.id)", (run, run))[0][0]
        T5['rows (source, score, text)'] = [(r[1], r[3], (text_of(r[2]) or '')[:90]) for r in rows[:6]]
        T5['said'] = d1
        T5['row 1 is wn sense 1 or Webster sense 1'] = bool(d1) and (d1.startswith('a member of the genus Canis') or d1.startswith('(Zool.) A quadruped of the genus'))
        R['dog_rows'] = [(r[1], r[3], text_of(r[2])) for r in rows]
    R['checks']['T5'] = T5
    d2 = say('define : dog')
    R['checks']['T6'] = {'same': d2 == d1, 'asks back': R['lines'][-1]['asks_back']}
    c = say('define : cat'); s = say('define : store')
    R['checks']['T7'] = {'cat': c, 'cat is the animal sense from a dictionary': bool(c) and (c.startswith('feline mammal') or c.startswith('(Zool.) Any animal belonging to the natural family Felidae') or c.startswith('a carnivorous mammal')), 'store (recorded only)': s}
    had = b.q("SELECT word FROM label WHERE word IN ('canis', 'Canis')")
    k1 = say('define : canis'); k2 = say('define : Canis')
    R['checks']['T8'] = {'existed before (born inside a return)': had, 'define : canis': k1, 'define : Canis': k2,
                         'sources hold canis': {s: b.q(f"SELECT count(*) FROM {s}.corpus WHERE word = 'canis'")[0][0] for s in b.SATS}}
    b.save(sys.argv[3])
    sh = sorted(x for (n,) in b.q("SELECT name FROM sqlite_master WHERE type = 'table' AND name GLOB 'g[0-9]*' AND sql LIKE '%arrival%'") for (x,) in b.q("SELECT shard FROM %s" % n))
    R['checks']['T3'] = {'shards': len(sh), 'one sequence, no gaps, no repeats': sh == list(range(1, len(sh) + 1)), 'counter': b.q("SELECT n FROM shards")[0][0]}
    R['size'] = {'neurons': b.q("SELECT count(*) FROM label WHERE word NOT LIKE '%.definition'")[0][0], 'triggers': b.q("SELECT count(*) FROM sqlite_master WHERE type = 'trigger'")[0][0],
                 'runs': b.q("SELECT kind, count(*) FROM run GROUP BY kind")}
th = threading.Thread(target=main); th.start(); th.join()
R.pop('lastsheet', None)
json.dump(R, open(sys.argv[2], 'w'), indent=1)
print(json.dumps(R['checks'], indent=1)[:6000])
