import sys, json, time, threading
sys.path.insert(0, '.'); from host18 import Brain
sys.setrecursionlimit(200000); threading.stack_size(1 << 29)
def main():
    b = Brain('physics18.json', sat=json.load(open(sys.argv[1])))
    born = json.load(open('sheet18.json'))[0][1]
    b.type(born); b.type('zebra')
    body = born[len('born = '):]
    t = time.time(); b.type('origin = ' + body); print('the same 847 tokens as a teaching run (hops only, BUILD not run):', round(time.time() - t, 2), 's', flush=True)
    n = {'c': 0}
    b.con.set_trace_callback(lambda s: n.__setitem__('c', n['c'] + 1))
    t = time.time(); b.type('yak'); dt = time.time() - t
    b.con.set_trace_callback(None)
    print('birth of yak:', round(dt, 2), 's; statements and trigger programs traced:', n['c'], flush=True)
    import collections; c = collections.Counter()
    b.con.set_trace_callback(lambda s: c.update([s.split()[2] if s.startswith('-- TRIGGER') else s[:30]]))
    b.type('gnu'); b.con.set_trace_callback(None)
    print(c.most_common(8))
th = threading.Thread(target=main); th.start(); th.join()
