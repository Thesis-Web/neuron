# turn 19 page builder: python3 -I build19.py <turn19 dir> <out html>
import sys, os, json
d = sys.argv[1]; outp = sys.argv[2]
body = open(os.path.join(d, 'body19.html')).read()
data = open(os.path.join(d, 'out', 'page19.json')).read().replace('</', '<\\/')
main = open(os.path.join(d, 'main19.js')).read()
prose = open(os.path.join(d, 'prose19.html')).read() if os.path.exists(os.path.join(d, 'prose19.html')) else ''
for k, v in (('/*PROSE*/', prose), ('/*MAIN*/', main), ('/*DATA*/', data)):
    assert body.count(k) == 1, k
    body = body.replace(k, v)
open(outp, 'w').write(body)
print(outp, len(body))
