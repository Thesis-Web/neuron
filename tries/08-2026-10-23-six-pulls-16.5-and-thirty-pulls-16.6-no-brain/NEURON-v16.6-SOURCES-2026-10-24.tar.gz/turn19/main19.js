(function () {
  var $ = function (id) { return document.getElementById(id); };
  var D = JSON.parse($('data19').textContent);
  function bytes(s) { var b = atob(s), u = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function mi(s) { return String(s).replace(/-/g, '−'); }
  function fx(v) { return (Math.round(v * 10) / 10).toFixed(1); }
  function pct(v) { return (v * 100).toFixed(v < 0.1 ? 1 : 0) + '%'; }
  function tier(v) { return v < 0.05 ? 'strong' : v < 0.15 ? 'clear' : v < 0.30 ? 'weak' : 'none'; }

  var W = D.words, N = W.length, KINDS = D.kinds, WIDX = {};
  W.forEach(function (w, i) { WIDX[w] = i; });
  var DEG = new Uint16Array(bytes(D.deg).buffer);
  var LA = new Int32Array(bytes(D.la).buffer), LB = new Int32Array(bytes(D.lb).buffer), LK = bytes(D.lk), NL = LA.length;
  var ADJ = []; for (var i = 0; i < N; i++) ADJ.push([]);
  for (var e = 0; e < NL; e++) { ADJ[LA[e]].push(e); ADJ[LB[e]].push(e); }
  var SPLIT = ['build', 'choose', 'test'];
  var KCOL = { alike: '#7fd1b9', opposite: '#ff6b6b', is: '#ffd166', has: '#c792ea', prefix: '#8fa3bf', suffix: '#a3b8cc', stem: '#f4a261', past: '#5fa8ff', singular: '#e07be0' };
  var PN = D.pool.name, PG = D.pool.group, PH = D.pool.how, PT = D.pool.top, NP = PN.length;
  var PS = bytes(D.pool.shown);                       // NP x N, strength 0..255
  var SL = D.slots.map(function (s) { var v = s[2], l = Math.hypot(v[0], v[1], v[2]); return { type: s[0], name: s[1], u: [v[0] / l, v[1] / l, v[2] / l] }; });
  var NSL = SL.length;
  var CLSN = D.clsNames || [], CLS = D.cls || [];
  var CLSCOL = { verb: '#ff7a45', noun: '#6ea8fe', adjective: '#52d18a', adverb: '#ffc069' };
  // one colour per slot: hue from the direction around z, lighter above, darker below
  var SCOL = SL.map(function (s) {
    var u = s.u, h = (Math.atan2(u[1], u[0]) * 180 / Math.PI + 360) % 360, l = u[2] > 0.3 ? 72 : u[2] < -0.3 ? 46 : 60;
    if (Math.abs(u[0]) < 1e-6 && Math.abs(u[1]) < 1e-6) return u[2] > 0 ? 'hsl(0,0%,92%)' : 'hsl(0,0%,62%)';
    if (s.type === 'quad') return 'hsl(' + h.toFixed(0) + ',45%,' + (l + 12) + '%)';
    return 'hsl(' + h.toFixed(0) + ',78%,' + l + '%)';
  });
  var GROUPS = ['action', 'relationship', 'tense', 'number', 'modifier', 'definition', 'class', 'source', 'depth', 'your word', 'topic'];
  var GNAME = { action: 'the fourteen actions', relationship: 'relationships (lines)', tense: 'tense', number: 'number', modifier: 'modifiers', definition: 'definitions', class: 'class', source: 'source', depth: 'depth (general / specific)', 'your word': 'near your words', topic: 'topic (WordNet files)' };

  var PRE = D.presets, cur = Math.max(0, PRE.map(function (p) { return p.key; }).indexOf('B')), assign = PRE[cur].assign.slice(), sel = -1, colorMode = 'pull';
  var P = new Float32Array(N * 3), shown = new Float32Array(N * 3), FIT = null;

  function compute() {
    P.fill(0);
    for (var s = 0; s < NSL; s++) { var k = assign[s]; if (k < 0) continue; var u = SL[s].u, off = k * N;
      for (var i = 0; i < N; i++) { var v = PS[off + i]; if (!v) continue; v = v / 255 * 100; P[3 * i] += v * u[0]; P[3 * i + 1] += v * u[1]; P[3 * i + 2] += v * u[2]; } }
  }
  function posOf(i) { return [P[3 * i], P[3 * i + 1], P[3 * i + 2]]; }
  function pullsOf(i) { var o = []; for (var s = 0; s < NSL; s++) { var k = assign[s]; if (k < 0) continue; var v = PS[k * N + i] / 255; if (v > 0) o.push({ s: s, k: k, v: v }); } return o; }

  // ---- live fit to all your lines (descriptive, not a held-out test): same place / scale each axis / linear map
  var rng = (function () { var x = 12345; return function () { x = (x * 1103515245 + 12345) % 2147483648; return x / 2147483648; }; })();
  var CAND = []; for (var c = 0; c < 1000; c++) CAND.push(Math.floor(rng() * N));
  var BYK = KINDS.map(function () { return []; });
  for (var e2 = 0; e2 < NL; e2++) BYK[LK[e2] >> 2].push(e2);
  var SYM = { alike: 1, opposite: 1 };
  var SAMPLE = BYK.map(function (lst) { var o = []; for (var t = 0; t < Math.min(200, lst.length); t++) o.push(lst[Math.floor(rng() * lst.length)]); return o; });
  function solve4(A, b) { // Gaussian elimination, 4x4
    var M = A.map(function (r, i) { return r.concat([b[i]]); });
    for (var c2 = 0; c2 < 4; c2++) { var p = c2; for (var r = c2 + 1; r < 4; r++) if (Math.abs(M[r][c2]) > Math.abs(M[p][c2])) p = r; var tmp = M[c2]; M[c2] = M[p]; M[p] = tmp; if (Math.abs(M[c2][c2]) < 1e-12) M[c2][c2] = 1e-12;
      for (var r2 = 0; r2 < 4; r2++) if (r2 !== c2) { var f = M[r2][c2] / M[c2][c2]; for (var q = c2; q < 5; q++) M[r2][q] -= f * M[c2][q]; } }
    return M.map(function (r, i) { return r[4] / r[i]; });
  }
  function fitKind(ki) {
    var lst = BYK[ki], sym = SYM[KINDS[ki]], n = 0, sa = [0, 0, 0], sb = [0, 0, 0], sxx = [0, 0, 0], sxy = [0, 0, 0], XtX = [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]], XtY = [[0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0]];
    function add(a, b) { var x = [P[3 * a], P[3 * a + 1], P[3 * a + 2], 1], y = [P[3 * b], P[3 * b + 1], P[3 * b + 2]]; n++;
      for (var d = 0; d < 3; d++) { sa[d] += x[d]; sb[d] += y[d]; sxx[d] += x[d] * x[d]; sxy[d] += x[d] * y[d]; }
      for (var r = 0; r < 4; r++) { for (var q = 0; q < 4; q++) XtX[r][q] += x[r] * x[q]; for (var q2 = 0; q2 < 3; q2++) XtY[r][q2] += x[r] * y[q2]; } }
    lst.forEach(function (e3) { add(LA[e3], LB[e3]); if (sym) add(LB[e3], LA[e3]); });
    var a = [1, 1, 1], t = [0, 0, 0];
    for (var d = 0; d < 3; d++) { var den = n * sxx[d] - sa[d] * sa[d]; a[d] = Math.abs(den) > 1e-9 ? (n * sxy[d] - sa[d] * sb[d]) / den : 0; t[d] = (sb[d] - a[d] * sa[d]) / n; }
    for (var r3 = 0; r3 < 4; r3++) XtX[r3][r3] += 1e-6;
    var Wl = [0, 1, 2].map(function (q) { return solve4(XtX, XtY.map(function (r) { return r[q]; })); });
    return { same: function (p) { return p; }, scale: function (p) { return [a[0] * p[0] + t[0], a[1] * p[1] + t[1], a[2] * p[2] + t[2]]; },
      linear: function (p) { return Wl.map(function (w) { return w[0] * p[0] + w[1] * p[1] + w[2] * p[2] + w[3]; }); } };
  }
  function shareAmong(q, b, cand) { var db = d2(q, b), less = 0, tie = 0, tol = 1e-6 * (1 + db); for (var c3 = 0; c3 < cand.length; c3++) { var j = cand[c3], d = d2(q, j); if (d < db - tol) less++; else if (Math.abs(d - db) <= tol) tie++; } return (less + tie / 2) / cand.length; }
  function d2(q, j) { var a = q[0] - P[3 * j], b = q[1] - P[3 * j + 1], c4 = q[2] - P[3 * j + 2]; return a * a + b * b + c4 * c4; }
  function median(a) { a = a.slice().sort(function (x, y) { return x - y; }); var m = a.length >> 1; return a.length % 2 ? a[m] : (a[m - 1] + a[m]) / 2; }
  function liveFit() {
    var per = [], funcs = [];
    KINDS.forEach(function (kn, ki) {
      var F = fitKind(ki), best = 9, bestf = 'same';
      ['same', 'scale', 'linear'].forEach(function (nm) { var s = SAMPLE[ki].map(function (e3) { return shareAmong(F[nm](posOf(LA[e3])), LB[e3], CAND); }); var m = median(s); if (m < best) { best = m; bestf = nm; } });
      per.push(best); funcs.push({ F: F, best: bestf });
    });
    FIT = { per: per, funcs: funcs, mean: per.reduce(function (a, b) { return a + b; }, 0) / per.length };
  }

  // ---- left rail
  function presetSelect() {
    $('preset').innerHTML = PRE.map(function (p, k) { return '<option value="' + k + '"' + (k === cur ? ' selected' : '') + '>' + esc(p.title) + ' (held-out ' + p.mean.toFixed(3) + ')</option>'; }).join('');
  }
  var OPTS = (function () {
    var h = '<option value="-1">empty</option>';
    GROUPS.forEach(function (g) { var ks = []; for (var k = 0; k < NP; k++) if (PG[k] === g) ks.push(k); if (!ks.length) return; h += '<optgroup label="' + esc(GNAME[g] || g) + '">' + ks.map(function (k) { return '<option value="' + k + '">' + esc(PN[k]) + '</option>'; }).join('') + '</optgroup>'; });
    return h;
  })();
  function slotTable() {
    var groups = [['axis', 'the 6 axes'], ['top', '4 top two-axis bisects (with +z)'], ['bottom', '4 bottom two-axis bisects (with −z)'], ['flat', '4 flat two-axis bisects'], ['three-axis', '8 three-axis bisects'], ['quad', '4 quads (in 3D +z and −z cancel: each lies on a flat bisect)']];
    var h = '';
    groups.forEach(function (g) {
      h += '<div class="sg"><div class="sgh">' + esc(g[1]) + '</div>';
      SL.forEach(function (s, k) { if (s.type !== g[0]) return; h += '<label class="slot"><span class="dir" style="--c:' + SCOL[k] + '">' + mi(s.name) + '</span><select id="slot' + k + '" data-s="' + k + '">' + OPTS + '</select></label>'; });
      h += '</div>';
    });
    $('slots').innerHTML = h;
    SL.forEach(function (s, k) { var el = $('slot' + k); el.value = String(assign[k]); el.addEventListener('change', function () { assign[k] = +el.value; refresh(false); }); });
  }
  function syncSlots() { SL.forEach(function (s, k) { $('slot' + k).value = String(assign[k]); }); }
  function status() {
    var at0 = 0, le2 = 0, filled = assign.filter(function (k) { return k >= 0; }).length;
    for (var i = 0; i < N; i++) { if (!P[3 * i] && !P[3 * i + 1] && !P[3 * i + 2]) at0++; var c5 = 0; for (var s = 0; s < NSL; s++) { var k = assign[s]; if (k >= 0 && PS[k * N + i] > 2) c5++; } if (c5 <= 2) le2++; }
    var o = WIDX['origin'], op = posOf(o), orad = Math.hypot(op[0], op[1], op[2]), nearer = 0;
    for (var j = 0; j < N; j++) if (Math.hypot(P[3 * j], P[3 * j + 1], P[3 * j + 2]) < orad) nearer++;
    var p = PRE[cur], same = assign.every(function (k, s) { return k === p.assign[s]; });
    $('status').innerHTML = '<div class="kv"><span>pulls filled</span><b>' + filled + ' of 30</b></div>' +
      '<div class="kv"><span>fit to all your lines now</span><b><span class="chip ' + tier(FIT.mean) + '">' + FIT.mean.toFixed(3) + '</span></b></div>' +
      '<div class="kv"><span>held-out test (this start, unchanged)</span><b>' + (same ? p.mean.toFixed(3) : 'changed: no test yet') + '</b></div>' +
      '<div class="kv"><span>words at 0,0,0</span><b>' + at0.toLocaleString() + '</b></div>' +
      '<div class="kv"><span>words with 2 or fewer pulls</span><b>' + le2.toLocaleString() + '</b></div>' +
      '<div class="kv"><span>"origin" sits at</span><b>' + op.map(fx).join(', ') + '</b></div>' +
      '<div class="kv"><span>words nearer 0,0,0 than "origin"</span><b>' + pct(nearer / N) + '</b></div>';
  }

  // ---- right rail
  function testTable() {
    var p = PRE[cur];
    var h = '<table class="sc"><thead><tr><th>kind</th><th title="chosen on the choose lines">formula</th><th title="0 = the real word is the closest; 0.5 = chance">rank share</th><th>hit@10</th><th>shuffled</th><th>same place</th></tr></thead><tbody>';
    KINDS.forEach(function (k) { var t = p.test[k]; if (!t) return; h += '<tr' + (p.pts.indexOf(k) >= 0 ? ' class="po"' : '') + '><td><span class="kd" style="--c:' + KCOL[k] + '"></span>' + k + '</td><td class="fn">' + esc(t.best) + '</td><td><span class="chip ' + tier(t.median) + '">' + t.median.toFixed(3) + '</span></td><td>' + pct(t.hit10) + '</td><td>' + t.shuffled.toFixed(3) + '</td><td>' + t.same.toFixed(3) + '</td></tr>'; });
    h += '</tbody></table><p class="m">' + esc(p.title) + ', held-out lines: mean ' + p.mean.toFixed(3) + '; kinds pointed out ' + p.pts.length + ' of 9 (' + esc(p.pts.join(', ') || 'none') + '). Control, the same pulls each shuffled across words: ' + D.random_mean.toFixed(3) + '.</p>';
    h += '<table class="sc"><thead><tr><th>WordNet line</th><th>formula</th><th>rank share</th><th>hit@10</th><th>lines</th></tr></thead><tbody>';
    Object.keys(p.wn).forEach(function (k) { var t = p.wn[k]; h += '<tr><td>' + k + '</td><td class="fn">' + esc(t.best) + '</td><td><span class="chip ' + tier(t.median) + '">' + t.median.toFixed(3) + '</span></td><td>' + pct(t.hit10) + '</td><td>' + t.n + '</td></tr>'; });
    $('tests').innerHTML = h + '</tbody></table>';
    var cv = p.curve || [];
    $('curve').innerHTML = cv.length ? '<table class="sc"><thead><tr><th>#</th><th>slot</th><th>pull added</th><th>score after</th></tr></thead><tbody>' + cv.map(function (c6, n) { return '<tr><td>' + (n + 1) + '</td><td>' + mi(c6[1]) + '</td><td>' + esc(c6[2]) + '</td><td>' + c6[0].toFixed(4) + '</td></tr>'; }).join('') + '</tbody></table>' : '<p class="m">This start was not built pull by pull.</p>';
  }
  var REL = [];
  function showWord(i) {
    sel = i;
    if (i < 0) { $('sel').innerHTML = '<span class="m">Click a point, or find a word above.</span>'; REL = []; drawSel(); return; }
    var p = posOf(i), pl = pullsOf(i), tot = pl.reduce(function (a, b) { return a + b.v; }, 0) || 1;
    pl.sort(function (a, b) { return b.v - a.v; });
    var gate = D.gates[W[i]];
    var h = '<div class="selh"><b class="w">' + esc(W[i]) + '</b>' + (gate ? '<span class="chip gate">brain gate: ' + esc(gate) + '</span>' : '') + (CLS[i] >= 0 && CLSN[CLS[i]] ? '<span class="m"> your map: ' + esc(CLSN[CLS[i]]) + '</span>' : '') + '<span class="m"> &middot; ' + DEG[i] + ' line' + (DEG[i] === 1 ? '' : 's') + ' in your map</span></div>';
    h += '<div class="xyz">x ' + fx(p[0]) + ' &nbsp; y ' + fx(p[1]) + ' &nbsp; z ' + fx(p[2]) + ' <span class="m">(' + fx(Math.hypot(p[0], p[1], p[2])) + ' from 0,0,0)</span></div>';
    h += '<p class="eq">' + esc(W[i]) + ' = ' + (pl.length ? pl.slice(0, 8).map(function (x) { return (x.v / tot * 100).toFixed(0) + '% ' + esc(PN[x.k]); }).join(' + ') + (pl.length > 8 ? ' + ' + (pl.length - 8) + ' more' : '') : 'no pull') + '</p>';
    h += '<table class="sc ratio"><thead><tr><th>pull</th><th>direction</th><th>strength</th><th>share of its pull</th></tr></thead><tbody>' + pl.map(function (x) {
      return '<tr><td>' + esc(PN[x.k]) + '</td><td><span class="dir" style="--c:' + SCOL[x.s] + '">' + mi(SL[x.s].name) + '</span></td><td>' + x.v.toFixed(2) + '</td><td><span class="bar"><i style="--w:' + (x.v / tot * 100).toFixed(1) + '%;--c:' + SCOL[x.s] + '"></i></span> ' + (x.v / tot * 100).toFixed(1) + '%</td></tr>'; }).join('') + '</tbody></table>';
    REL = [];
    var rows = ADJ[i].slice(0, 300).map(function (e4) {
      var a = LA[e4], b = LB[e4], ki = LK[e4] >> 2, k = KINDS[ki], other = a === i ? b : a, f = FIT.funcs[ki], q = f.F[f.best](posOf(a));
      REL.push({ a: a, b: b, k: k, q: q, other: other });
      return { a: a, b: b, k: k, other: other, q: q, spl: SPLIT[LK[e4] & 3], f: f.best };
    });
    rows.forEach(function (r) { var db = d2(r.q, r.b), less = 0, tie = 0, tol = 1e-6 * (1 + db); for (var j = 0; j < N; j++) { if (j === r.a || j === r.b) continue; var d = d2(r.q, j); if (d < db - tol) less++; else if (Math.abs(d - db) <= tol) tie++; } r.share = (less + tie / 2) / (N - 2); });
    rows.sort(function (x, y) { return KINDS.indexOf(x.k) - KINDS.indexOf(y.k) || x.share - y.share; });
    h += '<table class="sc rel"><thead><tr><th>line</th><th>other word sits at</th><th>formula puts B at</th><th title="share of all words closer to the formula\'s point than the real word">rank share</th></tr></thead><tbody>' + rows.map(function (x) {
      return '<tr><td><span class="kd" style="--c:' + KCOL[x.k] + '"></span><a href="#" data-w="' + x.other + '">' + esc(W[x.a]) + ' —' + x.k + '→ ' + esc(W[x.b]) + '</a></td><td>' + posOf(x.other).map(fx).join(', ') + '</td><td>' + x.q.map(fx).join(', ') + ' <span class="m">' + x.f + '</span></td><td><span class="chip ' + tier(x.share) + '">' + x.share.toFixed(3) + '</span></td></tr>'; }).join('') + '</tbody></table>';
    if (ADJ[i].length > 300) h += '<p class="m">first 300 of ' + ADJ[i].length + ' lines</p>';
    $('sel').innerHTML = h;
    Array.prototype.forEach.call($('sel').querySelectorAll('a[data-w]'), function (a) { a.addEventListener('click', function (ev) { ev.preventDefault(); showWord(+a.getAttribute('data-w')); }); });
    drawSel();
  }
  function findWord(s) {
    s = (s || '').trim().toLowerCase(); if (!s) return;
    if (WIDX[s] != null) { showWord(WIDX[s]); $('sugg').innerHTML = ''; return; }
    var m = []; for (var i = 0; i < N && m.length < 12; i++) if (W[i].indexOf(s) === 0) m.push(i);
    $('sugg').innerHTML = m.length ? m.map(function (i) { return '<button type="button" data-w="' + i + '">' + esc(W[i]) + '</button>'; }).join('') : '<span class="m">No word in your map starts with "' + esc(s) + '".</span>';
    Array.prototype.forEach.call($('sugg').querySelectorAll('button'), function (b) { b.addEventListener('click', function () { showWord(+b.getAttribute('data-w')); }); });
  }

  // ---- atlas
  function atlas() {
    var f = ($('afind').value || '').trim().toLowerCase(), show = $('ashow').value, rows = [];
    for (var i = 0; i < N; i++) {
      if (f && W[i].indexOf(f) < 0) continue;
      if (show === 'gates' && !D.gates[W[i]]) continue;
      if (show === 'le2' && DEG[i] > 2) continue;
      rows.push(i);
    }
    var h = '<thead><tr><th>label</th><th>x</th><th>y</th><th>z</th><th>from 0,0,0</th><th>strongest pulls (share)</th><th>pulls</th><th>lines in your map</th><th>brain gate</th></tr></thead><tbody>';
    rows.slice(0, 400).forEach(function (i) {
      var p = posOf(i), pl = pullsOf(i), tot = pl.reduce(function (a, b) { return a + b.v; }, 0) || 1; pl.sort(function (a, b) { return b.v - a.v; });
      h += '<tr class="arow" data-w="' + i + '"><td>' + esc(W[i]) + '</td><td>' + fx(p[0]) + '</td><td>' + fx(p[1]) + '</td><td>' + fx(p[2]) + '</td><td>' + fx(Math.hypot(p[0], p[1], p[2])) + '</td><td>' + esc(pl.slice(0, 3).map(function (x) { return PN[x.k] + ' ' + (x.v / tot * 100).toFixed(0) + '%'; }).join(', ')) + '</td><td>' + pl.length + '</td><td>' + DEG[i] + '</td><td>' + (D.gates[W[i]] || '') + '</td></tr>';
    });
    $('atable').innerHTML = h + '</tbody>';
    $('asum').textContent = rows.length.toLocaleString() + ' words match' + (rows.length > 400 ? '; showing the first 400 A to Z. Type in "find" to narrow.' : '.') + ' Places are the 30-pull formula with the pulls set in the left rail, computed in this page; the brain holds no places yet.';
    Array.prototype.forEach.call($('atable').querySelectorAll('tr.arow'), function (tr) { tr.addEventListener('click', function () { showWord(+tr.getAttribute('data-w')); }); });
  }

  // ---- 3D
  var hasGL = !!window.THREE && (function () { try { var c7 = document.createElement('canvas'); return !!(c7.getContext('webgl') || c7.getContext('experimental-webgl')); } catch (e5) { return false; } })();
  var renderer, scene, camera, geo, colAttr, guideGroup, selGroup, labelBox, labels = [], allLines = null;
  var theta = 0.7, phi = 1.1, dist = 600, tween = null, reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function w3(p) { return new THREE.Vector3(p[0], p[2], -p[1]); }
  function radius95() { var r = []; for (var i = 0; i < N; i += 7) r.push(Math.hypot(P[3 * i], P[3 * i + 1], P[3 * i + 2])); r.sort(function (a, b) { return a - b; }); return r[Math.floor(r.length * 0.95)] || 100; }
  function fitCam() { var r = radius95(); dist = Math.max(60, r * 1.25 / Math.tan(20 * Math.PI / 180) / Math.min(1, camera.aspect)); }
  function colorize() {
    var c = new THREE.Color();
    for (var i = 0; i < N; i++) {
      var col = '#59606b';
      if (colorMode === 'pull') { var bs = -1, bv = 0; for (var s = 0; s < NSL; s++) { var k = assign[s]; if (k < 0) continue; var v = PS[k * N + i]; if (v > bv) { bv = v; bs = s; } } if (bs >= 0) col = SCOL[bs]; }
      else if (colorMode === 'lines') { var d = DEG[i]; col = d <= 1 ? '#ff5d5d' : d === 2 ? '#ffb347' : d <= 5 ? '#7fd1b9' : '#6ea8fe'; }
      else if (colorMode === 'class') { col = CLSCOL[CLSN[CLS[i]]] || '#59606b'; }
      else if (colorMode === 'gates') { col = D.gates[W[i]] ? '#ffd166' : '#3a3f47'; }
      c.set(col); colAttr.setXYZ(i, c.r, c.g, c.b);
    }
    colAttr.needsUpdate = true;
  }
  function makeLabel(text, color, cls) { var el = document.createElement('div'); el.className = 'lab' + (cls ? ' ' + cls : ''); el.textContent = text; if (color) el.style.color = color; labelBox.appendChild(el); return el; }
  function guides() {
    while (guideGroup.children.length) guideGroup.remove(guideGroup.children[0]);
    labels.filter(function (l) { return l.guide; }).forEach(function (l) { l.el.remove(); });
    labels = labels.filter(function (l) { return !l.guide; });
    var R = radius95() * 1.25, op = +$('gop').value / 100, showEmpty = $('gempty').checked, showLab = $('glab').checked;
    SL.forEach(function (s, k) {
      var k2 = assign[k]; if (k2 < 0 && !showEmpty) return;
      var geo2 = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, 0), w3([s.u[0] * R, s.u[1] * R, s.u[2] * R])]);
      guideGroup.add(new THREE.Line(geo2, new THREE.LineBasicMaterial({ color: new THREE.Color(SCOL[k]), transparent: true, opacity: k2 < 0 ? op * 0.5 : op, depthWrite: false })));
      if (showLab) { var rr = R * (s.type === 'quad' ? 1.1 : 1.03); labels.push({ guide: true, el: makeLabel(mi(s.name) + ' ' + (k2 >= 0 ? PN[k2] : '(empty)'), SCOL[k], 'g'), at: [s.u[0] * rr, s.u[1] * rr, s.u[2] * rr] }); }
    });
    labels.push({ guide: true, el: makeLabel('0,0,0 origin', '#f2efe6', 'g'), at: [0, 0, 0] });
  }
  function drawSel() {
    if (!hasGL) return;
    while (selGroup.children.length) selGroup.remove(selGroup.children[0]);
    labels.filter(function (l) { return l.sel; }).forEach(function (l) { l.el.remove(); });
    labels = labels.filter(function (l) { return !l.sel; });
    if (sel < 0) return;
    var hp = [], hc = [], segs = [], scol = [], ghosts = [], gcol = [], c = new THREE.Color();
    function push(arr, carr, p, col) { arr.push(p[0], p[2], -p[1]); c.set(col); carr.push(c.r, c.g, c.b); }
    var ps = posOf(sel); push(hp, hc, ps, '#ffffff');
    // the selected word's own pulls: a faint line along each pull, as long as its strength
    pullsOf(sel).forEach(function (x) { var u = SL[x.s].u, L2 = x.v * 100; push(segs, scol, ps, SCOL[x.s]); push(segs, scol, [ps[0] - u[0] * L2, ps[1] - u[1] * L2, ps[2] - u[2] * L2], SCOL[x.s]); });
    var named = 0;
    REL.forEach(function (r) {
      var on = $('k_' + r.k); if (on && !on.checked) return;
      var po = posOf(r.other); push(hp, hc, po, KCOL[r.k]); push(segs, scol, ps, KCOL[r.k]); push(segs, scol, po, KCOL[r.k]);
      if ($('ghost').checked) { push(ghosts, gcol, r.q, KCOL[r.k]); push(segs, scol, r.q, '#ffffff'); push(segs, scol, posOf(r.b), '#ffffff'); }
      if (named < 40) { labels.push({ sel: true, el: makeLabel(W[r.other], KCOL[r.k], 'sm'), at: po }); named++; }
    });
    labels.push({ sel: true, el: makeLabel(W[sel], '#ffffff'), at: ps });
    var gp = new THREE.BufferGeometry(); gp.setAttribute('position', new THREE.Float32BufferAttribute(hp, 3)); gp.setAttribute('color', new THREE.Float32BufferAttribute(hc, 3));
    selGroup.add(new THREE.Points(gp, new THREE.PointsMaterial({ size: 9, sizeAttenuation: false, vertexColors: true, depthTest: false, transparent: true })));
    if (ghosts.length) { var gg = new THREE.BufferGeometry(); gg.setAttribute('position', new THREE.Float32BufferAttribute(ghosts, 3)); gg.setAttribute('color', new THREE.Float32BufferAttribute(gcol, 3)); selGroup.add(new THREE.Points(gg, new THREE.PointsMaterial({ size: 6, sizeAttenuation: false, vertexColors: true, depthTest: false, transparent: true, opacity: 0.6 }))); }
    var gl = new THREE.BufferGeometry(); gl.setAttribute('position', new THREE.Float32BufferAttribute(segs, 3)); gl.setAttribute('color', new THREE.Float32BufferAttribute(scol, 3));
    selGroup.add(new THREE.LineSegments(gl, new THREE.LineBasicMaterial({ vertexColors: true, transparent: true, opacity: 0.75, depthTest: false })));
  }
  function drawAllLines() {
    if (!hasGL) return;
    if (allLines) { scene.remove(allLines); allLines = null; }
    var k = $('allk').value; if (!k) return;
    var ki = KINDS.indexOf(k), arr = [];
    for (var e6 = 0; e6 < NL; e6++) { if ((LK[e6] >> 2) !== ki) continue; var a = posOf(LA[e6]), b = posOf(LB[e6]); arr.push(a[0], a[2], -a[1], b[0], b[2], -b[1]); }
    var gl = new THREE.BufferGeometry(); gl.setAttribute('position', new THREE.Float32BufferAttribute(arr, 3));
    allLines = new THREE.LineSegments(gl, new THREE.LineBasicMaterial({ color: KCOL[k], transparent: true, opacity: 0.1, depthWrite: false }));
    scene.add(allLines);
  }
  function writePos() { var a = geo.attributes.position; for (var i = 0; i < N; i++) a.setXYZ(i, shown[3 * i], shown[3 * i + 2], -shown[3 * i + 1]); a.needsUpdate = true; geo.computeBoundingSphere(); }
  function pick(ev) {
    var rect = renderer.domElement.getBoundingClientRect(), mx = ev.clientX - rect.left, my = ev.clientY - rect.top, best = -1, bd = 12 * 12, v = new THREE.Vector3();
    camera.updateMatrixWorld();
    for (var i = 0; i < N; i++) { v.set(shown[3 * i], shown[3 * i + 2], -shown[3 * i + 1]).project(camera); if (v.z > 1) continue; var sx = (v.x + 1) / 2 * rect.width, sy = (1 - v.y) / 2 * rect.height, d = (sx - mx) * (sx - mx) + (sy - my) * (sy - my); if (d < bd) { bd = d; best = i; } }
    showWord(best);
  }
  function initGL() {
    var canvas = $('c');
    renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true }); renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    scene = new THREE.Scene(); camera = new THREE.PerspectiveCamera(40, 1, 0.5, 100000);
    geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(new Float32Array(N * 3), 3));
    colAttr = new THREE.Float32BufferAttribute(new Float32Array(N * 3), 3); geo.setAttribute('color', colAttr);
    scene.add(new THREE.Points(geo, new THREE.PointsMaterial({ size: 2.6, sizeAttenuation: false, vertexColors: true, transparent: true, opacity: 0.85 })));
    guideGroup = new THREE.Group(); scene.add(guideGroup); selGroup = new THREE.Group(); scene.add(selGroup);
    labelBox = $('labels');
    var ptrs = {}, dragging = false, moved = false, lx = 0, ly = 0, pinch = 0;
    canvas.addEventListener('pointerdown', function (e7) { ptrs[e7.pointerId] = [e7.clientX, e7.clientY]; dragging = true; moved = false; lx = e7.clientX; ly = e7.clientY; canvas.setPointerCapture(e7.pointerId); });
    canvas.addEventListener('pointermove', function (e7) {
      if (!dragging) return; ptrs[e7.pointerId] = [e7.clientX, e7.clientY]; var ids = Object.keys(ptrs);
      if (ids.length >= 2) { var a = ptrs[ids[0]], b = ptrs[ids[1]], d = Math.hypot(a[0] - b[0], a[1] - b[1]); if (pinch) dist = Math.min(1e5, Math.max(8, dist * pinch / d)); pinch = d; moved = true; return; }
      var dx = e7.clientX - lx, dy = e7.clientY - ly; lx = e7.clientX; ly = e7.clientY; if (Math.abs(dx) + Math.abs(dy) > 2) moved = true; theta -= dx * 0.005; phi = Math.min(Math.PI - 0.05, Math.max(0.05, phi - dy * 0.005));
    });
    function up(e7) { delete ptrs[e7.pointerId]; if (Object.keys(ptrs).length < 2) pinch = 0; if (!Object.keys(ptrs).length) { dragging = false; if (!moved) pick(e7); } }
    canvas.addEventListener('pointerup', up); canvas.addEventListener('pointercancel', up);
    canvas.addEventListener('wheel', function (e7) { e7.preventDefault(); dist = Math.min(1e5, Math.max(8, dist * (1 + e7.deltaY * 0.0012))); }, { passive: false });
    function resize() { var w = $('stage').clientWidth, h = $('stage').clientHeight; renderer.setSize(w, h, false); camera.aspect = w / Math.max(1, h); camera.updateProjectionMatrix(); }
    window.addEventListener('resize', resize); resize();
    var last = performance.now(), v = new THREE.Vector3();
    function frame(now) {
      var dt = (now - last) / 1000; last = now;
      if ($('spin').getAttribute('aria-pressed') === 'true' && !dragging) theta += dt * 0.1;
      if (tween) { var t = Math.min(1, (now - tween.t0) / 700), s = t * t * (3 - 2 * t); for (var i = 0; i < N * 3; i++) shown[i] = tween.from[i] + (P[i] - tween.from[i]) * s; writePos(); if (t >= 1) tween = null; }
      camera.position.set(dist * Math.sin(phi) * Math.sin(theta), dist * Math.cos(phi), dist * Math.sin(phi) * Math.cos(theta)); camera.lookAt(0, 0, 0);
      renderer.render(scene, camera);
      var w = $('stage').clientWidth, h = $('stage').clientHeight;
      labels.forEach(function (l) { v.copy(w3(l.at)).project(camera); if (v.z > 1 || Math.abs(v.x) > 1.1 || Math.abs(v.y) > 1.1) { l.el.style.display = 'none'; return; } l.el.style.display = ''; l.el.style.transform = 'translate(' + ((v.x + 1) / 2 * w).toFixed(1) + 'px,' + ((1 - v.y) / 2 * h).toFixed(1) + 'px)'; });
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }

  function refresh(newPreset) {
    var from = shown.slice();
    compute(); liveFit(); status();
    if (hasGL) { colorize(); guides(); if (newPreset) fitCam(); if (reduce || newPreset === 'first') { shown.set(P); writePos(); } else tween = { from: from, t0: performance.now() }; }
    drawAllLines();
    if (sel >= 0) showWord(sel); else drawSel();
    if (!$('atlas').hidden) atlas();
    $('hudg').textContent = assign.filter(function (k) { return k >= 0; }).length + ' pulls: ' + N.toLocaleString() + ' words; 100 = one full pull';
  }
  function setPreset(k) { cur = k; assign = PRE[k].assign.slice(); $('preset').value = String(k); syncSlots(); testTable(); refresh(true); }

  // ---- wire up
  $('lkinds').innerHTML = KINDS.map(function (k) { return '<label class="chk"><input type="checkbox" id="k_' + k + '" checked><span class="kd" style="--c:' + KCOL[k] + '"></span>' + k + '</label>'; }).join('');
  $('allk').innerHTML = '<option value="">none</option>' + KINDS.map(function (k) { return '<option value="' + k + '">' + k + '</option>'; }).join('');
  KINDS.forEach(function (k) { $('k_' + k).addEventListener('change', drawSel); });
  ['gop', 'gempty', 'glab'].forEach(function (id) { $(id).addEventListener('input', function () { if (hasGL) guides(); }); $(id).addEventListener('change', function () { if (hasGL) guides(); }); });
  $('ghost').addEventListener('change', drawSel);
  $('allk').addEventListener('change', drawAllLines);
  $('cmode').addEventListener('change', function () { colorMode = $('cmode').value; if (hasGL) colorize(); legend(); });
  $('preset').addEventListener('change', function () { setPreset(+$('preset').value); });
  $('reset').addEventListener('click', function () { setPreset(cur); });
  $('fitb').addEventListener('click', function () { if (hasGL) fitCam(); });
  $('find').addEventListener('keydown', function (e8) { if (e8.key === 'Enter') findWord($('find').value); });
  $('findb').addEventListener('click', function () { findWord($('find').value); });
  $('spin').addEventListener('click', function () { var b = $('spin'); b.setAttribute('aria-pressed', b.getAttribute('aria-pressed') === 'true' ? 'false' : 'true'); });
  $('atlasbtn').addEventListener('click', function () { $('atlas').hidden = false; atlas(); });
  $('aclose').addEventListener('click', function () { $('atlas').hidden = true; });
  $('afind').addEventListener('input', atlas); $('ashow').addEventListener('change', atlas);
  function legend() {
    var h = '';
    if (colorMode === 'pull') h = '<span>colour = the direction of the word\'s strongest pull (same colour as that pull\'s line)</span>';
    if (colorMode === 'lines') h = '<span><i style="--c:#ff5d5d"></i>1 line</span><span><i style="--c:#ffb347"></i>2 lines</span><span><i style="--c:#7fd1b9"></i>3 to 5</span><span><i style="--c:#6ea8fe"></i>6 or more</span>';
    if (colorMode === 'class') h = Object.keys(CLSCOL).map(function (t) { return '<span><i style="--c:' + CLSCOL[t] + '"></i>' + t + '</span>'; }).join('') + '<span><i style="--c:#59606b"></i>other</span>';
    if (colorMode === 'gates') h = '<span><i style="--c:#ffd166"></i>brain gate</span><span><i style="--c:#3a3f47"></i>map word</span>';
    $('legend').innerHTML = h;
  }
  presetSelect(); slotTable(); testTable(); legend();
  if (hasGL) initGL(); else $('err').style.display = 'flex';
  refresh('first'); if (hasGL) { fitCam(); }
  var hash = (location.hash || '').slice(1); showWord(hash && WIDX[decodeURIComponent(hash)] != null ? WIDX[decodeURIComponent(hash)] : (WIDX['sluggish'] != null ? WIDX['sluggish'] : -1));
  window.__pulls = { ready: true, presets: function () { return PRE.map(function (p) { return { key: p.key, mean: p.mean }; }); }, set: setPreset, fit: function () { return FIT.mean; },
    pos: function (w) { return posOf(WIDX[w]); }, sel: function () { return $('sel').innerText; }, status: function () { return $('status').innerText; },
    setSlot: function (s, k) { assign[s] = k; syncSlots(); refresh(false); return FIT.mean; }, assign: function () { return assign.slice(); },
    atlas: function () { $('atlas').hidden = false; atlas(); return $('atable').querySelectorAll('tr.arow').length; }, guides: function () { return hasGL ? guideGroup.children.map(function (g) { return g.material.opacity; }) : []; } };
})();
