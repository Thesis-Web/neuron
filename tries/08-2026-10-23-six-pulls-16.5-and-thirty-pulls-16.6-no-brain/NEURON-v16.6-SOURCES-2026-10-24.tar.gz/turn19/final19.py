# turn 19: exact held-out scores for the 30-pull presets (build pulls), controls, checks on the shown places, page export
# usage: python3 -I final19.py <turn18 out> <turn19 out> <told physics16.json>   (env PROCS, default 4)
import sys, os, json, base64, time, collections
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'turn18'))
from lib18 import *
import multiprocessing as mp

src, out, toldp = sys.argv[1:4]
PROCS = int(os.environ.get('PROCS', '4'))
j, z, L, WN = load(src)
words = j['words']; n = len(words); w2i = {w: i for i, w in enumerate(words)}
PZ = np.load(os.path.join(out, 'pool19.npz')); POOLB, POOLS = PZ['build'], PZ['shown']
meta = json.load(open(os.path.join(out, 'pool19.json'))); NAMES = meta['name']
told = json.load(open(toldp))
t0 = time.time()
def log(*a): print(round(time.time() - t0), 's', *a, flush=True)

PRE = [('A', 'Best 30 found'), ('B', 'Relationships + actions'), ('C', 'The fourteen actions'), ('D', 'Six named pulls (v16.5)')]
SR = {k: json.load(open(os.path.join(out, 'search19_%s.json' % k))) for k, _ in PRE}
SL = SR['A']['slots']
U = np.array([np.array(v, float) / np.linalg.norm(v) for _, _, v in SL])
def place(assign, pool):
    P = np.zeros((pool.shape[1], 3))
    for s, k in enumerate(assign):
        if k >= 0: P += np.outer(pool[k], U[s])
    return P

def _exact(key):
    P = place(SR[key]['assign'], POOLB)
    r = score_graph(P, L, maxlines=2000)
    w = score_graph(P, WN, kinds=WNKINDS, train_split='fit', choose_split='fit', report_split='score', maxlines=2000)
    rs = score_graph(P[np.random.default_rng(7).permutation(n)], L, maxlines=2000)
    return key, {'map': r, 'wn': w, 'shuffled': rs}
def _random(_):
    rr = np.random.default_rng(11); a = SR['A']['assign']
    pool = POOLB.copy()
    for k in set(a):
        if k >= 0: pool[k] = pool[k][rr.permutation(n)]
    return score_graph(place(a, pool), L, maxlines=2000)
with mp.Pool(PROCS) as pp:
    RES = dict(pp.map(_exact, [k for k, _ in PRE]))
    RANDOM = pp.map(_random, [0])[0]
def mean_med(r): return float(np.mean([v['test'][v['best']]['median'] for v in r.values()]))
def pts(r, sh):
    return [k for k in KINDS if r[k]['test'][r[k]['best']]['median'] < 0.25 and r[k]['test'][r[k]['best']]['hit10'] >= 0.003 and sh[k]['test'][sh[k]['best']]['median'] >= 0.45]
for k, t in PRE:
    r = RES[k]
    log(k, t, 'mean', round(mean_med(r['map']), 4), 'points out', pts(r['map'], r['shuffled']),
        {kn: (v['best'], round(v['test'][v['best']]['median'], 3), round(v['test'][v['best']]['hit10'] * 100, 1)) for kn, v in r['map'].items()})
    log(k, 'shuffled', {kn: round(v['test'][v['best']]['median'], 3) for kn, v in r['shuffled'].items()})
    log(k, 'wordnet', {kn: (v['best'], round(v['test'][v['best']]['median'], 3), round(v['test'][v['best']]['hit10'] * 100, 1)) for kn, v in r['wn'].items()})
log('random pulls (A)', round(mean_med(RANDOM), 4), {kn: round(v['test'][v['best']]['median'], 3) for kn, v in RANDOM.items()})

# ---- checks on the SHOWN places (pulls from all lines)
deg = np.zeros(n, int); kset = collections.defaultdict(set)
for a, b, kn, spl in j['lines']:
    deg[a] += 1; deg[b] += 1; kset[a].add(kn); kset[b].add(kn)
DV = np.array([np.array(v, float) / np.linalg.norm(v) for v in
               [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)] +
               [tuple(sa * (i == a) + sb * (i == b) for i in range(3)) for a in range(3) for b in range(a + 1, 3) for sa in (1, -1) for sb in (1, -1)] +
               [(x, y, zz) for x in (1, -1) for y in (1, -1) for zz in (1, -1)]])
CHK = {}
EX = ['sluggish', 'sluggishness', 'origin', 'zero', 'absent', 'cat', 'dog', 'before', 'after', 'move', 'read', 'memory', 'hot', 'cold']
for k, t in PRE:
    a = SR[k]['assign']; P = place(a, POOLS); rad = np.linalg.norm(P, axis=1)
    filled = [kk for kk in a if kk >= 0]
    npull = (POOLS[filled] > 0.01).sum(0)
    cosmax = np.where(rad > 1e-9, ((P / np.maximum(rad, 1e-12)[:, None]) @ DV.T).max(1), 1)
    online = rad > 1e-9
    online &= cosmax > np.cos(np.radians(3))
    keyp = np.round(P, 9); uq, cnt = np.unique(keyp, axis=0, return_counts=True)
    o = w2i['origin']
    ex = {}
    for w in EX:
        if w not in w2i: continue
        i = w2i[w]; sh = [(SL[s][1], NAMES[kk], float(POOLS[kk][i])) for s, kk in enumerate(a) if kk >= 0 and POOLS[kk][i] > 0]
        tot = sum(x[2] for x in sh) or 1
        ex[w] = {'place': (P[i] * 100).round(1).tolist(), 'radius_pct': float((rad < rad[i]).mean()), 'lines': int(deg[i]),
                 'ratio': sorted([(d, nm, round(v / tot * 100, 1)) for d, nm, v in sh], key=lambda x: -x[2])[:8]}
    CHK[k] = {'at_origin': int((rad < 1e-9).sum()), 'distinct': int(len(uq)), 'largest_stack': int(cnt.max()),
              'pulls_le2': int((npull <= 2).sum()), 'on_a_line_3deg': int(online.sum()),
              'origin_place': (P[o] * 100).round(1).tolist(), 'origin_radius_pct': float((rad < rad[o]).mean()),
              'median_radius': float(np.median(rad) * 100), 'examples': ex}
    log(k, {kk: v for kk, v in CHK[k].items() if kk != 'examples'})
    log(k, 'sluggish', ex.get('sluggish'))
lines12 = {'words': n, 'le2_lines': int((deg <= 2).sum()), 'one_kind': int(sum(1 for i in range(n) if len(kset[i]) == 1))}
log('map', lines12)

json.dump({'res': RES, 'random': RANDOM, 'chk': CHK, 'map': lines12, 'search': {k: {'assign': SR[k]['assign'], 'score': SR[k]['score'], 'curve': SR[k]['curve']} for k, _ in PRE}},
          open(os.path.join(out, 'final19.json'), 'w'), default=lambda o: o.tolist() if hasattr(o, 'tolist') else (int(o) if isinstance(o, np.integer) else str(o)))

# ---- page export
def b64(a): return base64.b64encode(np.ascontiguousarray(a).tobytes()).decode()
gate = {}
for grp, lst in (('physics', told['physics']), ('action', told['actions']), ('sql', told['sqlroots']), ('arrival', told['arrivals']), ('port', told['ports']), ('sat', told['sats'])):
    for w in lst:
        if w.lower() in w2i: gate[w.lower()] = grp
gate['origin'] = 'told'
def topw(v, k=10):
    o = np.argsort(-v); return [words[i] for i in o[:k] if v[i] > 0]
la, lb, lk = [], [], []
SPL = {'train': 0, 'val': 1, 'test': 2}
for (kn, spl), p in L.items():
    la.append(p[:, 0]); lb.append(p[:, 1]); lk.append(np.full(len(p), KINDS.index(kn) * 4 + SPL[spl]))
EXP = {'words': words, 'kinds': KINDS, 'cls': z['cls'].tolist(), 'clsNames': j['clsNames'], 'gates': gate, 'deg': b64(np.minimum(deg, 65535).astype(np.uint16)),
       'la': b64(np.concatenate(la).astype(np.int32)), 'lb': b64(np.concatenate(lb).astype(np.int32)), 'lk': b64(np.concatenate(lk).astype(np.uint8)),
       'pool': {'name': NAMES, 'group': meta['group'], 'how': meta['how'], 'top': [topw(POOLS[k]) for k in range(len(NAMES))],
                'shown': b64(np.where(POOLS > 0, np.maximum(1, np.round(POOLS * 255)), 0).astype(np.uint8))},
       'slots': SL, 'map': lines12,
       'presets': [{'key': k, 'title': t, 'assign': SR[k]['assign'], 'curve': SR[k]['curve'], 'chk': {kk: v for kk, v in CHK[k].items() if kk != 'examples'},
                    'test': {kn: {'best': v['best'], 'median': v['test'][v['best']]['median'], 'hit10': v['test'][v['best']]['hit10'],
                                  'same': v['test'].get('same', v['test'][v['best']])['median'] if 'same' in v['test'] else v['test'][v['best']]['median'],
                                  'shuffled': RES[k]['shuffled'][kn]['test'][RES[k]['shuffled'][kn]['best']]['median']} for kn, v in RES[k]['map'].items()},
                    'wn': {kn: {'best': v['best'], 'median': v['test'][v['best']]['median'], 'hit10': v['test'][v['best']]['hit10'], 'n': v['test'][v['best']]['n']} for kn, v in RES[k]['wn'].items()},
                    'mean': mean_med(RES[k]['map']), 'pts': pts(RES[k]['map'], RES[k]['shuffled'])} for k, t in PRE],
       'random_mean': mean_med(RANDOM)}
json.dump(EXP, open(os.path.join(out, 'page19.json'), 'w'), default=lambda o: o.tolist() if hasattr(o, 'tolist') else (int(o) if isinstance(o, np.integer) else str(o)))
log('export', os.path.getsize(os.path.join(out, 'page19.json')))
# numbers the page must reproduce: shown places for 30 random words per preset
rc = np.random.default_rng(3)
C = {k: [[words[i], (place(SR[k]['assign'], POOLS)[i] * 100).tolist()] for i in rc.choice(n, 30, replace=False)] for k, _ in PRE}
json.dump(C, open(os.path.join(out, 'check19.json'), 'w'))
log('done')
