// turn 19 page check: node shot19.js <html> <shot prefix> <check19.json>
const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
const fs = require('fs');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const errs = [], R = {};
  const chk = JSON.parse(fs.readFileSync(process.argv[4], 'utf8'));
  const open = async (opts) => {
    const page = await browser.newPage(opts); page.on('pageerror', e => errs.push(e.message)); page.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text()); });
    await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('data:') || u.includes('cdnjs.cloudflare.com') || u.includes('fonts.g') ? r.continue() : r.abort(); });
    await page.goto('file://' + process.argv[2]); await page.waitForFunction(() => window.__pulls && window.__pulls.ready, null, { timeout: 120000 }); return page; };
  const page = await open({ viewport: { width: 1600, height: 950 } });
  await page.waitForTimeout(2000);
  R.presets = await page.evaluate(() => window.__pulls.presets());
  R.pos = [];
  for (let k = 0; k < R.presets.length; k++) {
    const key = R.presets[k].key;
    const t0 = Date.now(); await page.evaluate(k => window.__pulls.set(k), k); R['setMs' + key] = Date.now() - t0; await page.waitForTimeout(900);
    let md = 0; for (const [w, p] of chk[key]) { const q = await page.evaluate(w => window.__pulls.pos(w), w); md = Math.max(md, Math.hypot(q[0] - p[0], q[1] - p[1], q[2] - p[2])); }
    R.pos.push([key, md, await page.evaluate(() => window.__pulls.fit())]);
    if (k === 0) R.status = await page.evaluate(() => window.__pulls.status());
  }
  await page.evaluate(() => window.__pulls.set(0)); await page.waitForTimeout(1000);
  R.guideOpacity = [...new Set(await page.evaluate(() => window.__pulls.guides()))];
  await page.fill('#find', 'sluggish'); await page.press('#find', 'Enter'); await page.waitForTimeout(800);
  R.sel = (await page.evaluate(() => window.__pulls.sel())).slice(0, 1200);
  await page.screenshot({ path: process.argv[3] + '-main.png' });
  // substitution: empty slot 0, then put it back
  const a0 = (await page.evaluate(() => window.__pulls.assign()))[0];
  const t1 = Date.now(); R.fitEmpty0 = await page.evaluate(() => window.__pulls.setSlot(0, -1)); R.substituteMs = Date.now() - t1;
  R.fitBack = await page.evaluate(a0 => window.__pulls.setSlot(0, a0), a0);
  await page.selectOption('#cmode', 'lines'); await page.waitForTimeout(400);
  await page.screenshot({ path: process.argv[3] + '-lines.png' });
  R.atlasRows = await page.evaluate(() => window.__pulls.atlas());
  await page.fill('#afind', 'origin'); await page.waitForTimeout(300);
  R.atlasOrigin = await page.evaluate(() => document.querySelector('#asum').innerText + ' | ' + (document.querySelector('#atable tr.arow') || {}).innerText);
  await page.screenshot({ path: process.argv[3] + '-atlas.png' });
  await page.click('#aclose');
  await page.evaluate(() => window.__pulls.set(2)); await page.waitForTimeout(1000); await page.selectOption('#cmode', 'pull'); await page.waitForTimeout(300);
  await page.screenshot({ path: process.argv[3] + '-actions.png' });
  R.overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  const phone = await open({ viewport: { width: 400, height: 860 }, deviceScaleFactor: 2 });
  await phone.waitForTimeout(1500); R.phoneOverflow = await phone.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  await phone.screenshot({ path: process.argv[3] + '-phone.png' });
  const dark = await open({ viewport: { width: 1600, height: 950 }, colorScheme: 'dark' });
  await dark.waitForTimeout(1500); await dark.screenshot({ path: process.argv[3] + '-dark.png' });
  R.errors = errs;
  console.log(JSON.stringify(R, null, 1));
  await browser.close();
})();
