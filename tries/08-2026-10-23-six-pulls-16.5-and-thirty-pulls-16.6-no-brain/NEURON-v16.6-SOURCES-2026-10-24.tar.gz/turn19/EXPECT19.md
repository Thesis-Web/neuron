# Turn 19: thirty pulls. Expected outputs, written BEFORE any graph was scored (2026-10-24, ~00:10 CDT)

Owner, verbatim (turn16/OWNER-VERBATIM.txt, messages 7-9):
- "the key is that the neurons all start at origin and are pulled away by their relationships further away the stronger the pull in that direction"
- "6 regular axis + 4 top linear ... + 4 bottom linear ... 4 flat linear ... triangular bisects (3 axis) ... then the quads" -> "this would give you 30 pulls , that could be relationships, actions, tense, defintions, suffix, prefix, etc..."
- "the graph says 14 pulls but I only see 6 pull lines , the other pull lines need to be visible"; "the added pull lines are very faint... I want to be able to see them, but just barely"
- "once you get the pulls correct , then you can change each pull by substitution until you start to see mathmatically where nuerons land ... taking a ratio of the various pulls to the neuron, we might be able to understand what the meaning of that neuron actually is"
- "if you see lines of neurons, or radiations ... then that neurons relationships are not more than 1 or 2"
- "the only word with zero pull is origin... even origin has those relationships, but the sum of their pull cancels ... or equals 0,0,0"
- "if something has no pull it has no definition, class, tense, opposite, similar, alike, how is it even a point on the graph??????"

## The form
30 pull slots, one per direction: 6 axes, 12 two-axis bisects (4 top with +z, 4 bottom with -z, 4 flat), 8 three-axis bisects, 4 quads (-z,y,x,z / -z,x,-y,z / -z,-x,z,y / -z,-x,-y,z).
In 3D +z and -z cancel inside a quad, so each quad points the same way as one flat bisect (x,y / x,-y / -x,y / -x,-y). They stay separate pull slots drawn on the same line.
    place = sum over the 30 slots of  strength(word, pull in that slot) x unit direction of the slot
Strength 0 to 1 per pull (as in v16.5). 100 on the page = one full pull. Nothing else: no steps, no cap, no spacing.
The 30 directions sum to zero, so a word pulled equally by all 30 sits at 0,0,0.

## Two versions of each word's pulls
- Scored version: pulls built from build lines only (70%); choose and test lines held back, as in v16.5.
- Shown version: pulls built from ALL lines (what the brain would have). Every word in the map has at least one line.
The page shows the shown version and a live fit number labelled as a fit to all lines, not a test.

## Graphs (presets the owner can start from and then substitute)
- A. Best 30 found: greedy fill of the 30 slots from the 106-pull pool (choose split), then swaps until nothing helps.
- B. Relationships + actions: the 16 relationship pulls (tense 2, number 2, modifiers 5, line counts 6, WordNet senses = definitions) + the 14 actions = 30; only their slots are chosen.
- C. The fourteen actions: all 14 visible, slots chosen among the 30.
- D. Six named pulls of v16.5, on the 6 axes (for comparison).

## Predictions (test mean rank share over 9 kinds; v16.5 named six = 0.102)
- A: 0.07. B: 0.15. C: 0.25. D: 0.102 (same graph as v16.5).
- The greedy curve flattens after about 12 pulls (each added pull helps by less than 0.002).
- A meets my v16.5 bar (7 of 9 map kinds, 3 of 5 WordNet kinds): no, about 5 of 9.
- Shuffled controls 0.50 +- 0.03 (except suffix/prefix, which a fixed guess finds); random pulls 0.40-0.50.
- The word "origin" lands at 0,0,0 or near it: no. More than 20% of words sit nearer 0,0,0 than "origin" in A, B and C.
- Words at exactly 0,0,0 in the shown version: 0 in A, B, C (every word has a line, and reach pulls touch 92%); a few in D.
- Radiations: words with 2 or fewer non-zero pulls among the filled slots in the shown version: under 10% in A and B (reach pulls are dense), more in D.
- Map fact (measured before this file): 10,197 of 27,606 words (37%) have only 1 or 2 lines; 5,875 have one kind of line.

## SQLite check
A scratch SQLite database (never the brain) holds pull(word, slot, strength) and dir(slot, ux, uy, uz); a view place = SUM(strength * u) GROUP BY word. Prediction: equal to the numpy places within 1e-9; an R*Tree 3D index answers "words near this point". Also run in sql.js (the engine the brain pages use).
