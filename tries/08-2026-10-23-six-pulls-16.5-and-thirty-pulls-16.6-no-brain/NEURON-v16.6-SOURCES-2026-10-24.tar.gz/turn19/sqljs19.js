// turn 19: the same scratch database opened in sql.js (the SQLite build the brain pages use)
// usage: node sqljs19.js <sql-asm-memory-growth.js> <scratch db>
const fs = require('fs');
const initSqlJs = require(process.argv[2]);
initSqlJs().then(SQL => {
  const db = new SQL.Database(fs.readFileSync(process.argv[3]));
  const out = { version: db.exec('SELECT sqlite_version()')[0].values[0][0] };
  let t = Date.now();
  const r = db.exec('SELECT word, x, y, z FROM place ORDER BY word')[0].values;
  out.view_ms = Date.now() - t; out.words = r.length;
  // compare with the python sqlite answer stored next to the db
  const py = JSON.parse(fs.readFileSync(process.argv[3] + '.places.json', 'utf8'));
  let md = 0; r.forEach(([w, x, y, z]) => { const p = py[w]; md = Math.max(md, Math.abs(p[0] - x), Math.abs(p[1] - y), Math.abs(p[2] - z)); });
  out.max_diff_vs_python_sqlite = md;
  try { out.rtree = db.exec('SELECT count(*) FROM near')[0].values[0][0]; } catch (e) { out.rtree = 'error: ' + e.message; }
  console.log(JSON.stringify(out));
});
