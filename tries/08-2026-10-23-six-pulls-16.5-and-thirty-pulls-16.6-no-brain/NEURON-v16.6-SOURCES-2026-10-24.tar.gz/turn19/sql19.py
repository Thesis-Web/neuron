# turn 19: can SQLite hold and compute the 3D pull graph? A scratch database only (never the brain).
#   word(id, label), pull(word, slot, strength), dir(slot, name, ux, uy, uz)
#   VIEW place: x, y, z = SUM(strength * u) per word        -- the 30-pull formula, in SQL
#   R*Tree 3D index over the places: "which words sit near this point"
# usage: python3 -I sql19.py <turn18 out> <turn19 out> <preset A|B|C|D> <scratch db path> <sql out path>
import sys, os, json, time, sqlite3
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'turn18'))
from lib18 import *

src, out, which, dbp, sqlp = sys.argv[1:6]
j = json.load(open(os.path.join(src, 'data18.json'))); words = j['words']; n = len(words)
POOLS = np.load(os.path.join(out, 'pool19.npz'))['shown']
S = json.load(open(os.path.join(out, 'search19_%s.json' % which)))
SL = S['slots']; assign = S['assign']
U = np.array([np.array(v, float) / np.linalg.norm(v) for _, _, v in SL])
P = np.zeros((n, 3))
for s, k in enumerate(assign):
    if k >= 0: P += np.outer(POOLS[k], U[s])

if os.path.exists(dbp): os.remove(dbp)
c = sqlite3.connect(dbp)
schema = """CREATE TABLE word (id INTEGER PRIMARY KEY, label TEXT);
CREATE TABLE dir (slot INTEGER PRIMARY KEY, name TEXT, ux REAL, uy REAL, uz REAL);
CREATE TABLE pull (word INTEGER, slot INTEGER, strength REAL);
CREATE VIEW place AS
  SELECT p.word AS word, SUM(p.strength * d.ux) AS x, SUM(p.strength * d.uy) AS y, SUM(p.strength * d.uz) AS z
  FROM pull p JOIN dir d ON d.slot = p.slot GROUP BY p.word;
CREATE VIRTUAL TABLE near USING rtree(word, x0, x1, y0, y1, z0, z1);"""
c.executescript(schema)
c.executemany('INSERT INTO word VALUES (?, ?)', enumerate(words))
c.executemany('INSERT INTO dir VALUES (?, ?, ?, ?, ?)', [(s, SL[s][1], *U[s]) for s in range(len(SL))])
rows = [(int(i), s, float(POOLS[k][i])) for s, k in enumerate(assign) if k >= 0 for i in np.nonzero(POOLS[k])[0]]
c.executemany('INSERT INTO pull VALUES (?, ?, ?)', rows); c.commit()
t = time.time(); got = c.execute('SELECT word, x, y, z FROM place ORDER BY word').fetchall(); tv = time.time() - t
Q = np.zeros((n, 3)); seen = np.zeros(n, bool)
for w, x, y, zz in got: Q[w] = (x, y, zz); seen[w] = True
diff = float(np.abs(Q - P).max())
t = time.time(); c.execute('INSERT INTO near SELECT word, x, x, y, y, z, z FROM place'); c.commit(); ti = time.time() - t
o = words.index('sluggish'); x, y, zz = Q[o]; r = 0.05
t = time.time()
nb = c.execute('SELECT w.label FROM near JOIN word w ON w.id = near.word WHERE x0 >= ? AND x1 <= ? AND y0 >= ? AND y1 <= ? AND z0 >= ? AND z1 <= ? LIMIT 25',
               (x - r, x + r, y - r, y + r, zz - r, zz + r)).fetchall()
tq = time.time() - t
print(json.dumps({'sqlite': sqlite3.sqlite_version, 'pull_rows': len(rows), 'words_placed': int(seen.sum()), 'max_diff_vs_numpy': diff,
                  'view_seconds': round(tv, 3), 'index_seconds': round(ti, 3), 'near_query_ms': round(tq * 1000, 2),
                  'near_sluggish': [x[0] for x in nb]}))
open(sqlp, 'w').write(schema + "\n-- place of one word:\nSELECT w.label, p.x, p.y, p.z FROM place p JOIN word w ON w.id = p.word WHERE w.label = 'sluggish';\n"
                      "-- words within 0.05 of it, from the 3D index:\nSELECT w.label FROM near JOIN word w ON w.id = near.word WHERE x0 >= :x - 0.05 AND x1 <= :x + 0.05 AND y0 >= :y - 0.05 AND y1 <= :y + 0.05 AND z0 >= :z - 0.05 AND z1 <= :z + 0.05;\n")
json.dump(Q.tolist(), open(dbp + '.places.json', 'w'))
c.close()
