# turn 19: page strengths as 0..255 with every non-zero pull kept non-zero (so "no pull" counts match Python)
# usage: python3 -I requant19.py <turn19 out>
import sys, os, json, base64
sys.path.append(os.path.expanduser('~/.local/lib/python3.10/site-packages'))
import numpy as np
out = sys.argv[1]
S = np.load(os.path.join(out, 'pool19.npz'))['shown']
q = np.where(S > 0, np.maximum(1, np.round(S * 255)), 0).astype(np.uint8)
E = json.load(open(os.path.join(out, 'page19.json')))
E['pool']['shown'] = base64.b64encode(np.ascontiguousarray(q).tobytes()).decode()
json.dump(E, open(os.path.join(out, 'page19.json'), 'w'))
print('requantized; zero cells', int((q == 0).sum()), 'python zero cells', int((S == 0).sum()))
