# turn 19: fill the 30 pull slots (6 axes, 12 two-axis, 8 three-axis, 4 quads) on the CHOOSE split, build pulls only
# usage: python3 -I search19.py <turn18 out> <turn19 out> <A|B|C|D>   (env PROCS, default 4)
import sys, os, json, time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'turn18'))
from lib18 import *
import multiprocessing as mp

src, out, which = sys.argv[1], sys.argv[2], sys.argv[3]
PROCS = int(os.environ.get('PROCS', '4'))
j, z, L, WN = load(src)
n = len(j['words'])
POOLB = np.load(os.path.join(out, 'pool19.npz'))['build']
meta = json.load(open(os.path.join(out, 'pool19.json')))
NAMES = meta['name']; NI = {nm: k for k, nm in enumerate(NAMES)}
PR = Proxy(L, n)

# the 30 slots, in the owner's order (message 7)
SL = [('axis', '+x', (1, 0, 0)), ('axis', '-x', (-1, 0, 0)), ('axis', '+y', (0, 1, 0)), ('axis', '-y', (0, -1, 0)), ('axis', '+z', (0, 0, 1)), ('axis', '-z', (0, 0, -1)),
      ('top', '+z,+x', (1, 0, 1)), ('top', '-y,+z', (0, -1, 1)), ('top', '-x,+z', (-1, 0, 1)), ('top', '+y,+z', (0, 1, 1)),
      ('bottom', '-z,+x', (1, 0, -1)), ('bottom', '-y,-z', (0, -1, -1)), ('bottom', '-x,-z', (-1, 0, -1)), ('bottom', '+y,-z', (0, 1, -1)),
      ('flat', '+x,-y', (1, -1, 0)), ('flat', '-y,-x', (-1, -1, 0)), ('flat', '-x,+y', (-1, 1, 0)), ('flat', '+y,+x', (1, 1, 0)),
      ('three-axis', '+y,-z,+x', (1, 1, -1)), ('three-axis', '+x,-z,-y', (1, -1, -1)), ('three-axis', '-y,-z,-x', (-1, -1, -1)), ('three-axis', '-x,-z,+y', (-1, 1, -1)),
      ('three-axis', '+y,+z,+x', (1, 1, 1)), ('three-axis', '+x,+z,-y', (1, -1, 1)), ('three-axis', '-y,+z,-x', (-1, -1, 1)), ('three-axis', '-x,+z,+y', (-1, 1, 1)),
      ('quad', '-z,+y,+x,+z', (1, 1, 0)), ('quad', '-z,+x,-y,+z', (1, -1, 0)), ('quad', '-z,-x,+z,+y', (-1, 1, 0)), ('quad', '-z,-x,-y,+z', (-1, -1, 0))]
U = np.array([np.array(v, float) / np.linalg.norm(v) for _, _, v in SL])
NS = len(SL)


def place(assign, pool):
    """assign: list of 30 pull indices or -1 (empty)"""
    P = np.zeros((pool.shape[1], 3))
    for s, k in enumerate(assign):
        if k >= 0: P += np.outer(pool[k], U[s])
    return P


BASE = None
def ev(move):
    s, k = move
    return PR(BASE + np.outer(POOLB[k], U[s])), s, k

def ev_assign(a):
    return PR(place(a, POOLB)), a


def run(fn, jobs):
    with mp.Pool(PROCS) as pp:
        return pp.map(fn, jobs, chunksize=16)


def greedy(allowed, max_slots):
    global BASE
    assign = [-1] * NS; curve = []; t0 = time.time()
    for step in range(max_slots):
        BASE = place(assign, POOLB)
        used = set(assign)
        jobs = [(s, k) for s in range(NS) if assign[s] < 0 for k in allowed if k not in used]
        if not jobs: break
        r = run(ev, jobs); r.sort(key=lambda x: x[0])
        sc, s, k = r[0]; assign[s] = k; curve.append((sc, SL[s][1], NAMES[k]))
        print('step', step + 1, round(sc, 4), SL[s][1], NAMES[k], round(time.time() - t0), 's', flush=True)
    return assign, curve


def improve(assign, allowed, fixed_set, passes=10):
    cur = PR(place(assign, POOLB))
    for p in range(passes):
        cands = []
        used = set(assign)
        for s in range(NS):
            if not fixed_set:            # replace the pull in a slot by an unused one
                for k in allowed:
                    if k not in used and assign[s] >= 0:
                        a = assign[:]; a[s] = k; cands.append(a)
            for t in range(s + 1, NS):    # swap two slots (moves a pull to another direction, or into an empty slot)
                if assign[s] != assign[t] and (assign[s] >= 0 or assign[t] >= 0) and not np.allclose(U[s], U[t]):
                    a = assign[:]; a[s], a[t] = a[t], a[s]; cands.append(a)
        r = run(ev_assign, cands); r.sort(key=lambda x: x[0])
        print('pass', p + 1, 'moves', len(cands), 'best', round(r[0][0], 4), 'was', round(cur, 4), flush=True)
        if r[0][0] > cur - 0.0005: break
        assign, cur = list(r[0][1]), r[0][0]
    return assign, cur


if __name__ == '__main__':
    t0 = time.time()
    G = [i for i, g in enumerate(meta['group'])]
    if which == 'A':
        allowed = list(range(len(NAMES)))
        assign, curve = greedy(allowed, NS)
        assign, sc = improve(assign, allowed, fixed_set=False)
    elif which == 'B':
        rel = [k for k, g in enumerate(meta['group']) if g in ('tense', 'number', 'modifier', 'relationship', 'definition')]
        act = [k for k, g in enumerate(meta['group']) if g == 'action']
        allowed = rel + act; assert len(allowed) == 30, len(allowed)
        assign, curve = greedy(allowed, NS)
        assign, sc = improve(assign, allowed, fixed_set=True)
    elif which == 'C':
        allowed = [k for k, g in enumerate(meta['group']) if g == 'action']
        assign, curve = greedy(allowed, len(allowed))
        assign, sc = improve(assign, allowed, fixed_set=True)
    elif which == 'D':
        six = ['source: in WordNet', 'WRITE', 'class: noun', 'class: adjective', 'WordNet share: adverb', 'HEAR']
        assign = [NI[nm] for nm in six] + [-1] * (NS - 6); curve = []
        sc = PR(place(assign, POOLB))
    print(which, 'done', round(sc, 4), [(SL[s][1], NAMES[k]) for s, k in enumerate(assign) if k >= 0], round(time.time() - t0), 's', flush=True)
    json.dump({'assign': assign, 'score': sc, 'curve': curve, 'slots': [(a, b, list(c)) for a, b, c in SL]}, open(os.path.join(out, 'search19_%s.json' % which), 'w'))
