# turn 19: the 106-pull pool of v16.5 (same definitions), built twice:
#   build version - from build lines only (used for every score)
#   shown version - from ALL lines (what the page draws; every word has at least one line)
# usage: python3 -I forces19.py <turn18 out dir> <turn19 out dir>
import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'turn18'))
from lib18 import *

src, out = sys.argv[1], sys.argv[2]
j, z, L, WN = load(src)
words = j['words']; n = len(words); w2i = {w: i for i, w in enumerate(words)}
cn = j['clsNames']; fc = z['f_cls']; fct = fc.sum(1); fct[fct == 0] = 1; fcs = fc / fct[:, None]
fp = z['f_pos']; tot = fp.sum(1); tot[tot == 0] = 1
fl = z['f_lex']; tl = fl.sum(1); tl[tl == 0] = 1
dep = z['f_depth']; known = ~np.isnan(dep)
OWNERW = 'action situation context perspective mood class tense plural singular modifier memory time state before after topic source correct incorrect'.split()
ACTS = 'read write compare add subtract move find split join clock hear say call spawn'.split()


def pool(Lb):
    """Lb: {kind: pairs} used to build the pulls. Returns ordered list of (name, group, how, vector 0..1)."""
    P = []
    def add(v, name, group, how):
        v = np.nan_to_num(np.asarray(v, float)); v[v < 0] = 0; m = v.max()
        P.append((name, group, how, v / m if m > 0 else v))
    def tr(kn): return Lb.get(kn, np.zeros((0, 2), int))
    def ends(kn, side):
        v = np.zeros(n); p = tr(kn); np.add.at(v, p[:, side], 1); return np.log1p(v)
    for c in ['verb', 'noun', 'adjective', 'adverb', 'number']:
        add(fcs[:, cn.index(c)], 'class: ' + c, 'class', "share of the word's nodes in your map with class " + c)
    add(fcs[:, [cn.index(c) for c in ['article', 'determiner', 'conjunction', 'pronoun', 'preposition']]].sum(1), 'class: small words', 'class',
        "share of the word's nodes in your map that are article, determiner, conjunction, pronoun or preposition")
    for k, nm in enumerate(['noun', 'verb', 'adjective', 'adverb']):
        add(fp[:, k] / tot, 'WordNet share: ' + nm, 'class', "share of the word's WordNet senses that are " + nm)
    add(ends('past', 1), 'tense: past form', 'tense', 'the word is the past end of a "past" line')
    add(ends('past', 0), 'tense: base verb', 'tense', 'the word is the base end of a "past" line')
    add(ends('singular', 0), 'number: plural', 'number', 'the word is the plural end of a "singular" line')
    add(ends('singular', 1), 'number: singular', 'number', 'the word is the singular end of a "singular" line')
    add(ends('prefix', 0), 'modifier: has a prefix', 'modifier', 'the word has a "prefix" line')
    add(ends('suffix', 0), 'modifier: has a suffix', 'modifier', 'the word has a "suffix" line')
    add(ends('stem', 0), 'modifier: built on a stem', 'modifier', 'the word has a "stem" line to its stem')
    add(ends('stem', 1), 'modifier: is a stem', 'modifier', 'other words have "stem" lines to this word')
    add(ends('prefix', 1) + ends('suffix', 1), 'modifier: is an affix', 'modifier', 'the word is the far end of prefix/suffix lines')
    add(ends('alike', 0) + ends('alike', 1), 'lines: alike', 'relationship', 'log of the word\'s "alike" lines')
    add(ends('opposite', 0) + ends('opposite', 1), 'lines: opposite', 'relationship', 'log of the word\'s "opposite" lines')
    add(ends('is', 0), 'lines: is a kind of', 'relationship', 'log of the word\'s "is" lines to a kind above it')
    add(ends('is', 1), 'lines: kinds below it', 'relationship', 'log of "is" lines from words below it')
    add(ends('has', 0), 'lines: has parts', 'relationship', 'log of "has" lines from the word')
    add(ends('has', 1), 'lines: is a part', 'relationship', 'log of "has" lines to the word')
    for k, nm in enumerate(j['lex']):
        add(fl[:, k] / tl, 'topic: ' + nm, 'topic', "share of the word's WordNet senses filed under " + nm)
    add(z['f_inwn'], 'source: in WordNet', 'source', 'WordNet 2025 has the word')
    add(np.log1p(z['f_senses']), 'definitions: WordNet senses', 'definition', 'log of the number of WordNet senses (definitions)')
    g = np.zeros(n); g[known] = dep[known].max() - dep[known]
    add(g, 'depth: general', 'depth', 'how few WordNet kinds sit above the word (general words high)')
    s_ = np.zeros(n); s_[known] = dep[known]
    add(s_, 'depth: specific', 'depth', 'how many WordNet kinds sit above the word (specific words high)')
    A = build_graph(n, {(k, 'b'): v for k, v in Lb.items()}, split='b')
    reach = {w: ppr(A, [w2i[w]]) for w in OWNERW + ACTS if w in w2i}
    allnz = np.concatenate([v[v > 0] for v in reach.values()]); floor = np.percentile(allnz, 1)
    for w, v in reach.items():
        s = np.where(v > 0, np.log10(np.maximum(v, floor) / floor), 0)
        if w in ACTS:
            add(s, w.upper(), 'action', f'how near "{w}" the word is through your map\'s lines (log reach from "{w}")')
        else:
            add(s, 'near: ' + w, 'your word', f'how near "{w}" the word is through your map\'s lines (log reach from "{w}")')
    return P


Lbuild = {kn: L[(kn, 'train')] for kn in KINDS}
Lall = {kn: np.vstack([L[(kn, s)] for s in ('train', 'val', 'test') if (kn, s) in L]) for kn in KINDS}
Pb = pool(Lbuild); Pa = pool(Lall)
assert [p[0] for p in Pb] == [p[0] for p in Pa]
names = [p[0] for p in Pb]
np.savez_compressed(os.path.join(out, 'pool19.npz'), build=np.array([p[3] for p in Pb]), shown=np.array([p[3] for p in Pa]))
json.dump({'name': names, 'group': [p[1] for p in Pb], 'how': [p[2] for p in Pb]}, open(os.path.join(out, 'pool19.json'), 'w'))
print('pulls', len(names), {g: [p[1] for p in Pb].count(g) for g in sorted(set(p[1] for p in Pb))})
Sb = np.array([p[3] for p in Pb]); Sa = np.array([p[3] for p in Pa])
print('words with no pull at all: build', int((Sb.max(0) == 0).sum()), 'shown', int((Sa.max(0) == 0).sum()))
print('all-zero pulls: build', [names[k] for k in range(len(names)) if Sb[k].max() == 0], 'shown', [names[k] for k in range(len(names)) if Sa[k].max() == 0])
