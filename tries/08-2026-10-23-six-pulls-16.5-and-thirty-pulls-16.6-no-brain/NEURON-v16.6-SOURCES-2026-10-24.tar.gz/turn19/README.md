# Thirty Pulls (v16.6, turn 19, 2026-10-24): sources
Page: NEURON-THIRTY-PULLS-v16.6-2026-10-24.html (Downloads), https://claude.ai/artifact/4Lfoq3EkHJ4wCRW4dr4uuk
Needs turn18 (from NEURON-v16.5-SOURCES-2026-10-23.tar.gz) for lib18.py and the dataset (turn18/out/data18.*, rebuilt by turn18/data18.py).
Nothing here touches the brain (~/neuron/v1). Scratch SQLite only.
Rebuild (each archive in its own NEW folder; python -I; 4 workers):
    python3 -I turn19/forces19.py turn18/out turn19/out                       # 20 s, pool19.npz (build + shown pulls)
    PROCS=4 python3 -I turn19/search19.py turn18/out turn19/out D|C|B|A          # A ~14 min, B ~4 min, C ~1 min
    PROCS=4 python3 -I turn19/final19.py turn18/out turn19/out <v16>/physics16.json   # ~30 min
    python3 -I turn19/requant19.py turn19/out                                 # only for page19.json made before the fix
    python3 -I turn19/build19.py turn19 thirty-pulls.html
    python3 -I turn19/sql19.py turn18/out turn19/out A scratch19.db place19.sql ; node turn19/sqljs19.js <sql-asm-memory-growth.js> scratch19.db
    node turn19/shot19.js thirty-pulls.html shots/s turn19/out/check19.json
Files: EXPECT19.md (predictions before scoring), out/final19.json (all scores and checks), out/search19_*.json, out/place19.sql (the place view as SQL), logs.
