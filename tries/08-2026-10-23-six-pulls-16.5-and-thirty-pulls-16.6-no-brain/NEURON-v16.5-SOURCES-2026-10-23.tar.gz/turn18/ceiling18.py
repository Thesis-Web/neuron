# turn 18, G6 ceiling: places fitted straight to the build lines (NOT a pull formula) - the best a 3D placement does
# plain numpy on the CPU (no torch, nothing touches the graphics card)
# usage: python3 -I ceiling18.py <out dir>
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib18 import *

out = sys.argv[1]; DIM = 3
rng = np.random.default_rng(0)
j, z, L, WN = load(out)
n = len(j['words']); nk = len(KINDS)
rows = []
for k, kn in enumerate(KINDS):
    p = both(L[(kn, 'train')], kn)
    rows.append(np.c_[p, np.full(len(p), k)])
R = np.vstack(rows)
trained = np.zeros(n, bool); trained[R[:, 0]] = True; trained[R[:, 1]] = True
P = 0.01 * rng.standard_normal((n, DIM)); a = np.ones((nk, DIM)); t = np.zeros((nk, DIM))
prm = [P, a, t]; m1 = [np.zeros_like(x) for x in prm]; m2 = [np.zeros_like(x) for x in prm]
lr, b1, b2, eps, step = 0.03, 0.9, 0.999, 1e-8, 0
K, B = 64, 2048
t0 = time.time()
for ep in range(80):
    perm = rng.permutation(len(R)); tot = 0.0
    for i in range(0, len(R), B):
        r = R[perm[i:i + B]]; m = len(r)
        A_, B_, k_ = r[:, 0], r[:, 1], r[:, 2]
        q = a[k_] * P[A_] + t[k_]                                   # (m,3)
        cand = np.c_[B_, rng.integers(0, n, (m, K))]                # (m,K+1), column 0 = the true word
        diff = q[:, None, :] - P[cand]                              # (m,K+1,3)
        d = (diff ** 2).sum(-1)
        l = -d; l -= l.max(1, keepdims=True); e = np.exp(l); pi = e / e.sum(1, keepdims=True)
        tot += float((d[:, 0] + np.log(np.exp(-d - (-d).max(1, keepdims=True)).sum(1)) + (-d).max(1)).sum())
        g = -pi; g[:, 0] += 1                                       # d loss / d d_j
        gq = 2 * (g[:, :, None] * diff).sum(1)                      # d loss / d q
        gP = np.zeros_like(P); ga = np.zeros_like(a); gt = np.zeros_like(t)
        np.add.at(gP, cand.ravel(), (-2 * g[:, :, None] * diff).reshape(-1, DIM))
        np.add.at(gP, A_, a[k_] * gq)
        np.add.at(ga, k_, P[A_] * gq); np.add.at(gt, k_, gq)
        step += 1
        for x, gx, mm, vv in zip(prm, (gP / m, ga / m, gt / m), m1, m2):
            mm *= b1; mm += (1 - b1) * gx; vv *= b2; vv += (1 - b2) * gx * gx
            x -= lr * (mm / (1 - b1 ** step)) / (np.sqrt(vv / (1 - b2 ** step)) + eps)
    if ep % 10 == 0 or ep == 79:
        print('epoch', ep, 'loss', round(tot / len(R), 4), round(time.time() - t0), 's', flush=True)
X = P.copy()
X[~trained] = 0          # a word with no build line gets no place: origin
np.save(os.path.join(out, 'G6_3d.npy'), X)
print('words placed', int(trained.sum()), 'of', n)
