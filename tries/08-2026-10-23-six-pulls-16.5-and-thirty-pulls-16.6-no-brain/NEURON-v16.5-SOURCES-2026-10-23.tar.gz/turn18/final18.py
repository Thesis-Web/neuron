# turn 18: score the chosen graphs exactly (choose split -> test split), controls, WordNet check, bisects, meaning checks, export
# usage: python3 -I final18.py <out dir> <told physics16.json>   (env PROCS = worker count, default 4)
import sys, os, json, base64, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib18 import *
import multiprocessing as mp

out, toldp = sys.argv[1], sys.argv[2]
PROCS = int(os.environ.get('PROCS', '4'))
j, z, L, WN = load(out)
words = j['words']; n = len(words); w2i = {w: i for i, w in enumerate(words)}
f = np.load(os.path.join(out, 'forces18.npz'))
meta = json.load(open(os.path.join(out, 'forces18.json')))
POOL = f['named']
told = json.load(open(toldp))
t0 = time.time()
def log(*a):
    print(round(time.time() - t0), 's', *a, flush=True)

# ---- the same sampled scorer the search used (for the diagonal pulls)
proxy = Proxy(L, n)

def place(axes, pool):
    P = np.zeros((n, 3))
    for k, (a, b) in enumerate(axes):
        P[:, k] = pool[a] - (pool[b] if b is not None else 0)
    return P

def exact(P, wn=True):
    r = score_graph(P, L, maxlines=2000)
    w = score_graph(P, WN, kinds=WNKINDS, train_split='fit', choose_split='fit', report_split='score', maxlines=2000) if wn else None
    return r, w

PICKPOOL = None
def _pick1(c):
    return objective(score_graph(place(c, PICKPOOL), L, maxlines=2000, report_split=None)), c
def pick(cands, pool):
    global PICKPOOL
    PICKPOOL = pool
    with mp.Pool(min(PROCS, len(cands))) as pp:
        r = pp.map(_pick1, cands)
    return min(r, key=lambda x: x[0])

S1 = json.load(open(os.path.join(out, 'search_g1.json')))
S2 = json.load(open(os.path.join(out, 'search_g2.json')))
S5 = json.load(open(os.path.join(out, 'search_g5.json')))
tup = lambda c: [tuple(x) for x in c]
g1o, g1 = pick([tup(c) for _, c in S1['depth3'][:6]], POOL); log('G1 picked', g1o, [(meta['name'][a], meta['name'][b]) for a, b in g1])
g2o, g2 = pick([tup(c) for _, c in S2['top'][:6]], POOL); log('G2 picked', g2o, [(meta['name'][a], meta['name'][b]) for a, b in g2])
G5 = list(f['G5'].T)
g5o, g5 = pick([tup(c) for _, c in S5['all'][:5]], G5); log('G5 picked', g5o, g5)

def topw(v, k=12):
    o = np.argsort(-v)
    return [words[i] for i in o[:k] if v[i] > 0]

GR = {}
def pullgraph(key, title, axes, pool, names, hows):
    P = place(axes, pool)
    six = np.zeros((n, 6)); pulls = []
    for k, (a, b) in enumerate(axes):
        six[:, 2 * k] = pool[a]; six[:, 2 * k + 1] = pool[b]
        pulls.append({'end': '+' + 'xyz'[k], 'name': names[a], 'how': hows[a], 'top': topw(pool[a])})
        pulls.append({'end': '-' + 'xyz'[k], 'name': names[b], 'how': hows[b], 'top': topw(pool[b])})
    GR[key] = {'title': title, 'P': P, 'six': six, 'pulls': pulls, 'kind': 'pulls'}

def foundgraph(key, title, P, how):
    six = np.zeros((n, 6)); pulls = []
    for k in range(3):
        six[:, 2 * k] = np.maximum(P[:, k], 0); six[:, 2 * k + 1] = np.maximum(-P[:, k], 0)
        for s, col in ((1, 2 * k), (-1, 2 * k + 1)):
            pulls.append({'end': ('+' if s > 0 else '-') + 'xyz'[k], 'name': 'found pull %s%s' % ('+' if s > 0 else '-', 'xyz'[k]), 'how': how, 'top': topw(six[:, col])})
    m = np.abs(P).max(0); m[m == 0] = 1
    GR[key] = {'title': title, 'P': P, 'six': six / m.repeat(2), 'pulls': pulls, 'kind': 'found'}

pullgraph('G1', 'Your named pulls, measured', g1, POOL, meta['name'], meta['how'])
pullgraph('G2', 'The fourteen actions as pulls', g2, POOL, meta['name'], meta['how'])
foundgraph('G3', "Found: the lines' own equation", f['G3'], 'eigenvector of the build lines (all kinds weight 1); this end of the axis')
foundgraph('G4', 'Found, signed: opposite lines push apart', f['G4'], 'eigenvector of the build lines with opposite lines counted negative; this end of the axis')
G5n = ['found pull %d' % (k + 1) for k in range(6)]
G5h = ['one of six non-negative pulls factored from the build lines, class and topic (pull %d)' % (k + 1) for k in range(6)]
pullgraph('G5', 'Found: six non-negative pulls', g5, G5, G5n, G5h)
if os.path.exists(os.path.join(out, 'G6_3d.npy')):
    foundgraph('G6', 'Places fitted to the lines (not a pull formula)', np.load(os.path.join(out, 'G6_3d.npy')), 'place fitted straight to the build lines; this end of the axis')

# ---- diagonal pulls on top of G1 (B2): best unused pool pull for each of the 20 diagonals, added while it helps
DIRS = []
for s in [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]: DIRS.append(('axis', np.array(s, float)))
for a in range(3):
    for b in range(a + 1, 3):
        for sa in (1, -1):
            for sb in (1, -1):
                v = np.zeros(3); v[a] = sa; v[b] = sb; DIRS.append(('two-axis', v / np.sqrt(2)))
for sx in (1, -1):
    for sy in (1, -1):
        for sz in (1, -1):
            DIRS.append(('three-axis', np.array([sx, sy, sz], float) / np.sqrt(3)))
def dname(v):
    return ','.join(('+' if c > 0 else '-') + 'xyz'[i] for i, c in enumerate(v) if abs(c) > 1e-9)

BASE = GR['G1']['P']
CUR = None
def ev_diag(args):
    k, d = args
    return proxy(CUR + np.outer(POOL[k], DIRS[d][1])), k, d
diag_added = []
cur = BASE.copy(); cur_s = proxy(cur); used = {x for p in g1 for x in p}
log('G1 proxy', cur_s)
for rnd in range(8):
    CUR = cur
    jobs = [(k, d) for d in range(6, 26) for k in range(len(POOL)) if k not in used and (k, d) not in [(a, b) for a, b, _ in diag_added]]
    with mp.Pool(PROCS) as pp:
        r = pp.map(ev_diag, jobs, chunksize=16)
    r.sort(key=lambda x: x[0])
    s, k, d = r[0]
    log('diag round', rnd, 'best', round(s, 4), meta['name'][k], dname(DIRS[d][1]), 'vs', round(cur_s, 4))
    if s > cur_s - 0.002: break
    diag_added.append((k, d, s)); used.add(k)
    cur = cur + np.outer(POOL[k], DIRS[d][1]); cur_s = s
if diag_added:
    six = GR['G1']['six']
    GR['G1d'] = {'title': 'Your named pulls + diagonal pulls', 'P': cur, 'six': six, 'pulls': GR['G1']['pulls'], 'kind': 'pulls',
                 'diag': [{'dir': dname(DIRS[d][1]), 'type': DIRS[d][0], 'name': meta['name'][k], 'how': meta['how'][k], 'top': topw(POOL[k]),
                           'vals': POOL[k]} for k, d, _ in diag_added]}

# ---- exact scores, controls
def _exact1(key):
    P = GR[key]['P']
    r, w = exact(P)
    rs, _ = exact(P[np.random.default_rng(7).permutation(n)], wn=False)
    return key, {'map': r, 'wn': w, 'shuffled': rs}
with mp.Pool(PROCS) as pp:
    RES = dict(pp.map(_exact1, list(GR)))
for key in GR:
    r, w, rs = RES[key]['map'], RES[key]['wn'], RES[key]['shuffled']
    log(key, 'map', {k: (v['best'], round(v['test'][v['best']]['median'], 3)) for k, v in r.items()})
    log(key, 'shuffled', {k: round(v['test'][v['best']]['median'], 3) for k, v in rs.items()})
    log(key, 'wordnet', {k: (v['best'], round(v['test'][v['best']]['median'], 3)) for k, v in w.items()})
# random pulls control: G1's six pulls, each shuffled across words on its own
rp = np.zeros((n, 3)); rr = np.random.default_rng(11)
for k, (a, b) in enumerate(g1):
    rp[:, k] = POOL[a][rr.permutation(n)] - POOL[b][rr.permutation(n)]
RES['random_pulls'], _ = exact(rp, wn=False)
log('random pulls', {k: round(v['test'][v['best']]['median'], 3) for k, v in RES['random_pulls'].items()})

# ---- opposite: signs per axis
SIGN = {}
for key, g in GR.items():
    P = g['P']; te = L[('opposite', 'test')]; o = []
    for k in range(3):
        a, b = P[te[:, 0], k], P[te[:, 1], k]; m = (np.abs(a) > 1e-9) & (np.abs(b) > 1e-9)
        ww = np.r_[a[m], b[m]]; p = (ww > 0).mean() if len(ww) else 0
        o.append({'axis': 'xyz'[k], 'pairs': int(m.sum()), 'opposite_sides': float((np.sign(a[m]) != np.sign(b[m])).mean()) if m.any() else None,
                  'expected_by_chance': float(2 * p * (1 - p))})
    SIGN[key] = o

# ---- bisects (B1, B3, B4)
DV = np.array([v for _, v in DIRS])
BIS = {}
for key, g in GR.items():
    P = g['P']; rad = np.linalg.norm(P, axis=1); nz = rad > 1e-9
    cos = (P[nz] / rad[nz, None]) @ DV.T; near = cos.argmax(1)
    idx = np.where(nz)[0]
    rows = []
    for d, (typ, v) in enumerate(DIRS):
        m = idx[near == d]
        top = m[np.argsort(-rad[m])][:10]
        rows.append({'dir': dname(v), 'type': typ, 'words': int(len(m)), 'top': [words[i] for i in top]})
    keyp = np.round(P, 9); uniq, cnt = np.unique(keyp, axis=0, return_counts=True)
    BIS[key] = {'dirs': rows, 'at_origin': int((~nz).sum()), 'distinct_points': int(len(uniq)), 'largest_stack': int(cnt.max()),
                'both_ways': [int(((g['six'][:, 2 * k] > 0.1) & (g['six'][:, 2 * k + 1] > 0.1)).sum()) for k in range(3)]}
B3 = []
if diag_added:
    six = GR['G1']['six']
    for k, d, _ in diag_added:
        v = DIRS[d][1]; own = []
        for ax in range(3):
            if abs(v[ax]) > 1e-9: own.append(2 * ax + (0 if v[ax] > 0 else 1))
        cs = [float(np.corrcoef(POOL[k], six[:, c])[0, 1]) if six[:, c].std() > 0 else 0.0 for c in range(6)]
        B3.append({'dir': dname(v), 'name': meta['name'][k], 'corr': cs, 'own': own,
                   'own_mean_abs': float(np.mean([abs(cs[c]) for c in own])), 'other_mean_abs': float(np.mean([abs(cs[c]) for c in range(6) if c not in own]))})

# ---- meaning checks (M1-M4)
from scipy.stats import spearmanr
ACTS = [w.lower() for w in told['actions']]
MEAN = {}
for key, g in GR.items():
    P = g['P']; rr = np.random.default_rng(5)
    def mpd(ix):
        X = P[ix]; D = np.sqrt(((X[:, None] - X[None]) ** 2).sum(-1)); return D[np.triu_indices(len(ix), 1)].mean()
    acts = [w2i[w] for w in ACTS if w in w2i]
    base = np.array([mpd(rr.choice(n, len(acts), replace=False)) for _ in range(500)])
    a_ = mpd(acts)
    dep = z['f_depth']; known = ~np.isnan(dep); rad = np.linalg.norm(P, axis=1)
    rho = spearmanr(rad[known], dep[known]).correlation
    o = w2i.get('origin'); orad = float(rad[o]) if o is not None else None
    MEAN[key] = {'actions_spread_ratio': float(a_ / base.mean()), 'actions_spread_pct': float((base < a_).mean()), 'actions_found': len(acts),
                 'radius_vs_depth_spearman': float(rho), 'origin_radius': orad, 'origin_radius_pct': float((rad < orad).mean()) if o is not None else None,
                 'origin_pos': (P[o] / (float(np.abs(P).max()) or 1) * 100).tolist() if o is not None else None,
                 'median_radius': float(np.median(rad))}
    log(key, MEAN[key])

json.dump({'res': RES, 'sign': SIGN, 'bis': BIS, 'b3': B3, 'mean': MEAN,
           'picked': {'G1': [g1o, g1], 'G2': [g2o, g2], 'G5': [g5o, g5]},
           'diag': [(meta['name'][k], dname(DIRS[d][1]), s) for k, d, s in diag_added]},
          open(os.path.join(out, 'final18.json'), 'w'), default=lambda o: o.tolist() if hasattr(o, 'tolist') else (int(o) if isinstance(o, (np.integer,)) else str(o)))

# ---- export for the page
def b64(a): return base64.b64encode(np.ascontiguousarray(a).tobytes()).decode()
EXP = {'words': words, 'kinds': KINDS, 'graphs': [], 'cls': z['cls'].tolist(), 'clsNames': j['clsNames']}
gate = {}
for grp, lst in (('physics', told['physics']), ('action', told['actions']), ('sql', told['sqlroots']), ('arrival', told['arrivals']), ('port', told['ports']), ('sat', told['sats'])):
    for w in lst:
        if w.lower() in w2i: gate[w.lower()] = grp
if 'origin' in w2i: gate['origin'] = 'told'
EXP['gates'] = gate
for key, g in GR.items():
    P = g['P']; sc = float(np.abs(P).max()) or 1
    q = np.round(P / sc * 30000).astype(np.int16)
    six = np.round(np.clip(g['six'], 0, 1) * 255).astype(np.uint8)
    e = {'key': key, 'title': g['title'], 'kind': g['kind'], 'scale': sc, 'pos': b64(q), 'six': b64(six), 'pulls': g['pulls'],
         'map': RES[key]['map'], 'wn': RES[key]['wn'], 'shuffled': {k: v['test'][v['best']] for k, v in RES[key]['shuffled'].items()},
         'sign': SIGN[key], 'bis': BIS[key], 'mean': MEAN[key]}
    if 'diag' in g:
        e['diag'] = [{k2: v2 for k2, v2 in d.items() if k2 != 'vals'} for d in g['diag']]
        e['diagvals'] = b64(np.round(np.array([d['vals'] for d in g['diag']]).T * 255).astype(np.uint8))
    EXP['graphs'].append(e)
la, lb, lk = [], [], []
SPL = {'train': 0, 'val': 1, 'test': 2}
for (kn, spl), p in L.items():
    la.append(p[:, 0]); lb.append(p[:, 1]); lk.append(np.full(len(p), KINDS.index(kn) * 4 + SPL[spl]))
EXP['la'] = b64(np.concatenate(la).astype(np.int32)); EXP['lb'] = b64(np.concatenate(lb).astype(np.int32)); EXP['lk'] = b64(np.concatenate(lk).astype(np.uint8))
EXP['random_pulls'] = {k: v['test'][v['best']] for k, v in RES['random_pulls'].items()}
EXP['b3'] = B3
json.dump(EXP, open(os.path.join(out, 'page18.json'), 'w'), default=lambda o: o.tolist() if hasattr(o, 'tolist') else (int(o) if isinstance(o, (np.integer,)) else str(o)))
log('export', os.path.getsize(os.path.join(out, 'page18.json')))

# ---- numbers the page must reproduce (checked in the browser by shot18.js)
CHK = {'graphs': []}
rc = np.random.default_rng(3)
for key, g in GR.items():
    P = g['P']; sc = float(np.abs(P).max()) or 1
    ws = rc.choice(n, 20, replace=False)
    item = {'key': key, 'pos': [[words[i], (P[i] / sc * 100).tolist()] for i in ws], 'rank': []}
    for kn in ('alike', 'opposite', 'is', 'past', 'suffix'):
        te = L[(kn, 'test')]; pick_ = te[rc.choice(len(te), 2, replace=False)]
        tr = both(L[(kn, 'train')], kn)
        F = fit_funcs(P[tr[:, 0]], P[tr[:, 1]]); fb = F[RES[key]['map'][kn]['best']]
        s, _ = rank_share(P, pick_, apply_func(fb, P[pick_[:, 0]]))
        for (a, b), v in zip(pick_, s): item['rank'].append([words[a], words[b], kn, float(v)])
    CHK['graphs'].append(item)
json.dump(CHK, open(os.path.join(out, 'check18.json'), 'w'))
log('check file written')
