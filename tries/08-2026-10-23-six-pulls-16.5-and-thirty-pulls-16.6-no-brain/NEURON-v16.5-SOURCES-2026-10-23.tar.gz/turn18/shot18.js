// turn 18 page check: node shot18.js <html> <shot prefix> <check.json from python>
const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
const fs = require('fs');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const errs = [], R = {};
  const chk = JSON.parse(fs.readFileSync(process.argv[4], 'utf8'));
  const open = async (opts) => {
    const page = await browser.newPage(opts); page.on('pageerror', e => errs.push(e.message)); page.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text()); });
    await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('data:') || u.includes('cdnjs.cloudflare.com') || u.includes('fonts.g') ? r.continue() : r.abort(); });
    await page.goto('file://' + process.argv[2]); await page.waitForFunction(() => window.__six, null, { timeout: 120000 }); return page; };
  const page = await open({ viewport: { width: 1600, height: 950 } });
  await page.waitForTimeout(2500);
  R.graphs = await page.evaluate(() => window.__six.graphs());
  R.pos = []; R.rank = [];
  for (const g of chk.graphs) {
    const k = R.graphs.findIndex(x => x.key === g.key);
    await page.evaluate(k => window.__six.set(k), k); await page.waitForTimeout(1100);
    let maxd = 0; for (const [w, p] of g.pos) { const q = await page.evaluate(w => window.__six.pos(w), w); maxd = Math.max(maxd, Math.hypot(q[0] - p[0], q[1] - p[1], q[2] - p[2])); }
    let maxr = 0, rows = []; for (const [a, b, kind, share] of g.rank) { const r = await page.evaluate(([a, b, kind]) => window.__six.rank(a, b, kind), [a, b, kind]); maxr = Math.max(maxr, Math.abs(r.share - share)); rows.push([a, b, kind, share, +r.share.toFixed(4)]); }
    R.pos.push([g.key, maxd]); R.rank.push([g.key, maxr, rows]);
  }
  await page.evaluate(() => window.__six.set(0)); await page.waitForTimeout(1200);
  await page.fill('#find', 'before'); await page.press('#find', 'Enter'); await page.waitForTimeout(800);
  R.selBefore = (await page.evaluate(() => window.__six.sel())).slice(0, 900);
  await page.screenshot({ path: process.argv[3] + '-before.png' });
  await page.check('#gtwo'); await page.check('#gthree'); await page.selectOption('#cmode', 'dir'); await page.waitForTimeout(500);
  await page.screenshot({ path: process.argv[3] + '-bisects.png' });
  await page.mouse.click(800, 480); await page.waitForTimeout(500);
  R.clickSel = (await page.evaluate(() => window.__six.sel())).slice(0, 120);
  R.atlasRows = await page.evaluate(() => window.__six.atlas());
  await page.fill('#afind', 'orig'); await page.waitForTimeout(300);
  R.atlasOrig = await page.evaluate(() => document.querySelector('#asum').innerText + ' | ' + (document.querySelector('#atable tr.arow') || {}).innerText);
  await page.screenshot({ path: process.argv[3] + '-atlas.png' });
  await page.click('#aclose');
  await page.uncheck('#gtwo'); await page.uncheck('#gthree'); await page.selectOption('#cmode', 'pull');
  for (let k = 1; k < R.graphs.length; k++) { await page.evaluate(k => window.__six.set(k), k); await page.waitForTimeout(1100); await page.screenshot({ path: process.argv[3] + '-g' + k + '.png' }); }
  R.overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  const phone = await open({ viewport: { width: 400, height: 860 }, deviceScaleFactor: 2 });
  await phone.waitForTimeout(2000);
  R.phoneOverflow = await phone.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  await phone.screenshot({ path: process.argv[3] + '-phone.png' });
  const dark = await open({ viewport: { width: 1600, height: 950 }, colorScheme: 'dark' });
  await dark.waitForTimeout(2000); await dark.screenshot({ path: process.argv[3] + '-dark.png' });
  R.errors = errs;
  console.log(JSON.stringify(R, null, 1));
  await browser.close();
})();
