# Six Pulls (v16.5, turn 18, 2026-10-23): sources

Page: NEURON-SIX-PULLS-v16.5-2026-10-23.html (Downloads), https://claude.ai/artifact/Ab1Xhb1VsJ3tXRVA4VKDHi
Nothing here touches the brain (~/neuron/v1). Everything is a test over the owner's relation map + WordNet.

Inputs (not in this archive):
- Owner map: Downloads/"Neuron Relation Map.zip" -> data.json (2,427,748 bytes, as of 2026-10-08 23:34 CDT)
- Open English WordNet 2025 JSON: https://github.com/globalwordnet/english-wordnet/releases/download/2025-edition/english-wordnet-2025-json.zip (9,986,555 bytes, sha256 starts 7d749f6e2c39e697), extract flat into one folder
- v16 told block: v16/physics16.json inside NEURON-v16.4-SOURCES-2026-10-23.tar.gz

Rebuild (extract every archive into its own NEW folder; python with -I):
    python3 -I turn18/data18.py <map>/data.json <oewn dir> turn18/out          # 5 s
    python3 -I turn18/forces18.py turn18/out                                   # 10 s
    PROCS=4 OMP_NUM_THREADS=1 python3 -I turn18/search18.py turn18/out g5      # then g1 (~15 min) and g2 (~6 min)
    OMP_NUM_THREADS=1 python3 -I turn18/ceiling18.py turn18/out                # 90 s, numpy only, no graphics card
    PROCS=4 OMP_NUM_THREADS=1 python3 -I turn18/final18.py turn18/out <v16>/physics16.json   # ~30 min
    python3 -I turn18/build18.py turn18 six-pulls.html
    node turn18/shot18.js six-pulls.html shots/s turn18/out/check18.json      # headless Chromium check
Use 4 workers: 12 ran slower on this machine (75 vs 138 evaluations a second).

Files: EXPECT18.md (predictions written before scoring + amendments), MY-NUMBERS.md (every number I chose),
out/final18.json (all scores), out/search_*.json, out/*.log, turn16/OWNER-VERBATIM.txt (owner words incl. messages 5 and 6).
