# turn 18: every candidate pull, measured per word from build lines + word facts (never from choose/test lines)
# usage: python3 -I forces18.py <out dir>
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib18 import *
from scipy.sparse.linalg import eigsh, LinearOperator

out = sys.argv[1]
j, z, L, WN = load(out)
words = j['words']; n = len(words); w2i = {w: i for i, w in enumerate(words)}
A = build_graph(n, L)
F, NAME, GROUP, HOW = [], [], [], []


def add(v, name, group, how):
    v = np.asarray(v, float); v = np.nan_to_num(v); v[v < 0] = 0
    m = v.max()
    if m <= 0: return
    F.append(v / m); NAME.append(name); GROUP.append(group); HOW.append(how)


def tr(kn):
    return L.get((kn, 'train'), np.zeros((0, 2), int))


# ---- class, from the owner's map (share of the word's map nodes with that class)
cn = j['clsNames']; cls = z['cls']; fc = z['f_cls']; fct = fc.sum(1); fct[fct == 0] = 1; fcs = fc / fct[:, None]
for c in ['verb', 'noun', 'adjective', 'adverb', 'number']:
    add(fcs[:, cn.index(c)], 'class: ' + c, 'class', "share of the word's nodes in your map with class " + c)
add(fcs[:, [cn.index(c) for c in ['article', 'determiner', 'conjunction', 'pronoun', 'preposition']]].sum(1),
    'class: small words', 'class', "share of the word's nodes in your map that are article, determiner, conjunction, pronoun or preposition")
# class share from WordNet senses
fp = z['f_pos']; tot = fp.sum(1); tot[tot == 0] = 1
for k, nm in enumerate(['noun', 'verb', 'adjective', 'adverb']):
    add(fp[:, k] / tot, 'WordNet share: ' + nm, 'class', 'share of the word\'s WordNet senses that are ' + nm)


# ---- tense, number, modifiers, from build lines (the line's direction says which end)
def ends(kn, side):
    v = np.zeros(n); p = tr(kn)
    np.add.at(v, p[:, side], 1); return np.log1p(v)


add(ends('past', 1), 'tense: past form', 'tense', 'the word is the past end of a build "past" line')
add(ends('past', 0), 'tense: base verb', 'tense', 'the word is the base end of a build "past" line')
add(ends('singular', 0), 'number: plural', 'number', 'the word is the plural end of a build "singular" line')
add(ends('singular', 1), 'number: singular', 'number', 'the word is the singular end of a build "singular" line')
add(ends('prefix', 0), 'modifier: has a prefix', 'modifier', 'the word has a build "prefix" line')
add(ends('suffix', 0), 'modifier: has a suffix', 'modifier', 'the word has a build "suffix" line')
add(ends('stem', 0), 'modifier: built on a stem', 'modifier', 'the word has a build "stem" line to its stem')
add(ends('stem', 1), 'modifier: is a stem', 'modifier', 'other words have build "stem" lines to this word')
add(ends('prefix', 1) + ends('suffix', 1), 'modifier: is an affix', 'modifier', 'the word is the far end of build prefix/suffix lines')
# relationship counts
add(ends('alike', 0) + ends('alike', 1), 'count: alike lines', 'count', 'log of the word\'s build "alike" lines')
add(ends('opposite', 0) + ends('opposite', 1), 'count: opposite lines', 'count', 'log of the word\'s build "opposite" lines')
add(ends('is', 0), 'count: is-a-kind-of (up)', 'count', 'log of the word\'s build "is" lines to a kind above it')
add(ends('is', 1), 'count: kinds below it', 'count', 'log of build "is" lines from words below it')
add(ends('has', 0), 'count: has parts', 'count', 'log of build "has" lines from the word')
add(ends('has', 1), 'count: is a part', 'count', 'log of build "has" lines to the word')

# ---- topic (WordNet's 45 topic files), source, depth
fl = z['f_lex']; tl = fl.sum(1); tl[tl == 0] = 1
for k, nm in enumerate(j['lex']):
    add(fl[:, k] / tl, 'topic: ' + nm, 'topic', 'share of the word\'s WordNet senses filed under ' + nm)
add(z['f_inwn'], 'source: in WordNet', 'source', 'WordNet 2025 has the word')
add(np.log1p(z['f_senses']), 'source: WordNet senses', 'source', 'log of the number of WordNet senses')
dep = z['f_depth']; known = ~np.isnan(dep)
g = np.zeros(n); g[known] = dep[known].max() - dep[known]
add(g, 'depth: general', 'depth', 'how few WordNet kinds sit above the word (general words high)')
s_ = np.zeros(n); s_[known] = dep[known]
add(s_, 'depth: specific', 'depth', 'how many WordNet kinds sit above the word (specific words high)')

# ---- reach of a word through the build lines (personalized PageRank, restart 0.15)
OWNERW = 'action situation context perspective mood class tense plural singular modifier memory time state before after topic source correct incorrect'.split()
ACTS = 'read write compare add subtract move find split join clock hear say call spawn'.split()
reach = {}
for w in OWNERW + ACTS:
    if w in w2i:
        reach[w] = ppr(A, [w2i[w]])
allnz = np.concatenate([v[v > 0] for v in reach.values()])
floor = np.percentile(allnz, 1)
for w, v in reach.items():
    s = np.where(v > 0, np.log10(np.maximum(v, floor) / floor), 0)
    grp = 'action' if w in ACTS else 'your word'
    add(s, 'reach: ' + w, grp, f'how near "{w}" the word is through build lines (log reach from "{w}")')

named = dict(F=np.array(F), name=NAME, group=GROUP, how=HOW)
print('pool', len(NAME), {g_: GROUP.count(g_) for g_ in sorted(set(GROUP))})
print('reach floor', floor, 'words reached from "move"', int((reach['move'] > 0).sum()))

# ---- found pulls
d = np.asarray(A.sum(1)).ravel(); tau = d.mean()
dt = 1 / np.sqrt(d + tau)
one = np.ones(n)
def mv(x):
    y = dt * x
    return dt * (A @ y + tau / n * one * y.sum())
val, vec = eigsh(LinearOperator((n, n), matvec=mv, dtype=float), k=4, which='LA')
o = np.argsort(-val); val, vec = val[o], vec[:, o]
G3 = (vec[:, 1:4] * dt[:, None])
G3 /= np.abs(G3).max(0)
print('G3 eigenvalues', val, 'share of |coord| held by top 100 words per axis', [round(float(np.sort(np.abs(G3[:, k]))[-100:].sum() / np.abs(G3[:, k]).sum()), 3) for k in range(3)])

# signed: opposite lines count negative
W = {k: 1.0 for k in KINDS}; W['opposite'] = -1.0
As = build_graph(n, L, weight=W)
da = np.asarray(abs(As).sum(1)).ravel()
ds = 1 / np.sqrt(da + tau)
def mv2(x):
    return ds * (As @ (ds * x))
val2, vec2 = eigsh(LinearOperator((n, n), matvec=mv2, dtype=float), k=3, which='LA')
o = np.argsort(-val2); val2, vec2 = val2[o], vec2[:, o]
G4 = vec2 * ds[:, None]; G4 /= np.abs(G4).max(0)
print('G4 eigenvalues', val2, 'top-100 share', [round(float(np.sort(np.abs(G4[:, k]))[-100:].sum() / np.abs(G4[:, k]).sum()), 3) for k in range(3)])

# NMF: build-line neighbours by kind + class + topic, tf-idf columns, each word's row scaled to length 1
from sklearn.decomposition import NMF
blocks = []
for kn in KINDS:
    p = tr(kn)
    if not len(p): continue
    M = sp.coo_matrix((np.ones(len(p)), (p[:, 0], p[:, 1])), shape=(n, n)).tocsr()
    blocks += [M, M.T.tocsr()] if kn not in SYM else [(M + M.T).tocsr()]
cl1 = sp.csr_matrix(fcs)
X = sp.hstack(blocks + [cl1, sp.csr_matrix(fl / tl[:, None])]).tocsc()
df = np.asarray((X > 0).sum(0)).ravel(); keep = np.where(df > 0)[0]
X = X[:, keep] @ sp.diags(np.log(n / df[keep]))
X = sp.csr_matrix(X)
rn = np.sqrt(np.asarray(X.multiply(X).sum(1)).ravel()); rn[rn == 0] = 1
X = sp.diags(1 / rn) @ X          # each word counts once, hubs do not drown the rest
nmf = NMF(n_components=6, init='nndsvd', max_iter=2000, tol=1e-6, random_state=0)
Wn = nmf.fit_transform(X)
G5 = Wn / Wn.max(0)
print('NMF reconstruction err', nmf.reconstruction_err_, 'iters', nmf.n_iter_)

np.savez_compressed(os.path.join(out, 'forces18.npz'), named=named['F'], G3=G3, G4=G4, G5=G5, eig3=val, eig4=val2)
json.dump({'name': NAME, 'group': GROUP, 'how': HOW, 'tau': tau, 'reach_floor': floor}, open(os.path.join(out, 'forces18.json'), 'w'))
