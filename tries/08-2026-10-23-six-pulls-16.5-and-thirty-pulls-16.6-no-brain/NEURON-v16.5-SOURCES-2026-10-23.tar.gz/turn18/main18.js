(function () {
  var $ = function (id) { return document.getElementById(id); };
  var D = JSON.parse($('data18').textContent);
  function bytes(s) { var b = atob(s), u = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  var W = D.words, N = W.length, KINDS = D.kinds, WIDX = {};
  W.forEach(function (w, i) { WIDX[w] = i; });
  var LA = new Int32Array(bytes(D.la).buffer), LB = new Int32Array(bytes(D.lb).buffer), LK = bytes(D.lk);
  var ADJ = []; for (var i = 0; i < N; i++) ADJ.push([]);
  for (var e = 0; e < LA.length; e++) { ADJ[LA[e]].push(e); ADJ[LB[e]].push(e); }
  var SPLIT = ['build', 'choose', 'test'];
  var KCOL = { alike: '#7fd1b9', opposite: '#ff6b6b', is: '#ffd166', has: '#c792ea', prefix: '#8fa3bf', suffix: '#a3b8cc', stem: '#f4a261', past: '#5fa8ff', singular: '#e07be0' };
  var ENDS = ['+x', '-x', '+y', '-y', '+z', '-z'];
  var ECOL = ['#ff7a45', '#ffc069', '#52d18a', '#2fa39a', '#6ea8fe', '#b38cf2'];
  var CLSN = D.clsNames || [], CLS = D.cls || [];
  var CLSCOL = { verb: '#ff7a45', noun: '#6ea8fe', adjective: '#52d18a', adverb: '#ffc069' };
  var DIRS = [];
  (function () {
    [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]].forEach(function (v) { DIRS.push({ type: 'axis', v: v }); });
    for (var a = 0; a < 3; a++) for (var b = a + 1; b < 3; b++) [1, -1].forEach(function (sa) { [1, -1].forEach(function (sb) { var v = [0, 0, 0]; v[a] = sa; v[b] = sb; DIRS.push({ type: 'two-axis', v: v }); }); });
    [1, -1].forEach(function (x) { [1, -1].forEach(function (y) { [1, -1].forEach(function (z) { DIRS.push({ type: 'three-axis', v: [x, y, z] }); }); }); });
    DIRS.forEach(function (d) { var l = Math.hypot(d.v[0], d.v[1], d.v[2]); d.u = d.v.map(function (c) { return c / l; }); d.name = d.v.map(function (c, k) { return c ? (c > 0 ? '+' : '-') + 'xyz'[k] : ''; }).filter(Boolean).join(','); });
  })();
  var DTCOL = { axis: '#ffd166', 'two-axis': '#6ea8fe', 'three-axis': '#ff6b9a' };

  var G = D.graphs.map(function (g) {
    var q = new Int16Array(bytes(g.pos).buffer), P = new Float32Array(N * 3);
    for (var i = 0; i < N * 3; i++) P[i] = q[i] / 30000 * 100;
    g.P = P; g.S = bytes(g.six); g.c = 100 / g.scale;
    if (g.diagvals) g.DV = bytes(g.diagvals);
    var stack = {};
    for (var i2 = 0; i2 < N; i2++) { var k = q[3 * i2] + ',' + q[3 * i2 + 1] + ',' + q[3 * i2 + 2]; stack[k] = (stack[k] || 0) + 1; }
    g.stackOf = function (i) { return stack[q[3 * i] + ',' + q[3 * i + 1] + ',' + q[3 * i + 2]]; };
    g.atOrigin = stack['0,0,0'] || 0;
    var pts = 0; KINDS.forEach(function (k) { if (pointsOut(g, k)) pts++; }); g.pts = pts;
    var m = 0, c = 0; KINDS.forEach(function (k) { var r = g.map[k]; if (r && r.test) { m += r.test[r.best].median; c++; } }); g.meanShare = c ? m / c : null;
    var wp = 0; Object.keys(g.wn || {}).forEach(function (k) { var r = g.wn[k]; if (r.test && r.test[r.best].median < 0.25 && r.test[r.best].hit10 >= 0.003) wp++; }); g.wnPts = wp;
    return g;
  });
  function pointsOut(g, k) { var r = g.map[k]; if (!r || !r.test) return false; var t = r.test[r.best], s = g.shuffled[k]; return t.median < 0.25 && t.hit10 >= 0.003 && (!s || s.median >= 0.45); }
  function tier(v) { return v < 0.05 ? 'strong' : v < 0.15 ? 'clear' : v < 0.30 ? 'weak' : 'none'; }
  function pct(v) { return (v * 100).toFixed(v < 0.1 ? 1 : 0) + '%'; }
  function fx(v) { return (Math.round(v * 10) / 10).toFixed(1); }

  var cur = 0, sel = -1, colorMode = 'pull';
  var hasGL = !!window.THREE && (function () { try { var c = document.createElement('canvas'); return !!(c.getContext('webgl') || c.getContext('experimental-webgl')); } catch (e) { return false; } })();

  // ---- left rail: graphs and their pulls
  function graphList() {
    $('graphs').innerHTML = G.map(function (g, k) {
      return '<label class="gopt' + (k === cur ? ' on' : '') + '"><input type="radio" name="g" value="' + k + '"' + (k === cur ? ' checked' : '') + '><span class="gt">' + esc(g.title) + '</span>' +
        '<span class="gs"><span class="chip ' + (g.pts >= 7 ? 'strong' : g.pts >= 4 ? 'clear' : g.pts >= 1 ? 'weak' : 'none') + '">points out ' + g.pts + ' of 9</span> <span class="m">mean rank share ' + (g.meanShare == null ? '-' : g.meanShare.toFixed(3)) + '</span></span></label>';
    }).join('');
    Array.prototype.forEach.call($('graphs').querySelectorAll('input'), function (r) { r.addEventListener('change', function () { setGraph(+r.value); }); });
  }
  function pullTable() {
    var g = G[cur];
    var h = '<table class="pulls"><thead><tr><th>end</th><th>pull</th><th>its strongest words</th></tr></thead><tbody>';
    g.pulls.forEach(function (p, k) {
      h += '<tr><td><span class="end" style="--c:' + ECOL[k] + '">' + p.end.replace('-', '&minus;') + '</span></td><td><b>' + esc(p.name) + '</b><div class="m">' + esc(p.how) + '</div></td><td class="tw">' + esc(p.top.slice(0, 8).join(', ')) + '</td></tr>';
    });
    if (g.diag) g.diag.forEach(function (p) {
      h += '<tr><td><span class="end diag">' + esc(p.dir.replace(/-/g, '−')) + '</span></td><td><b>' + esc(p.name) + '</b><div class="m">diagonal pull (' + esc(p.type) + '): ' + esc(p.how) + '</div></td><td class="tw">' + esc(p.top.slice(0, 8).join(', ')) + '</td></tr>';
    });
    $('pulls').innerHTML = h + '</tbody></table>';
    $('gform').innerHTML = g.kind === 'pulls' ?
      'x = pull(+x) &minus; pull(&minus;x), y = pull(+y) &minus; pull(&minus;y), z = pull(+z) &minus; pull(&minus;z)' + (g.diag ? ' + each diagonal pull times its direction' : '') + '. Each pull is 0 to 1; 100 on the axes = a full pull.' :
      (g.key === 'G6' ? 'Places fitted straight to the build lines: no pull formula. Shown as the best a 3D placement does with these lines. 100 = the farthest point.' : 'x, y, z = three eigenvectors of the build lines. The + and &minus; ends of each axis are the six pulls. 100 = the farthest point.');
  }

  // ---- right rail: scores
  function funcText(g, k) {
    var r = g.map[k]; if (!r || !r.func) return '';
    var f = r.func, c = g.c;
    function v3(a) { return '(' + a.map(function (x) { return fx(x * c); }).join(', ') + ')'; }
    if (f[0] === 'same') return 'same place: B = A';
    if (f[0] === 'shift') return 'shift: B = A + ' + v3(f[1]);
    if (f[0] === 'flip') { var s = f[1][0], ax = ['x', 'y', 'z'].filter(function (a, i) { return s[i] < 0; }); return (ax.length === 3 && Math.abs(f[1][1][0]) + Math.abs(f[1][1][1]) + Math.abs(f[1][1][2]) < 1e-12 ? 'through origin: B = -A' : 'flip ' + ax.join(',') + ', then shift ' + v3(f[1][1])); }
    if (f[0] === 'scale') return 'scale each axis: B = (' + f[1][0].map(function (a, i) { return a.toFixed(2) + '·' + 'xyz'[i] + (f[1][1][i] * c >= 0 ? ' + ' : ' − ') + fx(Math.abs(f[1][1][i] * c)); }).join(', ') + ')';
    if (f[0] === 'linear') return 'any linear map: B = M·A + ' + v3(f[1][3]);
    return f[0];
  }
  function scoreTable() {
    var g = G[cur];
    var h = '<table class="sc"><thead><tr><th>kind</th><th title="chosen on the choose lines, scored on the held-back lines">formula</th><th title="share of all words closer to the formula\'s point than the real word; 0.5 = chance">rank share</th><th title="real word among the 10 closest">hit@10</th><th title="same graph, places shuffled among words">shuffled</th><th>same place</th><th>through origin</th></tr></thead><tbody>';
    KINDS.forEach(function (k) {
      var r = g.map[k]; if (!r || !r.test) return;
      var t = r.test[r.best], s = g.shuffled[k];
      h += '<tr' + (pointsOut(g, k) ? ' class="po"' : '') + '><td><span class="kd" style="--c:' + KCOL[k] + '"></span>' + k + '</td><td class="fn">' + esc(funcText(g, k)) + '</td><td><span class="chip ' + tier(t.median) + '">' + t.median.toFixed(3) + '</span></td><td>' + pct(t.hit10) + '</td><td>' + (s ? s.median.toFixed(3) : '-') + '</td><td>' + (r.test.same ? r.test.same.median.toFixed(3) : '-') + '</td><td>' + (r.test['through origin'] ? r.test['through origin'].median.toFixed(3) : (r.best === 'through origin' ? t.median.toFixed(3) : '-')) + '</td></tr>';
    });
    $('scores').innerHTML = h + '</tbody></table><p class="m">' + t_lines(g) + '</p>';
    var w = '<table class="sc"><thead><tr><th>WordNet line</th><th>formula</th><th>rank share</th><th>hit@10</th><th>lines</th></tr></thead><tbody>';
    Object.keys(g.wn || {}).forEach(function (k) { var r = g.wn[k]; if (!r.test) return; var t = r.test[r.best]; w += '<tr><td>' + k + '</td><td class="fn">' + esc(r.best) + '</td><td><span class="chip ' + tier(t.median) + '">' + t.median.toFixed(3) + '</span></td><td>' + pct(t.hit10) + '</td><td>' + t.n + '</td></tr>'; });
    $('wnscores').innerHTML = w + '</tbody></table>';
    var sg = '<table class="sc"><thead><tr><th>axis</th><th>opposite pairs on both sides of 0</th><th>by chance</th><th>pairs</th></tr></thead><tbody>';
    g.sign.forEach(function (s) { sg += '<tr><td>' + s.axis + '</td><td>' + (s.opposite_sides == null ? '-' : pct(s.opposite_sides)) + '</td><td>' + pct(s.expected_by_chance) + '</td><td>' + s.pairs + '</td></tr>'; });
    $('signs').innerHTML = sg + '</tbody></table>';
    var b = g.bis, bh = '<p class="m">' + b.at_origin.toLocaleString() + ' words sit at 0,0,0 (no pull). ' + b.distinct_points.toLocaleString() + ' distinct points for ' + N.toLocaleString() + ' words; the largest stack holds ' + b.largest_stack.toLocaleString() + '. Words pulled both ways on one axis (both ends above 0.1): x ' + b.both_ways[0] + ', y ' + b.both_ways[1] + ', z ' + b.both_ways[2] + '.</p><table class="sc"><thead><tr><th>direction</th><th>words nearest it</th><th>farthest out</th></tr></thead><tbody>';
    b.dirs.forEach(function (d) { bh += '<tr><td><span class="kd" style="--c:' + DTCOL[d.type] + '"></span>' + esc(d.dir.replace(/-/g, '−')) + '</td><td>' + d.words.toLocaleString() + '</td><td class="tw">' + esc(d.top.slice(0, 6).join(', ')) + '</td></tr>'; });
    $('bisects').innerHTML = bh + '</tbody></table>';
    var me = g.mean;
    $('meanings').innerHTML = '<ul><li>The fourteen actions (read, write, compare, add, subtract, move, find, split, join, clock, hear, say, call, spawn) sit ' + me.actions_spread_ratio.toFixed(2) + '&times; as far apart as 14 random words (' + pct(me.actions_spread_pct) + ' of random sets sit closer together).</li>' +
      '<li>The word "origin" lands at ' + (me.origin_pos ? me.origin_pos.map(fx).join(', ') : '-') + '; ' + (me.origin_radius_pct == null ? '' : pct(me.origin_radius_pct) + ' of words sit nearer to 0,0,0.') + '</li>' +
      '<li>Distance from 0,0,0 against how many WordNet kinds sit above the word (general vs specific): rank correlation ' + me.radius_vs_depth_spearman.toFixed(2) + ' (0 = none).</li></ul>';
  }
  function t_lines(g) {
    return 'Kinds pointed out (rank share under 0.25, hit@10 at least 0.3%, shuffled control at least 0.45): ' + g.pts + ' of 9. WordNet kinds: ' + g.wnPts + ' of 5.';
  }
  function randomPulls() {
    var r = D.random_pulls, h = 'Control, the first graph\'s six pulls each shuffled across words: ';
    h += KINDS.map(function (k) { return k + ' ' + (r[k] ? r[k].median.toFixed(2) : '-'); }).join(', ') + '.';
    $('rpulls').textContent = h;
  }

  // ---- selected word
  function applyF(g, k, p) {
    var r = g.map[k]; if (!r || !r.func) return p.slice();
    var f = r.func, c = g.c;
    if (f[0] === 'same') return p.slice();
    if (f[0] === 'shift') return p.map(function (x, i) { return x + f[1][i] * c; });
    if (f[0] === 'flip' || f[0] === 'scale') return p.map(function (x, i) { return f[1][0][i] * x + f[1][1][i] * c; });
    if (f[0] === 'linear') { var M = f[1]; return [0, 1, 2].map(function (j) { return p[0] * M[0][j] + p[1] * M[1][j] + p[2] * M[2][j] + M[3][j] * c; }); }
    return p.slice();
  }
  function posOf(g, i) { return [g.P[3 * i], g.P[3 * i + 1], g.P[3 * i + 2]]; }
  function rankOf(g, q, a, b) {
    var P = g.P, db = (q[0] - P[3 * b]) ** 2 + (q[1] - P[3 * b + 1]) ** 2 + (q[2] - P[3 * b + 2]) ** 2, less = 0, tie = 0, tol = 1e-6 * (1 + db);
    for (var j = 0; j < N; j++) { if (j === a || j === b) continue; var d = (q[0] - P[3 * j]) ** 2 + (q[1] - P[3 * j + 1]) ** 2 + (q[2] - P[3 * j + 2]) ** 2; if (d < db - tol) less++; else if (Math.abs(d - db) <= tol) tie++; }
    return { closer: less, share: (less + tie / 2) / (N - 2) };
  }
  var REL = [];
  function showWord(i) {
    sel = i; var g = G[cur];
    if (i < 0) { $('sel').innerHTML = '<span class="m">Click a point, or find a word above.</span>'; REL = []; drawSel(); return; }
    var p = posOf(g, i), six = []; for (var k = 0; k < 6; k++) six.push(g.S[6 * i + k] / 255);
    var order = six.map(function (v, k) { return [v, k]; }).filter(function (x) { return x[0] > 0; }).sort(function (a, b) { return b[0] - a[0]; });
    var words = order.map(function (x, n) { return (n === 0 ? 'strongest ' : '') + ENDS[x[1]].replace('-', '−') + ' (' + g.pulls[x[1]].name + ') ' + x[0].toFixed(2); });
    var gate = D.gates[W[i]];
    var h = '<div class="selh"><b class="w">' + esc(W[i]) + '</b>' + (gate ? '<span class="chip gate">brain gate: ' + esc(gate) + '</span>' : '') + (CLS[i] >= 0 && CLSN[CLS[i]] ? '<span class="m"> your map: ' + esc(CLSN[CLS[i]]) + '</span>' : '') + '</div>';
    h += '<div class="xyz">x ' + fx(p[0]) + ' &nbsp; y ' + fx(p[1]) + ' &nbsp; z ' + fx(p[2]) + '</div>';
    var st = g.stackOf(i); if (st > 1) h += '<div class="m">' + (st - 1).toLocaleString() + ' other words sit on exactly this point (the same pulls).</div>';
    h += '<div class="six">' + six.map(function (v, k) { return '<div class="sb"><span>' + ENDS[k].replace('-', '−') + '</span><i style="--w:' + (v * 100).toFixed(1) + '%;--c:' + ECOL[k] + '"></i><span>' + v.toFixed(2) + '</span></div>'; }).join('') + '</div>';
    if (g.DV) { var dv = []; g.diag.forEach(function (d, k) { var v = g.DV[g.diag.length * i + k] / 255; if (v > 0) dv.push(d.dir.replace(/-/g, '−') + ' (' + d.name + ') ' + v.toFixed(2)); }); if (dv.length) h += '<div class="m">diagonal pulls: ' + esc(dv.join('; ')) + '</div>'; }
    h += '<p class="m">' + (words.length ? esc(words.join('; ')) : 'No pull at all: this word sits at 0,0,0.') + '</p>';
    REL = [];
    var es = ADJ[i].slice(0, 400);
    var rows = es.map(function (e2) {
      var a = LA[e2], b = LB[e2], k = KINDS[LK[e2] >> 2], spl = SPLIT[LK[e2] & 3];
      var other = a === i ? b : a;
      var q = applyF(g, k, posOf(g, a)), r = rankOf(g, q, a, b);
      REL.push({ a: a, b: b, k: k, q: q, other: other });
      return { a: a, b: b, k: k, spl: spl, r: r, other: other, q: q };
    });
    rows.sort(function (x, y) { return KINDS.indexOf(x.k) - KINDS.indexOf(y.k) || x.r.share - y.r.share; });
    h += '<table class="sc rel"><thead><tr><th>line</th><th>other word sits at</th><th>formula puts B at</th><th title="share of all words closer to the formula\'s point than the real word">rank share</th><th>split</th></tr></thead><tbody>';
    rows.forEach(function (x) {
      h += '<tr><td><span class="kd" style="--c:' + KCOL[x.k] + '"></span><a href="#" data-w="' + x.other + '">' + esc(W[x.a]) + ' —' + x.k + '→ ' + esc(W[x.b]) + '</a></td><td>' + posOf(g, x.other).map(fx).join(', ') + '</td><td>' + x.q.map(fx).join(', ') + '</td><td><span class="chip ' + tier(x.r.share) + '">' + x.r.share.toFixed(3) + '</span></td><td class="m">' + x.spl + '</td></tr>';
    });
    if (ADJ[i].length > 400) h += '<tr><td colspan="5" class="m">first 400 of ' + ADJ[i].length + ' lines</td></tr>';
    h += '</tbody></table><p class="m">A line A —kind→ B: the formula for that kind starts at A and gives a point; the rank share says how many words sit closer to that point than B really does (0 = B is the closest word, 0.5 = chance).</p>';
    $('sel').innerHTML = h;
    Array.prototype.forEach.call($('sel').querySelectorAll('a[data-w]'), function (a) { a.addEventListener('click', function (ev) { ev.preventDefault(); showWord(+a.getAttribute('data-w')); }); });
    drawSel();
  }
  function findWord(s) {
    s = (s || '').trim().toLowerCase(); if (!s) return;
    if (WIDX[s] != null) { showWord(WIDX[s]); $('sugg').innerHTML = ''; return; }
    var m = []; for (var i = 0; i < N && m.length < 12; i++) if (W[i].indexOf(s) === 0) m.push(i);
    $('sugg').innerHTML = m.length ? m.map(function (i) { return '<button type="button" data-w="' + i + '">' + esc(W[i]) + '</button>'; }).join('') : '<span class="m">No word in your map starts with "' + esc(s) + '".</span>';
    Array.prototype.forEach.call($('sugg').querySelectorAll('button'), function (b) { b.addEventListener('click', function () { showWord(+b.getAttribute('data-w')); }); });
  }

  // ---- atlas
  var ATN = 400;
  function atlas() {
    var g = G[cur], f = ($('afind').value || '').trim().toLowerCase(), show = $('ashow').value, rows = [];
    for (var i = 0; i < N; i++) {
      if (f && W[i].indexOf(f) < 0) continue;
      if (show === 'gates' && !D.gates[W[i]]) continue;
      if (show === 'origin' && (g.P[3 * i] || g.P[3 * i + 1] || g.P[3 * i + 2])) continue;
      if (show === 'stacked' && g.stackOf(i) < 2) continue;
      rows.push(i);
    }
    var h = '<thead><tr><th>label</th><th>x</th><th>y</th><th>z</th>' + ENDS.map(function (e2) { return '<th>' + e2.replace('-', '−') + '</th>'; }).join('') + '<th>nearest of 26 directions</th><th>lines</th><th>shares point with</th><th>brain gate</th></tr></thead><tbody>';
    rows.slice(0, ATN).forEach(function (i) {
      var p = posOf(g, i), r = Math.hypot(p[0], p[1], p[2]), dn = '-';
      if (r > 1e-9) { var best = -2; DIRS.forEach(function (d) { var c = (p[0] * d.u[0] + p[1] * d.u[1] + p[2] * d.u[2]) / r; if (c > best) { best = c; dn = d.name; } }); } else dn = 'origin';
      h += '<tr class="arow" data-w="' + i + '"><td>' + esc(W[i]) + '</td><td>' + fx(p[0]) + '</td><td>' + fx(p[1]) + '</td><td>' + fx(p[2]) + '</td>' + [0, 1, 2, 3, 4, 5].map(function (k) { return '<td>' + (g.S[6 * i + k] / 255).toFixed(2) + '</td>'; }).join('') + '<td>' + esc(dn.replace(/-/g, '−')) + '</td><td>' + ADJ[i].length + '</td><td>' + (g.stackOf(i) - 1).toLocaleString() + '</td><td>' + (D.gates[W[i]] || '') + '</td></tr>';
    });
    $('atable').innerHTML = h + '</tbody>';
    $('asum').textContent = rows.length.toLocaleString() + ' words match' + (rows.length > ATN ? '; showing the first ' + ATN + ' A to Z. Type in "find" to narrow.' : '.') + ' Positions are ' + g.title + '\'s formula, computed in this page from numbers my test computed; the brain holds no positions.';
    Array.prototype.forEach.call($('atable').querySelectorAll('tr.arow'), function (tr) { tr.addEventListener('click', function () { showWord(+tr.getAttribute('data-w')); }); });
  }

  // ---- 3D
  var renderer, scene, camera, pts, geo, colAttr, guideGroup, selGroup, labelBox, labels = [];
  var theta = 0.7, phi = 1.1, dist = 330, tween = null, reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var shown = new Float32Array(N * 3);
  function colorize() {
    var g = G[cur], c = new THREE.Color();
    for (var i = 0; i < N; i++) {
      var col = '#59606b';
      if (colorMode === 'pull') { var b = -1, bv = 0; for (var k = 0; k < 6; k++) { var v = g.S[6 * i + k]; if (v > bv) { bv = v; b = k; } } if (b >= 0) col = ECOL[b]; }
      else if (colorMode === 'dir') { var p = posOf(g, i), r = Math.hypot(p[0], p[1], p[2]); if (r > 1e-9) { var best = -2, bt = 'axis'; DIRS.forEach(function (d) { var cc = (p[0] * d.u[0] + p[1] * d.u[1] + p[2] * d.u[2]) / r; if (cc > best) { best = cc; bt = d.type; } }); col = DTCOL[bt]; } }
      else if (colorMode === 'class') { var nm = CLSN[CLS[i]]; col = CLSCOL[nm] || '#59606b'; }
      else if (colorMode === 'gates') { col = D.gates[W[i]] ? '#ffd166' : '#3a3f47'; }
      c.set(col); colAttr.setXYZ(i, c.r, c.g, c.b);
    }
    colAttr.needsUpdate = true;
  }
  function makeLabel(text, color, small) {
    var el = document.createElement('div'); el.className = 'lab' + (small ? ' sm' : ''); el.textContent = text; if (color) el.style.color = color; labelBox.appendChild(el); return el;
  }
  function guides() {
    while (guideGroup.children.length) guideGroup.remove(guideGroup.children[0]);
    labels.filter(function (l) { return l.guide; }).forEach(function (l) { l.el.remove(); });
    labels = labels.filter(function (l) { return !l.guide; });
    var g = G[cur], show = { axis: $('gaxis').checked, 'two-axis': $('gtwo').checked, 'three-axis': $('gthree').checked };
    DIRS.forEach(function (d, k) {
      if (!show[d.type]) return;
      var R = 115, geo2 = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, 0), new THREE.Vector3(d.u[0] * R, d.u[2] * R, -d.u[1] * R)]);
      var mat = new THREE.LineBasicMaterial({ color: d.type === 'axis' ? ECOL[k] : DTCOL[d.type], transparent: true, opacity: d.type === 'axis' ? 0.55 : 0.35, depthTest: false });
      guideGroup.add(new THREE.Line(geo2, mat));
      var txt = d.name.replace(/-/g, '−');
      if (d.type === 'axis') txt += ' ' + g.pulls[k].name;
      labels.push({ guide: true, el: makeLabel(txt, d.type === 'axis' ? ECOL[k] : DTCOL[d.type], d.type !== 'axis'), at: [d.u[0] * (R + 6), d.u[1] * (R + 6), d.u[2] * (R + 6)] });
    });
    if (show.axis) [50, 100].forEach(function (v) { [[v, 0, 0], [-v, 0, 0], [0, v, 0], [0, -v, 0], [0, 0, v], [0, 0, -v]].forEach(function (p) { labels.push({ guide: true, el: makeLabel(String(p[0] || p[1] || p[2]).replace('-', '−'), '#8b929c', true), at: p }); }); });
    labels.push({ guide: true, el: makeLabel('0,0,0 origin', '#f2efe6', true), at: [0, 0, 0] });
  }
  // brain-graph x,y,z -> drawing: x right, z up the screen, y into the screen
  function w3(p) { return new THREE.Vector3(p[0], p[2], -p[1]); }
  function drawSel() {
    if (!hasGL) return;
    while (selGroup.children.length) selGroup.remove(selGroup.children[0]);
    labels.filter(function (l) { return l.sel; }).forEach(function (l) { l.el.remove(); });
    labels = labels.filter(function (l) { return !l.sel; });
    if (sel < 0) return;
    var g = G[cur], kOn = {};
    KINDS.forEach(function (k) { var c = $('k_' + k); kOn[k] = !c || c.checked; });
    var hp = [], hc = [], segs = [], scol = [], ghosts = [], gcol = [], c = new THREE.Color();
    function push(arr, carr, p, col) { arr.push(p[0], p[2], -p[1]); c.set(col); carr.push(c.r, c.g, c.b); }
    push(hp, hc, posOf(g, sel), '#ffffff');
    var named = 0;
    REL.forEach(function (r) {
      if (!kOn[r.k]) return;
      var po = posOf(g, r.other), ps = posOf(g, sel);
      push(hp, hc, po, KCOL[r.k]);
      push(segs, scol, ps, KCOL[r.k]); push(segs, scol, po, KCOL[r.k]);
      if ($('ghost').checked) { push(ghosts, gcol, r.q, KCOL[r.k]); push(segs, scol, r.q, '#ffffff'); push(segs, scol, posOf(g, r.b), '#ffffff'); }
      if (named < 40) { labels.push({ sel: true, el: makeLabel(W[r.other], KCOL[r.k], true), at: po }); named++; }
    });
    labels.push({ sel: true, el: makeLabel(W[sel], '#ffffff'), at: posOf(g, sel) });
    var gp = new THREE.BufferGeometry(); gp.setAttribute('position', new THREE.Float32BufferAttribute(hp, 3)); gp.setAttribute('color', new THREE.Float32BufferAttribute(hc, 3));
    selGroup.add(new THREE.Points(gp, new THREE.PointsMaterial({ size: 9, sizeAttenuation: false, vertexColors: true, depthTest: false, transparent: true })));
    if (ghosts.length) { var gg = new THREE.BufferGeometry(); gg.setAttribute('position', new THREE.Float32BufferAttribute(ghosts, 3)); gg.setAttribute('color', new THREE.Float32BufferAttribute(gcol, 3)); selGroup.add(new THREE.Points(gg, new THREE.PointsMaterial({ size: 6, sizeAttenuation: false, vertexColors: true, depthTest: false, transparent: true, opacity: 0.6 }))); }
    var gl = new THREE.BufferGeometry(); gl.setAttribute('position', new THREE.Float32BufferAttribute(segs, 3)); gl.setAttribute('color', new THREE.Float32BufferAttribute(scol, 3));
    selGroup.add(new THREE.LineSegments(gl, new THREE.LineBasicMaterial({ vertexColors: true, transparent: true, opacity: 0.8, depthTest: false })));
  }
  var allLines = null;
  function drawAllLines() {
    if (!hasGL) return;
    if (allLines) { scene.remove(allLines); allLines = null; }
    var k = $('allk').value; if (!k) return;
    var ki = KINDS.indexOf(k), arr = [], g = G[cur];
    for (var e2 = 0; e2 < LA.length; e2++) { if ((LK[e2] >> 2) !== ki) continue; var a = posOf(g, LA[e2]), b = posOf(g, LB[e2]); arr.push(a[0], a[2], -a[1], b[0], b[2], -b[1]); }
    var gl = new THREE.BufferGeometry(); gl.setAttribute('position', new THREE.Float32BufferAttribute(arr, 3));
    allLines = new THREE.LineSegments(gl, new THREE.LineBasicMaterial({ color: KCOL[k], transparent: true, opacity: 0.12, depthWrite: false }));
    scene.add(allLines);
  }
  function setGraph(k) {
    var from = shown.slice(); cur = k;
    graphList(); pullTable(); scoreTable();
    if (hasGL) { colorize(); guides(); if (reduce) { shown.set(G[cur].P); writePos(); } else tween = { from: from, t0: performance.now() }; }
    if (sel >= 0) showWord(sel); else drawSel();
    drawAllLines();
    if (!$('atlas').hidden) atlas();
    $('hudg').textContent = G[cur].title + ': ' + N.toLocaleString() + ' words, ' + G[cur].atOrigin.toLocaleString() + ' at 0,0,0';
  }
  function writePos() { var a = geo.attributes.position; for (var i = 0; i < N; i++) a.setXYZ(i, shown[3 * i], shown[3 * i + 2], -shown[3 * i + 1]); a.needsUpdate = true; geo.computeBoundingSphere(); }
  function pick(ev) {
    var rect = renderer.domElement.getBoundingClientRect(), mx = ev.clientX - rect.left, my = ev.clientY - rect.top, best = -1, bd = 12 * 12, v = new THREE.Vector3();
    camera.updateMatrixWorld();
    for (var i = 0; i < N; i++) { v.set(shown[3 * i], shown[3 * i + 2], -shown[3 * i + 1]).project(camera); if (v.z > 1) continue; var sx = (v.x + 1) / 2 * rect.width, sy = (1 - v.y) / 2 * rect.height, d = (sx - mx) * (sx - mx) + (sy - my) * (sy - my); if (d < bd) { bd = d; best = i; } }
    showWord(best);
  }
  function initGL() {
    var canvas = $('c');
    renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true }); renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    scene = new THREE.Scene(); camera = new THREE.PerspectiveCamera(40, 1, 0.5, 20000);
    geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(new Float32Array(N * 3), 3));
    colAttr = new THREE.Float32BufferAttribute(new Float32Array(N * 3), 3); geo.setAttribute('color', colAttr);
    pts = new THREE.Points(geo, new THREE.PointsMaterial({ size: 2.6, sizeAttenuation: false, vertexColors: true, transparent: true, opacity: 0.85 }));
    scene.add(pts); guideGroup = new THREE.Group(); scene.add(guideGroup); selGroup = new THREE.Group(); scene.add(selGroup);
    labelBox = $('labels');
    shown.set(G[cur].P); writePos();
    var ptrs = {}, dragging = false, moved = false, lx = 0, ly = 0, pinch = 0;
    canvas.addEventListener('pointerdown', function (e) { ptrs[e.pointerId] = [e.clientX, e.clientY]; dragging = true; moved = false; lx = e.clientX; ly = e.clientY; canvas.setPointerCapture(e.pointerId); });
    canvas.addEventListener('pointermove', function (e) {
      if (!dragging) return; ptrs[e.pointerId] = [e.clientX, e.clientY]; var ids = Object.keys(ptrs);
      if (ids.length >= 2) { var a = ptrs[ids[0]], b = ptrs[ids[1]], d = Math.hypot(a[0] - b[0], a[1] - b[1]); if (pinch) dist = Math.min(4000, Math.max(8, dist * pinch / d)); pinch = d; moved = true; return; }
      var dx = e.clientX - lx, dy = e.clientY - ly; lx = e.clientX; ly = e.clientY; if (Math.abs(dx) + Math.abs(dy) > 2) moved = true; theta -= dx * 0.005; phi = Math.min(Math.PI - 0.05, Math.max(0.05, phi - dy * 0.005));
    });
    function up(e) { delete ptrs[e.pointerId]; if (Object.keys(ptrs).length < 2) pinch = 0; if (!Object.keys(ptrs).length) { dragging = false; if (!moved) pick(e); } }
    canvas.addEventListener('pointerup', up); canvas.addEventListener('pointercancel', up);
    canvas.addEventListener('wheel', function (e) { e.preventDefault(); dist = Math.min(4000, Math.max(8, dist * (1 + e.deltaY * 0.0012))); }, { passive: false });
    function resize() { var w = $('stage').clientWidth, h = $('stage').clientHeight; renderer.setSize(w, h, false); camera.aspect = w / Math.max(1, h); camera.updateProjectionMatrix(); }
    window.addEventListener('resize', resize); resize();
    var last = performance.now(), v = new THREE.Vector3();
    function frame(now) {
      var dt = (now - last) / 1000; last = now;
      if ($('spin').getAttribute('aria-pressed') === 'true' && !dragging) theta += dt * 0.1;
      if (tween) { var t = Math.min(1, (now - tween.t0) / 900), s = t * t * (3 - 2 * t), P = G[cur].P; for (var i = 0; i < N * 3; i++) shown[i] = tween.from[i] + (P[i] - tween.from[i]) * s; writePos(); if (t >= 1) tween = null; }
      camera.position.set(dist * Math.sin(phi) * Math.sin(theta), dist * Math.cos(phi), dist * Math.sin(phi) * Math.cos(theta)); camera.lookAt(0, 0, 0);
      renderer.render(scene, camera);
      var w = $('stage').clientWidth, h = $('stage').clientHeight;
      labels.forEach(function (l) { v.copy(w3(l.at)).project(camera); if (v.z > 1 || Math.abs(v.x) > 1.1 || Math.abs(v.y) > 1.1) { l.el.style.display = 'none'; return; } l.el.style.display = ''; l.el.style.transform = 'translate(' + ((v.x + 1) / 2 * w).toFixed(1) + 'px,' + ((1 - v.y) / 2 * h).toFixed(1) + 'px)'; });
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }

  // ---- wire up
  $('lkinds').innerHTML = KINDS.map(function (k) { return '<label class="chk"><input type="checkbox" id="k_' + k + '" checked><span class="kd" style="--c:' + KCOL[k] + '"></span>' + k + '</label>'; }).join('');
  $('allk').innerHTML = '<option value="">none</option>' + KINDS.map(function (k) { return '<option value="' + k + '">' + k + '</option>'; }).join('');
  KINDS.forEach(function (k) { $('k_' + k).addEventListener('change', drawSel); });
  ['gaxis', 'gtwo', 'gthree'].forEach(function (id) { $(id).addEventListener('change', function () { if (hasGL) guides(); }); });
  $('ghost').addEventListener('change', drawSel);
  $('allk').addEventListener('change', drawAllLines);
  $('cmode').addEventListener('change', function () { colorMode = $('cmode').value; if (hasGL) colorize(); legend(); });
  $('find').addEventListener('keydown', function (e) { if (e.key === 'Enter') findWord($('find').value); });
  $('findb').addEventListener('click', function () { findWord($('find').value); });
  $('spin').addEventListener('click', function () { var b = $('spin'); b.setAttribute('aria-pressed', b.getAttribute('aria-pressed') === 'true' ? 'false' : 'true'); });
  $('atlasbtn').addEventListener('click', function () { $('atlas').hidden = false; atlas(); });
  $('aclose').addEventListener('click', function () { $('atlas').hidden = true; });
  $('afind').addEventListener('input', atlas); $('ashow').addEventListener('change', atlas);
  function legend() {
    var h = '';
    if (colorMode === 'pull') h = ENDS.map(function (e2, k) { return '<span><i style="--c:' + ECOL[k] + '"></i>' + e2.replace('-', '−') + '</span>'; }).join('') + '<span><i style="--c:#59606b"></i>no pull</span>';
    if (colorMode === 'dir') h = Object.keys(DTCOL).map(function (t) { return '<span><i style="--c:' + DTCOL[t] + '"></i>' + t + '</span>'; }).join('') + '<span><i style="--c:#59606b"></i>origin</span>';
    if (colorMode === 'class') h = Object.keys(CLSCOL).map(function (t) { return '<span><i style="--c:' + CLSCOL[t] + '"></i>' + t + '</span>'; }).join('') + '<span><i style="--c:#59606b"></i>other</span>';
    if (colorMode === 'gates') h = '<span><i style="--c:#ffd166"></i>brain gate</span><span><i style="--c:#3a3f47"></i>map word</span>';
    $('legend').innerHTML = h;
  }
  if (hasGL) { initGL(); } else { $('err').style.display = 'flex'; }
  randomPulls(); legend();
  setGraph(0);
  var hash = (location.hash || '').slice(1); if (hash && WIDX[decodeURIComponent(hash)] != null) showWord(WIDX[decodeURIComponent(hash)]); else showWord(WIDX['origin'] != null ? WIDX['origin'] : -1);
  window.__six = { graphs: function () { return G.map(function (g) { return { key: g.key, pts: g.pts, mean: g.meanShare, origin: g.atOrigin }; }); }, set: setGraph, show: showWord, idx: function (w) { return WIDX[w]; },
    pos: function (w) { return posOf(G[cur], WIDX[w]); }, sel: function () { return $('sel').innerText; }, atlas: function () { $('atlas').hidden = false; atlas(); return $('atable').querySelectorAll('tr.arow').length; }, rank: function (a, b, k) { var g = G[cur]; return rankOf(g, applyF(g, k, posOf(g, WIDX[a])), WIDX[a], WIDX[b]); } };
})();
