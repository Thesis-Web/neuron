# turn 18 dataset: the owner's relation map (lines, classes) + Open English WordNet 2025 (word facts, its own lines)
# usage: python3 -I data18.py <owner data.json> <oewn json dir> <out dir>
import sys, os, json, glob, hashlib, collections
sys.path.append(os.path.expanduser('~/.local/lib/python3.10/site-packages'))
import numpy as np

src, wdir, out = sys.argv[1], sys.argv[2], sys.argv[3]
d = json.load(open(src))
names = d['names']; rels = [r['key'] for r in d['rels']]; cls = d['cls']; clsNames = d['clsNames']
e = d['edges']
E = [(e[i], e[i + 1], e[i + 2]) for i in range(0, len(e), 3)]
SYM = {'alike', 'opposite'}

# one point per spelling (one gate per word, NOCASE): map nodes that share a spelling are merged, their lines kept
lname = [w.lower() for w in names]
spell = sorted(set(lname)); sid_ = {w: i for i, w in enumerate(spell)}
node2w = [sid_[w] for w in lname]
names = spell
ccount = np.zeros((len(spell), len(clsNames)))
for i, c in enumerate(cls):
    if c >= 0: ccount[node2w[i], c] += 1
pairs = collections.defaultdict(set)
for a, b, k in E:
    kn = rels[k]
    a, b = node2w[a], node2w[b]
    if kn in SYM:
        a, b = min(a, b), max(a, b)
    if a != b:
        pairs[kn].add((a, b))

deg = collections.Counter()
for kn, s in pairs.items():
    for a, b in s:
        deg[a] += 1; deg[b] += 1
V = sorted(deg)                       # words with at least one line
vid = {w: i for i, w in enumerate(V)}  # map name index -> row

def split_of(a, b, kn):
    h = hashlib.sha1(f'{kn}|{names[a]}|{names[b]}'.encode()).digest()[0]
    return 'train' if h < 179 else ('val' if h < 217 else 'test')   # 70 / 15 / 15

lines = []
for kn in rels:
    for a, b in sorted(pairs[kn]):
        lines.append((vid[a], vid[b], kn, split_of(a, b, kn)))

# ---- WordNet facts per word (lemma match, lower case, spaces as _)
ent = {}
for f in sorted(glob.glob(os.path.join(wdir, 'entries-*.json'))):
    for lemma, v in json.load(open(f)).items():
        ent.setdefault(lemma.lower(), []).append(v)
syn = {}
lexfiles = sorted(os.path.basename(f)[:-5] for f in glob.glob(os.path.join(wdir, '*.json'))
                  if not os.path.basename(f).startswith('entries') and os.path.basename(f) != 'frames.json')
for lf in lexfiles:
    for sid, s in json.load(open(os.path.join(wdir, lf + '.json'))).items():
        s['_lex'] = lf
        syn[sid] = s
LEX = lexfiles

def wn_of(w):
    return ent.get(w.lower().replace(' ', '_'), [])

# hypernym depth (shortest path to a root) per synset
depth_cache = {}
def depth(sid, guard=0):
    if sid in depth_cache: return depth_cache[sid]
    s = syn.get(sid)
    if s is None or guard > 40: return 0
    hs = s.get('hypernym', []) + s.get('instance_hypernym', [])
    dd = 0 if not hs else 1 + min(depth(h, guard + 1) for h in hs)
    depth_cache[sid] = dd
    return dd

nV = len(V)
POS = ['n', 'v', 'a', 'r']  # 's' (satellite adj) folded into 'a'
f_pos = np.zeros((nV, 4)); f_lex = np.zeros((nV, len(LEX))); f_senses = np.zeros(nV)
f_depth = np.full(nV, np.nan); f_inwn = np.zeros(nV); f_forms = np.zeros(nV)
word_syns = [set() for _ in range(nV)]
for i, w in enumerate(V):
    for v in wn_of(names[w]):
        f_inwn[i] = 1
        for p, pv in v.items():
            pp = 'a' if p == 's' else p
            ss = pv.get('sense', [])
            if pp in POS: f_pos[i, POS.index(pp)] += len(ss)
            f_senses[i] += len(ss)
            f_forms[i] += len(pv.get('form', []))
            for se in ss:
                sid = se['synset']; word_syns[i].add(sid)
                if sid in syn: f_lex[i, LEX.index(syn[sid]['_lex'])] += 1
    ds = [depth(s) for s in word_syns[i] if s in syn and syn[s]['partOfSpeech'] in ('n', 'v')]
    if ds: f_depth[i] = min(ds)

# ---- WordNet's own lines between map words (a second source, used only to CHECK, never to build)
lemma2v = {}
for i, w in enumerate(V):
    lemma2v.setdefault(names[w].lower().replace(' ', '_'), i)
syn_members = collections.defaultdict(set)
for sid, s in syn.items():
    for m in s.get('members', []):
        j = lemma2v.get(m.lower().replace(' ', '_'))
        if j is not None: syn_members[sid].add(j)
wnl = collections.defaultdict(set)
for sid, mem in syn_members.items():
    mem = sorted(mem)
    for x in range(len(mem)):
        for y in range(x + 1, len(mem)):
            wnl['synonym'].add((mem[x], mem[y]))
    s = syn[sid]
    for rel, kn in (('hypernym', 'hypernym'), ('mero_part', 'part'), ('mero_member', 'part'), ('mero_substance', 'part'), ('similar', 'similar')):
        for t in s.get(rel, []):
            for a in mem:
                for b in syn_members.get(t, ()):
                    if a != b: wnl[kn].add((a, b) if kn != 'similar' else (min(a, b), max(a, b)))
# antonyms are on senses: sense key -> word
for i, w in enumerate(V):
    for v in wn_of(names[w]):
        for p, pv in v.items():
            for se in pv.get('sense', []):
                for ak in se.get('antonym', []):
                    j = lemma2v.get(ak.split('%')[0].lower())
                    if j is not None and j != i: wnl['antonym'].add((min(i, j), max(i, j)))

os.makedirs(out, exist_ok=True)
np.savez_compressed(os.path.join(out, 'data18.npz'), f_pos=f_pos, f_lex=f_lex, f_senses=f_senses, f_depth=f_depth,
                    f_inwn=f_inwn, f_forms=f_forms, f_cls=ccount[V],
                    cls=np.where(ccount[V].sum(1) > 0, ccount[V].argmax(1), -1))
json.dump({'words': [names[w] for w in V], 'rels': rels, 'clsNames': clsNames, 'lex': LEX, 'pos': POS,
           'lines': lines, 'wnlines': {k: sorted(v) for k, v in wnl.items()}},
          open(os.path.join(out, 'data18.json'), 'w'))
cnt = collections.Counter((kn, sp) for _, _, kn, sp in lines)
print('words', nV, 'in WordNet', int(f_inwn.sum()))
for kn in rels: print(kn, cnt[(kn, 'train')], cnt[(kn, 'val')], cnt[(kn, 'test')])
for k, v in wnl.items(): print('wordnet', k, len(v))
print('depth known', int((~np.isnan(f_depth)).sum()))
