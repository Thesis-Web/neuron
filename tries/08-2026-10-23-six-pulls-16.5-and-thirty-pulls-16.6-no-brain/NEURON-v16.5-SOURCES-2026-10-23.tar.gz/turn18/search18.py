# turn 18: choose pulls for each axis on the CHOOSE split (sampled scorer), saved after every step
# usage: python3 -I search18.py <out dir> <stage: g1|g2|g5>   (env PROCS = worker count, default 12)
import sys, os, json, itertools, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib18 import *
import multiprocessing as mp

out, stage = sys.argv[1], sys.argv[2]
PROCS = int(os.environ.get('PROCS', '12'))
j, z, L, WN = load(out)
n = len(j['words'])
f = np.load(os.path.join(out, 'forces18.npz'))
meta = json.load(open(os.path.join(out, 'forces18.json')))
PR = Proxy(L, n)

POOL = None


def place(axes, pool):
    P = np.zeros((n, 3))
    for k, (a, b) in enumerate(axes):
        P[:, k] = pool[a] - (pool[b] if b is not None else 0)
    return P


def ev(axes):
    return PR(place(axes, POOL)), axes


def run_pool(cands, procs=PROCS):
    with mp.Pool(procs) as pp:
        return pp.map(ev, cands, chunksize=8)


def save(res):
    json.dump(res, open(os.path.join(out, 'search_%s.json' % stage), 'w'), default=lambda o: o.tolist() if hasattr(o, 'tolist') else int(o))


if __name__ == '__main__':
    t0 = time.time()
    res = {}
    if stage == 'g1':
        POOL = f['named']
        m = len(POOL)
        beam = [[]]
        for depth in range(3):
            used = lambda ax: {x for p in ax for x in p}
            cands = []
            for ax in beam:
                u = used(ax)
                for a in range(m):
                    for b in range(a + 1, m):
                        if a in u or b in u: continue
                        cands.append(ax + [(a, b)])
            # drop axis-order duplicates
            seen, uniq = set(), []
            for c in cands:
                key = tuple(sorted(c))
                if key not in seen: seen.add(key); uniq.append(c)
            r = run_pool(uniq)
            r.sort(key=lambda x: x[0])
            beam = [c for _, c in r[:6]]
            print('depth', depth + 1, 'evaluated', len(uniq), 'best', [(round(s, 4), [(meta['name'][a], meta['name'][b]) for a, b in c]) for s, c in r[:3]], round(time.time() - t0), 's', flush=True)
            res['depth%d' % (depth + 1)] = [(s, c) for s, c in r[:40]]
            save(res)
        res['beam'] = beam
    elif stage == 'g2':
        POOL = f['named']
        acts = [i for i, g in enumerate(meta['group']) if g == 'action']
        cands = []
        for six in itertools.combinations(acts, 6):
            a0 = six[0]
            for p in six[1:]:
                rest = [x for x in six[1:] if x != p]
                b0 = rest[0]
                for q in rest[1:]:
                    last = [x for x in rest[1:] if x != q]
                    cands.append([(a0, p), (b0, q), tuple(last)])
        print('action graphs', len(cands), flush=True)
        r = run_pool(cands)
        r.sort(key=lambda x: x[0])
        res['all_scores'] = [s for s, _ in r]
        res['top'] = [(s, c) for s, c in r[:40]]
        res['worst'] = [(s, c) for s, c in r[-5:]]
        print('best', [(round(s, 4), [(meta['name'][a], meta['name'][b]) for a, b in c]) for s, c in r[:3]], round(time.time() - t0), 's', flush=True)
    elif stage == 'g5':
        G5 = f['G5']; POOL = list(G5.T)
        cands = []
        for p in range(1, 6):
            rest = [x for x in range(1, 6) if x != p]
            for q in rest[1:]:
                last = [x for x in rest[1:] if x != q]
                cands.append([(0, p), (rest[0], q), tuple(last)])
        r = run_pool(cands, min(PROCS, 15))
        r.sort(key=lambda x: x[0])
        res['all'] = [(s, c) for s, c in r]
        print('g5 pairings', [(round(s, 4), c) for s, c in r], flush=True)
    save(res)
