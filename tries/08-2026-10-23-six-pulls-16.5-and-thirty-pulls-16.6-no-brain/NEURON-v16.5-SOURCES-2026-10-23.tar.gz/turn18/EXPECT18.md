# Turn 18: six pulls. Expected outputs, written BEFORE any graph was computed (2026-10-23)

(Restored after the 7:56 PM Windows crash wiped the temp folder: the text below is the file as first written, copied back from the session history. The amendments at the end are the ones made before the final scoring, plus a crash note.)

Owner, verbatim (turn16/OWNER-VERBATIM.txt, message 5):
- "I think that we have 8 forces that are pulling away from origin each line axis .... every word has a relationship to these 8 forces"
- "a point that is pulled to -8,9,-56 has a strong relationship to the -z force and a less strong relationship to the +y and -x forces"
- "test as many types of pulls on the graph on the axis in different directions and see if you can find an 6 pull graph that actually makes sense, meaning the point that a gate lands ons, and the points the other points that it relates to lands on actually make since in a mathmatical since.. like you can find an equation, formula, function, log rhythm that when used points out every relationship in this way or that way"
- "you might find 6 main axis pulls, 8 linear bisects pulls , and 8- 3 axis bissects, and 4 ... 4 axis bissects ... I would think that each of these bissects would have relations to their main axis somehow"
- "this can't be correct you are putting limits on the shape of the graph"

Earlier owner words this builds on: "a point is six whole numbers (x+ x- y+ y- z+ z-)", "opposite = swap" (my notes of the 10-03 build); "the overlay 3d graph of simplest expressions that are fixed and never move and the points are gates numbers that move based on relationships"; "3D, not Nd" (10-17); "only known placed word is origin" (10-23).

## The form tested (no steps, no cap, no springs, no spacing, no rest lengths)
Each word w gets six strengths s1..s6 >= 0, one per pull. Pulls sit on +x, -x, +y, -y, +z, -z.
    x = s(+x) - s(-x),  y = s(+y) - s(-y),  z = s(+z) - s(-z)
One formula, computed once. Words with equal pulls land on the same point. Words with no pull land on origin.

## Data (data18.py)
- The owner's relation map (data.json, 2026-10-08): 33,703 words with a line; 9 kinds. Lines split by a hash of the pair: 70% build, 15% choose, 15% final test. Pulls are built from build lines only.
- Open English WordNet 2025: word facts (class share, topic file, number of senses, depth below the top kinds). Its own lines between map words (synonym, similar, hypernym, part, antonym) are used only to CHECK, never to build; lines that the map also has are dropped from the check.

## Score ("points out a relationship")
For a kind R, a function f_R is fitted on build lines: q = f_R(place of A). For each held-out line A -R-> B: the share of all words that sit closer to q than B does (ties count half). 0 = B is the closest word, 0.5 = chance. Median over lines = "median rank share". Also hit@10 = share of lines where B is among the 10 words closest to q (chance 10/33,703 = 0.03%).
Functions tried for every kind: same place (B = A); shift (B = A + t); flip one, two or all three axes then shift (the swap); scale per axis then shift; any 3x3 linear + shift. Chosen on the choose split, reported on the test split.
Tiers: strong < 0.05, clear < 0.15, weak < 0.30, none >= 0.30.
A graph "points out" kind R if test median < 0.25 AND hit@10 >= 10x chance (0.3%) AND the shuffled control is >= 0.45.
A graph "makes sense" (my bar, set now) if it points out >= 7 of the 9 map kinds and >= 3 of the 5 WordNet kinds.

## Graphs
- C0 controls: (a) best graph with places shuffled among words; (b) six random pulls.
- G1 your named pulls, measured from data: class (verb, noun, adjective, adverb, small words), tense (past form, base verb), number (plural, singular), modifiers (has prefix, has suffix, is a stem, is an affix), topic (WordNet's 45 topic files), source (in WordNet, senses), depth (general vs specific), and the reach of your listed words through the build lines (action, situation, context, perspective, mood, class, tense, plural, singular, modifier, memory, time, state, before, after, topic, source, correct, incorrect). Best 6 chosen greedily, axis by axis, on the choose split.
- G2 the fourteen actions as pulls (reach of READ WRITE COMPARE ADD SUBTRACT MOVE FIND SPLIT JOIN CLOCK HEAR SAY CALL SPAWN); best 6 and pairing chosen on the choose split.
- G3 found: the graph's own equation (eigenvectors of the build lines, all kinds equal weight). Each axis's + end and - end are two pulls.
- G4 found, signed: same with opposite lines counted negative.
- G5 found: six non-negative pulls factored from build lines + class + topic; pairing chosen on the choose split (15 pairings).
- G6 ceiling: places fitted directly to the build lines (not a pull formula). The best any 3D placement does with these lines.

## Predictions (median rank share on test; hit@10)
| kind | C0 shuffled | G1 named | G2 actions | G3/G4 found | G5 | G6 ceiling |
|---|---|---|---|---|---|---|
| alike | 0.50 | 0.30 | 0.30 | 0.10 | 0.15 | 0.03 |
| opposite | 0.50 | 0.30 | 0.35 | 0.12 | 0.15 | 0.05 |
| is | 0.50 | 0.35 | 0.40 | 0.20 | 0.25 | 0.10 |
| has | 0.50 | 0.40 | 0.45 | 0.25 | 0.30 | 0.15 |
| prefix, suffix | 0.50 | 0.20 | 0.40 | 0.25 | 0.25 | 0.05 |
| stem | 0.50 | 0.25 | 0.40 | 0.25 | 0.25 | 0.10 |
| past | 0.50 | 0.15 | 0.40 | 0.25 | 0.25 | 0.05 |
| singular | 0.50 | 0.20 | 0.40 | 0.25 | 0.25 | 0.05 |
- hit@10: under 0.5% for every kind in G1 and G2; 0.5-2% for alike in G3-G5; 3-8% for alike in G6.
- Controls: shuffled 0.50 +- 0.03 every kind; random pulls 0.40-0.50.
- WordNet check (lines the map does not have), G3/G4: synonym 0.15, similar 0.15, antonym 0.15, hypernym 0.25, part 0.30.
- Opposite: in G3-G6 the best function is "same place" or "shift", NOT the flip through origin; the flip through origin scores >= 0.40. In G4 (signed) the flip may win on one axis.
- past, singular: "shift" beats "same place" in every graph whose pulls carry tense or number.
- No 6-pull graph (G1-G5) meets my "makes sense" bar. G6 may.
- The fourteen actions in G3: mean distance between them / mean distance between random words = 0.9 (not clustered).
- The word "origin" does not land at 0,0,0 by itself in any graph.

## Bisects
- B1: every word is assigned to the nearest of the 26 directions (6 axes, 12 two-axis diagonals, 8 three-axis diagonals). Prediction: all 26 hold words in G3; in G1 most words sit exactly on a few points (yes/no pulls stack).
- B2: a 7th+ pull added along a diagonal (best from the G1 pool for each of the 20 diagonals): improves the test score by less than 10% relative.
- B3 "relations to their main axis": a pull that wins a diagonal correlates with the two (or three) axis pulls it bisects no more than with the other axis pulls. Prediction: no special relation.
- B4 the "4-axis bisect" (x,-x,y,z): +x and -x cancel, so it lands on the y,z diagonal. Count the words pulled both ways on one axis: those words lose that axis's information in x,y,z (kept only in six numbers).

## Amendments made BEFORE the final scoring (each with why)
- 19:0x: the map has 6,487 spellings on more than one node ("rubbish" x3). v16 has one gate per word (NOCASE), so nodes are merged by spelling: 27,606 words, lines kept (self-lines dropped). Line counts above shrink accordingly.
- 19:2x: the choose-split search uses a sampled scorer (200 lines per kind, 1,000 candidate words, functions same/scale/linear) because the full scorer took ~1 s per graph. Reported numbers still come from the full scorer on the test split.
- 19:3x: after depth 1 of the search showed stacks (many words on one point), hit@10 counts a word tied in a stack by its average place (closer + half the ties < 10). Without this a stack of 50 would count all 50 as hits.
- 21:3x (after the crash): the ceiling G6 is refitted in plain numpy on the CPU (same loss, same settings) instead of torch, so nothing touches the graphics card. Its numbers differ slightly from the lost run (final training loss 0.755 vs 0.748). The six numbers shown for found graphs are scaled 0 to 1 per axis.
- Before the crash, the lost run had reached: G5 pairings (identical in the rerun), G1 depth 1-3 (best 0.0895 on the sampled scorer), G6 sampled score 0.087. Nothing had been scored on the test split.
