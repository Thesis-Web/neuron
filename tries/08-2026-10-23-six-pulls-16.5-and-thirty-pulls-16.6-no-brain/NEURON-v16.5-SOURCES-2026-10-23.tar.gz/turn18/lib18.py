# turn 18 shared code: load the dataset, build-line graph, functions per kind, rank-share scoring
import sys, os, json, hashlib
sys.path.append(os.path.expanduser('~/.local/lib/python3.10/site-packages'))
import numpy as np
import scipy.sparse as sp

SYM = {'alike', 'opposite', 'synonym', 'similar', 'antonym'}
KINDS = ['alike', 'opposite', 'is', 'has', 'prefix', 'suffix', 'stem', 'past', 'singular']
WNKINDS = ['synonym', 'similar', 'antonym', 'hypernym', 'part']
SIGNS = [np.array(s, float) for s in [(1, 1, 1), (-1, 1, 1), (1, -1, 1), (1, 1, -1), (-1, -1, 1), (-1, 1, -1), (1, -1, -1), (-1, -1, -1)]]


def load(out):
    j = json.load(open(os.path.join(out, 'data18.json')))
    z = dict(np.load(os.path.join(out, 'data18.npz')))
    L = {}
    for a, b, kn, spl in j['lines']:
        L.setdefault((kn, spl), []).append((a, b))
    L = {k: np.array(v, int) for k, v in L.items()}
    # WordNet check lines: drop the ones the map also has (any kind, either way); split 50/50 into fit / score
    have = set()
    for a, b, kn, spl in j['lines']:
        have.add((a, b)); have.add((b, a))
    WN = {}
    for kn, lst in j['wnlines'].items():
        keep = [(a, b) for a, b in lst if (a, b) not in have]
        f = [p for p in keep if hashlib.sha1(f'{kn}|{p[0]}|{p[1]}'.encode()).digest()[0] < 128]
        s = [p for p in keep if hashlib.sha1(f'{kn}|{p[0]}|{p[1]}'.encode()).digest()[0] >= 128]
        WN[(kn, 'fit')] = np.array(f, int).reshape(-1, 2)
        WN[(kn, 'score')] = np.array(s, int).reshape(-1, 2)
    return j, z, L, WN


def both(pairs, kn):
    """symmetric kinds are scored both ways"""
    if kn in SYM and len(pairs):
        return np.vstack([pairs, pairs[:, ::-1]])
    return pairs


def build_graph(n, L, kinds=KINDS, weight=None, split='train'):
    rows, cols, vals = [], [], []
    for kn in kinds:
        p = L.get((kn, split))
        if p is None or not len(p): continue
        w = 1.0 if weight is None else weight.get(kn, 1.0)
        rows += [p[:, 0], p[:, 1]]; cols += [p[:, 1], p[:, 0]]; vals += [np.full(len(p), w)] * 2
    A = sp.coo_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=(n, n)).tocsr()
    A.sum_duplicates()
    return A


# ---- functions per kind: q = f(place of A)
def fit_funcs(PA, PB):
    F = {'same': ('same', None)}
    if len(PA) == 0:
        return F
    F['shift'] = ('shift', (PB - PA).mean(0))
    for s in SIGNS[1:]:
        nm = 'flip ' + ''.join(ax for ax, v in zip('xyz', s) if v < 0)
        F[nm] = ('flip', (s, (PB - s * PA).mean(0)))
    F['through origin'] = ('flip', (SIGNS[7], np.zeros(3)))
    a = np.ones(3); t = np.zeros(3)
    for k in range(3):
        X = np.c_[PA[:, k], np.ones(len(PA))]
        c, *_ = np.linalg.lstsq(X, PB[:, k], rcond=None)
        a[k], t[k] = c
    F['scale'] = ('scale', (a, t))
    X = np.c_[PA, np.ones(len(PA))]
    W, *_ = np.linalg.lstsq(X, PB, rcond=None)
    F['linear'] = ('linear', W)
    return F


def apply_func(f, PA):
    kind, p = f
    if kind == 'same': return PA
    if kind == 'shift': return PA + p
    if kind == 'flip': return p[0] * PA + p[1]
    if kind == 'scale': return p[0] * PA + p[1]
    if kind == 'linear': return np.c_[PA, np.ones(len(PA))] @ p


def rank_share(P, pairs, Q, cand=None, chunk=512):
    """for each line (A,B) with query point q: share of candidate words (not A, not B) closer to q than B; ties half.
    returns (share array, words closer + half the words tied)"""
    n = len(P)
    C = P if cand is None else P[cand]
    m = len(C)
    out = np.empty(len(pairs)); closer_n = np.empty(len(pairs))
    PM = float((P * P).sum(1).max())
    for i in range(0, len(pairs), chunk):
        q = Q[i:i + chunk]
        a = pairs[i:i + chunk, 0]; b = pairs[i:i + chunk, 1]
        qq = (q * q).sum(1)
        dB = np.maximum(qq - 2 * (q * P[b]).sum(1) + (P[b] ** 2).sum(1), 0)
        D = np.maximum(qq[:, None] - 2 * q @ C.T + (C * C).sum(1)[None, :], 0)
        dBc = dB[:, None]
        tol = 1e-7 * (1 + qq + PM)[:, None]
        less = (D < dBc - tol).sum(1).astype(float)
        tie = (np.abs(D - dBc) <= tol).sum(1).astype(float)
        # remove A and B themselves from the counts
        if cand is None:
            dA = np.maximum(qq - 2 * (q * P[a]).sum(1) + (P[a] ** 2).sum(1), 0)
            for arr_d, idx in ((dA, a), (dB, b)):
                l = arr_d < dB - tol[:, 0]; t = np.abs(arr_d - dB) <= tol[:, 0]
                less -= l; tie -= t
            denom = n - 2
        else:
            denom = m
        out[i:i + chunk] = (less + 0.5 * np.maximum(tie, 0)) / denom
        closer_n[i:i + chunk] = less + 0.5 * np.maximum(tie, 0)   # expected place among ties: a stack is not 'all found'
    return out, closer_n


def score_graph(P, L, kinds=KINDS, choose_split='val', report_split='test', funcs=None, cand=None, maxlines=None, seed=0,
                train_split='train'):
    """fit every function on build lines, choose per kind on choose_split, report on report_split"""
    rng = np.random.default_rng(seed)
    res = {}
    for kn in kinds:
        tr = both(L.get((kn, train_split), np.zeros((0, 2), int)), kn)
        if not len(tr):
            continue
        F = fit_funcs(P[tr[:, 0]], P[tr[:, 1]])
        if funcs is not None:
            F = {k: v for k, v in F.items() if k in funcs}
        ch = both(L.get((kn, choose_split), np.zeros((0, 2), int)), kn)
        if maxlines and len(ch) > maxlines:
            ch = ch[rng.choice(len(ch), maxlines, replace=False)]
        best, bestv, per = None, 9, {}
        for nm, f in F.items():
            s, _ = rank_share(P, ch, apply_func(f, P[ch[:, 0]]), cand)
            per[nm] = float(np.median(s))
            if per[nm] < bestv: best, bestv = nm, per[nm]
        r = {'best': best, 'choose': bestv, 'choose_all': per}
        if report_split:
            te = both(L.get((kn, report_split), np.zeros((0, 2), int)), kn)
            out = {}
            for nm in ([best] + [x for x in ('same', 'through origin', 'shift') if x in F and x != best]):
                s, c = rank_share(P, te, apply_func(F[nm], P[te[:, 0]]), cand)
                out[nm] = {'median': float(np.median(s)), 'mean': float(s.mean()), 'hit10': float((c < 10).mean()), 'n': int(len(te))}
            r['test'] = out
            f = F[best]
            r['func'] = [f[0], (None if f[1] is None else (f[1].tolist() if isinstance(f[1], np.ndarray) else [np.asarray(x).tolist() for x in f[1]]))]
        res[kn] = r
    return res


def objective(res, kinds=KINDS):
    return float(np.mean([res[k]['choose'] for k in kinds if k in res]))


def ppr(A, seeds, alpha=0.15, iters=60):
    """reach from a set of seed words through the lines (personalized PageRank, restart alpha)"""
    n = A.shape[0]
    d = np.asarray(A.sum(1)).ravel(); d[d == 0] = 1
    Pt = sp.diags(1 / d) @ A
    PtT = Pt.T.tocsr()
    e = np.zeros(n); e[seeds] = 1 / len(seeds)
    x = e.copy()
    for _ in range(iters):
        x = (1 - alpha) * (PtT @ x) + alpha * e
    return x


class Proxy:
    """sampled scorer for choosing pulls: choose-split lines (<= per kind), a fixed candidate sample, functions same/scale/linear
    fitted by normal equations; float32; ties count half. Used only to CHOOSE; reported numbers come from score_graph."""
    def __init__(self, L, n, per=200, ncand=1000, seed=0, kinds=KINDS):
        rng = np.random.default_rng(seed)
        self.kinds = kinds
        self.C = np.sort(rng.choice(n, ncand, replace=False))
        self.S, self.T = {}, {}
        for kn in kinds:
            v = both(L[(kn, 'val')], kn)
            self.S[kn] = v[rng.choice(len(v), min(per, len(v)), replace=False)]
            self.T[kn] = both(L[(kn, 'train')], kn)

    @staticmethod
    def _share(Q, PB, C, cc):
        qq = (Q * Q).sum(1)
        D = qq[:, None] - 2 * (Q @ C.T) + cc[None, :]
        dB = qq - 2 * (Q * PB).sum(1) + (PB * PB).sum(1)
        tol = (1e-4 * (1 + qq + cc.max()))[:, None]
        lo = (D < dB[:, None] - tol).sum(1)
        le = (D <= dB[:, None] + tol).sum(1)
        return (lo + 0.5 * (le - lo)) / C.shape[0]

    def __call__(self, P, detail=False):
        P = P.astype(np.float32)
        C = P[self.C]; cc = (C * C).sum(1)
        vals = []
        for kn in self.kinds:
            tr = self.T[kn]; A, B = P[tr[:, 0]].astype(np.float64), P[tr[:, 1]].astype(np.float64)
            ch = self.S[kn]; PA, PB = P[ch[:, 0]], P[ch[:, 1]]
            best = float(np.median(self._share(PA, PB, C, cc)))       # same place
            m = len(A); sa, sb = A.sum(0), B.sum(0)
            # scale per axis: b = a*x + t
            sxx = (A * A).sum(0); sxy = (A * B).sum(0)
            den = m * sxx - sa * sa
            a = np.where(np.abs(den) > 1e-12, (m * sxy - sa * sb) / np.where(np.abs(den) > 1e-12, den, 1), 0.0)
            t = (sb - a * sa) / m
            best = min(best, float(np.median(self._share((PA * a + t).astype(np.float32), PB, C, cc))))
            X = np.c_[A, np.ones(m)]
            XtX = X.T @ X + 1e-9 * np.eye(4)
            Wl = np.linalg.solve(XtX, X.T @ B)
            Q = (np.c_[PA, np.ones(len(PA), np.float32)] @ Wl.astype(np.float32))
            best = min(best, float(np.median(self._share(Q, PB, C, cc))))
            vals.append(best)
        return (float(np.mean(vals)), vals) if detail else float(np.mean(vals))
