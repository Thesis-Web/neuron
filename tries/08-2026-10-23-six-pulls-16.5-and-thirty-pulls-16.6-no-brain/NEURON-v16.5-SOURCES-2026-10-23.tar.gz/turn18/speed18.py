# how many workers help: time 240 sampled-scorer evaluations at several worker counts
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib18 import *
import multiprocessing as mp
out = sys.argv[1]
j, z, L, WN = load(out); n = len(j['words'])
POOL = np.load(os.path.join(out, 'forces18.npz'))['named']
PR = Proxy(L, n)
def ev(ab):
    a, b = ab
    P = np.zeros((n, 3)); P[:, 0] = POOL[a] - POOL[b]
    return PR(P)
jobs = [(a, a + 1 + k) for a in range(40) for k in range(6)]
t = time.time(); [ev(x) for x in jobs[:24]]; print('1 proc', round((time.time() - t) / 24, 4), 's per eval', flush=True)
for p in (4, 6, 8, 12):
    t = time.time()
    with mp.Pool(p) as pp: pp.map(ev, jobs, chunksize=8)
    dt = time.time() - t; print(p, 'procs', round(len(jobs) / dt, 1), 'evals/s', flush=True)
