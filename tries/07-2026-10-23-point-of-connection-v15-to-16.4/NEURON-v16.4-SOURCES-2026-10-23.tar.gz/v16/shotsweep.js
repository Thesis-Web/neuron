const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  for (const [a, p] of [[0.02, 1], [0.06, 2], [0.12, 3], [0.2, 4]]) {
    const page = await browser.newPage({ viewport: { width: 1600, height: 950 } });
    await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.includes('cdnjs.cloudflare.com') ? r.continue() : r.abort(); });
    await page.goto('file://' + process.argv[2]); await page.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 120000 });
    await page.evaluate(([a, p]) => { window.__poc.setParam('ACROSS', a); window.__poc.setParam('PASSES', p); }, [a, p]);
    await page.waitForTimeout(25000);
    const r = await page.evaluate(() => { const p = window.__poc.positions(), ks = Object.keys(p).filter(k => k !== 'origin'), c = [0, 0, 0]; ks.forEach(k => { for (let i = 0; i < 3; i++) c[i] += p[k][i] / ks.length; }); const rr = ks.map(k => Math.hypot(...p[k])).sort((x, y) => x - y);
      return { across: window.__poc.acrossShare('opposite'), closest: +window.__poc.closest().toFixed(1), centroidOverMedian: +(Math.hypot(...c) / rr[Math.floor(rr.length / 2)]).toFixed(2), stretch: +window.__poc.stretch().toFixed(2), fps: 0 }; });
    r.fps = +(await page.evaluate(() => window.__poc.fps(2000))).toFixed(1);
    console.log(JSON.stringify({ ACROSS: a, PASSES: p, ...r })); await page.close();
  }
  await browser.close();
})().catch(e => { console.log('FATAL', e.message); process.exit(1); });
