// SHARED by the worker and the page's main thread: put a brain back after sql.js export() (which closes and reopens the database),
// restore one from a snapshot, and take a snapshot. Nothing here decides anything for the brain.
function reopenBrain(b, sat) {
  var self = b, db = b.db;
  db.create_function('mother', function (text, run, stmt) { return self.mother(text, run, stmt); });
  db.create_function('satwork', function (s, ask, word, n) { self.populated.push([s, ask, word, n]); return 1; });
  db.run('PRAGMA recursive_triggers = ON');
  b.SATS.forEach(function (s) {
    db.run("ATTACH ':memory:' AS " + s);
    db.run("CREATE TABLE " + s + ".corpus (word TEXT COLLATE NOCASE, hw TEXT, text TEXT, words TEXT); CREATE INDEX " + s + ".cw ON corpus(word);" +
      "CREATE TABLE " + s + ".inbox (ask INTEGER PRIMARY KEY, word TEXT); CREATE TABLE " + s + ".outbox (ask INTEGER, word TEXT, hw TEXT, text TEXT, words TEXT);" +
      "CREATE TRIGGER " + s + ".work AFTER INSERT ON inbox BEGIN INSERT INTO outbox SELECT NEW.ask, NEW.word, hw, text, words FROM corpus WHERE word = NEW.word;" +
      " SELECT satwork('" + s + "', NEW.ask, NEW.word, (SELECT count(*) FROM outbox WHERE ask = NEW.ask)); DELETE FROM inbox WHERE ask = NEW.ask; END;");
    var st = db.prepare("INSERT INTO " + s + ".corpus VALUES (?, ?, ?, ?)"); ((sat || {})[s] || []).forEach(function (r) { st.run([r[0], r[1], r[2], r.length > 3 ? r[3] : null]); }); st.free();
  });
}
function exportBrain(b, sat) { var c = b.cache || {}; Object.keys(c).forEach(function (k) { c[k].forEach(function (st) { try { st.free(); } catch (e) {} }); }); b.cache = {}; var bytes = b.db.export(); reopenBrain(b, sat); return bytes; }
function restoreBrain(SQL, told, sat, bytes) { var b = Object.create(Neuron.Brain.prototype); b.told = told; b.SATS = told.sats; b.populated = []; b.db = new SQL.Database(bytes); reopenBrain(b, sat); return b; }
