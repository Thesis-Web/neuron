const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const page = await browser.newPage({ viewport: { width: 1600, height: 950 } });
  await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.includes('cdnjs.cloudflare.com') ? r.continue() : r.abort(); });
  await page.goto('file://' + process.argv[2]); await page.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 90000 });
  if (process.argv[3] === 'define') { await page.fill('#line', 'define store'); await page.press('#line', 'Enter'); await page.waitForTimeout(200); await page.waitForFunction(() => !window.__poc.busy(), null, { timeout: 600000 });
    await page.evaluate(() => { const s = document.getElementById('time'); s.value = s.max; s.dispatchEvent(new Event('input')); }); }
  await page.waitForTimeout(6000);
  const r = await page.evaluate(() => {
    const p = window.__poc.positions(), roles = window.__poc.roles(), out = { atOrigin: {}, byRole: {}, stacks: 0, samples: {} };
    const ks = Object.keys(p);
    ks.forEach(k => { if (Math.hypot(...p[k]) < 2 && k !== 'origin') { const role = roles[k] || '?'; const n = Object.keys(window.__poc.linesOf(k)).length; out.byRole[role] = (out.byRole[role] || 0) + 1; (out.samples[role] = out.samples[role] || []).length < 14 && out.samples[role].push(k + (n ? '(' + n + ' kinds of line)' : '')); } });
    // points sharing a spot (within 0.5) anywhere
    const cell = {}; ks.forEach(k => { const key = p[k].map(v => Math.round(v * 2)).join(','); (cell[key] = cell[key] || []).push(k); });
    out.stacks = Object.values(cell).filter(a => a.length > 1).map(a => a.length).sort((a, b) => b - a).slice(0, 8);
    out.biggestStack = Object.values(cell).sort((a, b) => b.length - a.length)[0].slice(0, 12);
    return out;
  });
  console.log(JSON.stringify(r, null, 1)); await browser.close();
})();
