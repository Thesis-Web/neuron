const fs = require('fs'), D = process.argv[2], R = process.argv[3];
global.initSqlJs = require(R + '/sqljs/sql-asm-memory-growth.js'); global.Neuron = require(D + '/host15.js').Neuron; eval(fs.readFileSync(D + '/shared15.js', 'utf8').replace(/^function (\w+)/mg, 'global.$1 = function $1'));
const msgs = []; global.postMessage = m => msgs.push(m);
eval(fs.readFileSync(D + '/worker15.js', 'utf8').replace('var SQLMOD = null;', 'global.SQLMOD = null;').replace(/^onmessage = /m, 'global.onmessage = '));
const html = fs.readFileSync(D + '/point-of-connection-15.html', 'utf8');
const presets = JSON.parse(html.match(/var E6PRESETS = (\[.*?\]);\nvar E6MEASURED/s)[1]);
(async () => {
  onmessage({ data: { type: 'init', told: JSON.parse(fs.readFileSync(D + '/physics15.json')), sat: JSON.parse(fs.readFileSync(D + '/sat15.json')) } });
  while (!msgs.some(m => m.type === 'ready' || m.type === 'error')) await new Promise(r => setTimeout(r, 200));
  const seq = [['define store']].concat(presets.map(p => p[1]));
  for (const lines of seq) {
    const n0 = msgs.length; onmessage({ data: { type: 'lines', lines } });
    msgs.slice(n0).filter(m => m.type === 'line' || m.type === 'done' || m.type === 'error').forEach(m => console.log(m.type === 'error' ? 'ERROR ' + m.error : JSON.stringify(m.line.slice(0, 50)) + ' -> ' + JSON.stringify(String(m.output).slice(0, 120))));
  }
  const q = (sql) => { onmessage({ data: { type: 'query', id: 9, sql } }); return msgs[msgs.length - 1].rows; };
  console.log(q("SELECT id, line, recalled, memid FROM run WHERE kind = 'line' ORDER BY id DESC LIMIT 6"));
})();
