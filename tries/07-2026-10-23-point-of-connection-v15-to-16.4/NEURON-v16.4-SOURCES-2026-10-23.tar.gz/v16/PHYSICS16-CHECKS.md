# v16 physics: checks written before the change (2026-10-23)
Grounding: turn16/OWNER-VERBATIM.txt (G2 core words, G3 no canned text, G10 waiting).

## New checks, each with a control that must fail
Q1 one gate per word (G2 "those core hand laid words can now just be words"): "AS", "As" and "as" are one gate; the told SAY action and the say table are one gate.
   Control: with case-sensitive words, three gates.
Q2 no canned text (G3 "the row holds pointers to the run through the neurons... neurons don't hold canned text"): the formula table has no column holding the formula's words; a formula row holds the run whose receipt rows are its path.
   E6's sentences give the same answers as in v15.
   Control: delete the receipt rows of the teaching run; the word then fires and sends no statement.
Q3 teaching runs through the neurons: after "w = ...", the body's DNA rows exist in its words' tables; firing w hits those rows (times up) and lays no new row in them.
   Control: v15 teaching lays no rows for the body.
Q4 a refused ask is not "waiting" (G10): a statement into a source's inbox that SQLite refuses gives a secondary-input row with the error, from that source, and no waiting event; a depth error is not swallowed by mother.
   Control: v15's mother writes "waiting" for it.
Q5 core words are words (G2): a typed line with a hand-laid word that was never looked up asks the sources for it once.
   Control: v15 with the word merged but roles unchanged asks nothing.
Q6 origin exists from the start, the one placed word (G1).

## Earlier checks that change on purpose, said before running
T12 read the body column of the formula table; there is none now. It becomes: old row ended, new row live, and the new row points at a different run.
T13 and T20 used a derive line that copied the body column. derive now copies the pointer: INSERT INTO formula ( word , run , origin ) SELECT :subject , run , 'derived' ...
Every other check must pass unchanged. A failure there is a regression to fix in the build, not in the check.

## Correction log, run 1 (2026-10-23)
- Root cause of 8 failures: DECODE used a gate number for ';' computed from the told list's order (v15 code). Merging SAY into say shifted it by one, so every statement decoded from the previous ';'. Fixed in the build: the gate of ';' is taken as it is laid. Not a check change.
- T13 failed: a regression I made. The teaching run no longer carried the taught word, so a taught word (derive) had no gate and nothing could fire it. Fixed in the build: teaching gives the word its gate. Not a check change.
- P5 (NOT predicted before running): it read memory row id 1 as the "cat sat" memory. v16 teaching runs leave a memory of their receipt, so row 1 is the told source formula's. The hop itself held (memhit, no landing, a timeline row). The check now reads the "cat sat" row by its line. Same property, the right row.
- Q4 control was wrong in the test: it ran v15's told block on the patched v16 host, so it could not show v15's waiting. v15 controls now run v15's own host and told block.
