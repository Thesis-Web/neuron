const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const page = await browser.newPage({ viewport: { width: 400, height: 860 } }); const errs = [];
  page.on('pageerror', e => errs.push(e.message));
  await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.includes('cdnjs.cloudflare.com') ? r.continue() : r.abort(); });
  await page.goto('file://' + process.argv[2]);
  await page.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 90000 });
  await page.fill('#line', 'cat sat'); await page.press('#line', 'Enter'); await page.waitForTimeout(300);
  await page.waitForFunction(() => !window.__poc.busy(), null, { timeout: 300000 });
  const r = await page.evaluate(() => ({ hud: document.getElementById('hud').textContent.length, busy: document.getElementById('busy').textContent, scrollW: document.documentElement.scrollWidth }));
  await page.screenshot({ path: process.argv[3] });
  console.log(JSON.stringify({ errs, ...r })); await browser.close();
})().catch(e => { console.log('FATAL', e.message); process.exit(1); });
