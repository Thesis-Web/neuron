const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const page = await browser.newPage({ viewport: { width: 1600, height: 950 } }); const errs = []; page.on('pageerror', e => errs.push(e.message));
  await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.includes('cdnjs.cloudflare.com') ? r.continue() : r.abort(); });
  await page.goto('file://' + process.argv[2]); await page.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 90000 });
  await page.fill('#line', 'define store'); await page.press('#line', 'Enter'); await page.waitForTimeout(300); await page.waitForFunction(() => !window.__poc.busy(), null, { timeout: 600000 });
  await page.evaluate(() => { const s = document.getElementById('time'); s.value = s.max; s.dispatchEvent(new Event('input')); }); await page.waitForTimeout(6000);
  await page.evaluate(() => { const c = document.getElementById('ghostlabels'); c.checked = true; c.dispatchEvent(new Event('change')); }); await page.waitForTimeout(1500);
  await page.screenshot({ path: process.argv[3] }); console.log(JSON.stringify({ errs })); await browser.close();
})();
