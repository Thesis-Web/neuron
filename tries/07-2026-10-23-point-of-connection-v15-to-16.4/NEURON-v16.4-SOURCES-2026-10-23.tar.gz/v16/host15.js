// HOST-START
// The host for physics15 in the browser: the bottom (writes a typed line into input, reads output) and mother (routes text and replies).
// Nothing else. Every decision is a trigger in the told block (physics15.json), run by real SQLite (sql.js).
var Neuron = (function () {
  var SQL = null;
  function init(sqlModule) { SQL = sqlModule; }
  function Brain(told, sat) {
    var self = this;
    this.told = told; this.SATS = told.sats; this.populated = [];
    var db = this.db = new SQL.Database();
    db.create_function('mother', function (text, run, stmt) { return self.mother(text, run, stmt); });
    db.create_function('satwork', function (sat, ask, word, n) { self.populated.push([sat, ask, word, n]); return 1; });
    // SATELLITE-START: stand-ins for the source brains. Each is its own database: a corpus, an inbox, an outbox, and its own trigger
    // that does its work the moment an ask lands and says when its outbox is populated.
    this.SATS.forEach(function (s) {
      db.run("ATTACH ':memory:' AS " + s);
      db.run("CREATE TABLE " + s + ".corpus (word TEXT COLLATE NOCASE, hw TEXT, text TEXT, words TEXT); CREATE INDEX " + s + ".cw ON corpus(word);" +
        "CREATE TABLE " + s + ".inbox (ask INTEGER PRIMARY KEY, word TEXT); CREATE TABLE " + s + ".outbox (ask INTEGER, word TEXT, hw TEXT, text TEXT, words TEXT);" +
        "CREATE TRIGGER " + s + ".work AFTER INSERT ON inbox BEGIN INSERT INTO outbox SELECT NEW.ask, NEW.word, hw, text, words FROM corpus WHERE word = NEW.word;" +
        " SELECT satwork('" + s + "', NEW.ask, NEW.word, (SELECT count(*) FROM outbox WHERE ask = NEW.ask)); DELETE FROM inbox WHERE ask = NEW.ask; END;");
      var st = db.prepare("INSERT INTO " + s + ".corpus VALUES (?, ?, ?, ?)");
      ((sat || {})[s] || []).forEach(function (r) { st.run([r[0], r[1], r[2], r.length > 3 ? r[3] : null]); });
      st.free();
    });
    // SATELLITE-END
    // the told block: laid once, as one block
    told.statements.forEach(function (st) { db.run(st); });
  }
  function ev(db, kind, gate, run, rowgate, text, roots) {
    db.run("INSERT INTO event (kind, gate, run, rowgate, text, roots) VALUES (?, ?, ?, ?, ?, ?)", [kind, gate, run, rowgate, text, roots || '']);
  }
  // MOTHER-START: she runs the text she is handed at the SQL prompt. If it is addressed to a source brain's inbox she carries it there,
  // and when that brain says its outbox is populated she picks it up and empties it. What came back she writes into secondary input.
  // She decides nothing and computes nothing about the reply.
  Brain.prototype.mother = function (text, run, stmt) {
    var db = this.db, self = this, addressed = [];
    (text.match(/\b(\w+)\.inbox\b/g) || []).forEach(function (a) { var s = a.replace(/\.inbox$/, ''); if (self.SATS.indexOf(s) >= 0 && addressed.indexOf(s) < 0) addressed.push(s); });
    if (run !== null) ev(db, 'mother', 'mother', run, 'mother', 'mother carries it ' + (addressed.length ? 'into the inbox of ' + addressed.join(', ') : 'to the SQL prompt'), 'CALL MOVE');
    this.populated = [];
    var cols = [], rows = [], err = null, changes = 0, lastid = null;
    // the SQL prompt keeps a compiled statement per text, as SQLite's own prompt cache does; one in use by an outer landing is never shared
    var pool = this.cache || (this.cache = {}), free = pool[text] || (pool[text] = []), st = null;
    try {
      st = free.length ? free.pop() : db.prepare(text);
      cols = st.getColumnNames();
      while (st.step()) rows.push(st.get());
      st.reset(); if (free.length < 4) free.push(st); else st.free(); st = null;
      if (!cols.length) { changes = db.getRowsModified(); var li = db.exec('SELECT last_insert_rowid()'); lastid = li.length ? li[0].values[0][0] : null; }
    } catch (e) {
      err = String(e.message || e); if (st) { try { st.free(); } catch (e2) {} }
      // a run nested deeper than this thread's stack is not a refusal: it goes up, so the line fails whole and can run where there is more stack
      if (e instanceof RangeError || !e.message || /call stack|recursion/i.test(err)) throw e;
    }
    var picked = this.populated; this.populated = [];
    if (run === null) {
      // a by-value step of the physics itself (a birth, a lay, a landing): the SQL prompt's own answer goes straight back
      if (err) throw new Error(err);
      return rows.length && rows[0].length ? rows[0][0] : lastid;
    }
    if (!addressed.length) {
      ev(db, 'sql', 'SQL prompt', run, 'SQL prompt', 'the SQL prompt ' + (err ? 'refuses it: ' + err : 'runs it'), '');
      ev(db, 'mother', 'mother', run, 'mother', 'mother carries the reply back', 'CALL MOVE');
      var val = rows.length ? rows.map(function (r) { return r.map(function (v) { return v === null ? '' : String(v); }).join(' '); }).join(' | ') : null;
      db.run("INSERT INTO secondary (run, stmt, src, value, cols, n, err, changes, last) VALUES (?, ?, 'sql', ?, ?, ?, ?, ?, 1)", [run, stmt, val, cols.join(','), rows.length, err, changes]);
      return rows.length && rows[0].length ? rows[0][0] : null;
    }
    addressed.forEach(function (sat) {
      var got = picked.filter(function (p) { return p[0] === sat; });
      // the SQL prompt refused the ask: it never reached the inbox; that is a refusal, not waiting
      if (err) { db.run("INSERT INTO secondary (run, stmt, src, err, n, last) VALUES (?, ?, ?, ?, 0, 1)", [run, stmt, sat, err]); return; }
      if (!got.length) { db.run("INSERT INTO secondary (run, stmt, src, waiting, last) VALUES (?, ?, ?, 1, 1)", [run, stmt, sat]); return; }
      got.forEach(function (p) {
        var s = p[0], ask = p[1], word = p[2], n = p[3];
        ev(db, 'mailbox', s, run, s, s + ': the ask for "' + word + '" lands in its inbox; its own trigger does its work at once', 'FIND READ WRITE');
        ev(db, 'populated', s, run, null, s + ': its outbox is populated with ' + n + ' row(s), and it says so', 'WRITE');
        var out = [], q = db.prepare("SELECT word, hw, text, words FROM " + s + ".outbox WHERE ask = ?"); q.bind([ask]); while (q.step()) out.push(q.get()); q.free();
        db.run("DELETE FROM " + s + ".outbox WHERE ask = ?", [ask]);
        ev(db, 'pickup', 'mother', run, 'mother', 'mother picks up ' + out.length + ' row(s) from ' + s + ' and empties that outbox', 'MOVE CALL');
        out.forEach(function (r) { db.run("INSERT INTO secondary (run, stmt, src, word, hw, value, words, last) VALUES (?, ?, ?, ?, ?, ?, ?, 0)", [run, stmt, s, r[0], r[1], r[2], r[3]]); });
        db.run("INSERT INTO secondary (run, stmt, src, word, n, last) VALUES (?, ?, ?, ?, ?, 1)", [run, stmt, s, word, out.length]);
      });
    });
    return null;
  };
  // MOTHER-END
  // THE BOTTOM: write a typed line into input; read what came out
  Brain.prototype.type = function (line, direction) {
    var before = this.q("SELECT coalesce(max(id), 0) FROM output")[0][0];
    this.db.run("INSERT INTO input (line, direction) VALUES (?, ?)", [line, direction || 'heard']);
    var r = this.q("SELECT text FROM output WHERE id > ? ORDER BY id DESC LIMIT 1", [before]);
    return r.length ? r[0][0] : null;
  };
  Brain.prototype.q = function (sql, params) {
    var st = this.db.prepare(sql), out = []; if (params) st.bind(params); while (st.step()) out.push(st.get()); st.free(); return out;
  };
  Brain.prototype.close = function () { var c = this.cache || {}; Object.keys(c).forEach(function (k) { c[k].forEach(function (st) { try { st.free(); } catch (e) {} }); }); this.cache = {}; if (this.db) { this.db.close(); this.db = null; } };
  return { init: init, Brain: Brain };
})();
// HOST-END
if (typeof module !== 'undefined') module.exports = { Neuron: Neuron };
