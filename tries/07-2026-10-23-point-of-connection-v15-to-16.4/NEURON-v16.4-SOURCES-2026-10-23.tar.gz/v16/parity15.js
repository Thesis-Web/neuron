// The same lines through the Python host and the browser host must leave the same rows: parity check.
const fs = require('fs'); const initSqlJs = require('../sqljs/sql-asm-memory-growth.js'); const { Neuron } = require('./host15.js');
const told = JSON.parse(fs.readFileSync('physics15.json', 'utf8')), sat = JSON.parse(fs.readFileSync('sat15.json', 'utf8'));
const SAYF = 'INSERT INTO say ( run , text ) VALUES ( :run , :found ) ;';
const lines = ['define store', 'like = INSERT INTO relation ( a , rel , b ) VALUES ( :subject , :head , :after ) ;', 'define shop',
  'who = SELECT value FROM state WHERE key = :after ; ' + SAYF, 'what = SELECT answer FROM memory WHERE line = :after ; ' + SAYF, 'who are -> what', 'sky => blue', 'who sky',
  "BUILD SELECT CAST ( '7' AS INTEGER ) ; BUILD", 'cat sat', 'cat sat'];
initSqlJs().then(SQL => {
  Neuron.init(SQL); const b = new Neuron.Brain(told, sat); const outs = lines.map(l => b.type(l));
  const sig = { outs, events: b.q('SELECT count(*) FROM event')[0][0], kinds: b.q('SELECT kind, count(*) FROM event GROUP BY kind ORDER BY kind'),
    rels: b.q('SELECT count(*) FROM relation')[0][0], mem: b.q('SELECT id, line, output, answer, times FROM memory ORDER BY id'), gates: b.q('SELECT count(*) FROM encoder')[0][0],
    hops: b.q("SELECT count(*) FROM sqlite_master WHERE type='trigger' AND name LIKE 'hop_%'")[0][0] };
  fs.writeFileSync('parity.js.json', JSON.stringify(sig)); console.log('js done', JSON.stringify(outs));
}).catch(e => { console.log('JS ERROR', e.stack); process.exit(1); });
