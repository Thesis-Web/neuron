const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const page = await browser.newPage({ viewport: { width: 1600, height: 950 } }); const errs = []; page.on('pageerror', e => errs.push(e.message));
  await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.includes('cdnjs.cloudflare.com') ? r.continue() : r.abort(); });
  await page.goto('file://' + process.argv[2]); await page.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 90000 });
  const R = {};
  let t = Date.now(); await page.fill('#line', 'define store'); await page.press('#line', 'Enter'); await page.waitForTimeout(200); await page.waitForFunction(() => !window.__poc.busy(), null, { timeout: 600000 });
  R.lineWallMs = Date.now() - t; R.busy = await page.evaluate(() => document.getElementById('busy').textContent);
  await page.evaluate(() => { const s = document.getElementById('time'); s.value = s.max; s.dispatchEvent(new Event('input')); }); await page.waitForTimeout(4000);
  R.render = await page.evaluate(() => window.__poc.timeRender()); R.fps = await page.evaluate(() => window.__poc.fps(3000));
  const close = (p) => { const ks = Object.keys(p).slice(0, 400); let c = 0; for (let i = 0; i < ks.length; i++) for (let j = i + 1; j < ks.length; j++) if (Math.hypot(p[ks[i]][0] - p[ks[j]][0], p[ks[i]][1] - p[ks[j]][1], p[ks[i]][2] - p[ks[j]][2]) < 1.5) c++; return c; };
  await page.evaluate(() => { const r = document.getElementById('spacing'); r.value = 1; r.dispatchEvent(new Event('input', { bubbles: true })); }); await page.waitForTimeout(1500);
  R.opensAt = 3; const d1 = await page.evaluate(() => window.__poc.drawn()), c1 = close(d1);
  await page.evaluate(() => { const r = document.getElementById('spacing'); r.value = 6; r.dispatchEvent(new Event('input', { bubbles: true })); }); await page.waitForTimeout(3000);
  const both = await page.evaluate(() => [window.__poc.positions(), window.__poc.drawn()]), b6 = both[0], d6 = both[1];   // the same instant: no settle step between the two reads
  let worst = 0; for (const k in d6) if (b6[k]) for (let i = 0; i < 3; i++) worst = Math.max(worst, Math.abs(d6[k][i] - 6 * b6[k][i]));
  R.W1 = { worstDifferenceFrom6x: +worst.toFixed(4) };
  R.W2 = { originOnScreen: await page.evaluate(() => window.__poc.screenOf('origin')), stage: await page.evaluate(() => { const r = document.getElementById('c').getBoundingClientRect(); return [r.left + r.width / 2, r.top + r.height / 2]; }) };
  R.W3 = { closePairsAt1: c1, closePairsAt6: close(d6) }; R.W4 = { axesObjects: await page.evaluate(() => window.__poc.axes()), errs };
  R.fpsAt6 = await page.evaluate(() => window.__poc.fps(3000));
  await page.screenshot({ path: process.argv[3] + '-spacing6.png' });
  await page.evaluate(() => { const c = document.getElementById('ghostlabels'); c.checked = true; c.dispatchEvent(new Event('change')); }); await page.waitForTimeout(1500);
  await page.screenshot({ path: process.argv[3] + '-spacing6-names.png' });
  console.log(JSON.stringify(R, null, 1)); await browser.close();
})().catch(e => { console.log('FATAL', e.message); process.exit(1); });
