# v16 page in headless Chromium: what each step must show (written before running)
V1 load: no page error; the brain ready; origin is the only fixed point and sits at 0,0,0.
V2 nothing pushes: a hand-laid word no line touches (SPAWN) stays within 2 units of origin after 3 s of settling.
V3 "define store": runs; store ends within 60 units of origin and is tied by at least one line (it has definition, sequence and memory lines).
V4 turning the sequence kind off moves the points (mean move > 1 unit within 2 s); turning it back on moves them again. Neither rail scrolls.
V5 E6 1, then E6 2: the last line says forty.
V6 E6 3, then E8: "how did you do that ?" says statements that include key = 'user.age'.
V7 E10: "define store" says a text that a source gave for store (it contains "store" or a word of a store definition, and is not the gap line "define? store?").
V8 E11: "what was before dog ran ?" says cat sat; the last line, "what was after dog ran ?", says bird flew.
V9 the card for age shows its formula read back from its run (contains "SELECT value FROM state").
V10 light, dark, phone 400 px: no horizontal page scroll.

## Run 1 results and the two open items (logged before rerunning)
V1, V2, V3, V5, V7, V8, V9, V10 held; no page errors.
V4 FAILED: 0.76 off, 0.92 on. The mean is over every point, and under springs only (no push, the owner's design) a point with no sequence line cannot move when
the sequence kind is turned off. v15 passed this because its push coupled every point to every other. Not loosened: run 2 reports the same mean again, and,
as a second number, the mean over the points that have a sequence line. Both are reported, whatever they are.
V6 not judged: the test kept 400 characters of the answer. Run 2 keeps it whole and looks for key = 'user.age'.

## Owner, after v16: "everything is pulled to the -x or the -z axis? 0,0 is on the edge... can we change the step value of the actual graph grid so the neurons space out more... not move the points or pull them"
Measured first: the points' center stays within 0.5 units of origin for 3 minutes; spread about 11 units per axis; 92 points within 2 units of origin.
Found in my drawing code: each source's label was shifted toward -x in world space, a heavy band of large text on one side whatever the view.
Change, drawing only: a spacing control multiplies every drawn position outward from origin; axes through origin with a tick every 10 units; source labels above their points.
Expected, written before running:
W1 spacing 6: every drawn point is exactly 6 times its brain position (within rounding); the brain positions themselves are not changed by the control.
W2 origin is drawn at the stage's center (within 5 px) when the camera looks at it.
W3 at spacing 6 fewer pairs of drawn points are within 1.5 units of each other than at spacing 1.
W4 no page error; axes drawn (3 axis lines and ticks).
Correction to W1's measurement (not to the page): the test read the brain's positions and the drawn positions in two calls, and a settle step ran between them
(worst 0.43). W1 now reads both in one call. Owner mid-turn: "increase it by like 200%": the page opens at spacing 3, the slider goes to 40.
Owner mid-turn: "x y and z axis as an overlay with the scale on them... almost transparent". And my finding: scaling labels, dots and camera together made spacing change nothing on screen.
Expected, written before running:
W5 spacing 3 to 6 with the camera left where it is: the on-screen distance between two tied points doubles (ratio 1.8 to 2.2), and a label's height on screen does not change (within 1 px).
W6 the axes are drawn over the points (no depth test), at opacity 0.3 or less, with scale numbers on both sides of origin.
Results: W5 label height 12 px at both spacings (held); on-screen distance 387 px at 3 and 665 px at 6, ratio 1.72: below my range. My expectation ignored perspective:
with the camera fixed, points pushed outward also change depth, so screen distance grows by less than the factor. Logged as my wrong expectation. W6 held: 3 axis lines,
opacity 0.28, drawn over the points, 36 scale labels from -L to +L. Published as 16.1, a new artifact; 16 is unchanged.

## Owner after 16.1: "there must be 100 nodes stacked at 0,0,0... you need to figure out why so many neurons are all stacked on top of each other... another 600% more"
Measured: 74 points within 2 units of origin. 25 SQL words never used, 26 map words with no line in the slice, 13 actions, 5 physics words never used,
heard, said, the SQL prompt, the SQLite docs source, one memory. They have no relationship yet, so they wait at origin. Spots shared by up to 5 points elsewhere.
My error: the owner wrote "there is not push or pull to shells"; I took it as no push of any kind and removed the spacing between points with the shell.
Change (16.2): a minimum space between points (a slider in the brain's units, default 5): two points closer than that are moved apart, half each; origin never moves.
Relationships still decide where everything goes. Drawing spacing opens at 21 (owner: 200% then 600% more). The camera's far limit raised so nothing is cut off.
Expected, written before running:
X1 after 10 s at space 5, no two visible points are closer than 4.5 brain units.
X2 the springs still hold: the mean stretch |length - rest| / rest over all springs is at most 1.5 times what it is with space 0.
X3 origin stays at 0,0,0, and the points with no line stay within 30 units of origin.
X4 the drawing opens at 21: drawn = 21 x brain position, read in one instant.
X5 no page error.
Results (16.2): X1 held, closest pair 4.9 at space 5 (0.48 at space 0). X2 held, mean spring stretch 0.070 against 0.048, 1.46 times. X3 origin held at 0,0,0;
the 71 points with no line reach 31.4 units, just past my bound of 30: FAILED as written. 71 points kept 5 apart beside the linked points cannot all fit inside 30; my bound was too tight.
X4 held, drawn = 21 x brain exactly. X5 held, no page error. Published as 16.2, a new artifact; 16 and 16.1 unchanged.

## 16.3, owner: "you never fixed the call, compare, join, spawn, clock, heard, hear, add, count, agree, write, subtract, find, update, said, split, *",
## "opposite, inverse, contradicts all should be on opposite... sides", "at least 200% more spacing", "relationship lines... like 20% opacity... run lines less [transparent]"
Expected, written before running:
Y1 load, no page error. SUBTRACT has an opposite line (to add); heard has a past line (to hear); CALL, MOVE and WRITE have does lines (mother, input).
Y2 with opposite across origin, at least 80% of the opposite lines between visible points have their two ends on opposite sides of origin (cosine under -0.5) after 15 s.
Y3 at space 15, no two visible points closer than 13.5.
Y4 origin no longer pushes: the center of all points sits within a tenth of the median distance from origin.
Y5 set "is" to north: the mean of (B - A) along +y over is-lines, divided by its rest length, is above 0.5 after 10 s.
Y6 relationship lines drawn at 0.22 (map lines 0.12); this run's lines at 0.85 to 1.
Y7 phone width 400: no horizontal scroll. Y8 the words still without any line at load are listed, whatever they are.
Run 1 of 16.3: Y1, Y5 (0.78), Y6, Y7 held. Y2 FAILED (19% across), Y3 FAILED (closest 4.2), Y4 just failed (0.13). My across rule was weaker than the plain
spring it replaced, and one spacing pass per step could not hold 1,192 points apart. Measured, 25 s each (across share, closest pair, center/median):
 across .02, 1 pass: 29%, 7.5, 0.12 | .06, 2 passes: 85%, 6.3, 0.18 | .12, 3 passes: 94%, 7.5, 0.19 | .20, 4 passes: 99%, 8.3, 0.19
Chosen: .12 and 3 passes. Not reached at any setting: closest 13.5 at space 15. A word with dozens of lines (MOVE has 69 "is" lines) holds its neighbours at
one rest distance, and that many points cannot sit 15 apart on that sphere. Y3 stays failed as written.
Drift found in 16.3: capping each point's step separately broke the balance of paired pulls; the center drifted from 18 to 22 units in 90 s.
Fix: one step scale from the 95th-largest pull, with a cap only for the few above it. Across pull raised to 0.25 after that.
Final 16.3 (15 s): Y2 58% across (89% at 60 s, 94% at 90 s: still settling at 15 s, FAILED as written); Y3 closest 7.8 (FAILED: hubs cannot hold
their neighbours 15 apart); Y4 held, center 2.8 from origin against a median distance of 73.7; Y5 held 0.60; Y6 held; Y7 held; no page error.
Still without any line at load: var, WHERE, AS, INTEGER, instr, group_concat, DESC, =, ",", *, >, <, ||, the SQL prompt and the seven sources (nothing asked yet).
Owner (16.2 screenshot): 18 of the 27 kinds have no data anywhere; state is only written by taught formulas; the hand-out's "state holds now and the last line" is not built.

## 16.4: the atlas (owner: "I need a table of all words, their triggers, their dna rows, triggers, and memories. we used to call this the atlas...
## list the tables in alphabetical order by label and include the physical position of the point on the map overlay, like 0,0,0 for origin")
Expected, written before building:
A1 the atlas lists every visible point once, sorted by label, case ignored; the count equals the visible points on the stage.
A2 origin's row says 0, 0, 0; every row's position equals that point's place in the brain's units at the moment the atlas was read.
A3 for a word in the brain, its DNA rows in the atlas equal the rows of its table read straight from SQLite (shard, arrival, remainder, trigger, times), and each row says whether its hop trigger exists.
A4 every row says what gives the point meaning: a formula (its path read back), a measured test result, a told job, or "no meaning yet"; the count of "no meaning yet" is shown at the top.
A5 each word in the brain lists its memories (the memory rows whose path holds its gate) and its own triggers (the gate's miss trigger; for a physics table, that table's triggers).
A6 no page error; at phone width the page does not scroll sideways (the table scrolls inside its own box).
