import sys, time; sys.path.insert(0, '.')
from host15 import Brain
b = Brain('physics15.json', sat_path='sat15.json')
TRIG = "SELECT count(*) FROM sqlite_master WHERE type='trigger'"
for l in ['define store', 'like = INSERT INTO relation ( a , rel , b ) VALUES ( :subject , :head , :after ) ;', 'define shop', 'who you', 'cat sat']:
    t = time.time(); b.type(l); n = b.q(TRIG)[0][0]
    print(f'{l[:30]:32} {time.time()-t:6.2f}s  triggers {n}')
