const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const page = await browser.newPage({ viewport: { width: 1600, height: 950 } });
  await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.includes('cdnjs.cloudflare.com') ? r.continue() : r.abort(); });
  await page.goto('file://' + process.argv[2]); await page.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 90000 });
  const c = () => page.evaluate(() => { const p = window.__poc.positions(), ks = Object.keys(p), n = ks.length, c = [0, 0, 0]; ks.forEach(k => { for (let i = 0; i < 3; i++) c[i] += p[k][i] / n; }); return c.map(v => +v.toFixed(2)).concat([+(window.__poc.frames ? window.__poc.frames() : 0)]); });
  for (const t of [5, 30, 60, 120, 180]) { await page.waitForTimeout((t - (t === 5 ? 0 : [5, 30, 60, 120, 180][[5, 30, 60, 120, 180].indexOf(t) - 1])) * 1000); console.log('t=' + t + 's centroid', JSON.stringify(await c())); }
  await page.screenshot({ path: process.argv[3] }); await browser.close();
})();
