# The sixteen physics as real SQLite. Checks written before the build, from the owner's words.
# Sources: Q1 (this turn); handoff and NOW spec: "gate = address", DNA row = (shard, arrival, remainder, trigger, times, first, last) + op,
# "each DNA row carries its own static hop trigger, laid once", "lay = write the row and its hop trigger through mother, then retry through mother",
# "born = mother: table, trigger, blank definition node, first row; then source", "the input string runs, and running it fires the triggers",
# "mother does no work other than the traverse", "populated driven, not timer driven".

P1  The host does only three things: write a typed line into input; be mother (run text she is handed, carry asks to mailboxes, pick up
    populated outboxes, write what came back into secondary input); read output. No gate logic, no tokenizing, no choosing in the host.
    Check: the host source has no word lists, no split of the line, no loop over gates; every decision is in physics15.sql.
P2  A typed line is tokenized by the encoder's own recursive trigger. An unknown word is born: mother makes table g<id>, view land_<id>,
    and its miss trigger; they appear in sqlite_master.
P3  A run lands by inserting into a gate's view. A hit counts the DNA row (times + 1) through that row's own hop trigger, which carries
    the run to the next gate. A miss inserts into lay; lay writes the row and its own hop trigger through mother and retries through mother.
    Check: first pass of a new line lays one row per gate and one hop trigger per row (named hop_<gate>_<shard>); the same line again
    (forced past memory) adds no row and no trigger, and every row reads times = 2.
P4  The retry works only because it is a new statement (fact 4): the run reaches its end on the first pass.
P5  Memory: the same line again is a memory hop: no landing, times 2 on the memory row, a timeline row.
P6  A formula is a row in the formula table. Its SQL statements are decoded from the gates the branch run passed, holes filled, at ";";
    the text goes into output to sources; mother runs it; the reply comes back into secondary input as a sub-input of the same root run;
    a cell is filled; "say" is a plain SQL insert into the say table.
P7  The v14 behaviour holds on the new physics: source asks only where its formula says (T3, T4, T22); populated order and empty
    outbox (T5); the three-question check with real headwords (T6); empty reply and asked wrong (T7); a silent source leaves the cell
    waiting (T23); step back to another row (T8, T19); relations only from a word's run, drawn by the relation trigger (T11);
    formula truth shift (T12); derive and its control (T13, T20); reopen and its control (T25, T26); AS in two places (T10).
P8  No state write that the owner did not ask for: v14's "a wrong answer writes state keyed after the first being word" was my
    invention and a language rule. Removed. A corrected answer lives in the memory row, as the owner's design says.
P9  No language rule in the physics: no list of being words, no subject or object cut. The physics gives a firing word only mechanical
    holes: :head (itself), :before and :after (the line's words before and after it), :line, :run, :prev (the previous root run),
    :speaker (user when heard, self when said), :subject (the word a born-run is about). Anything else is a cell a word's own formula writes.
P10 Depth: a 40-word line and nested definition-row runs complete without hitting the trigger depth limit.
P11 v14 is untouched (hash) and nothing is written in ~/neuron/v1.
P12 (Q13) mother is a router only. Her code: run the text she is handed at the SQL prompt; if the text addresses a source brain's
    inbox, carry it there; when that brain's outbox signals populated, pick it up and empty it; write what came back into secondary
    input. She computes nothing about the reply. Every trip is drawn: brain, output to sources, mother, SQL prompt or a source brain,
    mother, secondary input. Her code is printed on the page.
P13 (Q13, NOW spec) A fresh brain asks its connected sources: the source neuron starts with a told formula row naming every connected
    source. Teaching source again ends that row and replaces it (truth shift). "define store" on a fresh brain asks the sources.

CORRECTION LOG (run 1, 36/40):
- P1 read too wide: it flagged mother reading the address on the envelope ("wn.inbox" -> "wn"), which P12 allows. The check now looks for what P1 states: the host never splits a line into words. The build was right.
- P6 route read too wide: "you" was a new word, so its source asks ran first in the same line; the check read the first six route events of the line. It now reads the who branch's own events. The build was right: out, mother, SQL prompt, mother, secondary, check.
- T8/T19 failed because of two real bugs: the bind queue row was written after the run that looks for it (the row "who are -> what" was never laid); and mother answered a query with no rows with the connection's last row id, so the step back fired a row whose trigger was "encoder". Fixed in the build. Also fixed: mother's change count included rows written by triggers; she now reports the statement's own changes, as the SQL prompt does.
Controls, written after 40/40 and before any change for them:
C1 (P3) Drop one row's own hop trigger; the same path again (forced past memory by a longer line) stops at that gate: no end, no output.
C2 (P13) Remove the told source row: a fresh brain asks no source, and a gap says no formula says where to look.
C3 (P12) mother refuses to carry (returns nothing, runs nothing): a new word cannot be born; the line cannot even start. No trigger can do her job.
- C1 (run 1) dropped hop_<cat>_1 assuming shard 1 was the line's row; cat had already been met in its own definition rows ("like house cat"), so shard 1 was the row arriving from house. The control now drops the row the line actually hits.

BUILD FIX (found while preparing E6's verification, before any test failed): a definition-row run shared the typed line's root, so its formulas wrote into the line's own cells. A definition row is the brain studying a word on the side; it now has its own root and its own context table. Added check P14: a definition row's formula cannot write into the typed line's cells.
