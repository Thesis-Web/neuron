import json, hashlib, html, re, sys
D = sys.argv[1]; R = sys.argv[2]   # v15 dir, scratchpad root
rd = lambda p: open(p, encoding='utf-8').read()
head, body, main, prose = rd(D + '/head15.html'), rd(D + '/body15.html'), rd(D + '/main15.js'), rd(D + '/prose15.html')
host = rd(D + '/host15.js'); host = re.sub(r"if \(typeof module !== 'undefined'\) module\.exports = .*?;\n?$", '', host.rstrip() + '\n', flags=re.S)
mcode = host[host.index('  // MOTHER-START'):host.index('  // MOTHER-END') + len('  // MOTHER-END')]
told = json.load(open(D + '/physics15.json'))
srcrow = next(s for s in told['statements'] if s.startswith("INSERT INTO formula") and 'inbox' in s)
srcbody = re.search(r"VALUES \('source', '(.*?)', 'told'", srcrow).group(1).replace(' ; ', ' ;\n')
e7 = rd(D + '/e7section.html'); e7res = ''
prose = prose.replace('/*MOTHERCODE*/', html.escape(mcode)).replace('/*SOURCEROW*/', 'source = ' + html.escape(srcbody)).replace('/*E7*/', e7.replace('/*E7RESULT*/', e7res))
enginesrc = rd(R + '/sqljs/sql-asm-memory-growth.js') + '\n' + host + '\n' + rd(D + '/shared15.js')
workersrc = rd(D + '/worker15.js')
for bad in ('</script', '<!--'): assert bad not in enginesrc and bad not in workersrc and bad not in main, bad
e6 = json.load(open(R + '/turn15/e6/e6verify.result.json'))
E6SQL = {
 'F1': "INSERT INTO var ( run , name , value ) VALUES ( :run , ':owner' , :speaker ) ;",
 'F2': "INSERT INTO var ( run , name , value ) SELECT :run , ':owner' , 'self' WHERE :speaker = 'user' ; INSERT INTO var ( run , name , value ) SELECT :run , ':owner' , 'user' WHERE :speaker = 'self' ;",
 'F3': "INSERT INTO var ( run , name , value ) VALUES ( :run , ':key' , :owner || '.' || :head ) ;",
 'F5c': "INSERT INTO state ( key , value ) SELECT :key , :after WHERE :key IS NOT NULL ;",
 'F7': "INSERT INTO say ( run , text ) VALUES ( :run , :answer ) ;"}
E6SQL['F11'] = E6SQL['F3'] + " SELECT value FROM state WHERE key = :key ORDER BY id DESC LIMIT 1 ; INSERT INTO var ( run , name , value ) VALUES ( :run , ':answer' , :found ) ;"
surv = e6['survivor, W-b']['assign']
HOW = "SELECT group_concat ( text , ' ' ) FROM stmt WHERE run IN ( SELECT id FROM run WHERE root = :prev OR root = ( SELECT run FROM memory WHERE id = ( SELECT memid FROM run WHERE id = :prev AND recalled = 1 ) ) ) ; INSERT INTO var ( run , name , value ) VALUES ( :run , ':answer' , :found ) ;"
for w, f in surv.items(): assert f in E6SQL, f
presets = [
 ['E6 1: teach the measured formulas (your, my, name, age, is, ?)', [w + ' = ' + E6SQL[f] for w, f in surv.items()]],
 ['E6 2: tell it its own name, as a told fact through the SQL prompt', ["BUILD INSERT INTO state ( key , value ) VALUES ( 'self.name' , 'neuron' ) ; BUILD"]],
 ['E6 3: what is your name ?', ['what is your name ?']],
 ['E6 4: two facts, two owners, then ask', ['your age is three', 'my age is forty', 'what is my age ?', 'what is your age ?']],
 ['E8 1: put the how formula on "how" (only so it can run), ask what is your name ?, then how did you do that ?', ['how = ' + HOW, 'what is your name ?', 'how did you do that ?']],
 ['E8 2: another line, then ask again: the memory flaw', ['your age is three', 'how did you do that ?']]]
measured = {
 'is': ['writes what follows it under the key built before it, only if a key was built: ' + E6SQL['F5c'], 'two facts with one owner, one fact with two owners, a question writes no fact'],
 'your': ['sets the owner of the key to the other one, the brain when you speak: ' + E6SQL['F2'], 'only once the brain holds its own name before anything is said; without that, your and my can swap'],
 'my': ['sets the owner of the key to the one speaking: ' + E6SQL['F1'], 'the same'],
 'name': ['builds the key from the owner and itself; it may also read the state (not decided): ' + E6SQL['F11'], 'two keys under one owner'],
 'age': ['builds the key from the owner and itself; it may also read the state (not decided): ' + E6SQL['F11'], 'two keys under one owner'],
 'what': ['16 of 18 forms survive', 'nothing: the sentences never needed it'],
 '?': ['13 of 18 forms survive; the one taught here says the answer', 'little']}
e6js = 'var E6PRESETS = ' + json.dumps(presets) + ';\nvar E6MEASURED = ' + json.dumps(measured) + ';'
assert main.count('/*E6PRESETS*/') == 1
main = main.replace('/*E6PRESETS*/', e6js)
out = head + body
for ph, val in [('/*PROSE*/', prose), ('/*ENGINESRC*/', enginesrc), ('/*WORKERSRC*/', workersrc), ('/*TOLD*/null', json.dumps(told)), ('/*SAT*/null', rd(D + '/sat15.json')),
                ('/*SLICE*/null', rd(R + '/ownerzip/slice.json')), ('/*READINGS*/null', 'null'), ('/*MAIN*/', main)]:
    assert out.count(ph) == 1, ph; out = out.replace(ph, lambda: None) if False else out.replace(ph, val.replace('\\', '\\\\') if False else val, 1)
open(D + '/point-of-connection-15.html', 'w', encoding='utf-8').write(out)
open(D + '/poc15-main.js', 'w', encoding='utf-8').write('var TOLD = ' + json.dumps(told) + ', SAT = null, SLICE = null, READINGS = null;\n' + main)
print('built', len(out.encode()), 'bytes; sha', hashlib.sha256(out.encode()).hexdigest()[:12])
