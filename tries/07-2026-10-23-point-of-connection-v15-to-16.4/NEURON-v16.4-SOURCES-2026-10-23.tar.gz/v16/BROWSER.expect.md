# v15 page in headless Chromium: what each step must show (written before running)
B1 load: no page error; brain ready within 90 s; at least 386 dim dots (your map) plus the told nodes have positions.
B2 "define store": while it runs the page answers (busy text changes per line); after, the events include mailbox, pickup, mother and sql rows (the brain reached sources and the SQL prompt), and the log shows them.
B3 alike off: the map's words move (mean move > 1 unit within 2 s); alike on: they move again. Neither rail's scroll position changes.
B4 a pull slider down: the words move.
B5 E6 presets 1, 2, 3: the last line says "neuron".
B6 E6 preset 4: "what is my age ?" says forty, then "what is your age ?" says three (the last line's output, read from the busy text).
B7 measure "your": the meaning panel lists the lines it was in, with outputs with and without it.
B8 click a dim dot: the selected card says it is a word of your relation map.
B9 screenshots: light, dark, phone width 400 with no horizontal page scroll.

## Correction log after run 1 (not loosening: my expectation was wrong about the brain)
B2 expected an sql event from "define store". That line only reaches the source mailboxes; nothing in it is sent to the SQL prompt. The SQL prompt is reached by
formula statements (E6 3 sends SELECT value FROM state ...). B2 now expects mailbox, pickup and mother; B5 must show sql events.
B3 FAILED on the page, not the check: the reshape moved words about 1 unit on a graph of radius 84. Fix in the page: a toggle settles at once and keeps settling faster for 90 frames.
## Added for run 2, written before it
B5b after E6 3, the events include sql rows.
B10 the card for "is" says 1 level below it; the card for "your" says 2.
B11 E8 1: the last output includes SELECT value FROM state WHERE key = 'self.name' and the say of 'neuron'. E8 2: the output is the old one (from memory).
B12 truth shift: teaching "is" a different formula row moves "is" on the stage by more than 1 unit within 3 s.

## Run 2 results and corrections, then run 3 (written before run 3)
Run 2: B1-B10, B12, B9 held (reshape now 2.7 units off and 2.7 on; truth shift moved "is" 8.3 units; levels is 1, your 2).
B11 FAILED, and the cause was found, not hidden: on "how did you do that ?" the brain stopped with an empty Error in the browser worker only.
Measured: mother nests 48 levels on that line (each new row is laid, then the line retries through mother one level deeper; definition rows of new words nest inside).
Node passes at a 600 KB stack and fails at 400 KB with the same empty Error; Chromium's worker has about 0.5 MB, its main thread about 1.3 MB.
The WebAssembly build fails at 400 KB too, so the build is not the cause. Fix in the page: a line too deep for the worker is undone from its snapshot and run on the page's main thread, then handed back.
Also found: after a memory hop, E8's formula had nothing to read; E8b follows the memory to its run (H6, checked in Python with the controls).
B11 (run 3): E8 1's last output includes SELECT value FROM state WHERE key = 'self.name' and the say of 'neuron'; E8 2's output equals E8 1's (the stale memory flaw, H5).
B13 (run 3): at least one line in the run reports that it ran on the page itself, and no line ends with "the brain stopped".
