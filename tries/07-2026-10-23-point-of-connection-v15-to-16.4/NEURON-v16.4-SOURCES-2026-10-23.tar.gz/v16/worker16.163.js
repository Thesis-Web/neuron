// WORKER: the brain runs here, off the page's thread, so the page stays alive while a line is learned.
// It holds the brain (real SQLite through the host), a snapshot of the brain before every line (for measuring a word), and answers
// the page's questions by reading the brain's own tables. It decides nothing for the brain.
var brain = null, TOLD = null, SAT = null, LINES = [], SNAPS = [], lastEvent = 0, KEEP = 24;
// a snapshot is the whole brain, about 3 MB after a few lines: only the last KEEP are kept; older lines cannot be re-run
function keepSnap(bytes) { SNAPS.push(bytes); if (SNAPS.length > KEEP + 1) SNAPS[SNAPS.length - KEEP - 2] = null; }
function snapshot() { return exportBrain(brain, SAT); }
function restore(bytes) { return restoreBrain(SQLMOD, TOLD, SAT, bytes); }
function rows(b, sql, p) { return b.q(sql, p); }
function bundle(b, since) {
  return {
    events: rows(b, 'SELECT id, kind, gate, run, rowgate, text, roots, a, b FROM event WHERE id > ? ORDER BY id', [since]),
    encoder: rows(b, 'SELECT gate, word, role, born, sourced FROM encoder'),
    // a formula is shown by reading its path back from the run it points at; the brain holds no text for it
    formula: rows(b, "SELECT word, coalesce((SELECT group_concat(w, ' ') FROM (SELECT e.word AS w FROM receipt r JOIN encoder e ON e.gate = r.gate WHERE r.run = formula.run ORDER BY r.id)), ''), origin, t, ended, run FROM formula"),
    defword: rows(b, "SELECT DISTINCT word, w FROM defword WHERE w IS NOT NULL AND length(w) > 1"),
    proc: rows(b, 'SELECT word, status, uses, right, wrong FROM proc'),
    run: rows(b, 'SELECT id, kind, word, parent, root, line, output, mark, recalled, memid, failed, t0, t1, expected, direction FROM run'),
    cells: rows(b, "SELECT v.id, v.run, v.name, v.value, v.src, v.t, s.asked, s.needed, s.wrong, s.setaside FROM var v LEFT JOIN sense s ON s.id = v.sense WHERE v.name NOT IN (':head', ':line', ':run', ':prev', ':speaker') OR v.value IS NOT NULL"),
    gaps: rows(b, 'SELECT run, need, fill, who, kind FROM gap'),
    trust: rows(b, "SELECT src, count(*), sum(kept), sum(aside), sum(total = 0) FROM sense WHERE src <> 'sql' GROUP BY src"),
    need: rows(b, 'SELECT w, n FROM need ORDER BY n DESC LIMIT 30'),
    defs: rows(b, "SELECT word, src, hw, text FROM definition WHERE src <> 'node'"),
    triggers: rows(b, "SELECT count(*) FROM sqlite_master WHERE type = 'trigger'")[0][0],
    tables: rows(b, "SELECT count(*) FROM sqlite_master WHERE type = 'table' AND name GLOB 'g[0-9]*'")[0][0]
  };
}
// the measure of a word: the line run again with it and without it, from the snapshot taken just before that line
var KINDS_GRAPH = { born: 'gates born', lay: 'DNA rows laid', rel: 'relations', memory: 'memory rows', timeline: 'timeline rows', state: 'state rows', taught: 'formula rows', derived: 'formula rows' };
function ledger(b, since) {
  var L = {}, G = {}, Q = {}, A = {}, cols = null;
  rows(b, 'SELECT kind, gate, roots, rowgate FROM event WHERE id > ?', [since]).forEach(function (e) {
    (e[2] || '').split(' ').filter(Boolean).forEach(function (r) { L[r] = (L[r] || 0) + 1; });
    if (KINDS_GRAPH[e[0]]) G[KINDS_GRAPH[e[0]]] = (G[KINDS_GRAPH[e[0]]] || 0) + 1;
    if (e[0] === 'lay') G['hop triggers'] = (G['hop triggers'] || 0) + 1;
    if (e[0] === 'input' && e[3] === null && e[1] && e[1] !== 'input') Q[e[1]] = (Q[e[1]] || 0) + 1;
    if (e[0] === 'mailbox') A[e[1]] = (A[e[1]] || 0) + 1;
  });
  return { silicon: L, graph: G, questions: Q, asks: A };
}
function diff(a, b) { var o = {}; Object.keys(a).concat(Object.keys(b)).forEach(function (k) { var v = (a[k] || 0) - (b[k] || 0); if (v) o[k] = v; }); return o; }
function lastBuildCols(b) { var r = rows(b, "SELECT cols FROM secondary WHERE src = 'sql' AND last = 1 ORDER BY id DESC LIMIT 1"); return r.length && r[0][0] ? r[0][0].split(',') : []; }
function contrast(i, word) {
  var line = LINES[i], toks = line.replace(/\s*=>.*$/, '').trim().split(/\s+/);
  if (toks.indexOf(word) < 0) return null;
  if (!SNAPS[i]) return { line: line, tooOld: true, silicon: {}, graph: {}, questions: {}, asks: {} };
  var expected = /=>/.test(line) ? line.split('=>')[1].trim() : null;
  var without = toks.filter(function (t) { return t !== word; }).join(' ') + (expected ? ' => ' + expected : '');
  var A = restore(SNAPS[i]), tA = rows(A, 'SELECT coalesce(max(id), 0) FROM event')[0][0], oa; try { oa = A.type(line); } catch (e) { A.close(); return { line: line, tooDeep: true, silicon: {}, graph: {}, questions: {}, asks: {} }; } var ca = /^BUILD /.test(line) ? lastBuildCols(A) : null, la = ledger(A, tA); A.close();
  var B = restore(SNAPS[i]), tB = rows(B, 'SELECT coalesce(max(id), 0) FROM event')[0][0], ob; try { ob = without.trim() ? B.type(without) : null; } catch (e) { B.close(); return { line: line, tooDeep: true, silicon: {}, graph: {}, questions: {}, asks: {} }; } var cb = /^BUILD /.test(without) ? lastBuildCols(B) : null, lb = ledger(B, tB); B.close();
  return { line: line, output: oa, outputWithout: ob, columns: ca ? { with: ca, without: cb || [] } : null, silicon: diff(la.silicon, lb.silicon), graph: diff(la.graph, lb.graph), questions: diff(la.questions, lb.questions), asks: diff(la.asks, lb.asks) };
}
function meaningOf(word) {
  var recs = [], runs = rows(brain, "SELECT id, input, recalled, memid FROM run WHERE kind = 'line' ORDER BY id"), byInput = {};
  runs.forEach(function (r) { byInput[r[1]] = r; });
  var inputs = rows(brain, "SELECT id, line FROM input WHERE kind = 'line' ORDER BY id");
  inputs.forEach(function (inp, i) {
    var line = LINES[i]; if (!line || /\s->\s/.test(line) || /^\S+\s=\s(?!>)/.test(line)) return;
    if (line.replace(/\s*=>.*$/, '').trim().split(/\s+/).indexOf(word) < 0) return;
    var r = byInput[inp[0]];
    if (r && r[2] === 1 && r[3]) {
      // answered from memory: the words point at that memory. Counted as the run that made it, plus the recall.
      var mrun = rows(brain, 'SELECT run, times FROM memory WHERE id = ?', [r[3]]), src = -1;
      if (mrun.length) { var srcInput = rows(brain, 'SELECT input FROM run WHERE id = ?', [mrun[0][0]]); inputs.forEach(function (x, j) { if (srcInput.length && x[0] === srcInput[0][0]) src = j; }); }
      var base = src >= 0 ? contrast(src, word) : null, rec = base ? JSON.parse(JSON.stringify(base)) : { silicon: {}, graph: {}, questions: {}, asks: {} };
      rec.line = line; rec.recalled = true; rec.memId = r[3]; rec.times = mrun.length ? mrun[0][1] : 1; rec.fromLine = src >= 0 ? LINES[src] : null;
      ['FIND', 'COMPARE', 'WRITE'].forEach(function (k) { rec.silicon[k] = (rec.silicon[k] || 0) + 1; }); rec.graph['memory recalls'] = (rec.graph['memory recalls'] || 0) + 1;
      recs.push(rec); return;
    }
    var c = contrast(i, word); if (c) recs.push(c);
  });
  var agg = { silicon: {}, graph: {}, questions: {}, asks: {} };
  recs.forEach(function (c) { ['silicon', 'graph', 'questions', 'asks'].forEach(function (k) { Object.keys(c[k] || {}).forEach(function (x) { agg[k][x] = (agg[k][x] || 0) + c[k][x]; }); }); });
  var sum = function (o) { return Object.keys(o).reduce(function (a, k) { return a + Math.abs(o[k]); }, 0); }, tot = sum(agg.silicon) + sum(agg.graph) + sum(agg.questions) + sum(agg.asks) || 1;
  var f = rows(brain, "SELECT coalesce((SELECT group_concat(w, ' ') FROM (SELECT e.word AS w FROM receipt r JOIN encoder e ON e.gate = r.gate WHERE r.run = formula.run ORDER BY r.id)), ''), origin FROM formula WHERE word = ? AND ended = 0", [word]);
  return { word: word, contexts: recs, ratios: { silicon: sum(agg.silicon) / tot, graph: sum(agg.graph) / tot, questions: sum(agg.questions) / tot, sources: sum(agg.asks) / tot }, aggregate: agg, formula: f.length ? { body: f[0][0], origin: f[0][1] } : null, defs: rows(brain, "SELECT src || ': ' || text FROM definition WHERE word = ? AND src <> 'node' LIMIT 8", [word]).map(function (x) { return x[0]; }) };
}
var SQLMOD = null;
onmessage = function (m) {
  var d = m.data;
  try {
    if (d.type === 'init') {
      TOLD = d.told; SAT = d.sat;
      initSqlJs().then(function (SQL) {
        SQLMOD = SQL; Neuron.init(SQL); brain = new Neuron.Brain(TOLD, SAT); SNAPS = []; keepSnap(snapshot()); LINES = [];
        var b = bundle(brain, 0); lastEvent = b.events.length ? b.events[b.events.length - 1][0] : 0; postMessage({ type: 'ready', bundle: b });
      }).catch(function (e) { postMessage({ type: 'error', error: String(e && e.message || e) }); });
    } else if (d.type === 'lines') {
      var t0 = Date.now(), outs = [];
      for (var k = 0; k < d.lines.length; k++) {
        var l = d.lines[k], t1 = Date.now(), o;
        try { o = brain.type(l); }
        catch (err) {
          // the brain as it stood before this line comes back from its snapshot; nothing of the failed line is kept
          var before = SNAPS[SNAPS.length - 1]; try { brain.close(); } catch (e2) {} brain = restore(before);
          var msg = String(err && err.message || err), deep = !msg || msg === 'Error' || /call stack|recursion/i.test(msg);
          postMessage({ type: deep ? 'deep' : 'failed', line: l, error: msg, bytes: before, rest: d.lines.slice(k + 1), k: k, of: d.lines.length, total: Date.now() - t0 });
          return;
        }
        LINES.push(l); outs.push(o); keepSnap(snapshot());
        var b = bundle(brain, lastEvent); if (b.events.length) lastEvent = b.events[b.events.length - 1][0];
        postMessage({ type: k === d.lines.length - 1 ? 'done' : 'line', line: l, output: o, k: k, of: d.lines.length, ms: Date.now() - t1, total: Date.now() - t0, bundle: b });
      }
    } else if (d.type === 'said') {
      LINES.push(d.line); var o = brain.type(d.line, 'said'); keepSnap(snapshot());
      var b2 = bundle(brain, lastEvent); if (b2.events.length) lastEvent = b2.events[b2.events.length - 1][0];
      postMessage({ type: 'done', outputs: [o], ms: 0, bundle: b2 });
    } else if (d.type === 'adopt') {
      try { brain.close(); } catch (e3) {} brain = restore(d.bytes); LINES.push(d.line); keepSnap(snapshot());
      var ba = bundle(brain, lastEvent); if (ba.events.length) lastEvent = ba.events[ba.events.length - 1][0];
      var last = !d.rest.length;
      postMessage({ type: last ? 'done' : 'line', line: d.line, output: d.output, k: 0, of: 1 + d.rest.length, ms: d.ms, total: d.ms, bundle: ba, onMain: true });
      if (!last) onmessage({ data: { type: 'lines', lines: d.rest } });
    } else if (d.type === 'query') {
      postMessage({ type: 'answer', id: d.id, rows: rows(brain, d.sql, d.params || []) });
    } else if (d.type === 'measure') {
      postMessage({ type: 'measured', id: d.id, result: meaningOf(d.word) });
    } else if (d.type === 'restart') {
      brain.close(); brain = new Neuron.Brain(TOLD, SAT); SNAPS = []; keepSnap(snapshot()); LINES = []; lastEvent = 0;
      var b3 = bundle(brain, 0); lastEvent = b3.events.length ? b3.events[b3.events.length - 1][0] : 0; postMessage({ type: 'ready', bundle: b3, restarted: true });
    }
  } catch (e) { postMessage({ type: 'error', error: String(e && e.stack || e) }); }
};
