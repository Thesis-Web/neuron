# v15 physics checks, from PHYSICS-CHECKS.md and the v14 checks restated for v15. Written before fixes; failures are understood, not re-worded.
import sys, re, hashlib, collections
sys.path.insert(0, '.')
from host15 import Brain
P = F = 0; FAILS = []
def check(name, cond, detail=''):
    global P, F
    if cond: P += 1; print('PASS', name)
    else: F += 1; FAILS.append(name); print('FAIL', name, '|', str(detail)[:400])
def fresh(): return Brain('physics15.json', sat_path='sat15.json')
def ev(b, t0, kind=None): return [e for e in b.q('SELECT id, kind, gate, rowgate, run, text FROM event WHERE id > ?', (t0,)) if kind is None or e[1] == kind]
def top(b): return b.q('SELECT coalesce(max(id), 0) FROM event')[0][0]
SAYF = "INSERT INTO say ( run , text ) VALUES ( :run , :found ) ;"

# P1, P12: the host is the bottom and mother; mother routes only
host = open('host15.py').read()
mother_src = host[host.index('def mother'):host.index('def type')]
check('P1 the host does not tokenize, choose gates, or touch the physics tables',
      not re.search(r"(line|text)\.split\(|\.split\(\)|\.split\(' '\)|INSERT INTO land_|INSERT INTO g[0-9{]|INSERT INTO (formula|encoder|gap|var|sense|run|memory)\b", host), 'found')
check('P12 mother only routes: she reads no physics table and computes nothing about a reply',
      not re.search(r"\b(formula|encoder|gap|sense|memory|receipt|var|run)\b\s*(WHERE|SET|\()", mother_src) and 'count(' not in mother_src.replace('(SELECT count(*) FROM outbox', ''), 'found')
check('P1 no timer or poll anywhere in the host', not re.search(r"sleep|Timer|threading|while True", host), 'found')

# P2, P3, P4, P5
b = fresh(); t0 = top(b); out = b.type('cat sat')
g = dict(b.q("SELECT word, gate FROM encoder WHERE word IN ('cat', 'sat')"))
objs = set(r[0] for r in b.q("SELECT name FROM sqlite_master"))
check('P2 born words get a table, a gate and a miss trigger through mother', all(n in objs for n in [f"g{g['cat']}", f"land_{g['cat']}", f"miss_{g['cat']}", f"g{g['sat']}"]), sorted(objs)[-6:])
check('P4 the run reaches its end on the first pass (retry through mother works)', out is not None and len(ev(b, t0, 'end')) == 1, out)
hops1 = set(r[0] for r in b.q("SELECT name FROM sqlite_master WHERE type='trigger' AND name LIKE 'hop_%'"))
check('P3 one hop trigger per laid row, named for its gate and shard', f"hop_{g['cat']}_1" in hops1 and f"hop_{g['sat']}_1" in hops1, sorted(hops1)[:6])
t1 = top(b); b.type('cat sat dog')
hops2 = set(r[0] for r in b.q("SELECT name FROM sqlite_master WHERE type='trigger' AND name LIKE 'hop_%'"))
row = b.q(f"SELECT times FROM g{g['cat']} WHERE arrival = (SELECT gate FROM encoder WHERE word='heard') AND remainder = {g['sat']}")
check('P3 a row hit again counts (times 2) and lays no new trigger for itself', row and row[0][0] == 2 and len([h for h in hops2 - hops1 if h.startswith(f"hop_{g['cat']}_")]) == 0, (row, sorted(hops2 - hops1)))
t2 = top(b); o2 = b.type('cat sat')
check('P5 the same line again is a memory hop: no landing, times 2, a timeline row', len(ev(b, t2, 'memhit')) == 1 and len(ev(b, t2, 'hit')) == 0 and b.q("SELECT times FROM memory WHERE id = 1")[0][0] == 2 and len(ev(b, t2, 'timeline')) == 1, [e[1] for e in ev(b, t2)])

# P6 / T1: a formula's SQL from its row, through output to sources, mother, the SQL prompt, secondary input, a cell
b = fresh()
b.type(f"who = SELECT value FROM state WHERE key = :after ; {SAYF}")
b.type("BUILD INSERT INTO state ( key , value ) VALUES ( 'you' , 'a brain' ) ; BUILD")
t0 = top(b); out = b.type('who you')
outs = [e[5] for e in ev(b, t0, 'out')]
check('P6 the statement leaves as the row says, holes filled', any("SELECT value FROM state WHERE key = 'you' ;" in o for o in outs), outs)
whorun = b.q("SELECT max(id) FROM run WHERE kind = 'formula' AND word = 'who'")[0][0]
route = [e[1] for e in ev(b, t0) if e[4] == whorun and e[1] in ('out', 'mother', 'sql', 'mailbox', 'secondary', 'check')]
check('P6 drawn route: output to sources, mother, SQL prompt, mother, secondary input, check', route[:6] == ['out', 'mother', 'sql', 'mother', 'secondary', 'check'], route[:8])
root = b.q("SELECT max(id) FROM run WHERE kind = 'line'")[0][0]
cells = b.q("SELECT name, value FROM var WHERE run IN (SELECT id FROM run WHERE root = ?)", (root,))
check('P6 a cell named by the statement holds the reply', any(n.startswith("SELECT value FROM state") and v == 'a brain' for n, v in cells), cells)
check('P6 the answer', out == 'a brain', out)

# P8: no state write the owner did not ask for
b = fresh(); b.type(f"who = SELECT value FROM state WHERE key = :after ; {SAYF}"); b.type('who you => a brain')
check('P8 a wrong answer writes no state row; the correction lives in memory', b.q("SELECT count(*) FROM state")[0][0] == 0 and b.q("SELECT answer FROM memory ORDER BY id DESC LIMIT 1")[0][0] == 'a brain', b.q("SELECT * FROM state"))

# P9: no language rule in the physics
told = open('physics15.json').read()
check('P9 no being-word list or subject/object cut in the physics', not re.search(r"'(is|are|was|were|am|be)'", told) and ':object' not in told and ':verb' not in told, re.findall(r"'(is|are|was|were|am|be)'", told)[:5])

# P13: the source neuron starts with a told row naming every connected source
b = fresh(); t0 = top(b); b.type('define store')
boxes = sorted(set(e[2] for e in ev(b, t0, 'mailbox')))
check('P13 a fresh brain asks its connected sources', boxes == sorted(b.SATS), boxes)
b.type("source = INSERT INTO wn.inbox ( word ) VALUES ( :subject ) ;")
check('P13 teaching source again ends the told row (truth shift)', b.q("SELECT count(*) FROM formula WHERE word='source' AND ended=1")[0][0] == 1 and b.q("SELECT count(*) FROM formula WHERE word='source' AND ended=0")[0][0] == 1)

# T4, T5, T22
b = fresh(); b.type("source = INSERT INTO wn.inbox ( word ) VALUES ( :subject ) ;"); t0 = top(b); b.type('define store')
boxes = [e[2] for e in ev(b, t0, 'mailbox')]
check('T4 only wn is asked, once per new word', boxes == ['wn', 'wn'], boxes)
order = [e[1] for e in ev(b, t0) if e[1] in ('out', 'mother', 'mailbox', 'populated', 'pickup', 'secondary')]
check('T5 populated-driven order', order[:6] == ['out', 'mother', 'mailbox', 'populated', 'pickup', 'secondary'], order[:8])
check('T5 outbox emptied by pickup', b.q("SELECT count(*) FROM wn.outbox")[0][0] == 0)
b = fresh(); b.type("source = INSERT INTO wn.inbox ( word ) VALUES ( :subject ) ; INSERT INTO moby.inbox ( word ) VALUES ( :subject ) ;"); t0 = top(b); b.type('store')
check('T22 exactly the two named', sorted(e[2] for e in ev(b, t0, 'mailbox')) == ['moby', 'wn'], [e[2] for e in ev(b, t0, 'mailbox')])

# T6, T7
b = fresh(); b.type("source = INSERT INTO gcide.inbox ( word ) VALUES ( :subject ) ; INSERT INTO mw.inbox ( word ) VALUES ( :subject ) ;"); b.type('define as')
srows = b.q("SELECT src, word, kept, aside, asked, needed, wrong, setaside FROM sense WHERE word = 'as'")
check('T6 every return checked, three answers each', len(srows) == 2 and all(r[4] and r[5] and r[6] for r in srows), srows)
aside = ' '.join(r[7] or '' for r in srows)
check('T6 Webster sends So, MW sends As and AS: set aside', 'So (' in aside and 'As:1' in aside and 'AS (' in aside, aside)
kept = b.q("SELECT hw FROM definition WHERE word = 'as' AND src IN ('gcide', 'mw')")
check('T6 only rows about as are kept', kept and all(re.sub(r':\d+$', '', h[0]) == 'as' for h in kept), kept)
b = fresh(); b.type("source = INSERT INTO wn.inbox ( word ) VALUES ( :subject ) ;"); b.type('define qzxv')
r = b.q("SELECT needed, wrong FROM sense WHERE word = 'qzxv'")
check('T7 empty reply: needed no, asked wrong is asked', r and r[0][0].startswith('no') and 'asked wrong' in r[0][1], r)
check('T7 a gap names it', b.q("SELECT count(*) FROM gap WHERE need LIKE 'an answer from wn for qzxv'")[0][0] == 1)

# T8, T19
WHO = f"who = SELECT value FROM state WHERE key = :after ; {SAYF}"
WHAT = f"what = SELECT answer FROM memory WHERE line = :after ; {SAYF}"
b = fresh(); [b.type(x) for x in [WHO, WHAT, 'who are -> what', 'sky => blue']]; t0 = top(b); out = b.type('who sky')
check('T8 a failed ask steps back to the other row', len(ev(b, t0, 'stepback')) == 1, [e[1] for e in ev(b, t0)][-30:])
check('T8 the other row answers from memory', out == 'blue', out)
b = fresh(); [b.type(x) for x in [WHO, WHAT, 'sky => blue']]; t0 = top(b); out = b.type('who sky')
check('T19 control: no other row, no blue, and a gap says so', out != 'blue' and b.q("SELECT count(*) FROM gap WHERE need LIKE 'another way to ask%'")[0][0] >= 1, out)

# T11
LIKE = "INSERT INTO relation ( a , rel , b ) VALUES ( :subject , :head , :after ) ;"
b = fresh(); b.type("source = INSERT INTO map.inbox ( word ) VALUES ( :subject ) ;"); b.type('define store')
check('T11 no relation before like has a formula', b.q("SELECT count(*) FROM relation")[0][0] == 0)
b.type('like = ' + LIKE); t0 = top(b); b.type('define shop')
rels = ev(b, t0, 'rel')
check('T11 relations written through the like formula and drawn by the relation trigger', len(rels) > 0 and b.q("SELECT count(*) FROM relation")[0][0] == len(rels), (len(rels), b.q("SELECT a, rel, b FROM relation")[:5]))

# T12, T13, T20, T21
b = fresh(); b.type(WHO); b.type(f"who = SELECT answer FROM memory WHERE line = :after ; {SAYF}")
rows = b.q("SELECT body, ended FROM formula WHERE word = 'who' ORDER BY id")
check('T12 old row ended, new row live', len(rows) == 2 and rows[0][1] == 1 and rows[1][1] == 0 and 'memory' in rows[1][0], rows)
DERIVE = "derive = INSERT INTO formula ( word , body , origin ) SELECT :subject , body , 'derived' FROM formula WHERE ended = 0 AND word IN ( SELECT b FROM relation WHERE a = :subject AND rel = 'like' ) AND NOT EXISTS ( SELECT 1 FROM formula WHERE word = :subject ) LIMIT 1 ;"
b = fresh(); b.type(f"wa = INSERT INTO say ( run , text ) VALUES ( :run , :head ) ;"); b.type("BUILD INSERT INTO relation ( a , rel , b ) VALUES ( 'wb' , 'like' , 'wa' ) ; BUILD"); b.type(DERIVE); t0 = top(b); b.type('wb')
rows = b.q("SELECT body, origin FROM formula WHERE word = 'wb'")
check('T13 derive copied the related formula, marked derived', rows and rows[0][1] == 'derived' and rows[0][0].startswith('INSERT INTO say'), rows)
b = fresh(); b.type(f"wa = INSERT INTO say ( run , text ) VALUES ( :run , :head ) ;"); b.type(DERIVE); b.type('wb')
check('T20 control: no relation, nothing derived', b.q("SELECT count(*) FROM formula WHERE word = 'wb'")[0][0] == 0)
b = fresh(); b.type(f"who = SELECT answer FROM memory WHERE line = :after ; {SAYF}"); t0 = top(b); b.type('who you')
outs = [e[5] for e in ev(b, t0, 'out')]
check('T21 control: the statement follows the row', any("SELECT answer FROM memory WHERE line = 'you' ;" in o for o in outs), outs)

# T23
b = fresh(); b.con.execute('DROP TRIGGER wn.work'); b.type("source = INSERT INTO wn.inbox ( word ) VALUES ( :subject ) ;"); t0 = top(b); b.type('store')
check('T23 control: no populated signal, no secondary input, the run knows it is waiting', len(ev(b, t0, 'waiting')) == 1 and len(ev(b, t0, 'secondary')) == 0, [e[1] for e in ev(b, t0)][:20])

# T25, T26: reopen when a gap is filled; control
b = fresh(); b.type('define store'); b.type('like = ' + LIKE); t0 = top(b); b.type('define store')
check('T25 a filled gap reopens the memory (the long way again)', len(ev(b, t0, 'memhit')) == 0 and any('again the long way' in e[5] for e in ev(b, t0, 'decide')), [e[1] for e in ev(b, t0)][:10])
b = fresh(); b.type('define store'); t0 = top(b); b.type('define store')
check('T26 control: nothing filled, a memory hop', len(ev(b, t0, 'memhit')) == 1)

# P10 depth
b = fresh(); line = ' '.join(['w%d' % i for i in range(40)]); out = b.type(line)
check('P10 a 40-word line completes', out is not None and out.count('?') == 40, (out or '')[:80])
b = fresh(); b.type('like = ' + LIKE); out = b.type('define store')
check('P10 nested definition-row runs complete', out is not None and b.q("SELECT count(*) FROM run WHERE kind = 'defrow'")[0][0] > 0, (out, b.q("SELECT count(*) FROM run WHERE kind='defrow'")))


# C1, C2, C3
b = fresh(); b.type('cat sat'); g = dict(b.q("SELECT word, gate FROM encoder WHERE word IN ('cat', 'sat')"))
sh = b.q(f"SELECT shard FROM g{g['cat']} WHERE arrival = (SELECT gate FROM encoder WHERE word = 'heard') AND remainder = {g['sat']}")[0][0]
b.con.execute(f"DROP TRIGGER hop_{g['cat']}_{sh}"); t0 = top(b); out = b.type('cat sat dog')
check('C1 control: without its own hop trigger the run stops at that gate', out is None and len(ev(b, t0, 'end')) == 0, (out, [e[1] for e in ev(b, t0)][:12]))
b = fresh(); b.con.execute("DELETE FROM formula WHERE word = 'source'"); t0 = top(b); b.type('define store')
check('C2 control: no source row, no source asked, and a gap says where to look is missing', len(ev(b, t0, 'mailbox')) == 0 and b.q("SELECT count(*) FROM gap WHERE kind = 'source'")[0][0] >= 1)
b = fresh(); b.con.create_function('mother', 3, lambda text, run, stmt: None); t0 = top(b)
try:
    out = b.type('zebra'); made = b.q(f"SELECT count(*) FROM sqlite_master WHERE name = 'g' || (SELECT gate FROM encoder WHERE word = 'zebra')")[0][0]
except Exception as e:
    out, made = 'error: ' + str(e), 0
check('C3 control: with mother doing nothing, no neuron is born and the line never runs', made == 0 and out is None, (out, made))

# P14: a definition row's run keeps its own context table
b = fresh(); b.type("probe = INSERT INTO var ( run , name , value ) VALUES ( :run , ':mark' , :head ) ;")
b.con.execute("INSERT INTO mw.corpus VALUES ('zork', 'zork', 'probe text', 'probe text')"); b.type('zork')
line = b.q("SELECT max(id) FROM run WHERE kind = 'line'")[0][0]
check('P14 a definition row writes into its own run, not the typed line', b.q("SELECT count(*) FROM var WHERE name = ':mark' AND run = ?", (line,))[0][0] == 0 and b.q("SELECT count(*) FROM var WHERE name = ':mark'")[0][0] >= 1, b.q("SELECT run, value FROM var WHERE name = ':mark'"))

# P11
h = hashlib.sha256(open('../v14/point-of-connection-14.html', 'rb').read()).hexdigest()[:12]
check('P11 v14 untouched', h == '01087b13eb76', h)
print(f"\n{P} passed, {F} failed" + (': ' + '; '.join(FAILS) if FAILS else ''))
