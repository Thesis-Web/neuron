# The same scaling test, run for the old physics (no envelope) and the new (envelope), side by side.
import sys, time, random, importlib; sys.path.insert(0, '.')
which = sys.argv[1]
mod = importlib.import_module('host15' if which == 'envelope' else 'host15.noenvelope'.replace('.', '_') if False else 'host15')
from host15 import Brain
told = 'physics15.json' if which == 'envelope' else 'physics15.noenvelope.json'
random.seed(3)
b = Brain(told, sat_path='sat15.json'); b.con.execute("DELETE FROM formula WHERE word = 'source'")
TRIG = "SELECT count(*) FROM sqlite_master WHERE type='trigger'"
vocab = [f'v{i}' for i in range(400)]; probe = 'v1 v2 v3 v4 v5 v6 v7 v8'; b.type(probe)
for step in range(int(sys.argv[2])):
    t = time.time()
    for k in range(60): b.type(' '.join(random.choice(vocab) for _ in range(9)))
    learn = (time.time() - t) / 60
    b.con.execute("UPDATE memory SET ended = 1"); b.type(probe); b.con.execute("UPDATE memory SET ended = 1")
    t = time.time(); b.type(probe); use = time.time() - t
    print(f"{which:12} triggers {b.q(TRIG)[0][0]:6d}  learn line {learn:7.3f}s  known line {use:8.4f}s", flush=True)
