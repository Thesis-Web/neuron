const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const page = await browser.newPage({ viewport: { width: 1600, height: 950 } });
  await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.includes('cdnjs.cloudflare.com') ? r.continue() : r.abort(); });
  await page.goto('file://' + process.argv[2]); await page.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 120000 });
  let last = 0;
  for (const t of [5, 15, 30, 60, 90]) { await page.waitForTimeout((t - last) * 1000); last = t;
    console.log('t=' + t + 's', JSON.stringify(await page.evaluate(() => { const p = window.__poc.positions(), ks = Object.keys(p).filter(k => k !== 'origin'), c = [0, 0, 0]; ks.forEach(k => { for (let i = 0; i < 3; i++) c[i] += p[k][i] / ks.length; }); const r = ks.map(k => Math.hypot(...p[k])).sort((a, b) => a - b); return { centroid: c.map(v => +v.toFixed(1)), median: +r[Math.floor(r.length / 2)].toFixed(0), across: window.__poc.acrossShare('opposite').across, closest: +window.__poc.closest().toFixed(1) }; }))); }
  await page.screenshot({ path: process.argv[3] }); await browser.close();
})();
