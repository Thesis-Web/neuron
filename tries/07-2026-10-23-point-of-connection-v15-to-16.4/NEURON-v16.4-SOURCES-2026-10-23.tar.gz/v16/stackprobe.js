const probe = "function f(n, a, b, c, d) { try { return f(n + 1, a + 1, b, c, d); } catch (e) { return n; } }";
if (process.argv[2] === 'node') { eval(probe); console.log('node', f(0, 0, 1, 2, 3)); }
else (async () => {
  const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader'] }); const page = await browser.newPage();
  await page.setContent('<html><body>probe</body></html>');
  const r = await page.evaluate((probe) => new Promise(res => {
    eval(probe); const main = f(0, 0, 1, 2, 3);
    const w = new Worker(URL.createObjectURL(new Blob([probe + '; postMessage(f(0, 0, 1, 2, 3));'], { type: 'text/javascript' })));
    w.onmessage = m => res({ main, worker: m.data });
  }), probe);
  console.log('chromium main', r.main, 'worker', r.worker); await browser.close();
})();
