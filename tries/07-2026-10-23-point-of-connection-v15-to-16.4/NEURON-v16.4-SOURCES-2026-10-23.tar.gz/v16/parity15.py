import json, sys; sys.path.insert(0, '.')
from host15 import Brain
SAYF = 'INSERT INTO say ( run , text ) VALUES ( :run , :found ) ;'
lines = ['define store', 'like = INSERT INTO relation ( a , rel , b ) VALUES ( :subject , :head , :after ) ;', 'define shop',
  'who = SELECT value FROM state WHERE key = :after ; ' + SAYF, 'what = SELECT answer FROM memory WHERE line = :after ; ' + SAYF, 'who are -> what', 'sky => blue', 'who sky',
  "BUILD SELECT CAST ( '7' AS INTEGER ) ; BUILD", 'cat sat', 'cat sat']
b = Brain('physics15.json', sat_path='sat15.json'); outs = [b.type(l) for l in lines]
sig = {'outs': outs, 'events': b.q('SELECT count(*) FROM event')[0][0], 'kinds': [list(r) for r in b.q('SELECT kind, count(*) FROM event GROUP BY kind ORDER BY kind')],
  'rels': b.q('SELECT count(*) FROM relation')[0][0], 'mem': [list(r) for r in b.q('SELECT id, line, output, answer, times FROM memory ORDER BY id')], 'gates': b.q('SELECT count(*) FROM encoder')[0][0],
  'hops': b.q("SELECT count(*) FROM sqlite_master WHERE type='trigger' AND name LIKE 'hop_%'")[0][0]}
json.dump(sig, open('parity.py.json', 'w')); print('py done', json.dumps(outs))
