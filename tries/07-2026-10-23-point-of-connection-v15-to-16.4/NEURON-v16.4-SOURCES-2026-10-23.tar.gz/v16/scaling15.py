# Does use stay cheap as the graph grows? Grow the brain with new lines that share words (so the graph is connected), and time a
# fixed known line (rows all laid, memory forgotten) at each size.
import sys, time, random; sys.path.insert(0, '.')
from host15 import Brain
random.seed(3)
b = Brain('physics15.json', sat_path='sat15.json'); b.con.execute("DELETE FROM formula WHERE word = 'source'")
TRIG = "SELECT count(*) FROM sqlite_master WHERE type='trigger'"
vocab = [f'v{i}' for i in range(400)]
probe = 'v1 v2 v3 v4 v5 v6 v7 v8'
b.type(probe)
print(f"{'triggers':>9} {'learn line (s)':>15} {'use line (s)':>13}")
for step in range(14):
    t = time.time(); n = 0
    for k in range(60):
        b.type(' '.join(random.choice(vocab) for _ in range(9))); n += 1
    learn = (time.time() - t) / n
    b.con.execute("UPDATE memory SET ended = 1")
    t = time.time(); b.type(probe); use = time.time() - t
    print(f"{b.q(TRIG)[0][0]:9d} {learn:15.3f} {use:13.4f}", flush=True)
