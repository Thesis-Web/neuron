// WORKER: the brain runs here, off the page's thread, so the page stays alive while a line is learned.
// It holds the brain (real SQLite through the host), a snapshot of the brain before every line (for measuring a word), and answers
// the page's questions by reading the brain's own tables. It decides nothing for the brain.
var brain = null, TOLD = null, SAT = null, LINES = [], SNAPS = [], lastEvent = 0, KEEP = 24;
// a snapshot is the whole brain, about 3 MB after a few lines: only the last KEEP are kept; older lines cannot be re-run
function keepSnap(bytes) { SNAPS.push(bytes); if (SNAPS.length > KEEP + 1) SNAPS[SNAPS.length - KEEP - 2] = null; }
function reopenBrain(b) {
  // sql.js export() closes and reopens the database: mother, the satellites and the recursion setting must be put back
  var self = b, db = b.db;
  db.create_function('mother', function (text, run, stmt) { return self.mother(text, run, stmt); });
  db.create_function('satwork', function (sat, ask, word, n) { self.populated.push([sat, ask, word, n]); return 1; });
  db.run('PRAGMA recursive_triggers = ON');
  b.SATS.forEach(function (s) {
    db.run("ATTACH ':memory:' AS " + s);
    db.run("CREATE TABLE " + s + ".corpus (word TEXT, hw TEXT, text TEXT, words TEXT); CREATE INDEX " + s + ".cw ON corpus(word);" +
      "CREATE TABLE " + s + ".inbox (ask INTEGER PRIMARY KEY, word TEXT); CREATE TABLE " + s + ".outbox (ask INTEGER, word TEXT, hw TEXT, text TEXT, words TEXT);" +
      "CREATE TRIGGER " + s + ".work AFTER INSERT ON inbox BEGIN INSERT INTO outbox SELECT NEW.ask, NEW.word, hw, text, words FROM corpus WHERE word = NEW.word;" +
      " SELECT satwork('" + s + "', NEW.ask, NEW.word, (SELECT count(*) FROM outbox WHERE ask = NEW.ask)); DELETE FROM inbox WHERE ask = NEW.ask; END;");
    var st = db.prepare("INSERT INTO " + s + ".corpus VALUES (?, ?, ?, ?)"); ((SAT || {})[s] || []).forEach(function (r) { st.run([r[0], r[1], r[2], r.length > 3 ? r[3] : null]); }); st.free();
  });
}
function snapshot() { var c = brain.cache || {}; Object.keys(c).forEach(function (k) { c[k].forEach(function (st) { try { st.free(); } catch (e) {} }); }); brain.cache = {}; var bytes = brain.db.export(); reopenBrain(brain); return bytes; }
function restore(bytes) {
  var b = Object.create(Neuron.Brain.prototype); b.told = TOLD; b.SATS = TOLD.sats; b.populated = []; b.db = new SQLMOD.Database(bytes); reopenBrain(b); return b;
}
function rows(b, sql, p) { return b.q(sql, p); }
function bundle(b, since) {
  return {
    events: rows(b, 'SELECT id, kind, gate, run, rowgate, text, roots, a, b FROM event WHERE id > ? ORDER BY id', [since]),
    encoder: rows(b, 'SELECT gate, word, role, born, sourced FROM encoder'),
    formula: rows(b, 'SELECT word, body, origin, t, ended FROM formula'),
    proc: rows(b, 'SELECT word, status, uses, right, wrong FROM proc'),
    run: rows(b, 'SELECT id, kind, word, parent, root, line, output, mark, recalled, memid, failed, t0, t1, expected, direction FROM run'),
    cells: rows(b, "SELECT v.id, v.run, v.name, v.value, v.src, v.t, s.asked, s.needed, s.wrong, s.setaside FROM var v LEFT JOIN sense s ON s.id = v.sense WHERE v.name NOT IN (':head', ':line', ':run', ':prev', ':speaker') OR v.value IS NOT NULL"),
    gaps: rows(b, 'SELECT run, need, fill, who, kind FROM gap'),
    trust: rows(b, "SELECT src, count(*), sum(kept), sum(aside), sum(total = 0) FROM sense WHERE src <> 'sql' GROUP BY src"),
    need: rows(b, 'SELECT w, n FROM need ORDER BY n DESC LIMIT 30'),
    defs: rows(b, "SELECT word, src, hw, text FROM definition WHERE src <> 'node'"),
    triggers: rows(b, "SELECT count(*) FROM sqlite_master WHERE type = 'trigger'")[0][0],
    tables: rows(b, "SELECT count(*) FROM sqlite_master WHERE type = 'table' AND name GLOB 'g[0-9]*'")[0][0]
  };
}
// the measure of a word: the line run again with it and without it, from the snapshot taken just before that line
var KINDS_GRAPH = { born: 'gates born', lay: 'DNA rows laid', rel: 'relations', memory: 'memory rows', timeline: 'timeline rows', state: 'state rows', taught: 'formula rows', derived: 'formula rows' };
function ledger(b, since) {
  var L = {}, G = {}, Q = {}, A = {}, cols = null;
  rows(b, 'SELECT kind, gate, roots, rowgate FROM event WHERE id > ?', [since]).forEach(function (e) {
    (e[2] || '').split(' ').filter(Boolean).forEach(function (r) { L[r] = (L[r] || 0) + 1; });
    if (KINDS_GRAPH[e[0]]) G[KINDS_GRAPH[e[0]]] = (G[KINDS_GRAPH[e[0]]] || 0) + 1;
    if (e[0] === 'lay') G['hop triggers'] = (G['hop triggers'] || 0) + 1;
    if (e[0] === 'input' && e[3] === null && e[1] && e[1] !== 'input') Q[e[1]] = (Q[e[1]] || 0) + 1;
    if (e[0] === 'mailbox') A[e[1]] = (A[e[1]] || 0) + 1;
  });
  return { silicon: L, graph: G, questions: Q, asks: A };
}
function diff(a, b) { var o = {}; Object.keys(a).concat(Object.keys(b)).forEach(function (k) { var v = (a[k] || 0) - (b[k] || 0); if (v) o[k] = v; }); return o; }
function lastBuildCols(b) { var r = rows(b, "SELECT cols FROM secondary WHERE src = 'sql' AND last = 1 ORDER BY id DESC LIMIT 1"); return r.length && r[0][0] ? r[0][0].split(',') : []; }
function contrast(i, word) {
  var line = LINES[i], toks = line.replace(/\s*=>.*$/, '').trim().split(/\s+/);
  if (toks.indexOf(word) < 0) return null;
  if (!SNAPS[i]) return { line: line, tooOld: true, silicon: {}, graph: {}, questions: {}, asks: {} };
  var expected = /=>/.test(line) ? line.split('=>')[1].trim() : null;
  var without = toks.filter(function (t) { return t !== word; }).join(' ') + (expected ? ' => ' + expected : '');
  var A = restore(SNAPS[i]), tA = rows(A, 'SELECT coalesce(max(id), 0) FROM event')[0][0], oa = A.type(line), ca = /^BUILD /.test(line) ? lastBuildCols(A) : null, la = ledger(A, tA); A.close();
  var B = restore(SNAPS[i]), tB = rows(B, 'SELECT coalesce(max(id), 0) FROM event')[0][0], ob = without.trim() ? B.type(without) : null, cb = /^BUILD /.test(without) ? lastBuildCols(B) : null, lb = ledger(B, tB); B.close();
  return { line: line, output: oa, outputWithout: ob, columns: ca ? { with: ca, without: cb || [] } : null, silicon: diff(la.silicon, lb.silicon), graph: diff(la.graph, lb.graph), questions: diff(la.questions, lb.questions), asks: diff(la.asks, lb.asks) };
}
function meaningOf(word) {
  var recs = [], runs = rows(brain, "SELECT id, input, recalled, memid FROM run WHERE kind = 'line' ORDER BY id"), byInput = {};
  runs.forEach(function (r) { byInput[r[1]] = r; });
  var inputs = rows(brain, "SELECT id, line FROM input WHERE kind = 'line' ORDER BY id");
  inputs.forEach(function (inp, i) {
    var line = LINES[i]; if (!line || /\s->\s/.test(line) || /^\S+\s=\s(?!>)/.test(line)) return;
    if (line.replace(/\s*=>.*$/, '').trim().split(/\s+/).indexOf(word) < 0) return;
    var r = byInput[inp[0]];
    if (r && r[2] === 1 && r[3]) {
      // answered from memory: the words point at that memory. Counted as the run that made it, plus the recall.
      var mrun = rows(brain, 'SELECT run, times FROM memory WHERE id = ?', [r[3]]), src = -1;
      if (mrun.length) { var srcInput = rows(brain, 'SELECT input FROM run WHERE id = ?', [mrun[0][0]]); inputs.forEach(function (x, j) { if (srcInput.length && x[0] === srcInput[0][0]) src = j; }); }
      var base = src >= 0 ? contrast(src, word) : null, rec = base ? JSON.parse(JSON.stringify(base)) : { silicon: {}, graph: {}, questions: {}, asks: {} };
      rec.line = line; rec.recalled = true; rec.memId = r[3]; rec.times = mrun.length ? mrun[0][1] : 1; rec.fromLine = src >= 0 ? LINES[src] : null;
      ['FIND', 'COMPARE', 'WRITE'].forEach(function (k) { rec.silicon[k] = (rec.silicon[k] || 0) + 1; }); rec.graph['memory recalls'] = (rec.graph['memory recalls'] || 0) + 1;
      recs.push(rec); return;
    }
    var c = contrast(i, word); if (c && !c.tooOld) recs.push(c); else if (c) recs.push({ line: line, tooOld: true, silicon: {}, graph: {}, questions: {}, asks: {} });
  });
  var agg = { silicon: {}, graph: {}, questions: {}, asks: {} };
  recs.forEach(function (c) { ['silicon', 'graph', 'questions', 'asks'].forEach(function (k) { Object.keys(c[k] || {}).forEach(function (x) { agg[k][x] = (agg[k][x] || 0) + c[k][x]; }); }); });
  var sum = function (o) { return Object.keys(o).reduce(function (a, k) { return a + Math.abs(o[k]); }, 0); }, tot = sum(agg.silicon) + sum(agg.graph) + sum(agg.questions) + sum(agg.asks) || 1;
  var f = rows(brain, 'SELECT body, origin FROM formula WHERE word = ? AND ended = 0', [word]);
  return { word: word, contexts: recs, ratios: { silicon: sum(agg.silicon) / tot, graph: sum(agg.graph) / tot, questions: sum(agg.questions) / tot, sources: sum(agg.asks) / tot }, aggregate: agg, formula: f.length ? { body: f[0][0], origin: f[0][1] } : null, defs: rows(brain, "SELECT src || ': ' || text FROM definition WHERE word = ? AND src <> 'node' LIMIT 8", [word]).map(function (x) { return x[0]; }) };
}
var SQLMOD = null;
onmessage = function (m) {
  var d = m.data;
  try {
    if (d.type === 'init') {
      TOLD = d.told; SAT = d.sat;
      initSqlJs().then(function (SQL) {
        SQLMOD = SQL; Neuron.init(SQL); brain = new Neuron.Brain(TOLD, SAT); SNAPS = []; keepSnap(snapshot()); LINES = [];
        var b = bundle(brain, 0); lastEvent = b.events.length ? b.events[b.events.length - 1][0] : 0; postMessage({ type: 'ready', bundle: b });
      }).catch(function (e) { postMessage({ type: 'error', error: String(e && e.message || e) }); });
    } else if (d.type === 'lines') {
      var t0 = Date.now(), outs = [];
      d.lines.forEach(function (l, k) {
        var t1 = Date.now(); LINES.push(l); var o = brain.type(l); outs.push(o); keepSnap(snapshot());
        var b = bundle(brain, lastEvent); if (b.events.length) lastEvent = b.events[b.events.length - 1][0];
        postMessage({ type: k === d.lines.length - 1 ? 'done' : 'line', line: l, output: o, k: k, of: d.lines.length, ms: Date.now() - t1, total: Date.now() - t0, bundle: b });
      });
    } else if (d.type === 'said') {
      LINES.push(d.line); var o = brain.type(d.line, 'said'); keepSnap(snapshot());
      var b2 = bundle(brain, lastEvent); if (b2.events.length) lastEvent = b2.events[b2.events.length - 1][0];
      postMessage({ type: 'done', outputs: [o], ms: 0, bundle: b2 });
    } else if (d.type === 'query') {
      postMessage({ type: 'answer', id: d.id, rows: rows(brain, d.sql, d.params || []) });
    } else if (d.type === 'measure') {
      postMessage({ type: 'measured', id: d.id, result: meaningOf(d.word) });
    } else if (d.type === 'restart') {
      brain.close(); brain = new Neuron.Brain(TOLD, SAT); SNAPS = []; keepSnap(snapshot()); LINES = []; lastEvent = 0;
      var b3 = bundle(brain, 0); lastEvent = b3.events.length ? b3.events[b3.events.length - 1][0] : 0; postMessage({ type: 'ready', bundle: b3, restarted: true });
    }
  } catch (e) { postMessage({ type: 'error', error: String(e && e.stack || e) }); }
};
