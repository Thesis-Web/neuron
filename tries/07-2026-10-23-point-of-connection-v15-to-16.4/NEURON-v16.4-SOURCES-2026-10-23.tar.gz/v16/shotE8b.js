const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const page = await browser.newPage({ viewport: { width: 1400, height: 900 } });
  const seen = []; page.on('console', m => { if (m.text().startsWith('OUT ')) seen.push(m.text()); });
  await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.includes('cdnjs.cloudflare.com') ? r.continue() : r.abort(); });
  await page.goto('file://' + process.argv[2]);
  await page.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 90000 });
  // record every busy text change, as a console line, from inside the page
  await page.evaluate(() => { const b = document.getElementById('busy'); new MutationObserver(() => console.log('OUT ' + b.textContent)).observe(b, { childList: true, characterData: true, subtree: true }); });
  const idle = () => page.waitForFunction(() => !window.__poc.busy(), null, { timeout: 600000 });
  const preset = async v => { await page.evaluate(v => [...document.querySelectorAll('#presets button')].find(b => b.textContent.indexOf(v) === 0).click(), v); await page.waitForTimeout(300); };
  await page.fill('#line', 'define store'); await page.press('#line', 'Enter'); await page.waitForTimeout(300); await idle();
  for (const p of ['E6 1', 'E6 2', 'E6 3', 'E6 4', 'E8 1', 'E8 2']) { await preset(p); await idle(); console.log(p, 'lastOutput =', JSON.stringify(await page.evaluate(() => window.__poc.lastOutput())).slice(0, 200)); }
  console.log(seen.filter(s => /said|stopped/.test(s)).join('\n'));
  await browser.close();
})().catch(e => { console.log('FATAL', e.message); process.exit(1); });
