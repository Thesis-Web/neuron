// can a brain's main database be snapshotted and restored, with its satellites re-attached, and run on identically?
const fs = require('fs'); const initSqlJs = require('../sqljs/sql-asm-memory-growth.js'); const { Neuron } = require('./host15.js');
const told = JSON.parse(fs.readFileSync('physics15.json', 'utf8')), sat = JSON.parse(fs.readFileSync('sat15.json', 'utf8'));
initSqlJs().then(SQL => {
  Neuron.init(SQL); let t = Date.now();
  const a = new Neuron.Brain(told, sat); a.type('define store'); a.type('like = INSERT INTO relation ( a , rel , b ) VALUES ( :subject , :head , :after ) ;');
  console.log('two lines', Date.now() - t, 'ms'); t = Date.now();
  const snap = a.db.export(); console.log('snapshot bytes', snap.length, Date.now() - t, 'ms');
  // restore: a Brain whose main database is the snapshot; satellites re-attached and reloaded
  t = Date.now();
  const b = Object.create(Neuron.Brain.prototype); b.told = told; b.SATS = told.sats; b.populated = [];
  b.db = new SQL.Database(snap);
  b.db.create_function('mother', (x, r, s) => b.mother(x, r, s)); b.db.create_function('satwork', (s, k, w, n) => { b.populated.push([s, k, w, n]); return 1; });
  told.sats.forEach(s => { b.db.run("ATTACH ':memory:' AS " + s); b.db.run("CREATE TABLE " + s + ".corpus (word TEXT, hw TEXT, text TEXT, words TEXT); CREATE INDEX " + s + ".cw ON corpus(word); CREATE TABLE " + s + ".inbox (ask INTEGER PRIMARY KEY, word TEXT); CREATE TABLE " + s + ".outbox (ask INTEGER, word TEXT, hw TEXT, text TEXT, words TEXT); CREATE TRIGGER " + s + ".work AFTER INSERT ON inbox BEGIN INSERT INTO outbox SELECT NEW.ask, NEW.word, hw, text, words FROM corpus WHERE word = NEW.word; SELECT satwork('" + s + "', NEW.ask, NEW.word, (SELECT count(*) FROM outbox WHERE ask = NEW.ask)); DELETE FROM inbox WHERE ask = NEW.ask; END;"); const st = b.db.prepare("INSERT INTO " + s + ".corpus VALUES (?, ?, ?, ?)"); (sat[s] || []).forEach(r => st.run([r[0], r[1], r[2], r[3]])); st.free(); });
  console.log('restore', Date.now() - t, 'ms');
  t = Date.now(); const oa = a.type('define shop'); console.log('original line', Date.now() - t, 'ms');
  t = Date.now(); const ob = b.type('define shop'); console.log('restored line', Date.now() - t, 'ms');
  const sig = x => JSON.stringify([x.q('SELECT count(*) FROM event')[0][0], x.q('SELECT count(*) FROM relation')[0][0], x.q("SELECT count(*) FROM sqlite_master WHERE type='trigger'")[0][0]]);
  console.log('same output', oa === ob, oa, '| same rows', sig(a) === sig(b), sig(a), sig(b));
}).catch(e => console.log('ERR', e.stack));
