const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
const file = process.argv[2], out = process.argv[3];
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const R = {}; const errs = [];
  async function open(opts) {
    const page = await browser.newPage(opts);
    page.on('pageerror', e => errs.push('pageerror: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text()); });
    await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.includes('cdnjs.cloudflare.com') ? r.continue() : r.abort(); });
    await page.goto('file://' + file); return page;
  }
  const page = await open({ viewport: { width: 1600, height: 950 } });
  const busyAll = []; page.on('console', m => { if (m.text().startsWith('BUSY ')) busyAll.push(m.text()); });
  let t = Date.now();
  await page.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 90000 });
  await page.evaluate(() => { const b = document.getElementById('busy'); new MutationObserver(() => console.log('BUSY ' + b.textContent)).observe(b, { childList: true, characterData: true, subtree: true }); });
  R.B1 = { readyMs: Date.now() - t, positions: Object.keys(await page.evaluate(() => window.__poc.positions())).length };
  await page.waitForTimeout(2500); await page.screenshot({ path: out + '-1-load.png' });
  const idle = async (ms) => { await page.waitForFunction(() => !window.__poc.busy(), null, { timeout: ms || 600000 }); };
  const preset = async (txt) => { await page.evaluate(v => { [...document.querySelectorAll('#presets button')].find(b => b.textContent.indexOf(v) === 0).click(); }, txt); await page.waitForTimeout(200); };
  // B2
  const busySeen = [];
  t = Date.now(); await page.fill('#line', 'define store'); await page.press('#line', 'Enter');
  const poll = setInterval(async () => { try { busySeen.push(await page.evaluate(() => document.getElementById('busy').textContent)); } catch (e) {} }, 1000);
  await idle(); clearInterval(poll);
  const kinds = await page.evaluate(() => { const o = {}; document.querySelectorAll('#log [data-t]'); return o; });
  R.B2 = { ms: Date.now() - t, busyTexts: [...new Set(busySeen)].slice(0, 4), busyEnd: await page.evaluate(() => document.getElementById('busy').textContent), kinds: await page.evaluate(() => window.__poc.kinds()) };
  await page.evaluate(() => { const s = document.getElementById('time'); s.value = s.max; s.dispatchEvent(new Event('input')); }); await page.waitForTimeout(1500);
  await page.screenshot({ path: out + '-2-define-store.png' });
  // B3
  await page.evaluate(() => { document.querySelector('aside.left').scrollTop = 200; document.querySelector('aside.right').scrollTop = 300; });
  const sc0 = await page.evaluate(() => [document.querySelector('aside.left').scrollTop, document.querySelector('aside.right').scrollTop]);
  const p0 = await page.evaluate(() => window.__poc.positions());
  await page.evaluate(() => { const c = document.querySelector('[data-rel="alike"]'); c.checked = false; c.dispatchEvent(new Event('change', { bubbles: true })); });
  await page.waitForTimeout(2000);
  const p1 = await page.evaluate(() => window.__poc.positions());
  const sc1 = await page.evaluate(() => [document.querySelector('aside.left').scrollTop, document.querySelector('aside.right').scrollTop]);
  await page.screenshot({ path: out + '-3-alike-off.png' });
  await page.evaluate(() => { const c = document.querySelector('[data-rel="alike"]'); c.checked = true; c.dispatchEvent(new Event('change', { bubbles: true })); });
  await page.waitForTimeout(2000);
  const p2 = await page.evaluate(() => window.__poc.positions());
  const move = (a, b) => { let s = 0, n = 0; for (const k in a) if (b[k]) { s += Math.hypot(a[k][0] - b[k][0], a[k][1] - b[k][1], a[k][2] - b[k][2]); n++; } return n ? s / n : 0; };
  R.B3 = { moveOff: move(p0, p1), moveOn: move(p1, p2), scrollBefore: sc0, scrollAfter: sc1 };
  // B4
  await page.evaluate(() => { const r = document.querySelector('[data-relw="opposite"]'); r.value = 0; r.dispatchEvent(new Event('input', { bubbles: true })); });
  await page.waitForTimeout(2000); const p3 = await page.evaluate(() => window.__poc.positions()); R.B4 = { move: move(p2, p3) };
  await page.evaluate(() => { const r = document.querySelector('[data-relw="opposite"]'); r.value = 1; r.dispatchEvent(new Event('input', { bubbles: true })); });
  // B5, B6
  const outs = [];
  for (const p of ['E6 1', 'E6 2', 'E6 3']) { t = Date.now(); await preset(p); await idle(); outs.push([p, Date.now() - t, await page.evaluate(() => document.getElementById('busy').textContent)]); }
  R.B5 = outs.slice(); R.B5b = { sql: (await page.evaluate(() => window.__poc.kinds())).sql || 0 };
  t = Date.now(); await preset('E6 4'); const seen4 = []; const poll4 = setInterval(async () => { try { seen4.push(await page.evaluate(() => document.getElementById('busy').textContent)); } catch (e) {} }, 500);
  await idle(); clearInterval(poll4); R.B6 = { ms: Date.now() - t, texts: [...new Set(seen4)], end: await page.evaluate(() => document.getElementById('busy').textContent) };
  await page.evaluate(() => { const s = document.getElementById('time'); s.value = s.max; s.dispatchEvent(new Event('input')); }); await page.waitForTimeout(1500);
  await page.screenshot({ path: out + '-4-e6.png' });
  // B11
  const e8 = [];
  for (const p of ['E8 1', 'E8 2']) { await preset(p); await idle(); e8.push(await page.evaluate(() => window.__poc.lastOutput())); }
  R.B11 = { e8_1_has_select: e8[0].indexOf("SELECT value FROM state WHERE key = 'self.name'") >= 0, e8_1_has_say: e8[0].indexOf("'neuron' )") >= 0, e8_2_same_as_e8_1: e8[1] === e8[0], len: [e8[0].length, e8[1].length] };
  // B10
  R.B10 = { is: (await page.evaluate(() => window.__poc.card('is'))).match(/levels of formula below it[^\n]*/), your: (await page.evaluate(() => window.__poc.card('your'))).match(/levels of formula below it[^\n]*/) };
  // B12: a truth shift moves the word
  const q0 = (await page.evaluate(() => window.__poc.positions()))['is'];
  await page.fill('#line', "is = INSERT INTO state ( key , value ) VALUES ( :key , :after ) ;"); await page.press('#line', 'Enter'); await idle();
  await page.evaluate(() => { const s = document.getElementById('time'); s.value = s.max; s.dispatchEvent(new Event('input')); });
  await page.waitForTimeout(3000); const q1 = (await page.evaluate(() => window.__poc.positions()))['is'];
  R.B12 = { before: q0, after: q1, move: q0 && q1 ? Math.hypot(q0[0] - q1[0], q0[1] - q1[1], q0[2] - q1[2]) : null };
  await page.screenshot({ path: out + '-6-truth-shift.png' });
  // B7
  await page.fill('#mword', 'your'); await page.click('#measure');
  await page.waitForFunction(() => !/measuring/.test(document.getElementById('meaning').textContent), null, { timeout: 600000 });
  R.B7 = (await page.evaluate(() => document.getElementById('meaning').innerText)).slice(0, 1500);
  await page.evaluate(() => { document.querySelector('aside.right').scrollTop = document.getElementById('meaning').offsetTop - 100; });
  await page.screenshot({ path: out + '-5-measure-your.png' });
  // B8: click the first visible ghost
  const ghost = await page.evaluate(() => window.__poc.screenOf(window.__poc.firstGhost()));
  if (ghost) { await page.mouse.click(ghost[0], ghost[1]); await page.waitForTimeout(500); }
  R.B8 = { ghost, sel: (await page.evaluate(() => document.getElementById('sel').innerText)).slice(0, 300) };
  await page.close();
  // B9
  for (const [name, opts] of [['light', { viewport: { width: 1400, height: 900 }, colorScheme: 'light' }], ['dark', { viewport: { width: 1400, height: 900 }, colorScheme: 'dark' }], ['phone', { viewport: { width: 400, height: 860 }, colorScheme: 'light' }]]) {
    const pg = await open(opts); await pg.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 90000 }); await pg.waitForTimeout(2000);
    R['B9-' + name] = await pg.evaluate(() => ({ scrollW: document.documentElement.scrollWidth, innerW: window.innerWidth }));
    await pg.screenshot({ path: out + '-9-' + name + '.png', fullPage: name === 'phone' }); await pg.close();
  }
  R.B13 = { onPage: busyAll.filter(t => /on the page itself/.test(t)).length, stopped: busyAll.filter(t => /brain stopped|deeper than this browser/.test(t)).length };
  R.errors = errs; console.log(JSON.stringify(R, null, 1)); await browser.close();
})().catch(e => { console.log('FATAL', e.message); process.exit(1); });
