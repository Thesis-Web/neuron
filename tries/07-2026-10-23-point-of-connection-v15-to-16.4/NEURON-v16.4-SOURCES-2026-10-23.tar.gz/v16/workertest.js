// run worker15.js in Node with a captured postMessage: init, three lines, then measure a word
const fs = require('fs'), D = process.argv[2], R = process.argv[3];
global.initSqlJs = require(R + '/sqljs/sql-asm-memory-growth.js');
global.Neuron = require(D + '/host15.js').Neuron; eval(fs.readFileSync(D + '/shared15.js', 'utf8').replace(/^function (\w+)/mg, 'global.$1 = function $1'));
const msgs = []; let waiters = [];
global.postMessage = m => { msgs.push(m); const w = waiters; waiters = []; w.forEach(f => f(m)); };
eval(fs.readFileSync(D + '/worker15.js', 'utf8').replace('var SQLMOD = null;', 'global.SQLMOD = null;').replace(/^onmessage = /m, 'global.onmessage = '));
let seen = 0;
const next = pred => new Promise(res => { while (seen < msgs.length) { const m = msgs[seen++]; if (pred(m)) return res(m); } const f = m => { seen = msgs.length; if (pred(m)) res(m); else waiters.push(f); }; waiters.push(f); });
(async () => {
  const told = JSON.parse(fs.readFileSync(D + '/physics15.json')), sat = JSON.parse(fs.readFileSync(D + '/sat15.json'));
  let t = Date.now(); onmessage({ data: { type: 'init', told, sat } });
  const r = await next(m => m.type === 'ready' || m.type === 'error'); if (r.type === 'error') throw new Error(r.error);
  console.log('ready in', Date.now() - t, 'ms; events', r.bundle.events.length, 'triggers', r.bundle.triggers);
  t = Date.now(); onmessage({ data: { type: 'lines', lines: ['cat sat', 'cat sat', 'BUILD SELECT 7 AS who ; BUILD'] } });
  const d = await next(m => m.type === 'done' || m.type === 'error'); if (d.type === 'error') throw new Error(d.error);
  console.log('3 lines in', Date.now() - t, 'ms; messages', msgs.map(m => m.type).join(','), '; last output', JSON.stringify(d.output));
  console.log('line outputs', msgs.filter(m => m.type === 'line' || m.type === 'done').map(m => m.output));
  onmessage({ data: { type: 'measure', id: 1, word: 'AS' } });
  const ms = await next(m => m.type === 'measured' || m.type === 'error'); if (ms.type === 'error') throw new Error(ms.error);
  console.log('AS measured:', JSON.stringify(ms.result.contexts.map(c => ({ line: c.line, out: c.output, without: c.outputWithout, cols: c.columns, silicon: c.silicon }))));
  onmessage({ data: { type: 'measure', id: 2, word: 'cat' } });
  const mc = await next(m => m.type === 'measured' || m.type === 'error'); if (mc.type === 'error') throw new Error(mc.error);
  console.log('cat measured:', JSON.stringify(mc.result.contexts.map(c => ({ line: c.line, recalled: !!c.recalled, from: c.fromLine, graph: c.graph }))), JSON.stringify(mc.result.ratios));
  onmessage({ data: { type: 'query', id: 3, sql: "SELECT count(*) FROM sqlite_master WHERE type = 'trigger'" } });
  const q = await next(m => m.type === 'answer'); console.log('triggers now', q.rows[0][0]);
})().catch(e => { console.log('FAIL', e.stack || e); process.exit(1); });
