import sys, time; sys.path.insert(0, '.')
from host15 import Brain
b = Brain('physics15.json', sat_path='sat15.json')
TRIG = "SELECT count(*) FROM sqlite_master WHERE type='trigger'"
b.con.execute("DELETE FROM formula WHERE word = 'source'")   # no source asks: time the run itself
def go(l, note):
    t = time.time(); n0 = b.q(TRIG)[0][0]; b.type(l); n1 = b.q(TRIG)[0][0]
    print(f'{note:44} {time.time()-t:7.3f}s  new triggers {n1 - n0:4d}  total {n1}')
line = 'the quick brown fox jumps over the lazy dog'
go(line, 'learning: a new 9-word line')
b.con.execute("UPDATE memory SET ended = 1")                   # forget the memory row so the line runs the long way again
go(line, 'use: the same line, every row already laid')
for i in range(6): go(' '.join(f'w{i}x{j}' for j in range(9)), f'learning: new line {i + 1} (9 new words)')
b.con.execute("UPDATE memory SET ended = 1")
go(line, 'use: the first line again, after the graph grew')
