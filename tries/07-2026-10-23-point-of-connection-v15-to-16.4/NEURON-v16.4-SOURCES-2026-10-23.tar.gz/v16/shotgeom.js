const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const page = await browser.newPage({ viewport: { width: 1600, height: 950 } });
  await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.includes('cdnjs.cloudflare.com') ? r.continue() : r.abort(); });
  await page.goto('file://' + process.argv[2]); await page.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 90000 });
  const geom = async (tag) => {
    await page.waitForTimeout(5000);
    const r = await page.evaluate(() => {
      const p = window.__poc.positions(), ks = Object.keys(p), n = ks.length, c = [0, 0, 0];
      ks.forEach(k => { for (let i = 0; i < 3; i++) c[i] += p[k][i] / n; });
      const sd = [0, 0, 0], mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9];
      ks.forEach(k => { for (let i = 0; i < 3; i++) { sd[i] += (p[k][i] - c[i]) ** 2 / n; mn[i] = Math.min(mn[i], p[k][i]); mx[i] = Math.max(mx[i], p[k][i]); } });
      const near = ks.filter(k => Math.hypot(...p[k]) < 2).length;
      let close = 0; for (let i = 0; i < Math.min(n, 400); i++) for (let j = i + 1; j < Math.min(n, 400); j++) if (Math.hypot(p[ks[i]][0] - p[ks[j]][0], p[ks[i]][1] - p[ks[j]][1], p[ks[i]][2] - p[ks[j]][2]) < 1.5) close++;
      return { points: n, centroid: c.map(v => +v.toFixed(1)), spread: sd.map(v => +Math.sqrt(v).toFixed(1)), min: mn.map(v => +v.toFixed(0)), max: mx.map(v => +v.toFixed(0)), within2ofOrigin: near, pairsCloserThan1_5_amongFirst400: close, originLines: window.__poc.linesOf('origin') };
    });
    console.log(tag, JSON.stringify(r));
  };
  await geom('load');
  await page.fill('#line', 'define store'); await page.press('#line', 'Enter'); await page.waitForTimeout(300); await page.waitForFunction(() => !window.__poc.busy(), null, { timeout: 600000 });
  await page.evaluate(() => { const s = document.getElementById('time'); s.value = s.max; s.dispatchEvent(new Event('input')); });
  await geom('after define store');
  await browser.close();
})();
