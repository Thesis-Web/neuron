const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const page = await browser.newPage({ viewport: { width: 1600, height: 950 } });
  await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.includes('cdnjs.cloudflare.com') ? r.continue() : r.abort(); });
  await page.goto('file://' + process.argv[2]); await page.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 90000 });
  const idle = () => page.waitForFunction(() => !window.__poc.busy(), null, { timeout: 900000 });
  const preset = async v => { await page.evaluate(v => [...document.querySelectorAll('#presets button')].find(b => b.textContent.indexOf(v) === 0).click(), v); await page.waitForTimeout(300); await idle(); };
  const geo = (tag) => page.evaluate((tag) => { const p = window.__poc.positions(), ks = Object.keys(p).filter(k => k !== 'origin'), n = ks.length, c = [0, 0, 0], neg = [0, 0, 0];
    ks.forEach(k => { for (let i = 0; i < 3; i++) { c[i] += p[k][i] / n; if (p[k][i] < 0) neg[i]++; } });
    return tag + ' points ' + n + ' centroid ' + c.map(v => v.toFixed(1)).join(',') + ' | share below 0 on x,y,z: ' + neg.map(v => Math.round(100 * v / n) + '%').join(' ') + ' | input ' + (p.input || []).map(v => v.toFixed(0)).join(','); }, tag);
  for (const p of ['define store']) { await page.fill('#line', p); await page.press('#line', 'Enter'); await page.waitForTimeout(300); await idle(); }
  for (const p of ['E6 1', 'E6 2', 'E6 3', 'E8', 'E10', 'E11']) await preset(p);
  await page.evaluate(() => { const s = document.getElementById('time'); s.value = s.max; s.dispatchEvent(new Event('input')); });
  for (const t of [2, 20, 60]) { await page.waitForTimeout(t === 2 ? 2000 : t === 20 ? 18000 : 40000); console.log(await geo('t=' + t + 's')); }
  console.log(JSON.stringify(await page.evaluate(() => { const p = window.__poc.positions(); return { originLines: window.__poc.linesOf('origin'), inputLines: window.__poc.linesOf('input') }; })));
  await browser.close();
})().catch(e => { console.log('FATAL', e.message); process.exit(1); });
