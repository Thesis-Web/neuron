(function () {
  var $ = function (id) { return document.getElementById(id); };
  function esc(s) { return String(s === null || s === undefined ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  var PHYSICS = TOLD.physics, ACTIONS = TOLD.actions, SQLROOTS = TOLD.sqlroots, SATS = TOLD.sats;
  var SATNAME = { wn: 'WordNet', gcide: 'Webster 1913', mw: 'MW Collegiate', mwt: 'MW thesaurus', moby: 'Moby', map: 'your map', sqldoc: 'SQLite docs' };
  var REL_OF = { like: 'alike', alike: 'alike', similar: 'similar', opposite: 'opposite', inverse: 'inverse', kind: 'is', class: 'is', has: 'has', part: 'part', before: 'before', after: 'after', topic: 'topic', context: 'context', category: 'category', method: 'method', use: 'use', supports: 'supports', contradicts: 'contradicts', derived: 'derived-from', includes: 'includes', begins: 'begins', ends: 'ends', present: 'present', plural: 'plural' };
  var REL_TYPES = [['made-of', 0.7, 'a word to the words of its formula, read back from the run that taught it'], ['sequence', 0.5, 'a DNA row: a word to the word after it in a run'],
    ['memory', 0.5, 'a word to the memory rows that hold it'], ['definition', 0.4, 'a word to the words of the definitions its sources gave'], ['answered', 0.4, 'a source brain to the words it answered'],
    ['carried', 0.3, 'mother or the SQL prompt to the words whose statements they carried'], ['does', 0.4, 'a physics step to the action words its told labels name (input does HEAR WRITE; mother does CALL MOVE...)'], ['state', 0.5, 'a word in a state key to state'], ['timeline', 0.3, 'a memory row to timeline'],
    ['alike', 1.0, 'synonym; in your map'], ['opposite', 1.0, 'antonym; in your map'], ['is', 0.9, 'kind, class; in your map'], ['includes', 0.9, ''], ['inverse', 0.9, ''], ['contradicts', 0.8, ''], ['supports', 0.7, ''], ['has', 0.7, 'in your map'], ['part', 0.7, ''], ['similar', 0.6, ''], ['prefix', 0.5, 'in your map'], ['begins', 0.5, ''], ['suffix', 0.5, 'in your map'], ['ends', 0.5, ''], ['stem', 0.5, 'in your map'], ['past', 0.5, 'in your map'], ['present', 0.5, ''], ['singular', 0.5, 'in your map'], ['plural', 0.5, ''], ['derived-from', 0.5, ''], ['use', 0.4, ''], ['before', 0.4, ''], ['after', 0.4, ''], ['topic', 0.3, ''], ['context', 0.3, ''], ['category', 0.3, ''], ['method', 0.3, '']];
  var REST = { does: 20, 'made-of': 16, sequence: 14, memory: 12, definition: 18, answered: 22, carried: 24, state: 14, timeline: 16, alike: 10, similar: 14, is: 22, includes: 22, has: 24, part: 24, opposite: 64, inverse: 64, contradicts: 64 };

  // ---- the brain lives in a worker; the page keeps what the brain's tables said, and its events in order
  var EV = [], FROWS = [], RUN = {}, ENC = {}, FORM = {}, PROC = {}, CELLS = [], GAPS = [], TRUST = [], NEED = [], DEFS = {}, DEFWORD = [], COUNTS = { triggers: 0, tables: 0 }, ready = false, busy = false, T = -1;
  var worker = new Worker(URL.createObjectURL(new Blob([$('engine-src').textContent + '\n' + $('worker-src').textContent], { type: 'text/javascript' })));
  var pending = {}, qid = 0;
  function ask(msg) { return new Promise(function (res) { msg.id = ++qid; pending[msg.id] = res; worker.postMessage(msg); }); }
  function absorb(b) {
    b.events.forEach(function (r) {
      var e = { t: EV.length, id: r[0], kind: r[1], gate: r[2], run: r[3], rowgate: r[4], text: r[5] || '', roots: (r[6] || '').split(' ').filter(Boolean), a: r[7], b: r[8] };
      if (e.kind === 'born') e.add = e.gate;
      if (e.kind === 'lay' && e.a) e.hop = [e.gate, e.a];
      if (e.kind === 'rel') { var rb = String(e.b || '').split('|'); e.rel = [e.gate, e.a, REL_OF[rb[0]] || rb[0], 'written by a run', parseFloat(rb[1]) || .6]; }
      if (e.kind === 'memory' && e.a) e.mem = { id: e.b, line: String(e.a) };
      if (e.kind === 'state' && e.a) e.st = e.a;
      if (e.kind === 'timeline') e.tl = e.a;
      EV.push(e);
    });
    RUN = {}; b.run.forEach(function (r) { RUN[r[0]] = { id: r[0], kind: r[1], word: r[2], parent: r[3], root: r[4], line: r[5], output: r[6], mark: r[7], recalled: r[8], memid: r[9], failed: r[10], t0: r[11], t1: r[12], expected: r[13], direction: r[14] }; });
    ENC = {}; b.encoder.forEach(function (r) { ENC[r[1]] = { gate: r[0], word: r[1], role: r[2], born: r[3], sourced: r[4] }; });
    FORM = {}; FROWS = b.formula; b.formula.forEach(function (r) { if (!r[4]) FORM[r[0]] = { body: r[1], origin: r[2] }; });
    PROC = {}; b.proc.forEach(function (r) { PROC[r[0]] = { status: r[1], uses: r[2], right: r[3], wrong: r[4] }; });
    CELLS = b.cells; GAPS = b.gaps; TRUST = b.trust; NEED = b.need; DEFWORD = b.defword || []; DEFS = {}; b.defs.forEach(function (r) { (DEFS[r[0]] = DEFS[r[0]] || []).push(r); });
    COUNTS = { triggers: b.triggers, tables: b.tables };
  }
  worker.onmessage = function (m) {
    var d = m.data;
    if (d.type === 'ready') { absorb(d.bundle); ready = true; fitLeft = 240; setBusy(''); if (d.restarted) { clearScene(); } render(EV.length - 1); return; }
    if (d.type === 'line' || d.type === 'done') {
      var first = EV.length; absorb(d.bundle);
      if (!playing || T < 0) { render(Math.min(first, EV.length - 1)); setPlay(true); } else render(T, true);
      lastOut = d.output || ''; OUTS.push(lastOut); var said = d.output === null || d.output === undefined ? 'nothing' : '"' + d.output + '"';
      var where = d.onMain ? ' on the page itself' : '';
      if (d.type === 'line') { setBusy('line ' + (d.k + 1) + ' of ' + d.of + ' ran' + where + ' in ' + (d.ms / 1000).toFixed(1) + ' s and said ' + said + '; running the next'); return; }
      busy = false; setBusy((d.of > 1 ? d.of + ' lines ran in ' + (d.total / 1000).toFixed(1) + ' s; the last said ' : 'the line ran' + where + ' in ' + (d.ms / 1000).toFixed(1) + ' s and said ') + said + '. ' + COUNTS.triggers + ' triggers in the brain now.');
      if (afterRun) { var f = afterRun; afterRun = null; f(); } return;
    }
    if (d.type === 'deep') {
      setBusy('The line "' + d.line + '" nests deeper than the page\'s background worker can follow: each new row is laid, then the line retries through mother one level deeper, and the worker\'s stack is the smallest in the browser. The brain was put back as it stood before the line. The line now runs on the page itself, which has more stack: the page is still until it finishes.');
      setTimeout(function () {
        mainEngine().then(function (SQL) {
          var t = Date.now(), b = restoreBrain(SQL, TOLD, SAT, d.bytes), out, bytes;
          try { out = b.type(d.line); bytes = exportBrain(b, SAT); b.close(); }
          catch (e) { try { b.close(); } catch (e2) {} busy = false; setBusy('The line "' + d.line + '" nests deeper than this browser can follow even on the page itself. The brain is as it stood before the line; nothing of it was kept. Real SQLite outside a browser has the stack for it.'); return; }
          worker.postMessage({ type: 'adopt', bytes: bytes, line: d.line, output: out, ms: Date.now() - t, rest: d.rest }, [bytes.buffer]);
        }).catch(function (e) { busy = false; setBusy('The page could not start SQLite on its own thread: ' + e); });
      }, 80);
      return;
    }
    if (d.type === 'failed') { busy = false; setBusy('SQLite refused the line "' + d.line + '": ' + d.error + '. The brain was put back as it stood before the line.'); return; }
    if (d.type === 'answer' || d.type === 'measured') { var r = pending[d.id]; delete pending[d.id]; if (r) r(d.type === 'answer' ? d.rows : d.result); return; }
    if (d.type === 'error') { setBusy('the brain stopped: ' + d.error); busy = false; }
  };
  worker.postMessage({ type: 'init', told: TOLD, sat: SAT });
  function setBusy(t) { $('busy').textContent = t; }
  // the same SQLite and host code as the worker, started on the page's own thread only when a line needs its bigger stack
  var MAINSQL = null;
  function mainEngine() { if (MAINSQL) return MAINSQL; (0, eval)($('engine-src').textContent); MAINSQL = initSqlJs().then(function (SQL) { Neuron.init(SQL); return SQL; }); return MAINSQL; }

  // ---- the stage
  var hasGL = true, renderer, scene, camera;
  try { if (!window.THREE) throw new Error('no three'); renderer = new THREE.WebGLRenderer({ canvas: $('c'), antialias: true }); } catch (e) { hasGL = false; $('err').style.display = 'flex'; }
  if (hasGL) { renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2)); scene = new THREE.Scene(); scene.background = new THREE.Color(0x0c0e12); camera = new THREE.PerspectiveCamera(40, 1, 1, 400000); }
  function hash(s) { var h = 2166136261; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function unit(seed) { var a = (hash('a' + seed) / 4294967296) * 2 * Math.PI, z = (hash('z' + seed) / 4294967296) * 2 - 1, r = Math.sqrt(1 - z * z); return new THREE.Vector3(r * Math.cos(a), r * Math.sin(a), z); }
  function fib(i, n, r) { var y = 1 - (i / Math.max(1, n - 1)) * 2, rad = Math.sqrt(Math.max(0, 1 - y * y)), th = i * 2.399963; return new THREE.Vector3(Math.cos(th) * rad * r, y * r, Math.sin(th) * rad * r); }
  // one placed word: origin, at the center (owner, 2026-10-23). Every other point sits only where its relationship lines pull it: no push, no shell.
  var FIXED = { origin: [0, 0, 0] };
  var LABEL = {}; SATS.forEach(function (s) { LABEL[s] = SATNAME[s] || s; });
  var NOTE = { input: 'primary input: a typed line lands here, the input table, and its trigger starts the run.', encoder: 'the encoder table: word to gate number, by its own recursive trigger; a word with no gate is born.', OUTPUT: 'output to use: where a run\'s answer goes, back to you.', 'output to sources': 'output to sources: the stmt table. A statement a run decoded at its ";" waits here; its trigger hands it to mother.', 'secondary input': 'secondary input: the secondary table. What mother brings back lands here, as a sub-input of the run that asked; its triggers check it before anything uses it.', mother: 'mother: the one routine beside SQLite. She runs the text she is handed at the SQL prompt, or carries it into a source brain\'s inbox; when that brain says its outbox is populated she picks it up and empties it. She decides nothing. Her code is printed in the rail.', 'SQL prompt': 'the SQL prompt: SQLite itself. mother hands it text; it runs it; its answer goes back through her.' };
  var HIDE = { 'output to sources': 1, 'secondary input': 1, OUTPUT: 1 };   // the ports are DNA rows and triggers of input and output, not points of their own
  var DOERS = { physics: 1, port: 1, sat: 1 };
  function roleOf(w) { if (String(w).indexOf('mem:') === 0) return 'memory'; var e = ENC[w]; return e ? e.role : 'ghost'; }
  function fixedPos(w) { return FIXED[w] ? new THREE.Vector3(FIXED[w][0], FIXED[w][1], FIXED[w][2]) : null; }
  var dotGeo = hasGL ? new THREE.SphereGeometry(1, 10, 10) : null, dotGroup, labelGroup, relGroup, hopGroup, runGroup, memGroup, flash, flashGeo;
  if (hasGL) { dotGroup = new THREE.Group(); labelGroup = new THREE.Group(); relGroup = new THREE.Group(); hopGroup = new THREE.Group(); runGroup = new THREE.Group(); memGroup = new THREE.Group(); [dotGroup, labelGroup, relGroup, hopGroup, runGroup, memGroup].forEach(function (g) { scene.add(g); }); flashGeo = new THREE.BufferGeometry(); flash = new THREE.LineSegments(flashGeo, new THREE.LineBasicMaterial({ color: 0xfff1a8, transparent: true, opacity: .95 })); scene.add(flash); }
  var NODE = {};   // name -> {mesh, label, pos (Vector3), fixed (bool), ghost (bool)}
  function colorOf(w, ghost) {
    if (ghost) return 0x8b95a2; var r = roleOf(w), f = FORM[w]; if (w === 'origin') return 0xfff1a8; if (r === 'memory') return 0x7ed07e;
    if (r === 'root') return 0xffffff; if (r === 'sqlroot') return 0xbfe3ff; if (r === 'sat') return 0x8fd3c1; if (r === 'port' || r === 'arrival') return 0xffffff; if (r === 'physics') return 0x9aa3ad;
    if (f) return f.origin && f.origin !== 'told' ? 0xffc98a : 0xf28c4b; if (r === 'literal' || r === 'var') return 0x7d8794; return DEFS[w] ? 0x8ea3b8 : 0x6f7a86;
  }
  function sizeOf(w, ghost) { if (ghost) return .55; if (w === 'origin') return 2.4; var r = roleOf(w); return r === 'memory' ? .8 : r === 'sat' ? 2.4 : r === 'port' ? 2.0 : 1.0; }
  // a label keeps its size on screen (px tall), whatever the zoom or the spacing; it sits just above its point
  function makeLabel(text, css, px, centered) { var c = document.createElement('canvas'), ctx = c.getContext('2d'); ctx.font = '500 26px "IBM Plex Mono", Consolas, monospace'; var w = Math.ceil(ctx.measureText(text).width) + 14; c.width = w; c.height = 36; ctx.font = '500 26px "IBM Plex Mono", Consolas, monospace'; ctx.fillStyle = css; ctx.textBaseline = 'middle'; ctx.fillText(text, 7, 18); var tex = new THREE.CanvasTexture(c); tex.minFilter = THREE.LinearFilter; var sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false, opacity: .92, sizeAttenuation: false })); if (!centered) sp.center.set(.5, -.35); sp.userData.px = px; sp.userData.aspect = w / 36; sizeLabel(sp); return sp; }
  function stageH() { return (renderer && renderer.domElement.clientHeight) || 800; }
  function sizeLabel(sp) { var y = sp.userData.px * 0.728 / stageH(); sp.scale.set(y * sp.userData.aspect, y, 1); }
  function ensureNode(w, ghost) {
    var n = NODE[w];
    if (n && n.ghost && !ghost) { dotGroup.remove(n.mesh); n.mesh.material.dispose(); if (n.label) { labelGroup.remove(n.label); n.label.material.map.dispose(); n.label.material.dispose(); } n = null; }
    if (!n) {
      // a new point has no place until its lines give it one: it waits at origin and is placed beside its neighbours once the lines are known
      var fp = fixedPos(w), old = NODE[w] && NODE[w].pos, p = fp || old || new THREE.Vector3(0, 0, 0);
      n = NODE[w] = { pos: p.clone(), fixed: !!fp, ghost: !!ghost, unplaced: !fp && !old };
      if (hasGL) {
        var col = colorOf(w, ghost), r = sizeOf(w, ghost), role = roleOf(w);
        n.mesh = new THREE.Mesh(dotGeo, new THREE.MeshBasicMaterial({ color: col, transparent: true, opacity: ghost ? .4 : .92 })); n.mesh.scale.setScalar(r); n.mesh.position.copy(n.pos); n.mesh.userData = { base: r, gate: w }; dotGroup.add(n.mesh);
        var big = role === 'sat' || w === 'origin';
        if (!ghost) n.label = makeLabel(role === 'memory' ? 'memory ' + w.slice(4) : (LABEL[w] || w), '#' + ('000000' + col.toString(16)).slice(-6), big ? 15 : ghost ? 10 : 12); if (n.label) { n.label.userData.dx = 0; n.label.position.copy(n.pos); labelGroup.add(n.label); }
      }
    } else if (hasGL) n.mesh.material.color.setHex(colorOf(w, n.ghost));
    return n;
  }
  function clearScene() { Object.keys(NODE).forEach(function (w) { var n = NODE[w]; if (hasGL) { dotGroup.remove(n.mesh); if (n.label) labelGroup.remove(n.label); } }); NODE = {}; }
  function ghostLabel(n, w, on) { if (!hasGL) return; if (on && !n.label) { n.label = makeLabel(w, '#8b95a2', 10); labelGroup.add(n.label); } if (n.label) n.label.visible = on; }
  // the owner's full map, indexed once: a word (any case) to its entries, an entry to its lines
  var MAPLOW = {}, MAPADJ = {}, MAPLINES = [];
  (function () { if (!MAP) return; MAP.names.forEach(function (w, i) { var l = w.toLowerCase(); (MAPLOW[l] = MAPLOW[l] || []).push(i); });
    for (var i = 0; i < MAP.edges.length; i += 3) { var a = MAP.edges[i], b = MAP.edges[i + 1], r = MAP.edges[i + 2]; (MAPADJ[a] = MAPADJ[a] || []).push([b, r, 0]); (MAPADJ[b] = MAPADJ[b] || []).push([a, r, 1]); } })();

  // ---- the relation kinds, the pull law, the settle
  var REL_COL = { does: 0xe8e2a0, 'made-of': 0xf28c4b, sequence: 0xd8d4c8, memory: 0x7ed07e, definition: 0x8ea3b8, answered: 0x8fd3c1, carried: 0xc9b6e4, state: 0xf0b429, timeline: 0x9aa3ad, alike: 0x4f9bd9, opposite: 0xe0573f, is: 0x9b7bd4, includes: 0xb59ae0, inverse: 0xd97b4f, contradicts: 0xc24f8a, supports: 0x4fb7a8, has: 0x6fa8dc, part: 0x8cb8e0, similar: 0x7fc2e8, prefix: 0xa8a070, begins: 0x5fc89a, suffix: 0xb0a860, ends: 0x4fb8c0, stem: 0x98a860, past: 0x8fb070, present: 0xe09ab8, singular: 0x90b888, plural: 0xe0a060, 'derived-from': 0xd0a050, use: 0xc8b070, before: 0x70b0c0, after: 0x60a0b8, topic: 0x909cb0, context: 0x98a4b8, category: 0xa0acc0, method: 0xa8b4c8 };
  function hexOf(r) { return '#' + ('000000' + (REL_COL[r] || 0x9aa3ad).toString(16)).slice(-6); }
  // a direction per kind: which way a line of that kind pulls its second word from its first. The owner chooses; opposite, inverse and contradicts start across origin.
  var DIRS = [['', 'any way'], ['x', 'east +x'], ['-x', 'west -x'], ['y', 'north +y'], ['-y', 'south -y'], ['z', 'up +z'], ['-z', 'down -z'], ['across', 'across origin']];
  var DEFAULT_DIR = { opposite: 'across', inverse: 'across', contradicts: 'across' };
  function dirVec(d) { if (!d || d === 'across') return null; var v = new THREE.Vector3(); v.setComponent({ x: 0, y: 1, z: 2 }[d.slice(-1)], d[0] === '-' ? -1 : 1); return v; }
  var RELSET = {}; REL_TYPES.forEach(function (r) { RELSET[r[0]] = { on: true, w: r[1], dir: DEFAULT_DIR[r[0]] || '' }; });
  (function () {
    var h = ''; REL_TYPES.forEach(function (r) { var k = r[0]; h += '<input type="checkbox" data-rel="' + k + '" checked aria-label="' + k + ' on or off"><span class="sw" style="background:' + hexOf(k) + '"></span><span title="' + esc(r[2]) + '">' + k + '</span><input type="range" min="0" max="1" step="0.05" value="' + r[1] + '" data-relw="' + k + '" aria-label="' + k + ' pull"><span class="n" id="rc-' + k + '">0</span>'
      + '<select class="dir" data-reldir="' + k + '" aria-label="' + k + ' direction">' + DIRS.map(function (d) { return '<option value="' + d[0] + '"' + ((DEFAULT_DIR[k] || '') === d[0] ? ' selected' : '') + '>' + d[1] + '</option>'; }).join('') + '</select>'; });
    $('reltypes').innerHTML = h;
    $('reltypes').addEventListener('change', function (e) { var k = e.target.getAttribute('data-rel'); if (k) { RELSET[k].on = e.target.checked; render(T, true); reshape(); } });
    $('reltypes').addEventListener('change', function (e) { var k = e.target.getAttribute('data-reldir'); if (k) { RELSET[k].dir = e.target.value; render(T, true); reshape(); } });
    $('reltypes').addEventListener('input', function (e) { var k = e.target.getAttribute('data-relw'); if (k) { RELSET[k].w = parseFloat(e.target.value); render(T, true); reshape(); } });
    $('spacing').addEventListener('input', function () { SP = parseFloat($('spacing').value); $('spv').textContent = '\u00d7' + SP; drawAxes(true); });
    $('axes').addEventListener('change', function () { drawAxes(true); });
    $('gap').addEventListener('input', function () { GAP = parseFloat($('gap').value); $('gapv').textContent = GAP; reshape(); });
    $('fitall').addEventListener('click', function () { userZoomed = false; fitLeft = 120; });
    ['bgmap', 'mapall', 'ghostlabels', 'runmode'].forEach(function (id) { $(id).addEventListener('change', function () { render(T, true); if (id === 'bgmap' || id === 'mapall') reshape(); }); });
  })();
  var SPRINGS = [];
  var LOWER = {};   // a word as written in a line, to its point (one gate per word, whatever the case)
  function key(w) { if (w === undefined || w === null) return null; w = String(w); return NODE[w] ? w : (LOWER[w.toLowerCase()] || null); }
  function buildSprings(V) {
    LOWER = {}; Object.keys(NODE).forEach(function (w) { var l = w.toLowerCase(); if (!LOWER[l] || !NODE[LOWER[l]].ghost) LOWER[l] = w; });
    var agg = {}, held = {};
    function add(a, b, kind, trust, dim) { a = key(a); b = key(b); if (!a || !b || a === b) return; var id = kind + '|' + (a < b ? a + '|' + b : b + '|' + a); if (!agg[id]) agg[id] = [a, b, kind, trust, dim, 0]; agg[id][5]++; }
    V.rels.forEach(function (e) { if (!e[1]) return; add(e[0], e[1], e[2], e[4] || .6, false); held[e[2] + '|' + e[0] + '|' + e[1]] = held[e[2] + '|' + e[1] + '|' + e[0]] = 1; });
    Object.keys(V.formAt).forEach(function (w) { var seen = {}; V.formAt[w].body.split(/\s+/).forEach(function (tok) { if (!tok || seen[tok]) return; seen[tok] = 1; add(w, tok, 'made-of', 1, false); }); });
    V.hops.forEach(function (p) { add(p[0], p[1], 'sequence', 1, false); });
    V.memLines.forEach(function (x) { String(x.line || '').split(/\s+/).forEach(function (w) { if (w) add('mem:' + x.id, w, 'memory', 1, false); }); });
    DEFWORD.forEach(function (d) { if (V.present[key(d[0])] && V.present[key(d[1])]) add(d[0], d[1], 'definition', .6, false); });
    Object.keys(DEFS).forEach(function (w) { if (!V.present[key(w)]) return; var seen = {}; DEFS[w].forEach(function (d) { if (!seen[d[1]]) { seen[d[1]] = 1; add(d[1], w, 'answered', 1, false); } }); });
    V.carried.forEach(function (c) { add(c[0], c[1], 'carried', 1, false); });
    V.does.forEach(function (c) { add(c[0], c[1], 'does', 1, false); });
    V.stLines.forEach(function (k) { String(k).split('.').forEach(function (w) { add(w, 'state', 'state', 1, false); }); });
    V.tlLines.forEach(function (id) { add('mem:' + id, 'timeline', 'timeline', 1, false); });
    if ($('mapall').checked) MAPLINES.forEach(function (l) { add(l[0], l[1], l[2], .8, true); });
    if ($('bgmap').checked) (SLICE.edges || []).forEach(function (e) { if (!held[e[2] + '|' + e[0] + '|' + e[1]]) add(e[0], e[1], e[2], .8, true); });
    var lines = Object.keys(agg).map(function (id) { return agg[id]; }), count = {};
    lines.forEach(function (l) { count[l[2]] = (count[l[2]] || 0) + 1; });
    REL_TYPES.forEach(function (r) { var c = $('rc-' + r[0]); if (c) { var nh = lines.filter(function (l) { return l[2] === r[0] && !l[4]; }).length; c.textContent = nh + (count[r[0]] - nh > 0 ? ' +' + (count[r[0]] - nh) : ''); } });
    var vis = function (w) { var n = NODE[w]; return n && (!hasGL || n.mesh.visible); };
    // the pull law: the kind's pull (its slider), times the line's trust, times how much of that kind the brain holds; a line laid again pulls harder
    SPRINGS = lines.filter(function (l) { return RELSET[l[2]] && RELSET[l[2]].on && vis(l[0]) && vis(l[1]); }).map(function (l) {
      return { a: NODE[l[0]], b: NODE[l[1]], k: RELSET[l[2]].w * l[3] * (.5 + .5 * Math.min(1, count[l[2]] / 40)) * (1 + Math.log(l[5])) * (l[4] ? .6 : 1), rest: REST[l[2]] || 30, kind: l[2], dim: l[4], names: [l[0], l[1]], dir: RELSET[l[2]].dir === 'across' ? 'across' : dirVec(RELSET[l[2]].dir) }; });
    placeNew();
    return lines;
  }
  // a point with no place yet goes beside the points it is tied to; with none, it stays at origin until a line pulls it out
  function placeNew() {
    var nb = {}; SPRINGS.forEach(function (sp) { (nb[sp.names[0]] = nb[sp.names[0]] || []).push(sp.b); (nb[sp.names[1]] = nb[sp.names[1]] || []).push(sp.a); });
    for (var pass = 0; pass < 4; pass++) Object.keys(NODE).forEach(function (w) {
      var n = NODE[w]; if (!n.unplaced) return; var placed = (nb[w] || []).filter(function (m) { return !m.unplaced; }); if (!placed.length && pass < 3) return;
      var c = new THREE.Vector3(); placed.forEach(function (m) { c.add(m.pos); }); if (placed.length) c.multiplyScalar(1 / placed.length);
      n.pos.copy(c.add(unit('u' + w).multiplyScalar(placed.length ? 4 : 1))); n.unplaced = false;
    });
  }
  var STEP = 0;
  function settle(steps) {
    // springs only: no push between points, no pull toward any shell (owner, 2026-10-23). origin alone is fixed.
    for (var s = 0; s < steps; s++) {
      STEP++;
      SPRINGS.forEach(function (sp) { sp.a.f = sp.a.f || new THREE.Vector3(); sp.b.f = sp.b.f || new THREE.Vector3(); sp.a.f.set(0, 0, 0); sp.b.f.set(0, 0, 0); });
      SPRINGS.forEach(function (sp) {
        var f;
        if (sp.dir === 'across') {
          // origin on the line between them: each is pulled toward the mirror of the other through origin, and toward its rest distance apart
          var ma = sp.b.pos.clone().negate().sub(sp.a.pos).multiplyScalar(sp.k * ACROSS), mb = sp.a.pos.clone().negate().sub(sp.b.pos).multiplyScalar(sp.k * ACROSS);
          if (!sp.a.fixed) sp.a.f.add(ma); if (!sp.b.fixed) sp.b.f.add(mb);
          var d0 = sp.b.pos.clone().sub(sp.a.pos), L0 = d0.length() || .01; f = d0.multiplyScalar(sp.k * (L0 - sp.rest) / L0 * .04);
        } else if (sp.dir) {
          // a direction: B wants to sit at A plus rest along it
          f = sp.a.pos.clone().add(sp.dir.clone().multiplyScalar(sp.rest)).sub(sp.b.pos).multiplyScalar(-sp.k * .04);
        } else { var d = sp.b.pos.clone().sub(sp.a.pos), L = d.length() || .01; f = d.multiplyScalar(sp.k * (L - sp.rest) / L * .04); }
        if (!sp.a.fixed) sp.a.f.add(f); if (!sp.b.fixed) sp.b.f.sub(f);
      });
      // one scale for every point's step, never a cap per point: a cap per point breaks the balance of paired pulls and the whole cloud drifts
      var fl = []; SPRINGS.forEach(function (sp) { fl.push(sp.a.f.length(), sp.b.f.length()); }); fl.sort(function (a, b) { return a - b; });
      var p95 = fl.length ? fl[Math.floor(fl.length * .95)] : 0, sc = p95 > 4 ? 4 / p95 : 1;
      SPRINGS.forEach(function (sp) { [sp.a, sp.b].forEach(function (n) { if (n.fixed || n.moved === STEP) return; n.moved = STEP; var s = n.f.clone().multiplyScalar(sc); if (s.length() > 6) s.setLength(6); n.pos.add(s); }); });
      if (GAP > 0) for (var cp = 0; cp < PASSES; cp++) spaceApart();
    }
  }
  // the space between points (owner, 10-23: "make the space between each point more"): any two points closer than GAP are moved apart along the line between them
  var GAP = 15, ACROSS = .25, PASSES = 3;   // the across pull and the spacing passes per step: set by measurement (BROWSER16.expect.md)
  function spaceApart() {
    var pts = Object.keys(NODE).map(function (w) { return NODE[w]; }).filter(function (n) { return !hasGL || n.mesh.visible; }), cell = {}, g = GAP;
    pts.forEach(function (n) { var k = Math.floor(n.pos.x / g) + ',' + Math.floor(n.pos.y / g) + ',' + Math.floor(n.pos.z / g); (cell[k] = cell[k] || []).push(n); });
    pts.forEach(function (n) {
      var cx = Math.floor(n.pos.x / g), cy = Math.floor(n.pos.y / g), cz = Math.floor(n.pos.z / g);
      for (var i = -1; i <= 1; i++) for (var j = -1; j <= 1; j++) for (var k = -1; k <= 1; k++) (cell[(cx + i) + ',' + (cy + j) + ',' + (cz + k)] || []).forEach(function (o) {
        if (o === n || n.fixed || o.fixed) return;
        var d = n.pos.clone().sub(o.pos), L = d.length();
        if (L >= g) return;
        if (L < 1e-6) { d = unit('s' + (n.label ? n.label.uuid : '') + (o.label ? o.label.uuid : '')); L = 1e-6; }
        var push = d.normalize().multiplyScalar((g - L) / 2);
        if (n.fixed) o.pos.sub(push.multiplyScalar(2)); else if (o.fixed) n.pos.add(push.multiplyScalar(2)); else { n.pos.add(push); o.pos.sub(push); }
      });
    });
  }
  // the graph moves to its new balance over the next frames, so the move is seen
  var reshapeLeft = 0; function reshape() { if (!hasGL) return; settle(40); reshapeLeft = 90; }
  function composition(lines) {
    var adj = {}; function add(r, a, b) { adj[r] = adj[r] || {}; (adj[r][a] = adj[r][a] || {})[b] = 1; }
    lines.forEach(function (l) { if (!RELSET[l[2]] || !RELSET[l[2]].on) return; add(l[2], l[0], l[1]); if (l[2] === 'alike' || l[2] === 'opposite') add(l[2], l[1], l[0]); });
    var rels = Object.keys(adj), out = [];
    rels.forEach(function (r1) { rels.forEach(function (r2) { var n = 0, back = 0, hit = {}; Object.keys(adj[r1]).forEach(function (a) { Object.keys(adj[r1][a]).forEach(function (b) { var m2 = adj[r2][b]; if (!m2) return; Object.keys(m2).forEach(function (c) { if (c === a) { back++; return; } n++; rels.forEach(function (r3) { if (adj[r3][a] && adj[r3][a][c]) hit[r3] = (hit[r3] || 0) + 1; }); }); }); }); if (n || back) { var best = Object.keys(hit).sort(function (x, y) { return hit[y] - hit[x]; })[0]; out.push([r1, r2, n, back, best || null, best ? hit[best] : 0]); } }); });
    var h = '<tr><th>R1 then R2</th><th>paths</th><th>back</th><th>lands on</th></tr>';
    out.sort(function (a, b) { return b[2] - a[2]; }).slice(0, 10).forEach(function (r) { h += '<tr><td><span style="color:' + hexOf(r[0]) + '">' + r[0] + '</span> then <span style="color:' + hexOf(r[1]) + '">' + r[1] + '</span></td><td>' + r[2] + '</td><td>' + r[3] + '</td><td>' + (r[4] ? '<span style="color:' + hexOf(r[4]) + '">' + r[4] + '</span> ' + (r[2] ? Math.round(100 * r[5] / r[2]) + '%' : '') : '<span class="f">none</span>') + '</td></tr>'; });
    $('comp').innerHTML = out.length ? h : '<tr><td class="f">No two lines join yet.</td></tr>';
  }
  function drawLines(group, segs) { while (group.children.length) { var c = group.children.pop(); c.geometry.dispose(); c.material.dispose(); } Object.keys(segs).forEach(function (key) { var sg = segs[key]; if (!sg.pts.length) return; group.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(sg.pts), new THREE.LineBasicMaterial({ color: sg.color, transparent: true, opacity: sg.opacity }))); }); }

  // ---- the view at tick T, replayed from the physics' own events
  function viewAt(t) {
    var V = { present: {}, born: {}, formula: {}, rels: [], hops: [], carried: [], does: [], memLines: [], stLines: [], tlLines: [], rows: {}, ledger: {}, mems: 0, tl: 0, mother: 0, asks: 0, lays: 0, aside: 0, waits: 0, cur: null, root: null };
    ACTIONS.forEach(function (r) { V.ledger[r] = 0; });
    Object.keys(ENC).forEach(function (w) { if (!ENC[w].born) V.present[w] = 1; });
    for (var i = 0; i <= t && i < EV.length; i++) {
      var e = EV[i];
      if (e.add) { V.present[e.add] = 1; V.born[e.add] = 1; }
      if (e.hop) V.hops.push(e.hop); if (e.rel) V.rels.push(e.rel);
      if (e.rowgate) (V.rows[e.run] = V.rows[e.run] || []).push(e.rowgate);
      if (e.mem) V.memLines.push(e.mem); if (e.st) V.stLines.push(e.st); if (e.tl) V.tlLines.push(e.tl);
      var dg = e.rowgate || e.gate; if (e.roots.length && dg && (DOERS[roleOf(dg)] || dg === 'mother' || dg === 'SQL prompt')) e.roots.forEach(function (r) { if (!HIDE[dg]) V.does.push([dg, r]); });
      if ((e.kind === 'mother' || e.kind === 'sql') && e.run && RUN[e.run] && RUN[e.run].kind === 'formula') V.carried.push([e.kind === 'sql' ? 'SQL prompt' : 'mother', RUN[e.run].word]);
      if (e.kind === 'memory') V.mems++; if (e.kind === 'timeline') V.tl++; if (e.kind === 'mailbox') V.asks++; if (e.kind === 'waiting') V.waits++; if (e.kind === 'lay') V.lays++;
      if (e.kind === 'mother' || e.kind === 'pickup' || e.kind === 'born' || e.kind === 'lay') V.mother++;
      if (e.kind === 'taught' || e.kind === 'derived') V.formula[e.gate] = e.kind;
      e.roots.forEach(function (r) { V.ledger[r] = (V.ledger[r] || 0) + 1; });
    }
    V.cur = t >= 0 ? EV[t] : null;
    // the formula each word held at this tick: the latest row written before it (a truth shift ends the old row and adds a new one)
    var curId = V.cur ? V.cur.id : 0; V.formAt = {}; FROWS.forEach(function (r) { if (r[3] < curId) V.formAt[r[0]] = { body: r[1], origin: r[2] }; });
    if (V.cur && V.cur.run && RUN[V.cur.run]) V.root = RUN[V.cur.run].root;
    return V;
  }
  function route(gs) { var out = []; gs.forEach(function (g) { if (HIDE[g]) return; if (g !== out[out.length - 1]) out.push(g); }); return out; }
  var curView = null;
  function render(t, keep) {
    if (!ready) return;
    T = t; var V = viewAt(t); curView = V;
    if (hasGL) {
      Object.keys(V.present).forEach(function (w) { if (HIDE[w]) return; var n = ensureNode(w, false); n.mesh.visible = n.label.visible = true; });
      var memOn = RELSET.memory.on || RELSET.timeline.on, memSeen = {}; V.memLines.forEach(function (x) { memSeen['mem:' + x.id] = 1; if (memOn) { var n = ensureNode('mem:' + x.id, false); n.mesh.visible = true; n.label.visible = false; } });
      Object.keys(NODE).forEach(function (w) { if (w.indexOf('mem:') === 0 && (!memOn || !memSeen[w])) { NODE[w].mesh.visible = false; if (NODE[w].label) NODE[w].label.visible = false; } });
      var bg = $('bgmap').checked, gl = $('ghostlabels').checked;
      // the owner's full map: every line of every word the brain holds; a far end the brain does not hold is a dim point
      MAPLINES = []; var mapOn = $('mapall').checked, mapSeen = {};
      if (mapOn) { var presentLow = {}; Object.keys(V.present).forEach(function (w) { presentLow[w.toLowerCase()] = w; });
        Object.keys(presentLow).forEach(function (lw) { (MAPLOW[lw] || []).forEach(function (id) { (MAPADJ[id] || []).forEach(function (e) {
          var other = MAP.names[e[0]], ol = other.toLowerCase(), rel = MAP.rels[e[1]], from = presentLow[lw], to = presentLow[ol] || other;
          if (!presentLow[ol]) { mapSeen[other] = 1; var gn = ensureNode(other, true); gn.mesh.visible = true; ghostLabel(gn, other, gl); }
          MAPLINES.push(e[2] ? [to, from, rel] : [from, to, rel]); }); }); }); }
      Object.keys(SLICE.words || {}).forEach(function (w) { if (V.present[w]) return; if (bg) { var n = ensureNode(w, true); n.mesh.visible = true; ghostLabel(n, w, gl); } else if (NODE[w] && NODE[w].ghost && !mapSeen[w]) { NODE[w].mesh.visible = false; if (NODE[w].label) NODE[w].label.visible = false; } });
      Object.keys(NODE).forEach(function (w) { if (!NODE[w].ghost && w.indexOf('mem:') !== 0 && (!V.present[w] || HIDE[w]) && NODE[w].mesh) { NODE[w].mesh.visible = false; if (NODE[w].label) NODE[w].label.visible = false; } });
      var lines = buildSprings(V); composition(lines);
      if (!keep) settle(30);
      var segs = {}; SPRINGS.forEach(function (sp) { var key = sp.kind + (sp.dim ? ':d' : ''); if (!segs[key]) segs[key] = { pts: [], color: REL_COL[sp.kind] || 0x9aa3ad, opacity: sp.dim ? .12 : .22 }; segs[key].pts.push(sp.a.pos, sp.b.pos); });
      relSegs = segs;
      runPaths = []; var mode = $('runmode').value;
      if (mode !== 'none') Object.keys(V.rows).forEach(function (rid) { var R = RUN[rid], mine = R && R.root === V.root; if (mode === 'cur' && !mine) return; var gs = route(V.rows[rid]).filter(function (g) { return NODE[g] && NODE[g].mesh.visible; }); if (gs.length < 2) return; runPaths.push({ rid: rid, nodes: gs.map(function (g) { return NODE[g]; }), branch: R && R.kind !== 'line', mine: mine, cur: V.cur && String(V.cur.run) === String(rid) }); });
      Object.keys(NODE).forEach(function (w) { var n = NODE[w]; if (n.mesh) n.mesh.userData.hot = false; });
      flashPts = [];
      if (V.cur) { var g = V.cur.rowgate || V.cur.gate; if (g && NODE[g] && NODE[g].mesh) { NODE[g].mesh.userData.hot = true; V.cur.roots.forEach(function (r) { if (NODE[r]) flashPts.push([NODE[g], NODE[r]]); }); } }
    }
    var n = EV.length;
    $('readout').textContent = n ? 'tick ' + Math.max(0, t) + ' of ' + (n - 1) : 'tick 0 of 0';
    $('time').max = Math.max(0, n - 1); $('time').value = Math.max(0, t);
    if (V.cur) { $('now').innerHTML = '<span class="k">tick ' + V.cur.t + ' · ' + esc(V.cur.kind) + (V.cur.run ? ' · run ' + V.cur.run : '') + (V.cur.roots.length ? ' · ' + V.cur.roots.join(' ') : '') + '</span><span>' + esc(V.cur.text) + '</span>'; $('hud').innerHTML = '<b>tick ' + V.cur.t + ' of ' + (n - 1) + '</b><span class="ev">' + esc(V.cur.text.length > 180 ? V.cur.text.slice(0, 177) + '\u2026' : V.cur.text) + '</span>'; }
    else { $('now').innerHTML = '<span class="k">this step</span><span>Nothing has happened. Type a line.</span>'; $('hud').innerHTML = '<b>' + (n ? 'before the first tick' : 'the told block is laid; nothing typed yet') + '</b>'; }
    renderLog(t); renderCells(V); renderGaps(V); renderCounts(V); renderLedger(V); renderProcs(); renderTrust();
  }
  var relSegs = {}, memSegs = {}, hopSegs = {}, runPaths = [], flashPts = [];
  // SPACING, drawing only: every drawn position is the brain's position times SP, outward from origin. The brain's places and lines are untouched.
  var fitLeft = 0, SP = 21, axesGroup = hasGL ? new THREE.Group() : null, axesL = 0, axesSP = 0; if (hasGL) scene.add(axesGroup);
  function drawAxes(force) {
    if (!hasGL) return;
    var on = $('axes').checked; axesGroup.visible = on; if (!on) return;
    var r = 30; Object.keys(NODE).forEach(function (w) { var n = NODE[w]; if (n.mesh && n.mesh.visible) r = Math.max(r, n.pos.length()); });
    var L = Math.ceil(r * 1.1 / 10) * 10;
    if (!force && L === axesL && SP === axesSP) return; axesL = L; axesSP = SP;
    while (axesGroup.children.length) { var c = axesGroup.children.pop(); if (c.geometry) c.geometry.dispose(); if (c.material) { if (c.material.map) c.material.map.dispose(); c.material.dispose(); } }
    [[0, 0xd9725f, 'x'], [1, 0x8fcf8f, 'y'], [2, 0x7fa8e0, 'z']].forEach(function (ax) {
      var pts = [], i = ax[0], e = function (v) { var p = new THREE.Vector3(); p.setComponent(i, v * SP); return p; };
      pts.push(e(-L), e(L));
      for (var t = -L; t <= L; t += 10) { if (t === 0) continue; var a = e(t), b = e(t), d = 1.2 * SP, o = (i + 1) % 3; a.setComponent(o, -d); b.setComponent(o, d); pts.push(a, b); }
      var line = new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineBasicMaterial({ color: ax[1], transparent: true, opacity: .28, depthTest: false })); line.renderOrder = 999; axesGroup.add(line);
      var col = '#' + ('000000' + ax[1].toString(16)).slice(-6);
      [['+' + ax[2], L], ['-' + ax[2], -L]].forEach(function (lb) { var s = makeLabel(lb[0], col, 14, true); s.material.opacity = .6; s.position.copy(e(lb[1] * 1.05)); s.renderOrder = 999; axesGroup.add(s); });
      for (var u = -L + 10; u < L; u += 10) { if (u === 0) continue; var s2 = makeLabel(String(u), col, 10, true); s2.material.opacity = .5; s2.position.copy(e(u)); s2.renderOrder = 999; axesGroup.add(s2); }
    });
  }
  function redrawLines() {
    if (!hasGL) return;
    var rs = {}; Object.keys(relSegs).forEach(function (k) { rs[k] = { pts: relSegs[k].pts.map(function (p) { return p.clone().multiplyScalar(SP); }), color: relSegs[k].color, opacity: relSegs[k].opacity }; }); drawLines(relGroup, rs);
    while (runGroup.children.length) { var c = runGroup.children.pop(); c.geometry.dispose(); c.material.dispose(); }
    runPaths.forEach(function (rp) { var line = new THREE.Line(new THREE.BufferGeometry().setFromPoints(rp.nodes.map(function (n) { return n.pos.clone().multiplyScalar(SP).add(unit('j' + rp.rid).multiplyScalar(1.2)); })), new THREE.LineBasicMaterial({ color: rp.branch ? 0xf28c4b : 0xf2efe6, transparent: true, opacity: rp.mine ? (rp.cur ? 1 : .85) : .3 })); line.userData.run = rp.rid; runGroup.add(line); });
    var fp = []; flashPts.forEach(function (p) { fp.push(p[0].pos.clone().multiplyScalar(SP), p[1].pos.clone().multiplyScalar(SP)); }); flashGeo.dispose(); flashGeo = new THREE.BufferGeometry().setFromPoints(fp); flash.geometry = flashGeo; flash.visible = fp.length > 0;
  }
  function renderLog(t) { var log = $('log'), a = Math.max(0, t - 30), b = Math.min(EV.length - 1, Math.max(t, 0) + 30), h = ''; for (var i = a; i <= b; i++) { var e = EV[i]; if (!e) continue; h += '<div class="' + (i === t ? 'cur ' : '') + e.kind + '" data-t="' + i + '"><span class="t">' + i + '</span><span class="k">' + esc(e.kind) + '</span><span>' + esc(e.text.length > 170 ? e.text.slice(0, 167) + '…' : e.text) + '</span></div>'; } log.innerHTML = h || '<div><span class="note">Nothing yet.</span></div>'; var cur = log.querySelector('.cur'); if (cur) log.scrollTop = cur.offsetTop - log.clientHeight / 2 + cur.offsetHeight / 2; }
  $('log').addEventListener('click', function (e) { var d = e.target.closest('[data-t]'); if (d) render(parseInt(d.getAttribute('data-t'), 10)); });
  function renderCells(V) {
    var el = $('cells'); if (!V.root) { el.innerHTML = '<tr><td class="f">Nothing yet.</td></tr>'; return; }
    var curId = V.cur ? V.cur.id : 0, runs = {}; Object.keys(RUN).forEach(function (k) { if (RUN[k].root === V.root) runs[k] = 1; });
    var h = '<tr><th>cell</th><th>value at this tick</th><th>check</th></tr>', open = 0, any = false;
    CELLS.forEach(function (c) { if (!runs[c[1]] || c[5] > curId) return; any = true; var filled = c[3] !== null; if (!filled) open++; h += '<tr><td>' + esc(c[2]) + '</td><td class="' + (filled ? '' : 'e') + '">' + (filled ? esc(c[3]) : '∅ empty') + (filled && c[4] ? ' <span class="f">← ' + esc(c[4]) + '</span>' : '') + '</td><td class="f">' + (c[6] ? 'asked for: ' + esc(c[6]) + '. needed: ' + esc(c[7]) + '. asked wrong: ' + esc(c[8]) + (c[9] ? '. set aside: ' + esc(c[9]) : '') : '') + '</td></tr>'; });
    el.innerHTML = any ? h + '<tr><td colspan="3" class="f">' + (open ? open + ' cell(s) empty' : 'every opened cell is filled') + '</td></tr>' : '<tr><td class="f">Run ' + V.root + ' has opened no cell.</td></tr>';
  }
  function renderGaps(V) { var el = $('gaps'), seen = {}, h = ''; GAPS.forEach(function (g) { if (g[0] !== V.root || seen[g[1]]) return; seen[g[1]] = 1; h += '<div class="gap"><div>' + esc(g[1]) + '</div><div class="who">fill: ' + esc(g[2]) + ' · by: ' + esc(g[3]) + '</div></div>'; }); el.innerHTML = h || '<span class="note">' + (V.root ? 'Nothing in run ' + V.root + '.' : 'Nothing yet.') + '</span>'; }
  function renderCounts(V) {
    var told = 0, born = 0, wf = 0; Object.keys(V.present).forEach(function (k) { if (V.born[k]) { born++; if (FORM[k]) wf++; } else told++; });
    var items = [[told, 'hand-laid gates'], [born, 'gates born'], [wf, 'born, with a formula'], [V.lays, 'DNA rows, each its own trigger'], [V.rels.length, 'relation rows'], [V.mems, 'memories'], [V.tl, 'timeline rows'], [V.mother, 'mother carries'], [V.asks, 'asks to sources'], [V.waits, 'asks waiting'], [COUNTS.triggers, 'triggers in SQLite now'], [COUNTS.tables, 'neuron tables now']];
    $('counts').innerHTML = items.map(function (it) { return '<div class="stat"><b>' + it[0].toLocaleString() + '</b><span>' + it[1] + '</span></div>'; }).join('');
  }
  var ledgerEl = $('ledger'); ACTIONS.forEach(function (r) { ledgerEl.insertAdjacentHTML('beforeend', '<span>' + r + '</span><div class="bar"><i id="lb-' + r + '"></i></div><span class="n" id="ln-' + r + '">0</span>'); });
  function renderLedger(V) { var mx = 1; ACTIONS.forEach(function (r) { if (V.ledger[r] > mx) mx = V.ledger[r]; }); ACTIONS.forEach(function (r) { $('lb-' + r).style.width = (100 * (V.ledger[r] || 0) / mx) + '%'; $('ln-' + r).textContent = (V.ledger[r] || 0).toLocaleString(); }); }
  function renderTrust() { var h = '<tr><th>source</th><th>asked</th><th>kept</th><th>set aside</th><th>empty</th></tr>'; TRUST.forEach(function (t) { h += '<tr><td>' + esc(SATNAME[t[0]] || t[0]) + '</td><td>' + t[1] + '</td><td class="ok">' + t[2] + '</td><td class="e">' + t[3] + '</td><td>' + t[4] + '</td></tr>'; }); $('trust').innerHTML = TRUST.length ? h : '<tr><td class="f">No source asked yet.</td></tr>'; }
  function renderProcs() {
    var h = '<tr><th>word</th><th>status</th><th>tested</th><th>formula</th></tr>';
    PHYSICS.forEach(function (p) { h += '<tr><td>' + p + '</td><td><span class="badge b-told">told</span></td><td></td><td class="f">a physics table with its own triggers, hand laid</td></tr>'; });
    Object.keys(FORM).forEach(function (w) { var p = PROC[w] || {}, st = p.status || 'taught'; h += '<tr><td>' + esc(w) + '</td><td><span class="badge b-' + esc(st) + '">' + esc(st) + '</span></td><td style="white-space:nowrap">' + ((p.right || p.wrong) ? (p.right || 0) + ' right, ' + (p.wrong || 0) + ' wrong' : '') + '</td><td style="font-family:var(--mono);font-size:.7rem">' + esc(FORM[w].body) + '</td></tr>'; });
    $('procs').innerHTML = h;
  }

  // ---- typing, presets
  var afterRun = null, lastOut = '', OUTS = [];
  function send(lines, then) { if (!ready || busy) return; busy = true; afterRun = then || null; setBusy('the brain is running ' + (lines.length > 1 ? lines.length + ' lines' : 'the line') + ': the physics is SQLite, so a line that brings new words, which sources answer, takes seconds'); worker.postMessage({ type: 'lines', lines: lines }); }
  function typeLine() { var v = $('line').value.trim(); if (!v) return; $('line').value = ''; send([v]); }
  $('run').addEventListener('click', typeLine); $('line').addEventListener('keydown', function (e) { if (e.key === 'Enter') typeLine(); });
  var SAYF = 'INSERT INTO say ( run , text ) VALUES ( :run , :found ) ;';
  var LIKE = 'INSERT INTO relation ( a , rel , b ) VALUES ( :subject , :head , :after ) ;';
  /*E6PRESETS*/
  var PRESETS = [
    ['define store (the told source row asks all seven)', ['define store']],
    ['teach like, opposite, kind (my lines)', ['like = ' + LIKE, 'opposite = ' + LIKE, 'kind = ' + LIKE]],
    ['define store again (the memory had gaps; it reopens)', ['define store']],
    ['teach derive and deduce (my lines)', ["derive = INSERT INTO formula ( word , run , origin ) SELECT :subject , run , 'derived' FROM formula WHERE ended = 0 AND word IN ( SELECT b FROM relation WHERE a = :subject AND rel = 'like' ) AND NOT EXISTS ( SELECT 1 FROM formula WHERE word = :subject ) LIMIT 1 ;", "deduce = INSERT INTO formula ( word , run , origin ) SELECT :subject , run , 'deduced' FROM formula WHERE ended = 0 AND word IN ( SELECT b FROM relation WHERE a = :subject AND rel = 'kind' ) AND NOT EXISTS ( SELECT 1 FROM formula WHERE word = :subject ) LIMIT 1 ;"]],
    ['define as: sources answer other words', ['source = INSERT INTO gcide.inbox ( word ) VALUES ( :subject ) ; INSERT INTO mw.inbox ( word ) VALUES ( :subject ) ; INSERT INTO mwt.inbox ( word ) VALUES ( :subject ) ;', 'define as']],
    ['AS, measured in two places', ["BUILD SELECT 'a brain' AS who ; BUILD", "BUILD SELECT CAST ( '7' AS INTEGER ) ; BUILD"], function () { $('mword').value = 'AS'; measure('AS'); }],
    ['a failed ask steps back to another row', ['who = SELECT value FROM state WHERE key = :after ; ' + SAYF, 'what = SELECT answer FROM memory WHERE line = :after ; ' + SAYF, 'who are -> what', 'sky => blue', 'who sky']],
    ['SQL roots by mother: CREATE, INSERT, SELECT, DELETE', ['BUILD CREATE TABLE things ( a ) ; BUILD', 'BUILD INSERT INTO things VALUES ( 1 ) ; BUILD', 'BUILD INSERT INTO things VALUES ( 2 ) ; BUILD', 'BUILD SELECT a FROM things ; BUILD', 'BUILD DELETE FROM things ; BUILD']],
    ['the same line twice: the second is a memory hop', ['cat sat', 'cat sat']]
  ].concat(E6PRESETS);
  PRESETS.forEach(function (p) { var b = document.createElement('button'); b.type = 'button'; b.textContent = p[0]; b.addEventListener('click', function () { send(p[1], p[2]); }); $('presets').appendChild(b); });
  $('restart').addEventListener('click', function () { if (!ready || busy) return; ready = false; EV = []; T = -1; setBusy('starting over: laying the told block'); worker.postMessage({ type: 'restart' }); });

  // ---- transport
  var playing = false, acc = 0;
  function setPlay(v) { playing = v; $('play').setAttribute('aria-pressed', String(v)); $('play').textContent = v ? 'pause' : 'play'; }
  $('back').addEventListener('click', function () { setPlay(false); if (T > 0) render(T - 1); });
  $('fwd').addEventListener('click', function () { setPlay(false); if (T < EV.length - 1) render(T + 1); });
  $('play').addEventListener('click', function () { setPlay(!playing); if (playing && T >= EV.length - 1) render(0); });
  $('time').addEventListener('input', function () { setPlay(false); render(parseInt($('time').value, 10)); });
  var spinning = false; $('spin').addEventListener('click', function () { spinning = !spinning; $('spin').setAttribute('aria-pressed', String(spinning)); });

  // ---- selection and the measured meaning
  var selEl = $('sel');
  function clearSel() { selEl.innerHTML = '<span class="m">Click a dot or a line in the stage.</span>'; }
  function pct(x) { return Math.round(x * 100) + '%'; }
  function fmtDelta(o) { var ks = Object.keys(o || {}).filter(function (k) { return o[k]; }); return ks.length ? ks.map(function (k) { return esc(k) + ' ' + (o[k] > 0 ? '+' : '') + o[k]; }).join(', ') : 'nothing'; }
  function measure(w) {
    var el = $('meaning'); if (!w) return; el.innerHTML = '<span class="m">measuring ' + esc(w) + ': each line it was in runs again, from the brain as it stood before that line, with and without it…</span>';
    ask({ type: 'measure', word: w }).then(function (m) {
      if (!m.contexts.length) { el.innerHTML = '<b>' + esc(w) + '</b><span class="m">has not been in a typed line yet, so nothing can be measured.</span>'; return; }
      var h = '<b>' + esc(w) + '</b><span class="m">measured over ' + m.contexts.length + ' line(s): the difference it makes.</span>';
      h += '<div class="meter" style="margin:4px 0"><i style="width:' + pct(m.ratios.silicon) + ';background:var(--accent)"></i><i style="width:' + pct(m.ratios.graph) + ';background:var(--taught)"></i><i style="width:' + pct(m.ratios.questions) + ';background:var(--learned)"></i><i style="width:' + pct(m.ratios.sources) + ';background:var(--derived)"></i></div>';
      h += '<span class="m">silicon ' + pct(m.ratios.silicon) + ' · graph, memory, time ' + pct(m.ratios.graph) + ' · questions ' + pct(m.ratios.questions) + ' · sources asked ' + pct(m.ratios.sources) + '</span>';
      h += '<span class="mono">silicon: ' + fmtDelta(m.aggregate.silicon) + '</span><span class="mono">graph, memory, time: ' + fmtDelta(m.aggregate.graph) + '</span><span class="mono">formulas it fires: ' + fmtDelta(m.aggregate.questions) + '</span><span class="mono">sources it asks: ' + fmtDelta(m.aggregate.asks) + '</span>';
      if (m.formula) h += '<span class="mono" style="color:#f28c4b">made of (' + esc(m.formula.origin) + '): ' + esc(m.formula.body) + '</span>';
      m.contexts.forEach(function (c) {
        if (c.tooDeep) { h += '<span class="mono"><span class="m">in</span> "' + esc(c.line) + '" <span class="m">: too deep to re-run in the page\'s worker</span></span>'; return; }
        if (c.tooOld) { h += '<span class="mono"><span class="m">in</span> "' + esc(c.line) + '" <span class="m">: too old to re-run here (the page keeps the brain as it stood before each of the last 24 lines)</span></span>'; return; }
        if (c.recalled) { h += '<span class="mono"><span class="m">in</span> "' + esc(c.line) + '" <span class="m">answered from memory ' + c.memId + ' (times ' + c.times + '): counted as the run that made it, "' + esc(c.fromLine || '') + '", plus the recall.</span></span>'; return; }
        h += '<span class="mono"><span class="m">in</span> "' + esc(c.line) + '" <span class="m">says</span> "' + esc(c.output) + '" <span class="m">; without it</span> "' + esc(c.outputWithout) + '"' + (c.columns ? ' <span class="m">; columns</span> ' + esc(c.columns.with.join(',')) + ' <span class="m">against</span> ' + esc(c.columns.without.join(',') || 'none') : '') + '</span>';
      });
      if (m.defs.length) h += '<span class="mono"><span class="m">definition rows kept:</span> ' + esc(m.defs.join('; ')) + '</span>';
      el.innerHTML = h;
    });
  }
  $('measure').addEventListener('click', function () { measure($('mword').value.trim()); });
  $('mword').addEventListener('keydown', function (e) { if (e.key === 'Enter') measure($('mword').value.trim()); });
  function showNode(w) {
    var n = NODE[w]; if (!n) return;
    if (n.ghost) { selEl.innerHTML = '<b>' + esc(w) + '</b><span class="m">a word of your relation map, not yet born in this brain. Its place comes from your map\'s lines alone. It has no meaning here yet.</span>'; return; }
    var e = ENC[w] || {}, role = e.role || 'word', h = '<b>' + esc(LABEL[w] || w) + '</b>';
    var roleText = { root: 'a physical action, hand laid', sqlroot: 'an SQL word, hand laid; its source is the SQLite docs', physics: 'a physics table with its own triggers, hand laid', port: esc(NOTE[w] || ''), sat: 'a source brain: its own database, a corpus, an inbox, an outbox, and its own trigger. A stand-in, fetched 2026-10-22.', arrival: 'an arrival gate: the first row of a line arrives from it', literal: 'a value written in a line', var: 'a hole, filled from the run', prime: 'a prime, born by typing; what it does is not told' }[role] || 'a word, born by typing';
    h += '<span class="m">' + roleText + (NOTE[w] && role !== 'port' ? ' ' + esc(NOTE[w]) : '') + '</span>';
    if (FORM[w]) h += '<span class="mono" style="color:#f28c4b">made of (' + esc(FORM[w].origin) + '): ' + esc(FORM[w].body) + '</span>';
    if (curView && curView.formAt[w]) { var L = levels(w, curView.formAt); h += '<span class="mono"><span class="m">levels of formula below it, down to the roots:</span> ' + L.n + (L.unknown.length ? ' <span class="m">; words in it with no formula yet, counted as 0:</span> ' + esc(L.unknown.join(', ')) : '') + '</span>'; }
    if (E6MEASURED[w]) h += '<span class="mono"><span class="m">measured in E6:</span> ' + esc(E6MEASURED[w][0]) + ' <span class="m">Forced by: ' + esc(E6MEASURED[w][1]) + '</span></span>';
    (DEFS[w] || []).slice(0, 6).forEach(function (d) { h += '<span class="mono">' + esc(SATNAME[d[1]] || d[1]) + (d[2] && d[2] !== w ? ' (' + esc(d[2]) + ')' : '') + ': ' + esc(String(d[3]).slice(0, 160)) + '</span>'; });
    selEl.innerHTML = h + '<span class="m" id="rowsfor">reading its DNA rows from SQLite…</span>';
    if (e.gate) ask({ type: 'query', sql: 'SELECT shard, (SELECT word FROM encoder WHERE gate = arrival), (SELECT word FROM encoder WHERE gate = remainder), (SELECT word FROM encoder WHERE gate = trigger), times FROM g' + e.gate + ' ORDER BY times DESC LIMIT 10' }).then(function (rows) { var el = $('rowsfor'); if (!el) return; el.className = 'mono'; el.innerHTML = rows.length ? 'its table g' + e.gate + ', DNA rows (arrival → remainder, trigger, times), each with its own trigger in SQLite: ' + esc(rows.map(function (r) { return 's' + r[0] + ' (' + r[1] + ' → ' + (r[2] || 'end') + ')' + (r[3] ? ' → ' + r[3] : '') + ' ×' + r[4]; }).join(', ')) : 'its table g' + e.gate + ' holds no DNA rows yet'; });
    if (role === 'word' || role === 'prime' || role === 'sqlroot') { $('mword').value = w; }
  }
  var ROOTROLES = { root: 1, sqlroot: 1, physics: 1, port: 1, arrival: 1, sat: 1 };
  function levels(w, formAt) {
    var memo = {}, unknown = {};
    function lv(x, stack) {
      if (memo[x] !== undefined) return memo[x];
      if (/^:/.test(x) || /^'/.test(x) || /^[0-9]/.test(x) || ROOTROLES[roleOf(x)]) return (memo[x] = 0);
      if (!formAt[x] || stack[x]) { if (!formAt[x]) unknown[x] = 1; return (memo[x] = 0); }
      stack[x] = 1; var mx = 0; formAt[x].body.split(/\s+/).forEach(function (t) { if (t && t !== x) mx = Math.max(mx, lv(t, stack)); }); delete stack[x];
      return (memo[x] = 1 + mx);
    }
    var n = lv(w, {}); delete unknown[w]; return { n: n, unknown: Object.keys(unknown) };
  }
  function readingHTML(rd) {
    if (!rd) return '';
    var sg = function (x) { return x[0] + ' ' + (x[1] >= 0 ? '+' : '') + x[1].toFixed(2); };
    var s = '<span class="mono"><span class="m">where its place reads, the 14 actions as the only known meanings (E5: not yet better than chance, p = 0.42; a pull, not a meaning):</span>';
    if (rd.map) s += ' your map: ' + rd.map.map(sg).join(', ') + ';';
    if (rd.use) s += ' the brain\'s use: ' + rd.use.map(sg).join(', ');
    return s + '</span>';
  }

  // ---- camera, pointer, frame
  var theta = 0, phi = 1.45, dist = 160, tgt = hasGL ? new THREE.Vector3(0, 0, 0) : null;   // the camera looks at origin
  function updateCam() { camera.position.set(tgt.x + dist * Math.sin(phi) * Math.sin(theta), tgt.y + dist * Math.cos(phi), tgt.z + dist * Math.sin(phi) * Math.cos(theta)); camera.lookAt(tgt); }
  window.__poc = { ready: function () { return ready; }, busy: function () { return busy; }, events: function () { return EV.length; }, positions: function () { var o = {}; Object.keys(NODE).forEach(function (w) { if (NODE[w].mesh && NODE[w].mesh.visible) o[w] = [NODE[w].pos.x, NODE[w].pos.y, NODE[w].pos.z]; }); return o; }, springs: function () { return SPRINGS.length; },
    kinds: function () { var o = {}; EV.forEach(function (e) { o[e.kind] = (o[e.kind] || 0) + 1; }); return o; },
    lastOutput: function () { return lastOut; },
    drawn: function () { var o = {}; Object.keys(NODE).forEach(function (w) { var n = NODE[w]; if (n.mesh && n.mesh.visible) o[w] = [n.mesh.position.x, n.mesh.position.y, n.mesh.position.z]; }); return o; },
    axes: function () { return hasGL ? axesGroup.children.length : 0; },
    screenDist: function (a, b) { var r = $('c').getBoundingClientRect(), p = function (w) { var v = NODE[w].mesh.position.clone().project(camera); return [(v.x + 1) / 2 * r.width, (1 - v.y) / 2 * r.height]; }, A = p(a), B = p(b); return Math.hypot(A[0] - B[0], A[1] - B[1]); },
    roles: function () { var o = {}; Object.keys(NODE).forEach(function (w) { o[w] = NODE[w].ghost ? 'your map' : roleOf(w); }); return o; },
    stretch: function () { var s = 0; SPRINGS.forEach(function (sp) { s += Math.abs(sp.a.pos.distanceTo(sp.b.pos) - sp.rest) / sp.rest; }); return SPRINGS.length ? s / SPRINGS.length : 0; },
    closest: function () { var ks = Object.keys(NODE).filter(function (w) { return !hasGL || NODE[w].mesh.visible; }), best = 1e9; for (var i = 0; i < ks.length; i++) for (var j = i + 1; j < ks.length; j++) { var d = NODE[ks[i]].pos.distanceTo(NODE[ks[j]].pos); if (d < best) best = d; } return best; },
    lonely: function () { var linked = {}; SPRINGS.forEach(function (sp) { linked[sp.names[0]] = 1; linked[sp.names[1]] = 1; }); var far = 0, n = 0; Object.keys(NODE).forEach(function (w) { var x = NODE[w]; if (linked[w] || (hasGL && !x.mesh.visible)) return; n++; far = Math.max(far, x.pos.length()); }); return { count: n, farthest: far }; },
    acrossShare: function (kind) { var n = 0, a = 0; SPRINGS.forEach(function (sp) { if (sp.kind !== kind) return; var A = sp.a.pos, B = sp.b.pos, la = A.length(), lb = B.length(); if (la < 1e-6 || lb < 1e-6) return; n++; if (A.dot(B) / (la * lb) < -0.5) a++; }); return { lines: n, across: n ? +(a / n).toFixed(2) : null }; },
    alongDir: function (kind, d) { var v = new THREE.Vector3(d[0], d[1], d[2]), s = 0, n = 0; SPRINGS.forEach(function (sp) { if (sp.kind !== kind) return; n++; s += sp.b.pos.clone().sub(sp.a.pos).dot(v) / sp.rest; }); return { lines: n, meanAlongOverRest: n ? +(s / n).toFixed(2) : null }; },
    lineOpacities: function () { var o = {}; relGroup.children.forEach(function (c) { o['relation ' + c.material.opacity] = (o['relation ' + c.material.opacity] || 0) + 1; }); runGroup.children.forEach(function (c) { o['run ' + c.material.opacity] = (o['run ' + c.material.opacity] || 0) + 1; }); return o; },
    unlinked: function () { var linked = {}; SPRINGS.forEach(function (sp) { linked[sp.names[0]] = 1; linked[sp.names[1]] = 1; }); return Object.keys(NODE).filter(function (w) { var n = NODE[w]; return !n.ghost && n.mesh.visible && !linked[w] && w !== 'origin'; }); },
    setParam: function (k, v) { if (k === 'ACROSS') ACROSS = v; if (k === 'PASSES') PASSES = v; reshape(); },
    axesInfo: function () { var lines = axesGroup.children.filter(function (c) { return c.type === 'LineSegments'; }), labels = axesGroup.children.filter(function (c) { return c.type === 'Sprite'; }); return { lines: lines.length, maxOpacity: Math.max.apply(null, lines.map(function (c) { return c.material.opacity; })), depthTest: lines.some(function (c) { return c.material.depthTest; }), negativeNumbers: labels.filter(function (c) { return false; }).length, labels: labels.length }; },
    labelPx: function (w) { return NODE[w].label.scale.y * stageH() / 0.728; },
    timeRender: function () { var s = performance.now(); render(EV.length - 1, true); var a = performance.now(); settle(2); var b = performance.now(); redrawLines(); var c = performance.now(); return { replayAndPanelsMs: a - s, settleTwoStepsMs: b - a, redrawLinesMs: c - b, events: EV.length, springs: SPRINGS.length, points: Object.keys(NODE).length }; },
    fps: function (ms) { return new Promise(function (res) { var n = 0, s = performance.now(); function f() { n++; if (performance.now() - s < ms) requestAnimationFrame(f); else res(n * 1000 / (performance.now() - s)); } requestAnimationFrame(f); }); },
    fixedPoints: function () { return Object.keys(NODE).filter(function (w) { return NODE[w].fixed; }); },
    linesOf: function (w) { return SPRINGS.filter(function (sp) { return sp.names[0] === w || sp.names[1] === w; }).map(function (sp) { return sp.kind; }).reduce(function (o, k) { o[k] = (o[k] || 0) + 1; return o; }, {}); },
    outputs: function () { return OUTS.slice(); },
    pointsWith: function (kind) { var o = {}; SPRINGS.forEach(function (sp) { if (sp.kind === kind) { o[sp.names[0]] = 1; o[sp.names[1]] = 1; } }); return Object.keys(o); },
    card: function (w) { showNode(w); return $('sel').innerText; },
    firstGhost: function () { return Object.keys(NODE).filter(function (w) { return NODE[w].ghost && NODE[w].mesh && NODE[w].mesh.visible; })[0] || null; },
    screenOf: function (w) { if (!w || !hasGL) return null; var v = NODE[w].pos.clone().multiplyScalar(SP).project(camera), r = $('c').getBoundingClientRect(); return [r.left + (v.x + 1) / 2 * r.width, r.top + (1 - v.y) / 2 * r.height]; } };
  if (hasGL) {
    var canvas = $('c'), ptrs = {}, dragging = false, moved = false, lastX = 0, lastY = 0, pinchD = 0, userZoomed = false;
    canvas.addEventListener('pointerdown', function (e) { ptrs[e.pointerId] = [e.clientX, e.clientY]; dragging = true; moved = false; lastX = e.clientX; lastY = e.clientY; canvas.setPointerCapture(e.pointerId); });
    canvas.addEventListener('pointermove', function (e) { if (!dragging) return; ptrs[e.pointerId] = [e.clientX, e.clientY]; var ids = Object.keys(ptrs); if (ids.length >= 2) { var a = ptrs[ids[0]], b = ptrs[ids[1]], d = Math.hypot(a[0] - b[0], a[1] - b[1]); if (pinchD) dist = Math.min(300000, Math.max(5, dist * pinchD / d)); pinchD = d; moved = true; userZoomed = true; return; } var dx = e.clientX - lastX, dy = e.clientY - lastY; lastX = e.clientX; lastY = e.clientY; if (Math.abs(dx) + Math.abs(dy) > 2) moved = true; theta -= dx * .005; phi = Math.min(Math.PI - .05, Math.max(.05, phi - dy * .005)); });
    function up(e) { delete ptrs[e.pointerId]; if (Object.keys(ptrs).length < 2) pinchD = 0; if (Object.keys(ptrs).length === 0) { dragging = false; if (!moved) pick(e); } }
    canvas.addEventListener('pointerup', up); canvas.addEventListener('pointercancel', up);
    canvas.addEventListener('wheel', function (e) { e.preventDefault(); userZoomed = true; dist = Math.min(300000, Math.max(5, dist * (1 + e.deltaY * .0012))); }, { passive: false });
    var ray = new THREE.Raycaster(); ray.params.Line.threshold = 1.4;
    function pick(e) { var rect = canvas.getBoundingClientRect(), v = new THREE.Vector2(((e.clientX - rect.left) / rect.width) * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1); ray.setFromCamera(v, camera); var hit = ray.intersectObjects(dotGroup.children.filter(function (m) { return m.visible; }), false); if (hit.length) { showNode(hit[0].object.userData.gate); return; } clearSel(); }
    function resize() { var w = $('stage').clientWidth, h = $('stage').clientHeight; renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); }
    // the camera keeps the points in view: its distance follows how far out the points sit, until you zoom yourself
    function fit() { if (userZoomed || fitLeft <= 0) return; fitLeft--; var rs = []; Object.keys(NODE).forEach(function (w) { var n = NODE[w]; if (n.mesh && n.mesh.visible) rs.push(n.pos.length() * SP); }); if (!rs.length) return; rs.sort(function (a, b) { return a - b; }); var r = rs[Math.floor(rs.length * .95)] || rs[rs.length - 1]; var want = Math.max(40, r * 1.15 / Math.tan(20 * Math.PI / 180) / Math.min(1, camera.aspect)); dist += (want - dist) * .05; }
    window.addEventListener('resize', resize);
    var last = performance.now();
    function frame(now) {
      var dt = (now - last) / 1000; last = now;
      if (spinning && !dragging) theta += dt * .08;
      if (ready) fit();
      if (ready) { settle(reshapeLeft > 0 ? 6 : 2); if (reshapeLeft > 0) reshapeLeft--; Object.keys(NODE).forEach(function (w) { var n = NODE[w]; if (n.mesh) { n.mesh.position.copy(n.pos).multiplyScalar(SP); if (n.mesh.visible) n.mesh.scale.setScalar(n.mesh.userData.base * 3.5 * (n.mesh.userData.hot ? 2 : 1) * 0.728 * camera.position.distanceTo(n.mesh.position) / stageH()); if (n.label) { sizeLabel(n.label); n.label.position.copy(n.mesh.position); } } }); redrawLines(); drawAxes(false); axesGroup.children.forEach(function (c) { if (c.userData.px) sizeLabel(c); }); }
      if (playing) { acc += dt; var per = 1 / parseFloat($('speed').value); if (acc > per) { var k = Math.max(1, Math.floor(acc / per)); acc = 0; if (T < EV.length - 1) render(Math.min(EV.length - 1, T + k), true); else setPlay(false); } }
      updateCam(); renderer.render(scene, camera); requestAnimationFrame(frame);
    }
    resize(); requestAnimationFrame(frame);
  } else {
    (function tick() { if (playing) { if (T < EV.length - 1) render(T + 1, true); else setPlay(false); } window.requestAnimationFrame(tick); })();
  }
})();
