import json, hashlib, html, re, sys
VER = sys.argv[3] if len(sys.argv) > 3 else '16'
D = sys.argv[1]; R = sys.argv[2]   # v15 dir, scratchpad root
rd = lambda p: open(p, encoding='utf-8').read()
head, body, main, prose = rd(D + '/head15.html').replace('Point Of Connection 15', 'Point Of Connection ' + VER).replace('</style>', '  .rels { grid-template-columns: auto 10px minmax(0, 1fr) 48px auto 70px; }\n  .rels select.dir { font-size: .64rem; padding: 0 1px; max-width: 70px; }\n  .atlasbtn { position: absolute; top: 10px; right: 10px; z-index: 3; font-family: var(--mono); font-size: .8rem; padding: 6px 12px; border-radius: 5px; border: 1px solid #4a4f58; background: rgba(12,14,18,.85); color: var(--stage-fg); cursor: pointer; }\n  .atlas { position: absolute; inset: 0; z-index: 4; background: var(--bg); color: var(--fg); display: flex; flex-direction: column; min-width: 0; }\n  .atlas[hidden] { display: none; }\n  .atop { display: flex; flex-wrap: wrap; gap: 6px 8px; align-items: center; padding: 8px 10px; border-bottom: 1px solid var(--line); }\n  .atop input[type=text] { flex: 1 1 10em; max-width: 18em; }\n  .asum { padding: 6px 10px; font-size: .8rem; line-height: 1.45; border-bottom: 1px solid var(--line); }\n  .atlas .m { color: var(--muted); } .atlas .no { color: var(--warn); }\n  .atw { flex: 1 1 auto; min-height: 0; overflow: auto; overscroll-behavior: contain; }\n  .atlas table { border-collapse: collapse; font-family: var(--mono); font-size: .72rem; width: max-content; min-width: 100%; }\n  .atlas th { position: sticky; top: 0; background: var(--panel); text-align: left; padding: 5px 7px; border-bottom: 1px solid var(--line); white-space: nowrap; z-index: 1; }\n  .atlas td { padding: 4px 7px; border-bottom: 1px solid var(--line); vertical-align: top; max-width: 34ch; overflow-wrap: anywhere; }\n  .atlas td.n { text-align: right; white-space: nowrap; font-variant-numeric: tabular-nums; }\n  .atlas tr.arow { cursor: pointer; } .atlas tr.arow:hover td { background: var(--panel); }\n  .atlas tr.det td { background: var(--panel); white-space: pre-wrap; max-width: none; }\n</style>', 1), rd(D + '/body16.html'), rd(D + '/main16.js'), rd(D + '/prose16.html')
host = rd(D + '/host15.js'); host = re.sub(r"if \(typeof module !== 'undefined'\) module\.exports = .*?;\n?$", '', host.rstrip() + '\n', flags=re.S)
mcode = host[host.index('  // MOTHER-START'):host.index('  // MOTHER-END') + len('  // MOTHER-END')]
told = json.load(open(D + '/physics16.json'))
srcrow = next(s for s in told['statements'] if s.startswith("INSERT INTO input") and 'inbox' in s)
srcbody = re.search(r"VALUES \('source = (.*?)', 'heard'\)", srcrow).group(1).replace(' ; ', ' ;\n')
e7 = rd(D + '/e7section.html'); e7res = ''
prose = prose.replace('/*MOTHERCODE*/', html.escape(mcode)).replace('/*SOURCEROW*/', 'source -> ' + html.escape(srcbody))
enginesrc = rd(R + '/sqljs/sql-asm-memory-growth.js') + '\n' + host + '\n' + rd(D + '/shared15.js')
workersrc = rd(D + '/worker16.js')
for bad in ('</script', '<!--'): assert bad not in enginesrc and bad not in workersrc and bad not in main, bad
F1 = "INSERT INTO var ( run , name , value ) VALUES ( :run , ':owner' , :speaker ) ;"
F2 = "INSERT INTO var ( run , name , value ) SELECT :run , ':owner' , 'self' WHERE :speaker = 'user' ; INSERT INTO var ( run , name , value ) SELECT :run , ':owner' , 'user' WHERE :speaker = 'self' ;"
F3 = "INSERT INTO var ( run , name , value ) VALUES ( :run , ':key' , :owner || '.' || :head ) ;"
F11 = F3 + " SELECT value FROM state WHERE key = :key ORDER BY id DESC LIMIT 1 ; INSERT INTO var ( run , name , value ) VALUES ( :run , ':answer' , :found ) ;"
F5c = "INSERT INTO state ( key , value ) SELECT :key , :after WHERE :key IS NOT NULL ;"
F7 = "INSERT INTO say ( run , text ) VALUES ( :run , :answer ) ;"
HOW = "SELECT group_concat ( text , ' ' ) FROM stmt WHERE run IN ( SELECT id FROM run WHERE root = :prev OR root = ( SELECT run FROM memory WHERE id = ( SELECT memid FROM run WHERE id = :prev AND recalled = 1 ) ) ) ; INSERT INTO var ( run , name , value ) VALUES ( :run , ':answer' , :found ) ;"
SAYF = "INSERT INTO say ( run , text ) VALUES ( :run , :found ) ;"
ANS = "INSERT INTO var ( run , name , value ) VALUES ( :run , ':answer' , :found ) ;"
MATCH = "( SELECT max ( id ) FROM memory WHERE :after LIKE line || '%' AND direction = 'heard' )"
D1 = "SELECT text FROM definition WHERE word = :after AND src <> 'node' ORDER BY id LIMIT 1 ; " + SAYF
B1 = f"SELECT line FROM memory WHERE direction = 'heard' AND id < {MATCH} ORDER BY id DESC LIMIT 1 ; " + ANS
B2 = f"SELECT line FROM memory WHERE direction = 'heard' AND id > {MATCH} ORDER BY id LIMIT 1 ; " + ANS
presets = [
 ['E6 1: teach the measured formulas (your, my, age, is, ?)', ['your = ' + F2, 'my = ' + F1, 'age = ' + F11, 'is = ' + F5c, '? = ' + F7]],
 ['E6 2: my age is forty, then ask', ['my age is forty', 'what is my age ?']],
 ['E6 3: two owners', ['your age is three', 'what is your age ?', 'what is my age ?']],
 ['E8: teach how, then how did you do that ?', ['how = ' + HOW, 'how did you do that ?']],
 ['E10: define, as the tests left it', ['define = ' + D1, 'define store']],
 ['E11: before and after, as the tests left them', ['before = ' + B1, 'after = ' + B2, 'cat sat', 'dog ran', 'bird flew', 'what was before dog ran ?', 'what was after dog ran ?']]]
measured = {
 'is': ['writes what follows it under the key built before it, only if a key was built', 'E6: two facts, two owners, a question writes no fact'],
 'your': ['sets the key owner to the other one: the brain when you speak', 'E6, only with a told self anchor; your and my can swap otherwise'],
 'my': ['sets the key owner to the one speaking', 'E6, the same'],
 'age': ['builds the key from the owner and itself; it may also read the state (not decided)', 'E6: two keys under one owner'],
 'define': ['reads what the sources gave for the word after it, and says it (one or all: not decided)', 'E10: define store, define shop, define zork, store alone'],
 'before': ['the heard line remembered just before the one named (whether teaching lines count: open)', 'E11'],
 'after': ['the heard line remembered just after the one named; the mirror of before', 'E11'],
 'what': ['16 of 18 forms survive', 'nothing: the sentences never needed it'],
 '?': ['13 of 18 forms survive; the one taught here says the answer', 'little']}
e6js = 'var E6PRESETS = ' + json.dumps(presets) + ';\nvar E6MEASURED = ' + json.dumps(measured) + ';'
assert main.count('/*E6PRESETS*/') == 1
main = main.replace('/*E6PRESETS*/', e6js)
body = body.replace('<h1>Point Of Connection 16</h1>', '<h1>Point Of Connection ' + VER + '</h1>')
LINKS = {'16.4': [('16.3', 'Aw7meuyz9v9bRVpzm9s61p'), ('16.2', 'GTpSuZ6Pw5EvqrexPdEyym'), ('16.1', 'PBjYkcaxzYbhCZqBdcemsd'), ('16', 'BXWCdcANz1pTX2rLfUFXQe')]}
if VER in LINKS: body = body.replace('<a href="https://claude.ai/artifact/28rFWxBVwbet45wsBvL3FY"', ''.join('<a href="https://claude.ai/artifact/%s" target="_blank" rel="noopener">version %s</a>, ' % (u, v) for v, u in LINKS[VER]) + '<a href="https://claude.ai/artifact/28rFWxBVwbet45wsBvL3FY"', 1)
elif VER != '16': body = body.replace('<a href="https://claude.ai/artifact/28rFWxBVwbet45wsBvL3FY"', '<a href="https://claude.ai/artifact/BXWCdcANz1pTX2rLfUFXQe" target="_blank" rel="noopener">version 16</a>, <a href="https://claude.ai/artifact/28rFWxBVwbet45wsBvL3FY"', 1)
out = head + body
for ph, val in [('/*PROSE*/', prose), ('/*ENGINESRC*/', enginesrc), ('/*WORKERSRC*/', workersrc), ('/*TOLD*/null', json.dumps(told)), ('/*SAT*/null', rd(D + '/sat15.json')),
                ('/*SLICE*/null', rd(R + '/ownerzip/slice.json')), ('/*READINGS*/null', 'null'), ('/*MAPFULL*/null', rd(R + '/v16map/map-full.json')), ('/*MAIN*/', main)]:
    assert out.count(ph) == 1, ph; out = out.replace(ph, lambda: None) if False else out.replace(ph, val.replace('\\', '\\\\') if False else val, 1)
open(D + '/point-of-connection-' + VER + '.html', 'w', encoding='utf-8').write(out)
open(D + '/poc16-main.js', 'w', encoding='utf-8').write('var TOLD = ' + json.dumps(told) + ', SAT = null, SLICE = null, READINGS = null;\n' + main)
print('built', len(out.encode()), 'bytes; sha', hashlib.sha256(out.encode()).hexdigest()[:12])
