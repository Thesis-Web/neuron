const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
const file = process.argv[2], out = process.argv[3];
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const R = {}, errs = [];
  async function open(opts) {
    const page = await browser.newPage(opts);
    page.on('pageerror', e => errs.push('pageerror: ' + e.message)); page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push('console: ' + m.text()); });
    await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.includes('cdnjs.cloudflare.com') ? r.continue() : r.abort(); });
    await page.goto('file://' + file); return page;
  }
  const page = await open({ viewport: { width: 1600, height: 950 } });
  await page.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 90000 });
  const idle = () => page.waitForFunction(() => !window.__poc.busy(), null, { timeout: 900000 });
  const preset = async v => { await page.evaluate(v => [...document.querySelectorAll('#presets button')].find(b => b.textContent.indexOf(v) === 0).click(), v); await page.waitForTimeout(300); await idle(); return page.evaluate(() => window.__poc.lastOutput()); };
  const pos = () => page.evaluate(() => window.__poc.positions());
  await page.waitForTimeout(3000);
  const p0 = await pos();
  R.V1 = { fixed: await page.evaluate(() => window.__poc.fixedPoints()), origin: p0.origin };
  R.V2 = { SPAWN: p0.SPAWN || null, dist: p0.SPAWN ? Math.hypot(...p0.SPAWN) : null };
  await page.screenshot({ path: out + '-1-load.png' });
  await page.fill('#line', 'define store'); await page.press('#line', 'Enter'); await page.waitForTimeout(300); await idle();
  await page.evaluate(() => { const s = document.getElementById('time'); s.value = s.max; s.dispatchEvent(new Event('input')); }); await page.waitForTimeout(3000);
  const p1 = await pos(); R.V3 = { store: p1.store, dist: p1.store ? Math.hypot(...p1.store) : null, lines: await page.evaluate(() => window.__poc.linesOf('store')) };
  await page.screenshot({ path: out + '-2-define-store.png' });
  await page.evaluate(() => { document.querySelector('aside.left').scrollTop = 200; document.querySelector('aside.right').scrollTop = 300; });
  const s0 = await page.evaluate(() => [document.querySelector('aside.left').scrollTop, document.querySelector('aside.right').scrollTop]);
  const q0 = await pos();
  await page.evaluate(() => { const c = document.querySelector('[data-rel="sequence"]'); c.checked = false; c.dispatchEvent(new Event('change', { bubbles: true })); }); await page.waitForTimeout(2000);
  const q1 = await pos(); await page.screenshot({ path: out + '-3-sequence-off.png' });
  await page.evaluate(() => { const c = document.querySelector('[data-rel="sequence"]'); c.checked = true; c.dispatchEvent(new Event('change', { bubbles: true })); }); await page.waitForTimeout(2000);
  const q2 = await pos(); const s1 = await page.evaluate(() => [document.querySelector('aside.left').scrollTop, document.querySelector('aside.right').scrollTop]);
  const move = (a, b) => { let s = 0, n = 0; for (const k in a) if (b[k]) { s += Math.hypot(a[k][0] - b[k][0], a[k][1] - b[k][1], a[k][2] - b[k][2]); n++; } return n ? s / n : 0; };
  const seqPts = await page.evaluate(() => window.__poc.pointsWith('sequence'));
  const sub = (o) => { const r = {}; seqPts.forEach(k => { if (o[k]) r[k] = o[k]; }); return r; };
  R.V4 = { off: move(q0, q1), on: move(q1, q2), offWithSeq: move(sub(q0), sub(q1)), onWithSeq: move(sub(q1), sub(q2)), withSeq: seqPts.length, all: Object.keys(q0).length, scroll: [s0, s1] };
  await preset('E6 1'); R.V5 = await preset('E6 2');
  await preset('E6 3'); R.V6 = await preset('E8'); R.V6has = R.V6.indexOf("key = 'user.age'") >= 0; R.V6 = R.V6.slice(0, 200);
  R.V7 = (await preset('E10')).slice(0, 300);
  R.V8 = { last: await preset('E11'), before: await page.evaluate(() => window.__poc.outputs().slice(-2)) };
  await page.evaluate(() => { const s = document.getElementById('time'); s.value = s.max; s.dispatchEvent(new Event('input')); }); await page.waitForTimeout(2500);
  await page.screenshot({ path: out + '-4-after-presets.png' });
  R.V9 = (await page.evaluate(() => window.__poc.card('age'))).slice(0, 600);
  await page.close();
  for (const [name, opts] of [['light', { viewport: { width: 1400, height: 900 }, colorScheme: 'light' }], ['dark', { viewport: { width: 1400, height: 900 }, colorScheme: 'dark' }], ['phone', { viewport: { width: 400, height: 860 }, colorScheme: 'light' }]]) {
    const pg = await open(opts); await pg.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 90000 }); await pg.waitForTimeout(2000);
    R['V10-' + name] = await pg.evaluate(() => ({ scrollW: document.documentElement.scrollWidth, innerW: window.innerWidth }));
    await pg.screenshot({ path: out + '-9-' + name + '.png' }); await pg.close();
  }
  R.errors = errs; console.log(JSON.stringify(R, null, 1)); await browser.close();
})().catch(e => { console.log('FATAL', e.message); process.exit(1); });
