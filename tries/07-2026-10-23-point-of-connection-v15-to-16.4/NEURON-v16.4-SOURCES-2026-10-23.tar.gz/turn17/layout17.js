const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
const fs = require('fs');
const VARIANTS = [
  ['A', {}, {}], ['A2', {}, {}], ['salt', { salt: 'x1' }, {}], ['salt2', { salt: 'x2' }, {}],
  ['nolimit', {}, { NOLIMIT: 1 }], ['rest20', {}, { REST_ALL: 20 }], ['across0', {}, { ACROSS: 0 }], ['gap0', {}, { GAP: 0 }]];
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const out = fs.existsSync(process.argv[3]) ? JSON.parse(fs.readFileSync(process.argv[3])) : {}, errs = [], only = (process.argv[4] || '').split(',').filter(Boolean);
  for (const [name, init, params] of VARIANTS) {
    if (only.length && !only.includes(name)) continue;
    const page = await browser.newPage({ viewport: { width: 1200, height: 800 } }); page.on('pageerror', e => errs.push(name + ': ' + e.message));
    await page.addInitScript(i => { window.__pocFreeze = true; window.__pocSalt = i.salt || ''; }, init);
    await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.includes('cdnjs.cloudflare.com') ? r.continue() : r.abort(); });
    await page.goto('file://' + process.argv[2]); await page.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 120000 });
    await page.waitForTimeout(500);
    for (const k of Object.keys(params)) await page.evaluate(([k, v]) => window.__poc.setParam(k, v), [k, params[k]]);
    const t0 = Date.now(); let step = 0;
    for (let i = 0; i < 20; i++) step = await page.evaluate(() => window.__poc.step(100));
    const r = await page.evaluate(() => ({ pos: window.__poc.positions(), across: window.__poc.acrossShare('opposite'), closest: window.__poc.closest(), springs: window.__poc.springCount(), roles: window.__poc.roles() }));
    r.step = step; r.ms = Date.now() - t0; out[name] = r; console.error(name, 'steps', step, 'ms', r.ms, 'points', Object.keys(r.pos).length, 'springs', r.springs);
    await page.close();
  }
  fs.writeFileSync(process.argv[3], JSON.stringify(out)); console.log('errors', JSON.stringify(errs)); await browser.close();
})().catch(e => { console.log('FATAL', e.message); process.exit(1); });
