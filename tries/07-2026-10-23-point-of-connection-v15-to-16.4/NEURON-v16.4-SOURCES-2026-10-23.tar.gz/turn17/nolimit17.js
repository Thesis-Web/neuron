const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  for (const lim of [0, 1]) {
    const page = await browser.newPage({ viewport: { width: 1200, height: 800 } });
    await page.addInitScript(() => { window.__pocFreeze = true; });
    await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.includes('cdnjs.cloudflare.com') ? r.continue() : r.abort(); });
    await page.goto('file://' + process.argv[2]); await page.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 120000 });
    await page.waitForTimeout(500);
    if (lim) await page.evaluate(() => window.__poc.setParam('NOLIMIT', 1));
    const rows = [];
    for (let i = 0; i < 40; i++) {
      const r = await page.evaluate(() => { const st = window.__poc.step(5), p = window.__poc.positions(); let mx = 0, bad = 0, who = ''; for (const k in p) { const d = Math.hypot(...p[k]); if (!isFinite(d)) bad++; else if (d > mx) { mx = d; who = k; } } return [st, +mx.toFixed(1), who, bad]; });
      rows.push(r); if (r[3] > 0 || r[1] > 1e7) break;
    }
    console.log(lim ? 'NO LIMIT' : 'WITH LIMIT', JSON.stringify(rows.filter((r, i) => i % 4 === 0 || i === rows.length - 1)));
    await page.close();
  }
  await browser.close();
})().catch(e => { console.log('FATAL', e.message); process.exit(1); });
