const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const errs = [], R = {};
  const open = async (opts) => { const page = await browser.newPage(opts); page.on('pageerror', e => errs.push(e.message));
    await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.includes('cdnjs.cloudflare.com') ? r.continue() : r.abort(); });
    await page.goto('file://' + process.argv[2]); await page.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 120000 }); return page; };
  const page = await open({ viewport: { width: 1600, height: 950 } });
  await page.waitForTimeout(3000);
  const check = async (tag) => page.evaluate(async () => {
    const a = await window.__poc.atlas(), p = window.__poc.positions(), keys = a.rows.map(r => r.key), out = {};
    out.rows = a.rows.length; out.summary = a.summary.slice(0, 420);
    const labels = a.rows.map(r => r.label.toLowerCase()); out.sorted = labels.every((l, i) => i === 0 || labels[i - 1] <= l);
    const count = {}; keys.forEach(k => count[k] = (count[k] || 0) + 1); out.dupes = Object.keys(count).filter(k => count[k] > 1);
    out.visibleMissing = Object.keys(p).filter(k => !count[k]); out.notDrawn = a.rows.filter(r => !r.pos).map(r => r.label);
    let maxd = 0; a.rows.forEach(r => { if (r.pos && p[r.key]) maxd = Math.max(maxd, Math.hypot(r.pos[0] - p[r.key][0], r.pos[1] - p[r.key][1], r.pos[2] - p[r.key][2])); }); out.posMaxDiff = maxd;
    out.origin = a.rows.filter(r => r.key === 'origin').map(r => r.pos);
    const cats = {}; a.rows.forEach(r => cats[r.cat] = (cats[r.cat] || 0) + 1); out.cats = cats; out.noCat = a.rows.filter(r => !r.cat).length;
    // A3/A5: every brain row's DNA, hop triggers and memories against SQLite read directly
    let bad = []; const brainRows = a.rows.filter(r => r.gate !== null);
    for (const r of brainRows) {
      const t = (await window.__poc.rawRows("SELECT count(*) FROM sqlite_master WHERE type = 'table' AND name = 'g" + r.gate + "'"))[0][0];
      const n = t ? (await window.__poc.rawRows('SELECT count(*) FROM g' + r.gate))[0][0] : 0;
      const h = (await window.__poc.rawRows("SELECT count(*) FROM sqlite_master WHERE type = 'trigger' AND name GLOB 'hop_" + r.gate + "_*'"))[0][0];
      const m = (await window.__poc.rawRows("SELECT id FROM memory WHERE instr(' ' || coalesce(receipt, '') || ' ', ' " + r.gate + ":s') > 0 ORDER BY id")).map(x => x[0]);
      if (n !== r.dna || h !== r.hops || JSON.stringify(m) !== JSON.stringify(r.mem.slice().sort((x, y) => x - y))) bad.push([r.label, r.gate, n, r.dna, h, r.hops, m, r.mem]);
    }
    out.brainRows = brainRows.length; out.withDna = brainRows.filter(r => r.dna).length; out.dnaRows = brainRows.reduce((s, r) => s + r.dna, 0); out.memLinks = brainRows.reduce((s, r) => s + r.mem.length, 0); out.mismatch = bad.slice(0, 5); out.mismatchN = bad.length;
    return out; });
  R.load = await check();
  await page.fill('#line', 'cat sat'); await page.click('#run');
  await page.waitForFunction(() => !window.__poc.busy(), null, { timeout: 180000 }); await page.waitForTimeout(1500);
  R.afterLine = await check();
  // the UI itself
  await page.click('#atlasbtn'); await page.waitForFunction(() => document.querySelectorAll('#atable tr.arow').length > 0, null, { timeout: 30000 });
  R.ui = await page.evaluate(() => window.__poc.atlasTable());
  await page.fill('#afind', 'cat'); await page.waitForTimeout(200);
  await page.click('#atable tr.arow'); await page.waitForTimeout(200);
  R.detail = await page.evaluate(() => { const d = document.querySelector('#atable tr.det'); return d ? d.innerText.slice(0, 900) : null; });
  await page.screenshot({ path: process.argv[3] + '-detail.png' });
  await page.fill('#afind', ''); await page.selectOption('#ashow', 'none'); await page.waitForTimeout(200);
  R.noneShown = await page.evaluate(() => document.getElementById('ashown').textContent);
  await page.selectOption('#ashow', 'all'); await page.waitForTimeout(200);
  await page.screenshot({ path: process.argv[3] + '-atlas.png' });
  await page.close();
  const ph = await open({ viewport: { width: 400, height: 860 } }); await ph.waitForTimeout(1500);
  await ph.click('#atlasbtn'); await ph.waitForFunction(() => document.querySelectorAll('#atable tr.arow').length > 0, null, { timeout: 30000 });
  R.phone = await ph.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth, document.querySelector('.atw').scrollWidth > document.querySelector('.atw').clientWidth]);
  await ph.screenshot({ path: process.argv[3] + '-phone.png' }); await ph.close();
  R.errs = errs; console.log(JSON.stringify(R, null, 1)); await browser.close();
})().catch(e => { console.log('FATAL', e.message); process.exit(1); });
