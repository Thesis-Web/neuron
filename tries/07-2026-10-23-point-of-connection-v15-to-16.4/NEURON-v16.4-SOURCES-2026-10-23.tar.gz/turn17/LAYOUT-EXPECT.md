# L: what sets a point's place in 16.3 (written before running, 2026-10-23)
Owner: "this capping thing ... what is causing it. an invention? something off spec / scope? ... sql? something else?"
Owner: "this seems like it might be manipulated to look a specific way ... if the graph is correct then where points sit on the graph mean something..... if not the graph is meaningless"
Owner: "holding something 60 points apart sounds like a 2d function on a 3d graph? no?"

Facts read from the code (page main16.js, not the brain; the brain holds no x, y, z):
- origin fixed at 0,0,0 (owner's rule).
- which points are tied: brain rows + owner's map (data).
- MINE: rest length per kind (alike 10 ... opposite 64, default 30); pull per kind (slider defaults); trust per line (.6/.8/1);
  maturity .5+.5*min(1,count/40); 1+log(times laid); map lines x.6; stiffness .04; across rule (pull toward the mirror
  through origin, x .25); step limit (all steps scaled so the 95th-largest moves 4, none more than 6); spacing 15, 3 passes;
  new point starts beside its tied points plus a fixed offset from a hash of its name.

Each variant: a fresh page, the same lines (none typed: the told block only), every setting as 16.3 except the one named,
settled the same number of steps (2,000), settling frozen outside the test's own steps.

Predictions:
L1 baseline run twice: identical positions (no randomness in the code; start = hash of the name).
L2 start moved (hash salt changed, all rules the same): the x, y, z of most points change by more than half their distance
   from origin, because nothing but opposite-across and origin fixes any direction: the cloud can settle turned any way.
   The distance from origin and the near neighbours change less than x, y, z (prediction: neighbour overlap > 0.5).
L3 step limit removed (no scale, no cap): points with many lines are thrown past their balance; the cloud blows up
   (farthest point > 10x baseline) or ends in a different balance. This is why the limit exists.
L4 every rest length the same (20): distances from origin change for most points (median change > 20% of distance).
L5 across rule off: opposite pairs across origin fall from ~94% toward the 27% measured in E13; the center moves off origin.
L6 spacing off: closest pair < 1 (points stack) and the cloud shrinks.
What would show positions carry the lines' meaning: what survives L2-L6 (who sits near whom). What would show they are
my numbers: what moves in L2-L6 (x, y, z, distance from origin, the round shape).

## Results (headless Chromium, page = 16.3 layout + test hooks, told block only, 2,000 steps each; layout17.json, layout17.result.txt)
At load: 1,192 points besides origin (90 brain points, 1,102 far ends from the owner's map), 1,221 lines.
L1 HELD: two baseline runs identical.
L2 x,y,z HELD, neighbours WRONG: a different start (same lines, same rules) moves the median point by 1.17x its distance
   from origin; turning the whole cloud about origin to best fit leaves 1.07x, so it is a different arrangement, not the same
   one turned. My prediction "neighbour overlap > 0.5" was wrong: brain points keep 14-17% of their 8 nearest neighbours
   (chance 9%); over all points the median keeps none. Order of pairwise distances kept: spearman 0.32-0.33.
   Distance from origin changes least: median 15-16%.
L3 HELD: no step limit -> farthest point 2,139 after 5 steps, 22 million after 15; the page crashed (first run).
   With the limit: ~107 and steady.
L4 WRONG on size: equal rest lengths change distance from origin by 14% (predicted >20%); x,y,z move 0.77x; spearman 0.45.
L5 across share HELD, center WRONG: without the across rule opposite pairs across origin fall from 100% to 1%
   (E13 on the full map: 27%). Predicted the center moves off origin; it moved closer (7.0 vs 13.6).
   Also: the baseline center after 2,000 steps is 13.6 from origin, not the 2.8 I reported for 16.3 at a live moment.
L6 HELD: spacing off -> closest pair 0.0 (stacked); the cloud shrinks from median radius 74 to 14 (max 37):
   the size of the ball is the spacing rule.
Reading: in 16.3 a point's x,y,z, its distance from origin, the ball, its size, and who sits near whom without a line
are set by the start and my numbers. What the lines carry is only that each tied pair sits near its rest length.
