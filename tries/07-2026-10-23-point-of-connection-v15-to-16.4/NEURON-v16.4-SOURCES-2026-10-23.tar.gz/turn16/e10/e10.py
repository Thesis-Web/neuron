# E10 define and E11 before/after on the real v16 brain. Each form: a fresh brain, the form taught by typing, the sentences typed, the expectations checked.
import sys, json
V16 = sys.argv[1]; sys.path.insert(0, V16)
from host15 import Brain
SAY = "INSERT INTO say ( run , text ) VALUES ( :run , :found ) ;"
ANS = "INSERT INTO var ( run , name , value ) VALUES ( :run , ':answer' , :found ) ;"
DEFINE = {
 'D0': None,
 'D1': "SELECT text FROM definition WHERE word = :after AND src <> 'node' ORDER BY id LIMIT 1 ; " + SAY,
 'D2': "SELECT text FROM definition WHERE word = :after AND src <> 'node' ORDER BY id DESC LIMIT 1 ; " + SAY,
 'D3': "SELECT group_concat ( text , '|' ) FROM definition WHERE word = :after AND src <> 'node' ; " + SAY,
 'D4': "SELECT value FROM state WHERE key = :after ORDER BY id DESC LIMIT 1 ; " + SAY,
 'D5': "SELECT answer FROM memory WHERE line = :after ORDER BY id DESC LIMIT 1 ; " + SAY,
 'D6': "INSERT INTO say ( run , text ) VALUES ( :run , :after ) ;",
 'D7': "SELECT text FROM definition WHERE word = :before AND src <> 'node' ORDER BY id LIMIT 1 ; " + SAY}
MATCH = "( SELECT max ( id ) FROM memory WHERE :after LIKE line || '%' AND direction = 'heard' )"
BEFORE = {
 'B0': None,
 'B1': f"SELECT line FROM memory WHERE direction = 'heard' AND id < {MATCH} ORDER BY id DESC LIMIT 1 ; " + ANS,
 'B2': f"SELECT line FROM memory WHERE direction = 'heard' AND id > {MATCH} ORDER BY id LIMIT 1 ; " + ANS,
 'B3': "SELECT line FROM memory WHERE :after LIKE line || '%' ORDER BY id DESC LIMIT 1 ; " + ANS,
 'B4': "SELECT line FROM memory WHERE direction = 'heard' ORDER BY id DESC LIMIT 1 ; " + ANS,
 'B5': "SELECT line FROM memory WHERE id < ( SELECT max ( id ) FROM memory WHERE :after LIKE line || '%' ) ORDER BY id DESC LIMIT 1 ; " + ANS}
F7 = "INSERT INTO say ( run , text ) VALUES ( :run , :answer ) ;"
def brain(): return Brain(V16 + '/physics16.json', sat_path=V16 + '/sat15.json')
def defs(b, word=None):
    q = "SELECT word, text FROM definition WHERE src <> 'node' AND text IS NOT NULL" + (" AND word = ?" if word else "")
    return b.q(q, (word,)) if word else b.q(q)
def has_def_of(out, b, word):
    return any(t and t in (out or '') for _, t in defs(b, word))
def has_other_def(out, b, word):
    return any(t and len(t) > 12 and t in (out or '') for w, t in defs(b) if w.lower() != word)
res = {'define': {}, 'before': {}, 'after': {}}
for name, f in DEFINE.items():
    b = brain()
    if f: b.type('define = ' + f)
    o1 = b.type('define store'); o2 = b.type('define shop'); o3 = b.type('define zork'); o4 = b.type('store')
    checks = {'define store says a store definition': has_def_of(o1, b, 'store') and not has_other_def(o1, b, 'store'),
              'define shop says a shop definition': has_def_of(o2, b, 'shop') and not has_other_def(o2, b, 'shop'),
              'define zork says no definition': not any(t and len(t) > 12 and t in (o3 or '') for _, t in defs(b)),
              'store alone says no definition': not any(t and len(t) > 12 and t in (o4 or '') for _, t in defs(b))}
    res['define'][name] = {'pass': all(checks.values()), 'checks': checks, 'outs': [(o or '')[:120] for o in (o1, o2, o3, o4)]}
    print('define', name, 'PASS' if all(checks.values()) else 'dies', {k: v for k, v in checks.items() if not v}, flush=True)
for word, sents in [('before', [('what was before dog ran ?', 'cat sat'), ('what was before bird flew ?', 'dog ran')]),
                    ('after', [('what was after dog ran ?', 'bird flew'), ('what was after cat sat ?', 'dog ran')])]:
    for name, f in BEFORE.items():
        b = brain(); b.type('? = ' + F7)
        if f: b.type(word + ' = ' + f)
        for l in ['cat sat', 'dog ran', 'bird flew']: b.type(l)
        outs = [b.type(q) for q, _ in sents]; ok = [o == e for o, (_, e) in zip(outs, sents)]
        res[word][name] = {'pass': all(ok), 'outs': outs}
        print(word, name, 'PASS' if all(ok) else 'dies', outs, flush=True)
json.dump(res, open(sys.argv[2], 'w'), indent=1)
print('define survivors', [k for k, v in res['define'].items() if v['pass']], '| before', [k for k, v in res['before'].items() if v['pass']], '| after', [k for k, v in res['after'].items() if v['pass']])
