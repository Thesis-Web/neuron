# E10 define, E11 before and after, E12 AS and "as" (written 2026-10-23 before any of them ran)
Owner (G9): "define and before test them ... yes test as = as also". The forms tried are mine, listed in full, built only from what a run holds
(its holes, the brain's tables, say). A word keeps only the forms its sentences cannot throw out. Runs are on the real v16 brain (E10, E11) or on E6's world (E12).

## E10 define. Fixed: no other word has a formula. Forms for define (each says what it found):
 D0 nothing
 D1 the first kept definition of the word after it
 D2 the last kept definition of the word after it
 D3 every kept definition of the word after it, joined
 D4 the state value at the word after it
 D5 the remembered answer of a line equal to the words after it
 D6 the words after it, said back
 D7 the first kept definition of the word before it
Sentences (written now): "define store" -> says a kept definition text of store and nothing about any other word; "define shop" -> a kept definition of shop;
 "define zork" (no source has it) -> no definition text; control "store" alone -> no definition text.
Prediction: D1, D2 and D3 survive; D0, D4, D5, D6, D7 die. What define does in this row: read what the sources gave for the word after it, and say it.

## E11 before and after. Fixed: what, was have no formula; ? says the answer (E6).
Typed first: "cat sat", "dog ran", "bird flew". Forms (the same list for before and for after):
 B0 nothing
 B1 the heard line remembered just before the remembered line the words after it begin with
 B2 the heard line remembered just after it
 B3 that same remembered line
 B4 the last heard line remembered
 B5 B1 without the heard-only filter (teaching runs count as lines)
Sentences: "what was before dog ran ?" -> cat sat; "what was before bird flew ?" -> dog ran; "what was after dog ran ?" -> bird flew; "what was after cat sat ?" -> dog ran.
Prediction: before keeps B1 alone, after keeps B2 alone, and the two survivors differ only in the direction of the comparison and the order.
That would be your map's line "before opposite after" showing up as a measured mirror in what the words do, not laid by anyone.

## E12 AS and "as"
SQL side, measured (E1): in all four places AS binds two sides, one taking the other's name, type or rows; SQLite does it after reading the whole statement.
English side, E6's world and its 18 forms, everything else as measured (your F2, my F1, age F11, is F5c, ? F7), take has no formula.
Sentences: "take forty as my age" then "what is my age ?" -> forty. Control: "take forty my age" then "what is my age ?" -> nothing.
Prediction: no form for "as" passes. It fires before "my" and "age" have built the key, and no form may build a key itself. If that holds, English "as" cannot
work the way SQL AS does while words fire one at a time: SQL binds after the whole statement is read. That is a statement about the firing model, not about "as".

## Results (e10.result.json, e12.result.json), 2026-10-23
E10 define: D1, D2, D3 survive; D0, D4, D5, D6, D7 die. Prediction held. What define does in this row: read what the sources gave for the word after it, and say it.
   Not decided: one definition or all of them (D1/D2 against D3). A sentence whose expected answer is all the definitions, or exactly one, would decide it.
E11 after: B2 alone survives. Prediction held.
E11 before: B1 AND B5 survive. Prediction partly WRONG: I predicted B1 alone. My sentences never separated them: B5 also counts teaching lines as lines,
   and no teaching line fell between the typed lines. The open question is the owner's: does a teaching line count as "what was before"?
   The mirror held between B1 and B2: the same form with the comparison flipped (below/above) and the order flipped (last/first).
E12 as: no form of the 18 passes. Prediction held. "take forty as my age" leaves nothing under my age for every form: "as" fires before "my" and "age" have
   built the key. SQL's AS binds after the whole statement is read. In this brain a formula's statement is also decoded only at its ";", after all of it has run.
   So the finding is about when words fire, not about "as": an English "as" can only bind like SQL's AS if the binding waits for the end of the phrase.
