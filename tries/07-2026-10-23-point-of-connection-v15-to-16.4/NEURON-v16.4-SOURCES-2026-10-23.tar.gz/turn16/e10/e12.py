# E12: English "as" in E6's world: every one of the 18 forms tried for "as", everything else as measured.
import sys, json
sys.argv = [sys.argv[0], sys.argv[1]]
src = open(sys.argv[1] + '/e6d.py').read().split('WORDS = [')[0]   # E6's world and forms (W3), without its search
exec(src)
fixed = {'your': 'F2', 'my': 'F1', 'age': 'F11', 'is': 'F5c', '?': 'F7', 'what': 'F0', 'take': 'F0'}
res = {}
for f in NAMES3:
    a = dict(fixed); a['as'] = f
    w = W3(False); w.line(S('take forty as my age'), a); o1 = w.line(S('what is my age ?'), a)
    c = W3(False); c.line(S('take forty my age'), a); o2 = c.line(S('what is my age ?'), a)
    # also: "as" must not break what is already measured
    k = W3(False); k.line(S('my age is forty'), a); o3 = k.line(S('what is my age ?'), a)
    res[f] = {'as line': o1, 'control without as': o2, 'is line still works': o3, 'pass': o1 == 'forty' and o2 is None and o3 == 'forty'}
print('forms for "as" that pass:', [f for f, r in res.items() if r['pass']])
print('what "take forty as my age" leaves, by form:', sorted(set(str(r['as line']) for r in res.values())))
json.dump(res, open('/tmp/claude-1000/-home-exnulla-neuron-v1/7c20c611-9fe3-4487-be20-478341fdbaa9/scratchpad/turn16/e10/e12.result.json', 'w'), indent=1)
print(json.dumps(res)[:600])
