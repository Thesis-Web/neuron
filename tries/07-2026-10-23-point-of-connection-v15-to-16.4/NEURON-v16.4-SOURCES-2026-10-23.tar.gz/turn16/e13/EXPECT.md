# E13: does each kind of relationship pull in its own direction? (written 2026-10-23 before any code)
Owner: "perhaps each space is a type of pull? tense pulls one way, mood/feeling, maybe it's senses? singular plural another, classes might pull in different
directions. i don't know the answer perhaps you can test to see what makes sense? we have 8 main directions to pull, and the idea is each direction is pulling
the correct thing in the correct direction then the graph itself will make sense"

## Test
Data: the owner's full relation map (35,597 words, 104,727 lines, 9 kinds: alike, opposite, is, has, prefix, suffix, stem, past, singular).
Give each directed kind its own direction in 3D (which direction is arbitrary; the owner chooses the real ones). Each line A-kind-B asks: B sits at A plus that direction.
Solve every word's position from all the lines at once (least squares, origin as the reference), with 20% of one kind's lines held out.
Then ask the held-out lines: does B sit at A plus that kind's direction, closer than chance?
 - Score = mean |(B - A) - d| over held-out lines, against a control: the same with d replaced by a random direction of the same length.
 - A kind "pulls in a direction" if its score beats the control clearly (ratio under 0.8).
Symmetric kinds, alike and opposite, cannot be one-way directions (A alike B and B alike A). They are tested as alike: closer than random pairs;
opposite: on opposite sides of origin (cosine of their positions below 0).

## Predictions
past, singular, stem, prefix, suffix: pull in a direction (ratio under 0.8). The map has many parallel pairs: walk/walked beside stroll/strolled.
is: weaker; maybe under 0.8. has: no.
alike: held-out pairs much closer than random pairs.
opposite: with no direction of its own, opposite pairs do NOT fall on opposite sides of origin by themselves (mean cosine near 0); they would need a rule that puts them there.
If every directed kind fails, giving kinds directions would only be my imposition on the map, not something its lines already carry.

Correction before any result was read: the first run asked opposite pairs to share a spot (no direction). Opposite lines are now left out of the solve; their held-out pairs are only measured.

## Results (e13.result.json; ratio = held-out error with the kind's own direction / with a random direction of the same length; under 0.8 = pulls in a direction)
is 0.35 (11,987 lines) | prefix 0.27 (1,421) | suffix 0.24 (6,821) | stem 0.46 (8,251) | has 0.68 (1,656) | past 0.78 (1,104) | singular 0.91 (365)
alike: held-out pairs 1.68 apart against 5.42 for random pairs (0.31). opposite: mean cosine around origin +0.25, only 27% across origin.
Against the predictions: prefix, suffix, stem, past held (past barely). singular FAILED (0.91). is was predicted weak and came out strong; has was predicted
not to and does (0.68). alike held. opposite held: opposite pairs do not fall across origin by themselves; a rule must put them there.
Reading: in the owner's own map, the kinds is, prefix, suffix and stem already behave like directions; a direction given to them is carried by the map's lines,
not imposed. Which way each one points is not in the data; that is the owner's to choose.
