# E13 on the owner's full map. Data is read only; positions are solved in numpy/scipy.
import json, sys, numpy as np, collections, time
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import cg
d = json.load(open(sys.argv[1])); N = d['names']; R = [r['key'] for r in d['rels']]; E = np.array(d['edges']).reshape(-1, 3)
n = len(N); rng = np.random.default_rng(16)
# a fixed direction per directed kind: 3D unit vectors spread apart (the choice is arbitrary; only consistency is tested)
KINDS = ['is', 'has', 'prefix', 'suffix', 'stem', 'past', 'singular']
D = {}
for k in KINDS:
    v = rng.normal(size=3); D[k] = v / np.linalg.norm(v) * 10
lam = 1e-3   # a faint pull of every word toward origin, so separate groups of words have a reference
def solve(lines, dirs):
    # minimize sum (x_b - x_a - d)^2 + lam |x|^2 : the Laplacian system, each axis separately
    a, b = lines[:, 0], lines[:, 1]; w = np.ones(len(a))
    L = coo_matrix((np.concatenate([w, w, -w, -w]), (np.concatenate([a, b, a, b]), np.concatenate([a, b, b, a]))), shape=(n, n)).tocsr()
    L = L + lam * coo_matrix((np.ones(n), (np.arange(n), np.arange(n))), shape=(n, n)).tocsr()
    X = np.zeros((n, 3))
    for ax in range(3):
        rhs = np.zeros(n); np.add.at(rhs, b, dirs[:, ax]); np.add.at(rhs, a, -dirs[:, ax])
        X[:, ax], _ = cg(L, rhs, maxiter=4000)
    return X
kind_of = np.array([R[k] for k in E[:, 2]])
res = {}
t0 = time.time()
for k in KINDS + ['alike', 'opposite']:
    idx = np.where(kind_of == k)[0]
    if len(idx) < 20: continue
    held = rng.choice(idx, size=max(10, len(idx) // 5), replace=False); keep = np.setdiff1d(np.arange(len(E)), held)
    keep = keep[kind_of[keep] != 'opposite']   # an opposite line has no direction and must not ask its pair to share a spot: left out of the solve
    dirs = np.array([D.get(kk, np.zeros(3)) for kk in kind_of[keep]])
    X = solve(E[keep, :2], dirs)
    A, B = X[E[held, 0]], X[E[held, 1]]
    if k in D:
        own = np.linalg.norm((B - A) - D[k], axis=1).mean()
        rnd = []
        for _ in range(20):
            u = rng.normal(size=(len(held), 3)); u = u / np.linalg.norm(u, axis=1, keepdims=True) * 10
            rnd.append(np.linalg.norm((B - A) - u, axis=1).mean())
        res[k] = {'lines': int(len(idx)), 'held_out': int(len(held)), 'error_own_direction': round(float(own), 2), 'error_random_direction': round(float(np.mean(rnd)), 2), 'ratio': round(float(own / np.mean(rnd)), 2)}
    elif k == 'alike':
        dist = np.linalg.norm(B - A, axis=1).mean(); rp = rng.integers(0, n, size=(2000, 2)); drand = np.linalg.norm(X[rp[:, 0]] - X[rp[:, 1]], axis=1).mean()
        res[k] = {'lines': int(len(idx)), 'held_out': int(len(held)), 'mean_distance_held_out': round(float(dist), 2), 'mean_distance_random_pairs': round(float(drand), 2), 'ratio': round(float(dist / drand), 2)}
    else:
        na, nb = np.linalg.norm(A, axis=1), np.linalg.norm(B, axis=1); ok = (na > 1e-6) & (nb > 1e-6)
        cosv = (A[ok] * B[ok]).sum(1) / (na[ok] * nb[ok])
        res[k] = {'lines': int(len(idx)), 'held_out': int(len(held)), 'mean_cosine_around_origin': round(float(cosv.mean()), 2), 'share_across_origin': round(float((cosv < -0.5).mean()), 2)}
    print(k, res[k], round(time.time() - t0), 's', flush=True)
json.dump({'directions': {k: [round(float(x), 3) for x in v] for k, v in D.items()}, 'results': res}, open(sys.argv[2], 'w'), indent=1)
