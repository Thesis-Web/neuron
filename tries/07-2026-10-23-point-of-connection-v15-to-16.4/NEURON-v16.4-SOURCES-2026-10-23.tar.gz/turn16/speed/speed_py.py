# The same line in native SQLite (Python's sqlite3), with the same split.
import sys, time, re, json
V16 = sys.argv[1]; sys.path.insert(0, V16)
import host15
from host15 import Brain
t = time.perf_counter(); b = Brain(V16 + '/physics16.json', sat_path=V16 + '/sat15.json'); tTold = time.perf_counter() - t
T = {'ddl': 0, 'nddl': 0, 'dml': 0, 'ndml': 0, 'mail': 0, 'nmail': 0}
orig = Brain.mother
def timed(self, text, run, stmt):
    s = time.perf_counter()
    try: return orig(self, text, run, stmt)
    finally:
        d = time.perf_counter() - s; k = 'ddl' if re.match(r'\s*CREATE\b', text, re.I) else 'mail' if '.inbox' in text else 'dml'
        T[k] += d; T['n' + k] += 1
b.con.create_function('mother', 3, lambda x, y, z: timed(b, x, y, z))
s = time.perf_counter(); b.type('define store'); t1 = time.perf_counter() - s
s = time.perf_counter(); b.type('define store'); t2 = time.perf_counter() - s
s = time.perf_counter(); b.type('store define'); t3 = time.perf_counter() - s
print(json.dumps({'engine': 'native SQLite (Python sqlite3)', 'tellBlockMs': round(tTold * 1000), 'defineStoreMs': round(t1 * 1000),
                  'mother': {'createCalls': T['nddl'], 'createMsNested': round(T['ddl'] * 1000), 'dataCalls': T['ndml'], 'dataMsNested': round(T['dml'] * 1000), 'sourceAsks': T['nmail']},
                  'sameLineAgainMs': round(t2 * 1000, 1), 'knownWordsNewOrderMs': round(t3 * 1000)}))
