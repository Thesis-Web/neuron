// Where the time goes in the page's engine (sql.js, compiled to JavaScript, the same file the page uses), outside any browser drawing.
const fs = require('fs'), D = process.argv[2], R = process.argv[3];
global.initSqlJs = require(R + '/sqljs/sql-asm-memory-growth.js'); global.Neuron = require(D + '/host15.js').Neuron;
eval(fs.readFileSync(D + '/shared15.js', 'utf8').replace(/^function (\w+)/mg, 'global.$1 = function $1'));
const now = () => Number(process.hrtime.bigint()) / 1e6;
initSqlJs().then(SQL => {
  Neuron.init(SQL);
  const told = JSON.parse(fs.readFileSync(D + '/physics16.json')), sat = JSON.parse(fs.readFileSync(D + '/sat15.json'));
  let t = now(); const b = new Neuron.Brain(told, sat); const tTold = now() - t;
  const T = { ddl: 0, nddl: 0, dml: 0, ndml: 0, mail: 0, nmail: 0 };
  const orig = b.mother.bind(b);
  b.mother = function (text, run, stmt) {
    const s = now(); try { return orig(text, run, stmt); } finally {
      const d = now() - s, k = /^\s*CREATE\b/i.test(text) ? 'ddl' : /\.inbox\b/.test(text) ? 'mail' : 'dml';
      T[k] += d; T['n' + k]++; } };
  // mother is called from inside SQLite: re-register so the timed one is the one SQLite calls
  b.db.create_function('mother', (x, y, z) => b.mother(x, y, z));
  const line = (l) => { const s = now(); const o = b.type(l); return [now() - s, o]; };
  const [t1, o1] = line('define store');
  const nest = { ...T }; // mother time is nested (a mother call runs SQL that calls mother), so the parts overlap; the counts are exact
  let s = now(); const bytes = exportBrain(b, sat); const tSnap = now() - s;
  s = now(); const q = (x) => b.q(x);
  ['SELECT id, kind, gate, run, rowgate, text, roots, a, b FROM event', 'SELECT * FROM encoder', 'SELECT * FROM run', 'SELECT * FROM var', 'SELECT * FROM definition', 'SELECT DISTINCT word, w FROM defword'].forEach(q);
  const tBundle = now() - s;
  for (const k of Object.keys(T)) T[k] = 0;
  const [t2] = line('define store');           // the same line again: a memory hop
  const [t3] = line('store define');           // known words, a new order: rows to lay, no births
  const trig = b.q("SELECT count(*) FROM sqlite_master WHERE type = 'trigger'")[0][0], tabs = b.q("SELECT count(*) FROM sqlite_master")[0][0];
  console.log(JSON.stringify({ engine: 'sql.js (asm.js), as in the page', tellBlockMs: +tTold.toFixed(0), defineStoreMs: +t1.toFixed(0), mother: { createCalls: nest.nddl, createMsNested: +nest.ddl.toFixed(0), dataCalls: nest.ndml, dataMsNested: +nest.dml.toFixed(0), sourceAsks: nest.nmail, sourceMsNested: +nest.mail.toFixed(0) },
    snapshotMs: +tSnap.toFixed(0), snapshotBytes: bytes.length, bundleQueriesMs: +tBundle.toFixed(0), sameLineAgainMs: +t2.toFixed(1), knownWordsNewOrderMs: +t3.toFixed(0), triggersNow: trig, schemaObjectsNow: tabs }));
});
