# Hypothesis (written before running): a schema change (any CREATE) makes SQLite recompile the next statements and the trigger programs they reach,
# so a known line right after one unrelated CREATE is much slower than the same known line with the schema untouched. Control: the same line twice, no CREATE.
import sys, time, json
V16 = sys.argv[1]; sys.path.insert(0, V16)
from host15 import Brain
b = Brain(V16 + '/physics16.json', sat_path=V16 + '/sat15.json')
for l in ['define store', 'define shop', 'store define']: b.type(l)
lines = ['store define', 'shop define', 'define store define shop']
def t(l):
    b.con.execute("UPDATE memory SET ended = 1 WHERE line = ? AND ended = 0", (l,))   # the long way: no memory hop, every row already exists
    n0 = b.q("SELECT count(*) FROM sqlite_master")[0][0]
    s = time.perf_counter(); b.type(l); d = (time.perf_counter() - s) * 1000
    assert b.q("SELECT count(*) FROM sqlite_master")[0][0] == n0, 'the line laid something; not a pure known run'
    return d
for l in lines: b.type(l); b.con.execute("UPDATE memory SET ended = 1 WHERE line = ?", (l,)); b.type(l)   # every row of these lines now exists, and their long runs have been made twice
warm, cold = [], []
for i in range(6):
    l = lines[i % 3]
    b.con.execute("SELECT 1")
    warm.append(t(l))                                            # schema untouched since the last run
    b.con.execute(f"CREATE TABLE unrelated_{i} (x)")             # one schema change that touches nothing the line uses
    cold.append(t(l))
trig = b.q("SELECT count(*) FROM sqlite_master WHERE type = 'trigger'")[0][0]
print(json.dumps({'triggers': trig, 'known line, schema untouched (ms)': [round(x, 1) for x in warm], 'same line after one unrelated CREATE (ms)': [round(x, 1) for x in cold]}))
