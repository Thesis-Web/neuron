# E9: decide, three ways, tested on one conversation (written 2026-10-23 before building any of them)
Owner (G6): "the decide neuron formula is not correct... a different row in decide dna that uses a different set of triggers to decide when a run arrives this way..
it could be a modifier trigger based on the question word... I think my way is better than your told rule.. but maybe test that and see what is better.
yeah you have to know the history of being wrong in order not to repeat the same mistakes"

## The three
C, as built: a line already in memory is answered from memory. A correction overwrites that memory's answer.
A, my told rule: a memory keeps which line came before it. If the run that made it read the line before (its formulas passed the hole :prev),
   and the line before is now different, decide runs the line again the long way.
B, the owner's way as I can build it now:
   - A wrong answer from memory is kept as history, not overwritten: which memory, which line came before, what was given, what was expected.
   - From that history, decide's own neuron gets a DNA row: arriving from the line's first word (the question word), its trigger column points at :prev,
     "the line before matters". It is laid through mother like any row.
   - Decide, arriving from a word whose row points at :prev, runs the line the long way when the line before differs from the memory's.
   - Not built: the reasoning about why, beyond noting that the line before was what differed.

## The conversation (formulas taught first: my, your, age, is, ? as measured in E6; how as E8b)
 1 my age is forty
 2 what is my age ?
 3 how did you do that ?
 4 your age is three
 5 how did you do that ?          (same words as 3, a different "that")
 6 how did you do that ?          (back to back: how it gave answer 5)
 7 what is my age ?               (same words as 2, nothing it read has changed)
 8 my age is fifty
 9 what is my age ?               (same words, the fact changed)
10 how did you do that ?
11 your age is four
12 how did you do that ?
13 my age is sixty
14 what is my age ?               (the fact changed again)
15 what is your age ?
The teacher: every question line carries the right answer, defined as what the same brain says if that line runs the long way, computed on a copy of the brain.
Count: wrong answers, and lines that ran the long way.

## Predictions
C: wrong at 5, 6, 9, 10 or 12, 14 at least; it never stops repeating them.
A: wrong at 9 and 14 (the fact changed; A only watches the line before), right on every how-line; it repeats the same kind of mistake at 14.
B: wrong at 5 (first how-repeat) and 9 (first what-repeat after a change); after each it lays the decide row for that question word and is right at 6, 10, 12, 14.
   Cost: B runs more lines the long way than A after learning (it is cautious for every "what" line once burned).
So: A makes fewer mistakes before anything is learned; B stops repeating mistakes A keeps making. If B shows no learning (wrong again at 14), my build of it is wrong.

## Correction to the harness, run 1 (before reading any result as a result)
In C and A the physics, given a line with the right answer attached, overwrites the memory with it and says it: run 1 scored C and A right by echoing the teacher.
Fix, same for all three: the brain's own answer is taken first, on a copy, with no answer attached; then the real brain gets the line with the teacher's answer, which is the correction.
"Right" means the brain's own answer equals the teacher's.

## Results, run 2 (e9.result.json), every prediction held
C (as built): wrong at 5, 6, 9, 10, 12, 14. Each correction overwrote the memory, and the next repeat was stale again. It never stops.
A (my told rule): wrong at 9 and 14. Right on every how-line without being taught, because it knows what the how formula reads. It made the same mistake twice: a changed fact under a repeated question.
B (the owner's way): wrong at 5 and 9, once each. Each wrong was kept as history (2 rows) and laid a row in decide's neuron: how -> :prev, what -> :prev. Right at 6, 10, 12 and 14 after that.
Long-way runs after learning: A 4, B 4.
Known cost of B, not exercised here: once burned on "what", every remembered "what" line after a different line before runs the long way, even when nothing it read changed.
Not built in B: reasoning about why beyond "the line before differed". A wrong caused by something else (a changed state row with the same line before) would teach the wrong lesson.
Decision for v16: B, the owner's way, is the decide of the v16 told block.
