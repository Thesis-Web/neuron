# E9: one conversation, three ways of deciding. The teacher's right answer for each question = the same brain running that line the long way (on a copy).
import sys, json
V16 = sys.argv[1]; sys.path.insert(0, V16)
from host15 import Brain
F1 = "INSERT INTO var ( run , name , value ) VALUES ( :run , ':owner' , :speaker ) ;"
F2 = "INSERT INTO var ( run , name , value ) SELECT :run , ':owner' , 'self' WHERE :speaker = 'user' ; INSERT INTO var ( run , name , value ) SELECT :run , ':owner' , 'user' WHERE :speaker = 'self' ;"
F3 = "INSERT INTO var ( run , name , value ) VALUES ( :run , ':key' , :owner || '.' || :head ) ;"
F11 = F3 + " SELECT value FROM state WHERE key = :key ORDER BY id DESC LIMIT 1 ; INSERT INTO var ( run , name , value ) VALUES ( :run , ':answer' , :found ) ;"
F5c = "INSERT INTO state ( key , value ) SELECT :key , :after WHERE :key IS NOT NULL ;"
F7 = "INSERT INTO say ( run , text ) VALUES ( :run , :answer ) ;"
HOW = "SELECT group_concat ( text , ' ' ) FROM stmt WHERE run IN ( SELECT id FROM run WHERE root = :prev OR root = ( SELECT run FROM memory WHERE id = ( SELECT memid FROM run WHERE id = :prev AND recalled = 1 ) ) ) ; INSERT INTO var ( run , name , value ) VALUES ( :run , ':answer' , :found ) ;"
TEACH = [('your', F2), ('my', F1), ('age', F11), ('is', F5c), ('?', F7), ('how', HOW)]
LINES = ['my age is forty', 'what is my age ?', 'how did you do that ?', 'your age is three', 'how did you do that ?', 'how did you do that ?',
         'what is my age ?', 'my age is fifty', 'what is my age ?', 'how did you do that ?', 'your age is four', 'how did you do that ?',
         'my age is sixty', 'what is my age ?', 'what is your age ?']
def clone(b, told):
    c = Brain(told, sat_path=V16 + '/sat15.json'); b.con.backup(c.con); return c
def run(mode):
    told = f'{V16}/physics16_{mode}.json'; b = Brain(told, sat_path=V16 + '/sat15.json')
    for w, f in TEACH: b.type(w + ' = ' + f)
    rows = []
    for i, L in enumerate(LINES, 1):
        exp = None
        if L.endswith('?'):
            c = clone(b, told); c.con.execute("UPDATE memory SET ended = 1 WHERE line = ? AND ended = 0", (L,)); exp = c.type(L); c.con.close()
        own, r = None, None
        if exp is not None:
            # the brain's own answer, before any correction: on a copy, the line with nothing attached
            c = clone(b, told); own = c.type(L); r = c.q("SELECT recalled, reopen FROM run WHERE kind = 'line' ORDER BY id DESC LIMIT 1")[0]; c.con.close()
            b.type(L + ' => ' + exp)          # then the teacher: the same line, with the right answer attached
        else:
            b.type(L); r = b.q("SELECT recalled, reopen FROM run WHERE kind = 'line' ORDER BY id DESC LIMIT 1")[0]
        rows.append({'n': i, 'line': L, 'question': exp is not None, 'right': (own == exp) if exp is not None else None, 'from_memory': r[0], 'long_way_again': r[1], 'out': (own or '')[:90], 'expected': (exp or '')[:90]})
    learned = b.q("SELECT count(*) FROM memwrong") if mode == 'B' else [(None,)]
    dg = b.q("SELECT gate FROM encoder WHERE word = 'decide'")[0][0]
    drows = b.q(f"SELECT (SELECT word FROM encoder WHERE gate = arrival), (SELECT word FROM encoder WHERE gate = trigger) FROM g{dg}")
    return rows, learned[0][0], drows
res = {}
for mode in ['C', 'A', 'B']:
    rows, learned, drows = run(mode)
    wrong = [r['n'] for r in rows if r['right'] is False]
    print(f'== {mode}: wrong at {wrong}; from memory at {[r["n"] for r in rows if r["from_memory"]]}; history rows {learned}; decide rows {drows}', flush=True)
    for r in rows:
        if r['question']: print(f"   {r['n']:2d} {r['line']:24s} {'RIGHT' if r['right'] else 'WRONG'} memory={r['from_memory']} again={r['long_way_again']} | got {r['out'][:60]!r}" + ('' if r['right'] else f" | right {r['expected'][:60]!r}"))
    res[mode] = {'wrong': wrong, 'rows': rows, 'history': learned, 'decide_rows': drows}
json.dump(res, open(sys.argv[2], 'w'), indent=1)
