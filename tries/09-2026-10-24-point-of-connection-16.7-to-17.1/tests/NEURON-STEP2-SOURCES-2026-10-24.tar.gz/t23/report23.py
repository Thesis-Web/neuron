# Writes RESULTS23.md from the measurement files. Every number comes from the JSON; the prose around them is the builder's.
import json, re, sys, collections
D = sys.argv[1]
A = json.load(open(f'{D}/a_diff.json')); PJ = json.load(open(f'{D}/a_js.json'))['pairs']
B = json.load(open(f'{D}/b.json')); B2 = json.load(open(f'{D}/b2.json')); B3 = json.load(open(f'{D}/b3.json'))['triggers']
FRAME = {'Init', 'Halt', 'Goto', 'Transaction', 'TableLock'}
L = []; P = L.append
def esc(x):
    return str(x).replace('|', '\\|')
def ops(d):
    return ' '.join(f"{k}" + (f"×{v}" if v > 1 else '') for k, v in sorted(d.items())) or '—'
def eff(e):
    if 'error' in e: return 'error'
    return f"{e['rows_out']} out" + (f", {e['changes']} changed" if e['changes'] else '') + (f", t {e['t_rows'][0]}→{e['t_rows'][1]}" if e['t_rows'][0] != e['t_rows'][1] else '') + (f", tables {e['tables'][0]}→{e['tables'][1]}" if e['tables'][0] != e['tables'][1] else '')
rows = {r['id']: r for r in A['rows']}

P('# Step 2 results: what each told word does to the silicon')
P('2026-10-24, turn 23. Measured in throwaway in-memory databases in the scratchpad. Nothing in ~/neuron/v1 or in any brain changed.')
P('')
P('- Plan and predictions were frozen at 19:06 before any run: NEURON-STEP2-EXPECT-2026-10-24.md (sha256 starts 0d4136a0c60f). The predictions are mine, not yours.')
P(f"- Two SQLites: the page's own (sql.js, SQLite {A['versions']['page']}) and this box's Python (SQLite {A['versions']['py']}). Tables below are the page's unless marked.")
P('- Every number below is read from the measurement files by report23.py. The words around them are mine.')
P('')
P('**Check one row yourself (10 seconds).** Paste this; the 5th word of the program is the compare the silicon uses for ">" (Le):')
P('```')
P('sqlite3 :memory: "CREATE TABLE t (a, b); EXPLAIN SELECT a FROM t WHERE a > 2;" | awk \'{print $2}\' | tr \'\\n\' \' \'')
P('```')
P('Swap `a > 2` for `NOT a > 2` and for `a <= 2`: both give Gt. The silicon\'s opposite of ">" is "<=".')
P('')
P('## Controls')
P('| Control | Page | Python |')
P('|---|---|---|')
names = {'C1': 'same line twice: identical program', 'C2a': 'literal only, 2→3: same opcodes', 'C2b': "literal only, 'y'→'z': same opcodes", 'C2c': 'literal only, LIMIT 1→2: same opcodes'}
for cid, c in A['controls'].items():
    f = lambda v: 'identical' if v['identical'] else ('same opcodes' if v['same_names'] else 'FAILED')
    P(f"| {names[cid]} | {f(c['page'])} | {f(c['py'])} |")
P('| authorizer: a table with no triggers reports only its own insert | — | passed |')
P('| authorizer: remove one trigger (agree_go), only its rows disappear | — | passed |')
P('')
P('So a word\'s bytecode diff shows the word, not the values typed with it. Where a diff shows "Integer" or "String8", that is the literal typed with the word (the 2 in `a > 2`) being loaded, not the word itself.')
P('')
P('## A. The told SQL words')
P('### A1. The statement words, whole (every program also has Init, Halt, Goto, Transaction; left out here)')
P('| Word | Line | Bytecode | Run on t (3 rows) |')
P('|---|---|---|---|')
for i in ['select', 'insert', 'update', 'delete', 'create', 'drop', 'delall']:
    r = rows[i]; o = [x for x in r['page']['ops_with'] if x not in FRAME]
    P(f"| {r['word']}{'' if r['told'] else ' (not told)'} | `{esc(r['with'])}` | {' '.join(o)} | {eff(r['page']['effect_with'])} |")
P('')
P('### A2. Every word: bytecode WITH it minus WITHOUT it')
P('| Word | With | Without | Added | Removed | Operands that changed (without → with) | Run: with / without |')
P('|---|---|---|---|---|---|---|')
for r in A['rows']:
    if r['kind'] == 'whole': continue
    pg = r['page']
    if 'error_without' in pg:
        P(f"| {esc(r['word'])}{'' if r['told'] else ' (not told)'} | `{esc(r['with'])}` | `{esc(r['without'])}` | cannot be removed: SQLite says *{pg['error_without']}* | | | {eff(pg['effect_with'])} / error |")
        continue
    od = ''
    if not pg['plus'] and not pg['minus']:
        od = '; '.join(f"{o[0]}: {o[2][3] if o[0] in ('SorterOpen','String8') else o[2][4] if o[0]=='Ne' else o[2][1]} → {o[1][3] if o[0] in ('SorterOpen','String8') else o[1][4] if o[0]=='Ne' else o[1][1]}" for o in (pg['operands'] or [])) or 'nothing differs'
    P(f"| {esc(r['word'])}{'' if r['told'] else ' (not told)'} | `{esc(r['with'])}` | `{esc(r['without'])}` | {ops(pg['plus'])} | {ops(pg['minus'])} | {od} | {eff(pg['effect_with'])} / {eff(pg['effect_without'])} |")
P('')
P('Notes on reading A2:')
P('- IS: same compare as =, with a different flag: = carries 84 (includes 16, "jump if NULL"), IS carries 196 (includes 128, "NULL equals NULL").')
P('- DESC: same bytecode; only the sorter\'s key changes, k(1,B) → k(1,-B).')
P('- INTEGER in CAST: same bytecode; Cast\'s target changes, 66 (TEXT) → 68 (INTEGER). In CREATE TABLE it changes only the stored schema text.')
P('')
P('### A3. The compare words: the jump each one compiles to')
P('SQLite compiles a compare as "skip this row unless ...", so it uses the opposite jump. Base line: `SELECT a FROM t WHERE a <op> 2`.')
P('| Word | Jump in the bytecode | Rows out (of 1,2,3) |')
P('|---|---|---|')
for i in ['eq', 'ne1', 'ne2', 'gt', 'le', 'lt', 'ge']:
    r = rows[i]; j = [k for k in r['page']['plus'] if k in ('Eq', 'Ne', 'Lt', 'Le', 'Gt', 'Ge')]
    P(f"| {r['word']}{'' if r['told'] else ' (not told)'} | {', '.join(j)} | {r['page']['effect_with']['rows_out']} |")
P('')
P('Identical programs (checked in Python\'s SQLite): `NOT a = 2` ≡ `a <> 2`; `NOT a > 2` ≡ `a <= 2`; `NOT a < 2` ≡ `a >= 2`; `NOT a <> 2` ≡ `a = 2`.')
P('- <> and != are one program: one meaning, two spellings.')
P('- The silicon\'s opposite pairs are =/<>, >/<=, </>=. ">" and "<" are mirror images (Le and Ge), not opposites.')
P('- AND adds a compare that rejects (Ne); OR adds one that accepts (Eq).')
P('')
P('### A4. Opposites the silicon shows by itself, and ones it does not')
P('| Pair | What the silicon shows |')
P('|---|---|')
ei, ed = rows['insert']['page']['effect_with'], rows['delete']['page']['effect_with']
P(f"| INSERT / DELETE | Insert vs Delete opcode; rows in t {ei['t_rows'][0]}→{ei['t_rows'][1]} vs {ed['t_rows'][0]}→{ed['t_rows'][1]} |")
ec, ex = rows['create']['page']['effect_with'], rows['drop']['page']['effect_with']
P(f"| CREATE / DROP | CreateBtree + ParseSchema vs Destroy + DropTable; tables {ec['tables'][0]}→{ec['tables'][1]} vs {ex['tables'][0]}→{ex['tables'][1]} |")
P('| = / <> , > / <= , < / >= | NOT of one is the identical program of the other |')
P('| AND / OR | reject jump (Ne) vs accept jump (Eq) |')
P('| + / - , × / ÷ | four separate opcodes (Add, Subtract, Multiply, Divide). Nothing in the bytecode marks them as opposites. That they are opposites is my belief, not measured. |')
P('| NULL / a value | Null vs Integer |')
P('')
P('### A5. Where the two SQLites differ')
P(f"Every with/without diff in A2 is the same in both. Three whole programs differ: UPDATE, CREATE and DROP. Python's SQLite {A['versions']['py']} adds one Delete opcode to each: it removes the old row and writes the new one. The page's SQLite {A['versions']['page']} rewrites the row in place, with no Delete. So \"update = delete + write\" holds in one SQLite version and not in the other.")
P('')
P('### A6. My predictions against the measurement')
P('| Prediction (frozen 19:06) | Measured | |')
P('|---|---|---|')
SC = [
 ('SELECT: OpenRead Rewind Column ResultRow Next; 3 out', 'exactly that', 'held'),
 ('INSERT: OpenWrite NewRowid MakeRecord Insert; t +1', 'that, + the literal loads', 'held'),
 ('UPDATE: Column, compare, MakeRecord, Insert, no NewRowid', 'that, + Rowid IsNull; Python\'s SQLite also Delete', 'held; build difference not predicted'),
 ('DELETE: OpenWrite Delete compare; t -1', 'that; with no WHERE it is one Clear', 'held'),
 ('CREATE: CreateBtree ParseSchema + schema write', 'that, + cookie reads and writes', 'held'),
 ('WITH: no difference from a subquery', 'nothing differs', 'held'),
 ('FROM: adds OpenRead Rewind Next', 'that, + Transaction: reading a table opens a read transaction', 'held + one not predicted'),
 ('compare words: = Ne, <> != Eq, > Le, < Ge, IS = Ne with a flag', 'exactly', 'held'),
 ('NOT: flips Ne to Eq, adds nothing', 'exactly', 'held'),
 ('IN (1,2): an ephemeral table', 'two compares (Eq), no table', 'WRONG'),
 ('EXISTS: not predicted', 'only the result\'s start value changes (Null → Integer 0)', '—'),
 ('LIMIT: Integer + DecrJumpZero', 'exactly', 'held'),
 ('ORDER BY: the sorter', 'that, + OpenPseudo MakeRecord', 'held'),
 ('DESC: only the sort key', 'exactly', 'held'),
 ('AS (alias), ( ), ; : nothing', 'nothing', 'held'),
 ('VALUES vs INSERT…SELECT: same or nearly', 'SELECT form adds a coroutine (5 opcodes)', 'held, roughly'),
 ('count max group_concat: AggStep AggFinal', 'that, + Copy Null (max + CollSeq)', 'held'),
 ('* (times) Multiply, || Concat, + Add, - Subtract, / Divide', 'exactly', 'held'),
 ('Opposites: INSERT/DELETE, CREATE/DROP, =/<>', 'shown', 'held'),
 ('Opposites: > / <', 'mirror images; the opposite of > is <=', 'WRONG as an opposite'),
 ('Opposites: + / -, × / ÷', 'not shown by the silicon', 'WRONG: my belief'),
 ('DELETE only in decide_go, lay_go and the stand-ins', 'exactly (+ mother\'s own host code empties outboxes)', 'held'),
 ('mother called by born, decide, lay, memwrong, bindrow, stmt', 'also end_branch (step back)', 'WRONG: missed one'),
 ('memory written only by end_line, end_teach, memhit_go', 'exactly', 'held'),
]
for a, b, c in SC: P(f'| {esc(a)} | {esc(b)} | {c} |')
P('')
P('## B. The physics: what each told trigger does')
P('Two measures, both SQLite\'s own: the authorizer (which tables a trigger reads, writes, removes, which functions it calls) and the bytecode SQLite lists for each trigger (page SQLite).')
P('"log" = writing the event table. The event table is in the brain\'s SQLite, but it is the narration the page draws from.')
P('')
P('### B1. Per trigger')
P('| Trigger | On | Reads | Writes (insert / update) | Removes | Calls | Bytecode: brain / log | Labels written in its log text |')
P('|---|---|---|---|---|---|---|---|')
for t in B['triggers']:
    if t['name'].startswith('miss_') or t['schema'] != 'main': continue
    b3 = B3[f"main.{t['name']}"]
    rd = ', '.join(k for k in t['reads'] if k != 'event') + (' + clock' if 'event' in t['reads'] else '')
    wr = ', '.join([x for x in t['inserts'] if x != 'event'] + [f"{k}.{'/'.join(v)}" for k, v in t['updates'].items() if k != 'event'])
    calls = ', '.join(f for f in t['functions'] if f in ('mother', 'satwork'))
    P(f"| {t['name']} | {t['event'].lower()} {t['table']} | {rd} | {wr or ('nothing itself; it hands its work to mother' if 'mother' in t['functions'] else '**only its own log line**')} | {', '.join(t['deletes'])} | {calls} | {sum(b3['counts'].values())} / {sum(b3['log'].values())} | {'; '.join(t['labels'])} |")
miss = [t for t in B['triggers'] if t['name'].startswith('miss_')]
P(f"| miss_k (×{len(miss)}, one shape) | insert land_k (instead of) | g_k arrival, remainder | lay | | | {sum(B3['main.miss_1']['counts'].values())} / 0 | |")
P(f"| work (×7, each source stand-in) | insert inbox | corpus, inbox, outbox | outbox | inbox | satwork | {sum(B3['wn.work']['counts'].values())} / 0 | |")
P('')
tb = collections.Counter(); tl = collections.Counter()
for k, v in B3.items():
    if k.startswith('main.') and '.miss_' not in k: tb.update(v['counts']); tl.update(v['log'])
P('### B2. The whole told physics (37 triggers), bytecode counted')
P(f"| Opcode | Brain work | Log for the page |")
P('|---|---|---|')
P(f"| all | {sum(tb.values())} | {sum(tl.values())} |")
for f, n in [('Insert', 'Insert (write a row)'), ('Delete', 'Delete (remove a row)'), ('Column', 'Column (read a cell)'), ('Ne', 'Ne'), ('Eq', 'Eq'), ('Le', 'Le'), ('Lt', 'Lt'), ('Ge', 'Ge'), ('Gt', 'Gt'),
             ('Add', 'Add'), ('Subtract', 'Subtract'), ('Multiply', 'Multiply'), ('Divide', 'Divide'), ('Concat', 'Concat (join text, ||)'), ('Program', 'Program (fire another trigger)'),
             ('Function:mother', 'mother'), ('Function:substr', 'substr (cut text)'), ('Function:instr', 'instr (find in text)'), ('Function:trim', 'trim')]:
    P(f'| {esc(n)} | {tb[f]} | {tl[f]} |')
P('')
P('### B3. One line in a bare brain (the told block\'s own last line, the source teaching line), real host')
P(f"Mother was handed {B2['mother_handed']} texts:")
P('| Kind | Count |')
P('|---|---|')
for k, n in B2['kinds']: P(f'| {k} | {n} |')
P(f"That is {B2['new_neuron_tables']} new neurons (table, view, miss trigger each), {B2['dna_rows_laid']} DNA rows, {B2['hop_triggers']} hop triggers, and the landings.")
P('')
P('What each DNA row\'s own hop trigger does (authorizer):')
P('| Hop triggers | Reads | Writes | Functions |')
P('|---|---|---|---|')
for s, n in B2['hop_shapes']:
    s = json.loads(s)
    P(f"| {n} | {', '.join(x for x in s.get('READ', []) if x != 'event')} + clock | {', '.join(x for x in s.get('INSERT', []) + ['%s (update)' % u for u in s.get('UPDATE', [])])} | {', '.join(s.get('FUNCTION', []))} |")
P('')
P('In words: count the hit on its own row, write the receipt, write a fire row, write the log line, and land the run on the next gate (or end it). The two on the ";" gate also decode the statement into output to sources.')
P('')
P('### B4. The brain\'s clock')
P('Every "now" in the told block is `(SELECT coalesce(max(id), 0) FROM event)`: the number of log rows written so far. The brain has no other clock. Its time is the length of the page\'s narration; if the log stopped being written, the brain\'s time would stop.')
P('')
P('## C. The 14 actions')
P('- In the told block each action (READ, WRITE, …, SPAWN) is a gate with an empty DNA table, a miss trigger, and no formula. Nothing runs when a line passes one.')
P('- The action names appear only as labels a builder wrote into the text of log rows. Count of each label in the told triggers\' log text, in the hop trigger text, and in mother\'s host code:')
lab = collections.Counter()
for t in B['triggers']:
    for l in t['labels']: lab.update(l.split())
host = ['CALL MOVE', 'CALL MOVE', 'FIND READ WRITE', 'WRITE', 'MOVE CALL']   # host15.py mother, read from its source
hl = collections.Counter(w for h in host for w in h.split())
P('| Action | Told triggers | Each hop trigger | Mother (host code) |')
P('|---|---|---|---|')
for a in ['READ', 'WRITE', 'COMPARE', 'ADD', 'SUBTRACT', 'MOVE', 'FIND', 'SPLIT', 'JOIN', 'CLOCK', 'HEAR', 'SAY', 'CALL', 'SPAWN']:
    P(f"| {a} | {lab[a]} | {1 if a in ('COMPARE', 'WRITE') else 0} | {hl[a]} |")
P('')
P(f"- ADD, SUBTRACT and SPLIT label nothing. The silicon does them anyway: the told physics has {tb['Add']} Add and {tb['Subtract']} Subtract opcodes (counters +1, and the word positions used to cut a line's first word off the rest) and {tb['Function:substr']} substr / {tb['Function:instr']} instr calls (that cut is the split).")
P(f"- DELETE (removes a row: {tb['Delete']} in the told physics) and NOT EXISTS (the miss test in all {len(miss)} miss triggers) are done and not named, as found before.")
P('- Four triggers write nothing but their own log line: run_said, relation_drawn, state_written, proc_status. Their labels (HEAR WRITE, WRITE, WRITE, COMPARE WRITE) describe the narration, not brain work.')
P('- Compare each label with that trigger\'s row in B1 to judge it. I have not scored them: deciding what a label "should" measure would be me assigning meanings.')
P('')
P('## D. Where the reference draft disagrees with today\'s measurements')
P('NEURON-REFERENCE-DRAFT-1-2026-10-23.md. I rebuilt the original draft from the commands of the session that wrote it (23:27-23:31 UTC on 10-23, plus its one wording edit) and diffed it with today\'s file: exactly two changes, both yours, lines 243 and 489. Below are lines that today\'s measurements contradict. I have not edited the draft.')
P('| Line | The draft says | Measured today |')
P('|---|---|---|')
P('| 276 | "14 physical actions: READ, WRITE, …" in the told block | Each is a gate with an empty DNA table and no formula; nothing runs when a line passes one. The names exist only as labels in log text (part C). ADD, SUBTRACT and SPLIT label nothing. |')
PH = ['input', 'encoder', 'decide', 'lay', 'born', 'source', 'agree', 'end', 'sense', 'memory', 'timeline', 'say', 'BUILD', 'formula', 'var', 'state']
ont = {t['table'] for t in B['triggers'] if t['schema'] == 'main'}
none = [p for p in PH if p not in ont]
P(f"| 277 | \"16 physics tables with their triggers\" | {', '.join(none)} have no trigger of their own (other triggers write them). state\'s only trigger writes the log and nothing else. |")
P('| 763, 780, 947 | positions exist only in the page | The same claim you corrected at line 489, three more times. It is true of what I built, but it is my gap against your design, written as if it were a plain fact. |')
P('| (missing) | — | The brain\'s clock is the count of log rows (B4). The draft does not say this anywhere. |')
P('')
P('## What this does not show')
P('- Part A\'s test lines are my choice; they are all in the table. Another base line could add or remove an opcode or two (the frame, a literal load).')
P('- B1 and B2 are static: what a trigger can do when it fires, not how often it fires. Only B3 is a real run, of one line.')
P('- This measures the SQL words and the physics only. It says nothing yet about any other word, or about where anything sits in the graph. No graph was changed.')
P('')
P('## Files')
P('- NEURON-STEP2-EXPECT-2026-10-24.md: the plan and predictions, frozen before the runs.')
P('- NEURON-STEP2-RESULTS-2026-10-24.md: this file.')
P('- NEURON-STEP2-SOURCES-2026-10-24.tar.gz: the scripts, every measurement file, and README with the commands to rerun all of it.')
M = []
for l in L:
    if l.startswith('|') and M and M[-1] and not M[-1].startswith('|'): M.append('')
    M.append(l)
open(f'{D}/RESULTS23.md', 'w').write('\n'.join(M) + '\n')
print(len(L), 'lines')
