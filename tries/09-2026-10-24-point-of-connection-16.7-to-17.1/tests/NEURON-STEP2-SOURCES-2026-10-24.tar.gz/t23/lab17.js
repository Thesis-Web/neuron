// LAB PLACE: where each measured point sits. The same code runs in the page and in the node check.
// A point's own place is its measured numbers on the three chosen axes, 10 brain units per unit (the lab's 'own' view in SQLite).
// Lines off: the place is the own place. Lines on, rule 'share' (default): place = (1 - pull) x own + pull x the average place of
// the points it is tied to, so a point keeps the same share of its own place however many lines it has. Rule 'sum' (tried first):
// place = (own + the sum of the tied places) / (1 + number of lines), so a point with many lines loses its own place to them.
// Both are solved for all points together until nothing moves; the answer is the same whatever the order or start.
var LabPlace = (function () {
  var UNIT = 10;
  function own(eff, axes) { return axes.map(function (k) { return (eff[k] || 0) * UNIT; }); }
  // rule 'share' (the default): place = (1 - pull) * own + pull * the average of its tied places. A point keeps the same share of
  // its own measured place however many lines it has. rule 'sum': each line pulls 1 against a hold of 1 (tried first: a point with
  // many lines loses its own place to them).
  function solve(points, ownOf, lines, pull, rule) {
    if (rule === 'sum') return solveSum(points, ownOf, lines, 1);
    var P = {}, ids = points.map(function (p) { return p.id; });
    ids.forEach(function (id) { P[id] = { own: (ownOf[id] || [0, 0, 0]).slice(), nb: [] }; });
    lines.forEach(function (l) { if (P[l[0]] && P[l[1]] && l[0] !== l[1]) { P[l[0]].nb.push(l[1]); P[l[1]].nb.push(l[0]); } });
    var X = {}; ids.forEach(function (id) { X[id] = P[id].own.slice(); });
    var it = 0, mv = 1;
    for (; it < 20000 && mv > 1e-9; it++) {
      mv = 0;
      ids.forEach(function (id) {
        var p = P[id], x;
        if (!p.nb.length) x = p.own.slice();
        else { var m = [0, 0, 0]; p.nb.forEach(function (j) { m[0] += X[j][0]; m[1] += X[j][1]; m[2] += X[j][2]; }); x = [0, 1, 2].map(function (k) { return (1 - pull) * p.own[k] + pull * m[k] / p.nb.length; }); }
        mv = Math.max(mv, Math.abs(x[0] - X[id][0]), Math.abs(x[1] - X[id][1]), Math.abs(x[2] - X[id][2])); X[id] = x;
      });
    }
    return { place: X, iterations: it, lastMove: mv };
  }
  function solveSum(points, ownOf, lines, hold) {
    var P = {}, ids = points.map(function (p) { return p.id; });
    ids.forEach(function (id) { P[id] = { own: (ownOf[id] || [0, 0, 0]).slice(), nb: [] }; });
    lines.forEach(function (l) { if (P[l[0]] && P[l[1]] && l[0] !== l[1]) { P[l[0]].nb.push(l[1]); P[l[1]].nb.push(l[0]); } });
    var X = {}; ids.forEach(function (id) { X[id] = P[id].own.slice(); });
    var it = 0, mv = 1;
    for (; it < 20000 && mv > 1e-9; it++) {
      mv = 0;
      ids.forEach(function (id) {
        var p = P[id], d = hold + p.nb.length, x = [hold * p.own[0], hold * p.own[1], hold * p.own[2]];
        p.nb.forEach(function (j) { x[0] += X[j][0]; x[1] += X[j][1]; x[2] += X[j][2]; });
        x = [x[0] / d, x[1] / d, x[2] / d];
        mv = Math.max(mv, Math.abs(x[0] - X[id][0]), Math.abs(x[1] - X[id][1]), Math.abs(x[2] - X[id][2])); X[id] = x;
      });
    }
    return { place: X, iterations: it, lastMove: mv };
  }
  return { solve: solve, own: own, UNIT: UNIT };
})();
if (typeof module !== 'undefined') module.exports = LabPlace;
