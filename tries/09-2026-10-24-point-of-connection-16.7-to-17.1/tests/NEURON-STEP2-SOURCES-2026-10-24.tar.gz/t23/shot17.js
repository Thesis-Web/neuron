// 17 check in a real headless Chromium: 16.4's parts still work, the measured tab places points exactly as node solves them,
// the places come back from SQLite, the switches work, the 16.4 view comes back, nothing scrolls sideways on a phone.
// usage: node shot17.js <html> <shot prefix> <expect17.json>
const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
const fs = require('fs');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const errs = [], R = {}, X = JSON.parse(fs.readFileSync(process.argv[4], 'utf8'));
  const open = async (opts) => { const page = await browser.newPage(opts); page.on('pageerror', e => errs.push(e.message)); page.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text()); });
    await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.startsWith('data:') || u.includes('cdnjs.cloudflare.com') || u.includes('fonts.g') ? r.continue() : r.abort(); });
    await page.goto('file://' + process.argv[2]); await page.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 180000 }); return page; };
  const settle = (page) => page.waitForFunction(() => { const s = window.__poc.lab.state(); return s.ready && !s.busy; }, null, { timeout: 60000 }).then(() => page.waitForTimeout(400));
  const cmp = async (page, want) => { const rows = await page.evaluate(() => window.__poc.lab.places()); let md = 0, n = 0, miss = [];
    rows.forEach(r => { const w = want[r[0]]; if (!w) { miss.push(r[0]); return; } n++; md = Math.max(md, Math.abs(r[1] - w[0]), Math.abs(r[2] - w[1]), Math.abs(r[3] - w[2])); });
    return { fromSQLite: rows.length, matched: n, expected: Object.keys(want).length, maxDiff: +md.toExponential(2), notExpected: miss }; };
  const page = await open({ viewport: { width: 1600, height: 950 } });
  await page.waitForTimeout(2500);
  // 16.4's parts
  R.presetButtons = await page.evaluate(() => document.querySelectorAll('#presets button').length);
  R.prompt = await page.evaluate(() => !!document.getElementById('line') && !!document.getElementById('run') && !!document.getElementById('restart'));
  R.graphTabSections = await page.evaluate(() => document.querySelectorAll('#panelg section').length);
  R.drawn164 = await page.evaluate(() => Object.keys(window.__poc.drawn()).length);
  await page.screenshot({ path: process.argv[3] + '-load.png' });
  const ev0 = await page.evaluate(() => window.__poc.events());
  await page.evaluate(() => { [...document.querySelectorAll('#presets button')].find(x => x.textContent.startsWith('the same line twice')).click(); });
  await page.waitForFunction(() => !window.__poc.busy(), null, { timeout: 240000 }); await page.waitForTimeout(1500);
  R.premade = { events: [ev0, await page.evaluate(() => window.__poc.events())], output: await page.evaluate(() => window.__poc.lastOutput()) };
  // the measured tab
  await page.click('#tabm'); await settle(page);
  R.labStatus = await page.evaluate(() => window.__poc.lab.state().status);
  R.panelsShown = await page.evaluate(() => [document.getElementById('panelg').hidden, document.getElementById('panelm').hidden]);
  for (let i = 0; i < 5; i++) { await page.click('#madd'); await settle(page); }
  R.firstFive = await page.evaluate(() => window.__poc.lab.state().added);
  R.firstFivePlaces = await page.evaluate(() => window.__poc.lab.places());
  R.view = await page.evaluate(() => window.__poc.lab.state().view);
  await page.click('#mall'); await settle(page); await page.waitForTimeout(1200);
  R.offCompare = await cmp(page, X.off);
  R.offLabels = await page.evaluate(() => window.__poc.lab.labels());
  R.axesLabels = await page.evaluate(() => window.__poc.lab.axesLabels());
  R.summary = await page.evaluate(() => document.getElementById('msum').innerText);
  R.brainHidden = await page.evaluate(() => Object.keys(window.__poc.lab.drawn()).length);
  await page.screenshot({ path: process.argv[3] + '-off.png' });
  // click a point on the stage: INSERT
  const xy = await page.evaluate(() => window.__poc.lab.screenOf('INSERT')); await page.mouse.click(xy[0], xy[1]); await page.waitForTimeout(500);
  R.clickInsert = (await page.evaluate(() => document.getElementById('sel').innerText)).slice(0, 400);
  // every kind of line, in proportion
  await page.evaluate(() => { document.querySelectorAll('#mkinds input[type=checkbox]').forEach(c => { c.checked = true; c.dispatchEvent(new Event('change', { bubbles: true })); }); });
  await settle(page); await page.waitForTimeout(1000);
  R.allShareCompare = await cmp(page, X.allShare); R.lineSegs = await page.evaluate(() => window.__poc.lab.lineSegs());
  await page.screenshot({ path: process.argv[3] + '-lines.png' });
  await page.selectOption('#mrule', 'sum'); await settle(page); R.allSumCompare = await cmp(page, X.allSum);
  await page.selectOption('#mrule', 'share'); await settle(page);
  // only completes
  await page.evaluate(() => { document.querySelectorAll('#mkinds input[type=checkbox]').forEach(c => { c.checked = c.getAttribute('data-mk') === 'completes'; c.dispatchEvent(new Event('change', { bubbles: true })); }); });
  await settle(page); R.completesCompare = await cmp(page, X.completesOnly);
  // lines off, axes read / test / gather
  await page.evaluate(() => { document.querySelectorAll('#mkinds input[type=checkbox]').forEach(c => { c.checked = false; c.dispatchEvent(new Event('change', { bubbles: true })); }); });
  await page.selectOption('#max', 'read'); await page.selectOption('#may', 'test'); await page.selectOption('#maz', 'gather'); await settle(page); await page.waitForTimeout(1000);
  R.rtgCompare = await cmp(page, X.rtg); R.rtgAxes = await page.evaluate(() => window.__poc.lab.axesLabels());
  await page.screenshot({ path: process.argv[3] + '-rtg.png' });
  await page.selectOption('#max', 'rows'); await page.selectOption('#may', 'structure'); await page.selectOption('#maz', 'text');
  // the words that are not told
  await page.check('#mnottold'); await page.click('#mall'); await settle(page); R.notToldCompare = await cmp(page, X.notTold);
  // the table of measured points
  await page.click('#mtable'); await page.waitForTimeout(500); R.tableRows = await page.evaluate(() => document.querySelectorAll('#ltable tr.arow').length);
  await page.evaluate(() => document.querySelector('#ltable tr.arow').click()); await page.waitForTimeout(300); R.tableDetail = (await page.evaluate(() => (document.querySelector('#ltable tr.det') || {}).innerText || '')).slice(0, 300);
  await page.click('#lclose');
  // start over: the brain restarts, the lab stays
  await page.click('#restart'); await page.waitForFunction(() => window.__poc.ready(), null, { timeout: 180000 }); await settle(page);
  R.afterRestart = await cmp(page, X.notTold);
  // back to the 16.4 view
  await page.uncheck('#mview'); await page.waitForTimeout(2500);
  R.back164 = { view: await page.evaluate(() => window.__poc.lab.state().view), drawn: await page.evaluate(() => Object.keys(window.__poc.drawn()).length), axes: await page.evaluate(() => window.__poc.lab.axesLabels().slice(0, 2)) };
  await page.click('#tabg'); R.tabBack = await page.evaluate(() => [document.getElementById('panelg').hidden, document.getElementById('panelm').hidden]);
  await page.fill('#line', 'dog ran'); await page.click('#run'); await page.waitForFunction(() => !window.__poc.busy(), null, { timeout: 240000 }); await page.waitForTimeout(800);
  R.typedAfter = await page.evaluate(() => window.__poc.lastOutput());
  await page.screenshot({ path: process.argv[3] + '-back.png' });
  R.overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  const phone = await open({ viewport: { width: 400, height: 860 }, deviceScaleFactor: 2 }); await phone.waitForTimeout(1500);
  await phone.click('#tabm'); await phone.waitForTimeout(500);
  R.phoneOverflow = await phone.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  await phone.evaluate(() => document.getElementById('tabm').scrollIntoView()); await phone.screenshot({ path: process.argv[3] + '-phone.png' });
  R.errors = errs; console.log(JSON.stringify(R, null, 1)); await browser.close();
})();
