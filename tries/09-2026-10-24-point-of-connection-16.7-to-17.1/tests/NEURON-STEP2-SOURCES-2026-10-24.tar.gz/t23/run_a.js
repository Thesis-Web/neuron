// Part A in the page's own SQLite (sql.js asm from the 16.4 sources): the same lines, the same measures as run_a.py.
// usage: node run_a.js <sql-asm-memory-growth.js> <pairs23.json> <out.json>
const fs = require('fs');
const initSqlJs = require(process.argv[2]);
const d = JSON.parse(fs.readFileSync(process.argv[3], 'utf8'));
initSqlJs().then(SQL => {
  const fresh = (pre) => { const db = new SQL.Database(); db.exec(d.setup + pre); return db; };
  const program = (pre, sql) => {
    const db = fresh(pre);
    try {
      const r = db.exec('EXPLAIN ' + sql);
      const rows = r.length ? r[0].values : [];
      return { ops: rows.map(x => [x[1], x[2], x[3], x[4], x[5] === null ? null : String(x[5]), x[6]]) };
    } catch (e) { return { error: String(e.message || e) }; }
  };
  const one = (db, q) => db.exec(q)[0].values[0][0];
  const effect = (pre, sql) => {
    const db = fresh(pre);
    const tables0 = one(db, "SELECT count(*) FROM sqlite_master WHERE type = 'table'");
    const rows0 = one(db, 'SELECT count(*) FROM t');
    const ch0 = one(db, 'SELECT total_changes()');
    let out;
    try { const r = db.exec(sql); out = r.length ? r[r.length - 1].values : []; }
    catch (e) { return { error: String(e.message || e) }; }
    return { rows_out: out.length, out: out.slice(0, 5), changes: one(db, 'SELECT total_changes()') - ch0,
             t_rows: [rows0, one(db, 'SELECT count(*) FROM t')], tables: [tables0, one(db, "SELECT count(*) FROM sqlite_master WHERE type = 'table'")] };
  };
  const ver = new SQL.Database().exec('SELECT sqlite_version()')[0].values[0][0];
  const res = { sqlite: ver, pairs: {}, controls: {} };
  for (const p of d.pairs) {
    const r = { with: Object.assign({ sql: p.with }, program(p.pre, p.with), { effect: effect(p.pre, p.with) }) };
    if (p.without) r.without = Object.assign({ sql: p.without }, program(p.pre, p.without), { effect: effect(p.pre, p.without) });
    res.pairs[p.id] = r;
  }
  for (const c of d.controls) res.controls[c.id] = { with: program('', c.with), without: program('', c.without) };
  fs.writeFileSync(process.argv[4], JSON.stringify(res, null, 1));
  console.log('sql.js sqlite', ver, Object.keys(res.pairs).length, 'pairs');
});
