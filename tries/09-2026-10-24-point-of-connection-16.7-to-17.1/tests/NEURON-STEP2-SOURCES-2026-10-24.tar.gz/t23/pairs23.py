# Part A pairs: for each told SQL word, a line with it and the nearest line without it (or with it swapped).
# The pairs are the builder's choice and are printed in the results exactly as run. Writes pairs23.json for both SQLites.
import json, sys

SETUP = "CREATE TABLE t (a INTEGER, b TEXT); INSERT INTO t VALUES (1, 'x'); INSERT INTO t VALUES (2, 'y'); INSERT INTO t VALUES (3, 'z');"
B = "SELECT a FROM t"
W = "SELECT a FROM t WHERE a"          # base for the compare operators: a truth test, no operator

# (id, word, told?, kind, with, without, extra setup)
# kind: whole = a verb, shown whole; pair = with/without; swap = the word replaced by another word; nopair = removing it is a syntax error
P = [
 ('select', 'SELECT', 1, 'whole', B, None, ''),
 ('insert', 'INSERT', 1, 'whole', "INSERT INTO t VALUES (4, 'w')", None, ''),
 ('update', 'UPDATE', 1, 'whole', "UPDATE t SET b = 'q' WHERE a = 1", None, ''),
 ('delete', 'DELETE', 1, 'whole', "DELETE FROM t WHERE a = 1", None, ''),
 ('create', 'CREATE', 1, 'whole', "CREATE TABLE u (c)", None, ''),
 ('with', 'WITH', 1, 'pair', "WITH c AS (SELECT a FROM t) SELECT a FROM c", "SELECT a FROM (SELECT a FROM t)", ''),
 ('from', 'FROM', 1, 'pair', "SELECT 1 FROM t", "SELECT 1", ''),
 ('where', 'WHERE', 1, 'pair', B + " WHERE a = 2", B, ''),
 ('eq', '=', 1, 'pair', W + " = 2", W, ''),
 ('gt', '>', 1, 'pair', W + " > 2", W, ''),
 ('lt', '<', 1, 'pair', W + " < 2", W, ''),
 ('is', 'IS', 1, 'swap', B + " WHERE a IS 2", B + " WHERE a = 2", ''),
 ('not', 'NOT', 1, 'pair', B + " WHERE NOT a = 2", B + " WHERE a = 2", ''),
 ('and', 'AND', 1, 'pair', B + " WHERE a = 2 AND b = 'y'", B + " WHERE a = 2", ''),
 ('or', 'OR', 1, 'pair', B + " WHERE a = 2 OR b = 'x'", B + " WHERE a = 2", ''),
 ('in', 'IN', 1, 'swap', B + " WHERE a IN (1, 2)", B + " WHERE a = 1", ''),
 ('like', 'LIKE', 1, 'swap', B + " WHERE b LIKE 'y'", B + " WHERE b = 'y'", ''),
 ('exists', 'EXISTS', 1, 'pair', "SELECT EXISTS (SELECT 1 FROM t WHERE a = 2)", "SELECT (SELECT 1 FROM t WHERE a = 2)", ''),
 ('limit', 'LIMIT', 1, 'pair', B + " LIMIT 1", B, ''),
 ('orderby', 'ORDER BY', 1, 'pair', B + " ORDER BY b", B, ''),
 ('desc', 'DESC', 1, 'pair', B + " ORDER BY b DESC", B + " ORDER BY b", ''),
 ('null', 'NULL', 1, 'swap', "SELECT NULL", "SELECT 1", ''),
 ('cast', 'CAST', 1, 'pair', "SELECT CAST(b AS INTEGER) FROM t", "SELECT b FROM t", ''),
 ('as', 'AS', 1, 'pair', "SELECT a AS k FROM t", B, ''),
 ('integer', 'INTEGER', 1, 'swap', "SELECT CAST(b AS INTEGER) FROM t", "SELECT CAST(b AS TEXT) FROM t", ''),
 ('integer2', 'INTEGER', 1, 'pair', "CREATE TABLE u (c INTEGER)", "CREATE TABLE u (c)", ''),
 ('values', 'VALUES', 1, 'swap', "INSERT INTO t VALUES (4, 'w')", "INSERT INTO t SELECT 4, 'w'", ''),
 ('into', 'INTO', 1, 'nopair', "INSERT INTO t VALUES (4, 'w')", "INSERT t VALUES (4, 'w')", ''),
 ('set', 'SET', 1, 'nopair', "UPDATE t SET b = 'q' WHERE a = 1", "UPDATE t b = 'q' WHERE a = 1", ''),
 ('table', 'TABLE', 1, 'nopair', "CREATE TABLE u (c)", "CREATE u (c)", ''),
 ('instr', 'instr', 1, 'pair', "SELECT instr(b, 'y') FROM t", "SELECT b FROM t", ''),
 ('count', 'count', 1, 'pair', "SELECT count(a) FROM t", B, ''),
 ('max', 'max', 1, 'pair', "SELECT max(a) FROM t", B, ''),
 ('group_concat', 'group_concat', 1, 'pair', "SELECT group_concat(b) FROM t", "SELECT b FROM t", ''),
 ('paren', '( )', 1, 'pair', "SELECT (a) FROM t", B, ''),
 ('comma', ',', 1, 'pair', "SELECT a, b FROM t", B, ''),
 ('semi', ';', 1, 'pair', B + ";", B, ''),
 ('star_all', '* (all columns)', 1, 'pair', "SELECT * FROM t", B, ''),
 ('star_times', '* (times)', 1, 'pair', "SELECT a * 2 FROM t", B, ''),
 ('concat', '||', 1, 'pair', "SELECT b || 'x' FROM t", "SELECT b FROM t", ''),
 ('assign', '= (in SET)', 1, 'nopair', "UPDATE t SET b = 'q' WHERE a = 1", "UPDATE t SET b 'q' WHERE a = 1", ''),
 # not told: measured because the owner asked about them
 ('ne1', '<>', 0, 'pair', W + " <> 2", W, ''),
 ('ne2', '!=', 0, 'pair', W + " != 2", W, ''),
 ('ge', '>=', 0, 'pair', W + " >= 2", W, ''),
 ('le', '<=', 0, 'pair', W + " <= 2", W, ''),
 ('drop', 'DROP', 0, 'whole', "DROP TABLE u", None, 'CREATE TABLE u (c);'),
 ('except', 'EXCEPT', 0, 'pair', B + " EXCEPT SELECT 1", B, ''),
 ('plus', '+', 0, 'pair', "SELECT a + 2 FROM t", B, ''),
 ('minus', '-', 0, 'pair', "SELECT a - 2 FROM t", B, ''),
 ('slash', '/', 0, 'pair', "SELECT a / 2 FROM t", B, ''),
 ('delall', 'DELETE (no WHERE)', 0, 'whole', "DELETE FROM t", None, ''),
 ('substr', 'substr', 0, 'pair', "SELECT substr(b, 1, 1) FROM t", "SELECT b FROM t", ''),
]
# controls
C = [
 ('C1', 'same line twice', B + " WHERE a = 2", B + " WHERE a = 2"),
 ('C2a', 'literal only: 2 -> 3', B + " WHERE a = 3", B + " WHERE a = 2"),
 ('C2b', "literal only: 'y' -> 'z'", B + " WHERE b LIKE 'z'", B + " WHERE b LIKE 'y'"),
 ('C2c', 'literal only: LIMIT 1 -> 2', B + " LIMIT 2", B + " LIMIT 1"),
]
out = {'setup': SETUP, 'pairs': [dict(zip(['id', 'word', 'told', 'kind', 'with', 'without', 'pre'], p)) for p in P],
       'controls': [dict(zip(['id', 'what', 'with', 'without'], c)) for c in C]}
json.dump(out, open(sys.argv[1], 'w'), indent=1)
print(len(P), 'pairs', len(C), 'controls')
