// The node side of the page check: the same rows, the same rule (lab17.js), the places the page must read back from SQLite.
// usage: node expect17.js lab.json lab17.js out.json
const fs = require('fs'), d = JSON.parse(fs.readFileSync(process.argv[2], 'utf8')), L = require(require('path').resolve(process.argv[3]));
const eff = {}; d.effects.forEach(e => { (eff[e[0]] = eff[e[0]] || {})[e[1]] = e[2]; });
const order = d.points.slice().sort((a, b) => a.ord - b.ord);
const KINDS = ['inverse', 'complement', 'negation', 'negates', 'same program', 'dual', 'completes', 'modifies', 'no change', 'same spelling'];
function scene(told, axes, kinds, pull, rule) {
  const pts = order.filter(p => told || p.told), on = {}; pts.forEach(p => { on[p.id] = 1; });
  const own = {}; pts.forEach(p => { own[p.id] = L.own(eff[p.id] || {}, axes); });
  const lines = d.lines.filter(l => kinds.includes(l[2]) && on[l[0]] && on[l[1]]);
  const r = L.solve(pts, own, lines, pull, rule), out = {}; pts.forEach(p => { out[p.label] = r.place[p.id]; }); return out;
}
const X = {
  off: scene(false, ['rows', 'structure', 'text'], [], 0.5, 'share'),
  allShare: scene(false, ['rows', 'structure', 'text'], KINDS, 0.5, 'share'),
  allSum: scene(false, ['rows', 'structure', 'text'], KINDS, 0.5, 'sum'),
  notTold: scene(true, ['rows', 'structure', 'text'], [], 0.5, 'share'),
  rtg: scene(false, ['read', 'test', 'gather'], [], 0.5, 'share'),
  completesOnly: scene(false, ['rows', 'structure', 'text'], ['completes'], 0.5, 'share') };
X.offAtOrigin = Object.values(X.off).filter(p => p.every(v => Math.abs(v) < .05)).length;
fs.writeFileSync(process.argv[4], JSON.stringify(X));
console.log('told points', Object.keys(X.off).length, '| at origin, lines off:', X.offAtOrigin, '| completes only: INTO at', X.completesOnly.INTO.map(v => v.toFixed(2)).join(', '));
