// which elements reach past the right edge at phone width, in each tab. usage: node wide17.js <html>
const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const page = await browser.newPage({ viewport: { width: 400, height: 860 }, deviceScaleFactor: 2 });
  await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.startsWith('data:') || u.includes('cdnjs.cloudflare.com') ? r.continue() : r.abort(); });
  await page.goto('file://' + process.argv[2]); await page.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 180000 }); await page.waitForTimeout(1500);
  const wide = () => page.evaluate(() => { const W = document.documentElement.clientWidth, out = []; document.querySelectorAll('body *').forEach(e => { const r = e.getBoundingClientRect(); if (r.width && r.right > W + 0.5 && e.offsetParent !== null) out.push(e.tagName + (e.id ? '#' + e.id : '') + (e.className && typeof e.className === 'string' ? '.' + e.className.split(' ')[0] : '') + ' right ' + Math.round(r.right) + ' w ' + Math.round(r.width)); }); return { scroll: document.documentElement.scrollWidth - W, over: out.slice(0, 12) }; });
  console.log('graph tab:', JSON.stringify(await wide()));
  await page.click('#tabm'); await page.waitForTimeout(500);
  console.log('measured tab:', JSON.stringify(await wide()));
  await browser.close();
})();
