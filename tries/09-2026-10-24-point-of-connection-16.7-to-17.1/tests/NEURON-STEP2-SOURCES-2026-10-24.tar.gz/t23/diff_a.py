# Part A diffs: opcodes added and removed (with minus without), operand changes when the opcode names match,
# executed effect, controls, and whether the two SQLite builds agree. Reads pairs23.json a_js.json a_py.json; writes a_diff.json.
import json, sys
from collections import Counter

FRAME = {'Init', 'Halt', 'Goto', 'Transaction', 'TableLock'}   # every program has these; shown, never counted as the word's

def names(prog):
    return Counter(o[0] for o in prog.get('ops', []))

def diff(w, wo):
    a, b = names(w), names(wo)
    plus = a - b; minus = b - a
    return dict(plus), dict(minus)

def operands(w, wo):
    # when both programs have the same opcode names in the same order, list the opcodes whose operands differ
    A, Bp = w.get('ops', []), wo.get('ops', [])
    if [o[0] for o in A] != [o[0] for o in Bp]:
        return None
    return [[x[0], x[1:], y[1:]] for x, y in zip(A, Bp) if x[1:] != y[1:]]

pairs = json.load(open(sys.argv[1]))['pairs']
R = {k: json.load(open(f)) for k, f in (('page', sys.argv[2]), ('py', sys.argv[3]))}
out = {'versions': {k: R[k]['sqlite'] for k in R}, 'rows': [], 'controls': {}}
for p in pairs:
    row = {'id': p['id'], 'word': p['word'], 'told': p['told'], 'kind': p['kind'], 'with': p['with'], 'without': p['without']}
    for k in R:
        r = R[k]['pairs'][p['id']]
        e = {'effect_with': r['with']['effect']}
        if 'error' in r['with']:
            e['error_with'] = r['with']['error']
        e['ops_with'] = [o[0] for o in r['with'].get('ops', [])]
        if 'without' in r:
            e['effect_without'] = r['without']['effect']
            if 'error' in r['without']:
                e['error_without'] = r['without']['error']
            else:
                e['plus'], e['minus'] = diff(r['with'], r['without'])
                e['operands'] = operands(r['with'], r['without'])
        row[k] = e
    pg, py = row['page'], row['py']
    row['builds_agree'] = (pg.get('plus'), pg.get('minus'), pg['ops_with'] if p['kind'] == 'whole' else None) == (py.get('plus'), py.get('minus'), py['ops_with'] if p['kind'] == 'whole' else None)
    out['rows'].append(row)
for k in R:
    for cid, c in R[k]['controls'].items():
        plus, minus = diff(c['with'], c['without'])
        out['controls'].setdefault(cid, {})[k] = {'plus': plus, 'minus': minus, 'same_names': not plus and not minus,
                                                   'identical': c['with'] == c['without']}
json.dump(out, open(sys.argv[4], 'w'), indent=1)

print('versions', out['versions'])
for cid, c in out['controls'].items():
    print(cid, {k: ('identical' if v['identical'] else 'same names' if v['same_names'] else f"DIFF +{v['plus']} -{v['minus']}") for k, v in c.items()})
print()
for r in out['rows']:
    pg = r['page']
    if r['kind'] == 'whole':
        ops = [o for o in pg['ops_with'] if o not in FRAME]
        print(f"{r['word']:<18} WHOLE  {' '.join(ops)}")
    elif 'error_without' in pg:
        print(f"{r['word']:<18} {r['kind'].upper():6} without: {pg['error_without']}")
    else:
        pl = ' '.join(f"+{k}" + (f"x{v}" if v > 1 else '') for k, v in sorted(pg['plus'].items()))
        mi = ' '.join(f"-{k}" + (f"x{v}" if v > 1 else '') for k, v in sorted(pg['minus'].items()))
        opd = '' if pl or mi else ('  operands: ' + '; '.join(f"{o[0]} {o[1]}->{o[2]}" for o in (pg['operands'] or [])) if pg['operands'] else '  (nothing differs)')
        print(f"{r['word']:<18} {r['kind'].upper():6} {pl} {mi}{opd}")
    ew, eo = pg['effect_with'], pg.get('effect_without')
    fx = lambda e: 'error: ' + e['error'] if 'error' in e else f"out {e['rows_out']} chg {e['changes']} t {e['t_rows'][0]}->{e['t_rows'][1]} tables {e['tables'][0]}->{e['tables'][1]}"
    print(f"{'':<18}        run with: {fx(ew)}" + (f" | without: {fx(eo)}" if eo else '') + ('' if r['builds_agree'] else '   <<< BUILDS DIFFER'))
