# Undo test: run A then B on a fresh test table and compare the database (or the value) with the start.
# exact = same schema, rows and rowids; content = same rows ignoring rowids. Writes undo.json.
import json, sqlite3, sys

SETUP = "CREATE TABLE t (a INTEGER, b TEXT); INSERT INTO t VALUES (1, 'x'); INSERT INTO t VALUES (2, 'y'); INSERT INTO t VALUES (3, 'z');"

def state(con):
    tabs = con.execute("SELECT name, sql FROM sqlite_master WHERE type = 'table' ORDER BY name").fetchall()
    exact = [(n, s, con.execute(f'SELECT rowid, * FROM "{n}" ORDER BY rowid').fetchall()) for n, s in tabs]
    content = [(n, s, sorted(map(repr, con.execute(f'SELECT * FROM "{n}"').fetchall()))) for n, s in tabs]
    return exact, content

def db_pair(a, b):
    con = sqlite3.connect(':memory:'); con.executescript(SETUP)
    e0, c0 = state(con)
    try:
        con.executescript(a); mid = state(con)[0]; con.executescript(b)
    except Exception as ex:
        return {'error': str(ex)}
    e1, c1 = state(con)
    return {'changed_between': mid != e0, 'exact': e1 == e0, 'content': c1 == c0}

def value_pair(expr):
    con = sqlite3.connect(':memory:'); con.executescript(SETUP)
    rows = con.execute(f'SELECT a, b, {expr} FROM t').fetchall()
    col = 'a' if 'a' in expr.split('(')[-1] or expr.startswith('(a') or expr.startswith('a') else 'b'
    got = [r[2] for r in rows]; want = [r[0] if col == 'a' else r[1] for r in rows]
    return {'values': got, 'start': want, 'exact': got == want}

D = [
 ('INSERT then DELETE that row', "INSERT INTO t VALUES (4, 'w');", "DELETE FROM t WHERE a = 4;"),
 ('DELETE then INSERT it back', "DELETE FROM t WHERE a = 2;", "INSERT INTO t VALUES (2, 'y');"),
 ('CREATE then DROP', "CREATE TABLE u (c);", "DROP TABLE u;"),
 ('DROP t then CREATE t', "DROP TABLE t;", "CREATE TABLE t (a INTEGER, b TEXT);"),
 ('UPDATE then UPDATE with the old value', "UPDATE t SET b = 'q' WHERE a = 1;", "UPDATE t SET b = 'x' WHERE a = 1;"),
 ('copy (INSERT ... SELECT) then DELETE the copy', "INSERT INTO t SELECT a + 10, b FROM t;", "DELETE FROM t WHERE a > 10;"),
 ('read (SELECT) then write (INSERT what was read)', "SELECT * FROM t WHERE a = 1;", "INSERT INTO t SELECT * FROM t WHERE a = 1;"),
 ('write (INSERT) then read (SELECT)', "INSERT INTO t VALUES (4, 'w');", "SELECT * FROM t;"),
 ('DELETE then CREATE (delete / spawn)', "DELETE FROM t WHERE a = 2;", "CREATE TABLE u (c);"),
]
V = [
 ('+2 then -2', '(a + 2) - 2'), ('-2 then +2', '(a - 2) + 2'), ('*2 then /2', '(a * 2) / 2'), ('/2 then *2', '(a / 2) * 2'),
 ("join (|| 'k') then cut back (substr)", "substr(b || 'k', 1, length(b))"),
]
out = {'sqlite': sqlite3.sqlite_version, 'db': {n: db_pair(a, b) for n, a, b in D}, 'value': {n: value_pair(e) for n, e in V}}
# cut into two pieces then join them, on a longer text (the first version of this line cut b || 'k' but compared with b: my error)
con = sqlite3.connect(':memory:')
for w in ['hello', 'store', 'a b c']:
    got = con.execute("SELECT substr(?, 1, 2) || substr(?, 3)", (w, w)).fetchone()[0]
    out['value'][f'cut {w!r} into two pieces then join them'] = {'values': [got], 'start': [w], 'exact': got == w}
# NOT twice, and = / <> as complements
con = sqlite3.connect(':memory:'); con.executescript(SETUP)
P = lambda q: [r[1:7] for r in con.execute('EXPLAIN ' + q)]
out['not_twice_same_program'] = P("SELECT a FROM t WHERE NOT (NOT a = 2)") == P("SELECT a FROM t WHERE a = 2")
eq = {r[0] for r in con.execute("SELECT a FROM t WHERE a = 2")}; ne = {r[0] for r in con.execute("SELECT a FROM t WHERE a <> 2")}
out['eq_ne'] = {'together_all_rows': eq | ne == {1, 2, 3}, 'overlap': sorted(eq & ne)}
json.dump(out, open(sys.argv[1], 'w'), indent=1)
for n, r in out['db'].items(): print(f"{n:<48} {r}")
for n, r in out['value'].items(): print(f"{n:<48} {r}")
print('NOT twice = no NOT:', out['not_twice_same_program'], '| = and <>:', out['eq_ne'])
