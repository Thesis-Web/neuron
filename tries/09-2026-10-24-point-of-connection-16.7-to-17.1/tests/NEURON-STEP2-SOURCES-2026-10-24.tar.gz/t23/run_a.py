# Part A in Python's sqlite3: for each line, its EXPLAIN program and what it does when run on a fresh copy of the test table.
import json, sqlite3, sys

def fresh(setup, pre):
    con = sqlite3.connect(':memory:', isolation_level=None)
    con.executescript(setup + pre)
    return con

def program(setup, pre, sql):
    con = fresh(setup, pre)
    try:
        rows = con.execute('EXPLAIN ' + sql).fetchall()
    except Exception as e:
        return {'error': str(e)}
    # addr, opcode, p1, p2, p3, p4, p5, comment
    return {'ops': [[r[1], r[2], r[3], r[4], None if r[5] is None else str(r[5]), r[6]] for r in rows]}

def effect(setup, pre, sql):
    con = fresh(setup, pre)
    tables0 = con.execute("SELECT count(*) FROM sqlite_master WHERE type = 'table'").fetchone()[0]
    rows_t0 = con.execute("SELECT count(*) FROM t").fetchone()[0]
    ch0 = con.total_changes
    try:
        cur = con.execute(sql)
        out = cur.fetchall()
    except Exception as e:
        return {'error': str(e)}
    tables1 = con.execute("SELECT count(*) FROM sqlite_master WHERE type = 'table'").fetchone()[0]
    rows_t1 = con.execute("SELECT count(*) FROM t").fetchone()[0]
    return {'rows_out': len(out), 'out': [list(map(lambda v: v if v is None or isinstance(v, (int, float)) else str(v), r)) for r in out][:5],
            'changes': con.total_changes - ch0, 't_rows': [rows_t0, rows_t1], 'tables': [tables0, tables1]}

d = json.load(open(sys.argv[1]))
res = {'sqlite': sqlite3.sqlite_version, 'pairs': {}, 'controls': {}}
for p in d['pairs']:
    r = {'with': {'sql': p['with'], **program(d['setup'], p['pre'], p['with']), 'effect': effect(d['setup'], p['pre'], p['with'])}}
    if p['without']:
        r['without'] = {'sql': p['without'], **program(d['setup'], p['pre'], p['without']), 'effect': effect(d['setup'], p['pre'], p['without'])}
    res['pairs'][p['id']] = r
for c in d['controls']:
    res['controls'][c['id']] = {'with': program(d['setup'], '', c['with']), 'without': program(d['setup'], '', c['without'])}
json.dump(res, open(sys.argv[2], 'w'), indent=1)
print('python sqlite', sqlite3.sqlite_version, len(res['pairs']), 'pairs')
