# Part B2: one line in a bare brain (the told block's own last line, the source teaching line), with the real host (host15.py).
# Records every text mother is handed, then asks SQLite's authorizer what each hop trigger laid by that line does.
# usage: run_b2.py <v16 dir> <physics16.json> <out.json>
import json, re, sqlite3, sys, collections
sys.path.insert(0, sys.argv[1])
from host15 import Brain

told = json.load(open(sys.argv[2]))
last = told['statements'][-1]
bare = dict(told, statements=told['statements'][:-1])
tmp = sys.argv[3] + '.told.json'
json.dump(bare, open(tmp, 'w'))
b = Brain(tmp, sat={})
handed = []
orig = b.mother
def logged(text, run, stmt):
    handed.append([text, run, stmt])
    return orig(text, run, stmt)
b.con.create_function('mother', 3, logged)
n0 = {t: b.con.execute(f'SELECT count(*) FROM "{t}"').fetchone()[0] for (t,) in b.con.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
b.con.execute(last)
n1 = {t: b.con.execute(f'SELECT count(*) FROM "{t}"').fetchone()[0] for (t,) in b.con.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}

def kind(t):
    m = re.match(r"\s*(CREATE TABLE g\d+|CREATE VIEW land_\d+|CREATE TRIGGER miss_\d+|CREATE TRIGGER hop_\d+_\d+|INSERT INTO g\d+|INSERT INTO land_\d+|UPDATE g\d+|SELECT \w+ FROM g\d+|INSERT INTO \w+\.inbox|\w+ ?\w*)", t)
    return re.sub(r'\d+', 'N', m.group(1)) if m else t[:30]
kinds = collections.Counter(kind(h[0]) for h in handed)

# the hop triggers this line laid: what each reads, inserts, updates, deletes and calls
seen = {}
def auth(action, a1, a2, db, src):
    if src and src.startswith('hop_'):
        seen.setdefault(src, set()).add((action, a1, a2))
    return sqlite3.SQLITE_OK
CODES = {sqlite3.SQLITE_READ: 'READ', sqlite3.SQLITE_INSERT: 'INSERT', sqlite3.SQLITE_UPDATE: 'UPDATE', sqlite3.SQLITE_DELETE: 'DELETE', sqlite3.SQLITE_FUNCTION: 'FUNCTION'}
hops = b.con.execute("SELECT name, tbl_name FROM sqlite_master WHERE type = 'trigger' AND name LIKE 'hop%'").fetchall()
b.con.set_authorizer(auth)
for v in sorted({t for _, t in hops}):
    b.con.execute(f'EXPLAIN INSERT INTO "{v}" (arrival, remainder, run, rest) VALUES (NULL, NULL, NULL, NULL)').fetchall()
b.con.set_authorizer(lambda *a: sqlite3.SQLITE_OK)
shapes = collections.Counter()
example = None
for name, acts in seen.items():
    s = {}
    for (a, a1, a2) in acts:
        nm = CODES.get(a)
        if not nm: continue
        tgt = a2 if nm == 'FUNCTION' else re.sub(r'\d+', 'N', a1 or '')
        s.setdefault(nm, set()).add(tgt)
    key = json.dumps({k: sorted(v) for k, v in sorted(s.items())})
    shapes[key] += 1
    example = example or (name, b.con.execute('SELECT sql FROM sqlite_master WHERE name = ?', (name,)).fetchone()[0])
out = {'line': last, 'mother_handed': len(handed), 'kinds': kinds.most_common(), 'first_texts': [h[0][:220] for h in handed[:12]],
       'rows_changed': {t: [n0.get(t, 0), n1[t]] for t in n1 if n1[t] != n0.get(t, 0) and not re.match(r'g\d+$', t)},
       'new_neuron_tables': sum(1 for t in n1 if t not in n0), 'dna_rows_laid': sum(n1[t] - n0.get(t, 0) for t in n1 if re.match(r'g\d+$', t)),
       'hop_triggers': len(hops), 'hop_shapes': shapes.most_common(), 'hop_example': example,
       'output': b.con.execute('SELECT text FROM output ORDER BY id DESC LIMIT 1').fetchone()}
json.dump(out, open(sys.argv[3], 'w'), indent=1)
print(json.dumps({k: out[k] for k in ('mother_handed', 'kinds', 'new_neuron_tables', 'dna_rows_laid', 'hop_triggers', 'rows_changed', 'output')}, indent=1))
print('hop trigger shapes:'); [print(' ', n, s) for s, n in shapes.most_common()]
print('example:', example[0]); print(example[1][:900])
