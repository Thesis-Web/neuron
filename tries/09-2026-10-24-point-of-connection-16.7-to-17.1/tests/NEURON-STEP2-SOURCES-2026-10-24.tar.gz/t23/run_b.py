# Part B: what each told trigger reads, inserts, updates, deletes and calls, reported by SQLite's own authorizer
# while it compiles (EXPLAIN, nothing runs) one statement into each table or view that has triggers.
# The told block is laid as in host15.py, minus its last statement (the source teaching line: a run, not physics).
# mother and satwork are stubs: EXPLAIN never calls them. usage: run_b.py physics16.json out.json [drop_trigger]
import json, re, sqlite3, sys

told = json.load(open(sys.argv[1]))
con = sqlite3.connect(':memory:', isolation_level=None)
con.create_function('mother', 3, lambda *a: None)
con.create_function('satwork', 4, lambda *a: 1)
for s in told['sats']:   # the source stand-ins, exactly as host15.py attaches them
    con.execute(f"ATTACH ':memory:' AS {s}")
    con.executescript(f"""CREATE TABLE {s}.corpus (word TEXT COLLATE NOCASE, hw TEXT, text TEXT, words TEXT); CREATE INDEX {s}.cw ON corpus(word);
        CREATE TABLE {s}.inbox (ask INTEGER PRIMARY KEY, word TEXT); CREATE TABLE {s}.outbox (ask INTEGER, word TEXT, hw TEXT, text TEXT, words TEXT);
        CREATE TRIGGER {s}.work AFTER INSERT ON inbox BEGIN INSERT INTO outbox SELECT NEW.ask, NEW.word, hw, text, words FROM corpus WHERE word = NEW.word;
          SELECT satwork('{s}', NEW.ask, NEW.word, (SELECT count(*) FROM outbox WHERE ask = NEW.ask)); DELETE FROM inbox WHERE ask = NEW.ask; END;""")
stmts = told['statements']
assert stmts[-1].startswith('INSERT INTO input'), 'last told statement is not the source teaching line'
for st in stmts[:-1]:
    con.execute(st)
if len(sys.argv) > 3:   # control C4: remove one trigger and measure again
    con.execute(f'DROP TRIGGER {sys.argv[3]}')

CODES = {getattr(sqlite3, n): n[7:] for n in dir(sqlite3) if n.startswith('SQLITE_') and n not in
         ('SQLITE_OK', 'SQLITE_DENY', 'SQLITE_IGNORE') and isinstance(getattr(sqlite3, n), int) and 0 < getattr(sqlite3, n) <= 33}
seen = {}
def auth(action, a1, a2, db, src):
    k = src or '(the statement itself)'
    seen.setdefault(k, set()).add((CODES.get(action, str(action)), a1, a2, db))
    return sqlite3.SQLITE_OK
con.set_authorizer(auth)

trigs = []
for schema in ['main'] + told['sats']:
    for name, tbl, sql in con.execute(f"SELECT name, tbl_name, sql FROM {schema}.sqlite_master WHERE type = 'trigger'"):
        m = re.match(r'CREATE TRIGGER (?:\w+\.)?\S+ (AFTER|INSTEAD OF|BEFORE) (INSERT|UPDATE|DELETE)(?: OF (\w+))? ON', sql)
        trigs.append({'schema': schema, 'name': name, 'table': tbl, 'when': m.group(1), 'event': m.group(2), 'col': m.group(3), 'sql': sql})
compiled = []
for key in sorted({(t['schema'], t['table'], t['event'], t['col']) for t in trigs}):
    schema, tbl, ev, col = key
    q = f'"{tbl}"' if schema == 'main' else f'{schema}."{tbl}"'
    if ev == 'INSERT':
        cols = [r[1] for r in con.execute(f'PRAGMA {schema}.table_info("{tbl}")')]
        sql = f"EXPLAIN INSERT INTO {q} ({', '.join(cols)}) VALUES ({', '.join('NULL' for _ in cols)})"
    elif ev == 'UPDATE':
        sql = f'EXPLAIN UPDATE {q} SET {col} = {col}'
    else:
        sql = f'EXPLAIN DELETE FROM {q}'
    try:
        con.execute(sql).fetchall(); compiled.append([sql, None])
    except Exception as e:
        compiled.append([sql, str(e)])
con.set_authorizer(lambda *a: sqlite3.SQLITE_OK)

out = {'sqlite': sqlite3.sqlite_version, 'compiled': compiled, 'triggers': []}
for t in trigs:
    acts = seen.get(t['name'], set())
    rd, ins, upd, dele, fn, other = {}, set(), {}, set(), set(), set()
    for (a, a1, a2, db) in acts:
        if a == 'READ': rd.setdefault(a1, set()).add(a2)
        elif a == 'INSERT': ins.add(a1)
        elif a == 'UPDATE': upd.setdefault(a1, set()).add(a2)
        elif a == 'DELETE': dele.add(a1)
        elif a == 'FUNCTION': fn.add(a2)
        elif a != 'SELECT': other.add(f'{a} {a1} {a2}')
    labels = []
    for m in re.finditer(r"'((?:READ|WRITE|COMPARE|ADD|SUBTRACT|MOVE|FIND|SPLIT|JOIN|CLOCK|HEAR|SAY|CALL|SPAWN)(?: (?:READ|WRITE|COMPARE|ADD|SUBTRACT|MOVE|FIND|SPLIT|JOIN|CLOCK|HEAR|SAY|CALL|SPAWN))*)'", t['sql']):
        labels.append(m.group(1))
    out['triggers'].append({**{k: t[k] for k in ('schema', 'name', 'table', 'when', 'event', 'col')}, 'compiled_seen': bool(acts),
        'reads': {k: sorted(x for x in v if x) for k, v in sorted(rd.items())}, 'inserts': sorted(ins), 'updates': {k: sorted(v) for k, v in sorted(upd.items())},
        'deletes': sorted(dele), 'functions': sorted(fn), 'other': sorted(other), 'labels': labels, 'mother_calls': t['sql'].count('mother(')})
json.dump(out, open(sys.argv[2], 'w'), indent=1)
bad = [c for c in compiled if c[1]]
print(len(trigs), 'triggers;', len(compiled), 'statements compiled;', len(bad), 'failed;', sum(1 for t in out['triggers'] if not t['compiled_seen']), 'triggers the authorizer never reported')
for c in bad: print('  FAILED', c)
