// Step 3: each point's own measured numbers, and the lines between points, each kind a test, in the page's SQLite (sql.js).
// usage: node rel.js <sql-asm-memory-growth.js> <pairs23.json> <lab.json>
const fs = require('fs');
const initSqlJs = require(process.argv[2]);
const PAIRS = JSON.parse(fs.readFileSync(process.argv[3], 'utf8'));
const SETUP = PAIRS.setup, SETUPNULL = SETUP + " INSERT INTO t VALUES (NULL, NULL);";
initSqlJs().then(SQL => {
  const fresh = (s) => { const db = new SQL.Database(); db.exec(s || SETUP); return db; };
  const prog = (sql, s) => { const db = fresh(s); try { const r = db.exec('EXPLAIN ' + sql); return { ops: r.length ? r[0].values.map(x => x.slice(1, 7)) : [] }; } catch (e) { return { error: String(e.message || e) }; } finally { db.close(); } };
  const run = (sql, s) => { const db = fresh(s); try { const r = db.exec(sql); return { rows: r.length ? r[r.length - 1].values : [] }; } catch (e) { return { error: String(e.message || e) }; } finally { db.close(); } };
  const same = (a, b) => !a.error && !b.error && JSON.stringify(a.ops) === JSON.stringify(b.ops);
  const ver = (() => { const d = new SQL.Database(); const v = d.exec('SELECT sqlite_version()')[0].values[0][0]; d.close(); return v; })();

  // ---- the points: one per told word; one spelling that measured two different jobs gets two points
  const TOLDW = ['SELECT', 'FROM', 'WHERE', 'INSERT', 'INTO', 'VALUES', 'UPDATE', 'SET', 'DELETE', 'CREATE', 'TABLE', 'AS', 'AND', 'OR', 'NOT', 'IN', 'LIKE', 'EXISTS', 'LIMIT', 'ORDER', 'BY', 'NULL', 'CAST', 'INTEGER', 'WITH', 'instr', 'count', 'max', 'group_concat', 'IS', 'DESC', '=', '(', ')', ',', ';', '*', '>', '<', '||'];
  const SPLIT = { 'AS': ['AS (name)', 'AS (in CAST, WITH)'], 'INTEGER': ['INTEGER (in CAST)', 'INTEGER (column type)'], '=': ['= (compare)', '= (in SET)'], '*': ['* (all columns)', '* (times)'] };
  const NOTTOLD = ['<>', '!=', '>=', '<=', 'DROP', 'EXCEPT', '+', '-', '/', 'substr'];
  const P = []; const PID = {};
  TOLDW.forEach(w => (SPLIT[w] || [w]).forEach(l => { PID[l] = P.length; P.push({ id: P.length, word: w, label: l, told: 1, ord: P.length }); }));
  NOTTOLD.forEach(w => { PID[w] = P.length; P.push({ id: P.length, word: w, label: w, told: 0, ord: P.length }); });
  const pairOf = { SELECT: 'select', FROM: 'from', WHERE: 'where', INSERT: 'insert', VALUES: 'values', UPDATE: 'update', DELETE: 'delete', CREATE: 'create', 'AS (name)': 'as', AND: 'and', OR: 'or', NOT: 'not', IN: 'in', LIKE: 'like', EXISTS: 'exists', LIMIT: 'limit',
    ORDER: 'orderby', BY: 'orderby', NULL: 'null', CAST: 'cast', 'INTEGER (in CAST)': 'integer', 'INTEGER (column type)': 'integer2', WITH: 'with', instr: 'instr', count: 'count', max: 'max', group_concat: 'group_concat', IS: 'is', DESC: 'desc',
    '= (compare)': 'eq', '(': 'paren', ')': 'paren', ',': 'comma', ';': 'semi', '* (all columns)': 'star_all', '* (times)': 'star_times', '>': 'gt', '<': 'lt', '||': 'concat',
    '<>': 'ne1', '!=': 'ne2', '>=': 'ge', '<=': 'le', DROP: 'drop', EXCEPT: 'except', '+': 'plus', '-': 'minus', '/': 'slash', substr: 'substr' };
  const PAIR = {}; PAIRS.pairs.forEach(p => { PAIR[p.id] = p; });

  // ---- a point's own numbers
  const FAM = { read: ['OpenRead', 'Rewind', 'Next', 'Prev', 'Column', 'Rowid', 'ResultRow', 'SeekRowid', 'SeekGE', 'SeekGT', 'SeekLE', 'SeekLT', 'IdxRowid', 'DeferredSeek'],
    test: ['Eq', 'Ne', 'Lt', 'Le', 'Gt', 'Ge', 'If', 'IfNot', 'IsNull', 'NotNull', 'IsTrue'], number: ['Add', 'Subtract', 'Multiply', 'Divide', 'Remainder', 'Cast', 'AddImm'],
    gather: ['AggStep', 'AggFinal', 'AggValue', 'SorterOpen', 'SorterInsert', 'SorterSort', 'SorterData', 'SorterNext', 'OpenEphemeral', 'IdxInsert', 'IdxDelete'],
    write: ['OpenWrite', 'NewRowid', 'MakeRecord', 'Insert', 'Delete', 'Clear', 'CreateBtree', 'Destroy', 'DropTable', 'ParseSchema', 'SetCookie'] };
  const FRAME = { Init: 1, Halt: 1, Goto: 1, Transaction: 1, TableLock: 1 };
  const count = (ops) => { const c = {}; ops.forEach(o => { c[o[0]] = (c[o[0]] || 0) + 1; }); return c; };
  const EFF = [];
  const effect = (pid, kind, value, how) => EFF.push([pid, kind, value, how]);
  const exec = (sql, pre) => { const db = fresh(SETUP + (pre || '')); const n0 = db.exec('SELECT count(*) FROM t')[0].values[0][0], k0 = db.exec("SELECT count(*) FROM sqlite_master WHERE type = 'table'")[0].values[0][0];
    let err = null; try { db.exec(sql); } catch (e) { err = String(e.message || e); }
    const n1 = db.exec('SELECT count(*) FROM t')[0].values[0][0], k1 = db.exec("SELECT count(*) FROM sqlite_master WHERE type = 'table'")[0].values[0][0]; db.close(); return { rows: n1 - n0, tables: k1 - k0, err }; };
  // text: join / cut, by length, on the words 'hello' and 'world'
  const TEXT = { '||': "SELECT 'hello' || 'world'", group_concat: "SELECT group_concat(w) FROM (SELECT 'hello' AS w UNION ALL SELECT 'world')", substr: "SELECT substr('hello', 1, 2)", instr: "SELECT instr('hello', 'l')",
    CAST: "SELECT CAST('hello' AS INTEGER)", max: "SELECT max(w) FROM (SELECT 'hello' AS w UNION ALL SELECT 'world')", count: "SELECT count(w) FROM (SELECT 'hello' AS w UNION ALL SELECT 'world')" };
  P.forEach(p => {
    const pid = p.id, pr = PAIR[pairOf[p.label]];
    // rows and structure: what its line does to t and to the schema, minus what the line without it does
    if (pr) {
      const a = exec(pr.with, pr.pre), b = pr.without ? exec(pr.without, pr.pre) : { rows: 0, tables: 0 };
      effect(pid, 'rows', Math.sign(a.rows - b.rows), `run "${pr.with}": t ${a.rows >= 0 ? '+' : ''}${a.rows} rows` + (pr.without ? `; without it, "${pr.without}": ${b.rows >= 0 ? '+' : ''}${b.rows}` : ''));
      effect(pid, 'structure', Math.sign(a.tables - b.tables), `run "${pr.with}": ${a.tables >= 0 ? '+' : ''}${a.tables} tables` + (pr.without ? `; without it: ${b.tables >= 0 ? '+' : ''}${b.tables}` : ''));
      // steps it adds over the line without it (for a verb, its whole program less the frame every program has)
      const pw = prog(pr.with, SETUP + pr.pre), po = pr.without ? prog(pr.without, SETUP + pr.pre) : { ops: [] };
      if (!pw.error && !po.error) {
        const cw = count(pw.ops), co = count(po.ops);
        Object.keys(FAM).forEach(f => { let n = 0; FAM[f].forEach(op => { n += Math.max(0, (cw[op] || 0) - (co[op] || 0)); }); effect(pid, f, n, `steps of ${f} its line adds: ` + FAM[f].filter(op => (cw[op] || 0) > (co[op] || 0)).map(op => op + ((cw[op] - (co[op] || 0)) > 1 ? ' x' + (cw[op] - (co[op] || 0)) : '')).join(', ')); });
      }
    } else {
      ['rows', 'structure', 'read', 'test', 'number', 'gather', 'write'].forEach(k => effect(pid, k, 0, 'not measured alone: removing it makes SQLite refuse the line (step 2)'));
    }
    const tq = TEXT[p.label];
    if (tq) {
      const r = run(tq), out = r.rows[0] ? r.rows[0][0] : null, ins = (tq.match(/'([a-z]+)'/g) || []).map(s => s.slice(1, -1)).filter(s => s.length > 1);
      const longest = Math.max(...ins.map(s => s.length));
      let v = 0; if (typeof out === 'string') { if (out.length > longest && ins.every(s => out.includes(s))) v = 1; else if (out.length < longest && ins.some(s => s.includes(out))) v = -1; }
      effect(pid, 'text', v, `"${tq}" gives ${JSON.stringify(out)}` + (typeof out === 'string' ? ` (${out.length} letters; longest in: ${longest})` : ' (not text)'));
    } else effect(pid, 'text', 0, 'its output is not text');
  });

  // ---- lines
  const L = [], REJ = [];
  const line = (a, b, kind, how) => L.push([PID[a], PID[b], kind, how]);
  // 1 inverse
  const state = (db) => JSON.stringify(db.exec("SELECT name, sql FROM sqlite_master WHERE type = 'table' ORDER BY name").concat(db.exec('SELECT rowid, * FROM t ORDER BY rowid')));
  const undo = (a, b) => { const db = fresh(); const s0 = state(db); try { db.exec(a); db.exec(b); } catch (e) { db.close(); return 'error'; } const s1 = state(db); db.close(); return s0 === s1; };
  const val = (e) => run(`SELECT ${e} FROM t`).rows.map(r => r[0]);
  const base = { a: val('a'), b: val('b') };
  const INV = [['INSERT', 'DELETE', "INSERT INTO t VALUES (4, 'w');", "DELETE FROM t WHERE a = 4;"], ['CREATE', 'DROP', 'CREATE TABLE u (c);', 'DROP TABLE u;']];
  INV.forEach(([A, B, a, b]) => { const ok = undo(a, b); (ok === true ? L : REJ).push([PID[A], PID[B], 'inverse', `${a} then ${b}: ${ok === true ? 'back exactly' : 'not back'}`]); });
  [['INSERT', 'UPDATE', "INSERT INTO t VALUES (4, 'w');", "UPDATE t SET b = 'q' WHERE a = 4;"], ['SELECT', 'DELETE', 'SELECT * FROM t;', 'DELETE FROM t WHERE a = 1;']].forEach(([A, B, a, b]) => { const ok = undo(a, b); (ok === true ? L : REJ).push([PID[A], PID[B], 'inverse', `${a} then ${b}: ${ok === true ? 'back exactly' : 'not back'}`]); });
  [['+', '-', '(a + 2) - 2', 'a'], ['* (times)', '/', '(a * 2) / 2', 'a'], ['||', 'substr', "substr(b || 'k', 1, length(b))", 'b'], ['+', '* (times)', '(a + 2) * 2', 'a']].forEach(([A, B, e, col]) => {
    const ok = JSON.stringify(val(e)) === JSON.stringify(base[col]); (ok ? L : REJ).push([PID[A], PID[B], 'inverse', `SELECT ${e}: ${JSON.stringify(val(e))} against ${col} ${JSON.stringify(base[col])}`]); });
  // 2 complement and 3 same program, every pair of the compare words
  const C = ['= (compare)', '<>', '!=', '>', '<', '>=', '<=', 'IS'], OPS = { '= (compare)': '=', IS: 'IS' };
  const op = (w) => OPS[w] || w;
  const kept = (w, s) => run(`SELECT rowid FROM t WHERE a ${op(w)} 2`, s).rows.map(r => r[0]);
  const ALL = (s) => run('SELECT rowid FROM t', s).rows.map(r => r[0]);
  for (let i = 0; i < C.length; i++) for (let j = i + 1; j < C.length; j++) {
    const A = C[i], B = C[j];
    [[SETUP, ''], [SETUPNULL, ' (with a NULL row)']].forEach(([s, tag]) => {
      const ka = kept(A, s), kb = kept(B, s), all = ALL(s), uni = new Set(ka.concat(kb)), both = ka.filter(x => kb.includes(x));
      const ok = uni.size === all.length && both.length === 0;
      const how = `rows kept on t${tag}: ${op(A)} ${JSON.stringify(ka)}, ${op(B)} ${JSON.stringify(kb)}, of ${JSON.stringify(all)}`;
      if (!tag) (ok ? L : REJ).push([PID[A], PID[B], 'complement', how]); else (ok ? L : REJ).push([PID[A], PID[B], 'complement (NULL row)', how]);
    });
    const pa = prog(`SELECT a FROM t WHERE a ${op(A)} 2`), pb = prog(`SELECT a FROM t WHERE a ${op(B)} 2`);
    (same(pa, pb) ? L : REJ).push([PID[A], PID[B], 'same program', `WHERE a ${op(A)} 2 and WHERE a ${op(B)} 2: ${same(pa, pb) ? 'identical programs' : 'programs differ'}`]);
  }
  // 4 negation: NOT A compiles to B
  C.forEach(A => { let found = false; C.forEach(B => { if (A === B) return; if (same(prog(`SELECT a FROM t WHERE NOT a ${op(A)} 2`), prog(`SELECT a FROM t WHERE a ${op(B)} 2`))) { found = true; L.push([PID[A], PID[B], 'negation', `NOT a ${op(A)} 2 is the identical program to a ${op(B)} 2`]); } });
    (found ? L : REJ).push([PID['NOT'], PID[A], 'negates', `NOT a ${op(A)} 2: ${found ? 'compiles to another compare word' : 'compiles to no other compare word'}`]); });
  // 5 dual (De Morgan), on several p, q
  const PQ = [['a = 2', "b = 'y'"], ['a > 1', "b = 'z'"], ['a < 3', "b = 'x'"]];
  const rowsOf = (w) => JSON.stringify(run(`SELECT rowid FROM t WHERE ${w}`).rows);
  const d1 = PQ.every(([p, q]) => rowsOf(`NOT (${p} AND ${q})`) === rowsOf(`(NOT ${p}) OR (NOT ${q})`)), d2 = PQ.every(([p, q]) => rowsOf(`NOT (${p} OR ${q})`) === rowsOf(`(NOT ${p}) AND (NOT ${q})`));
  const dself = PQ.every(([p, q]) => rowsOf(`${p} AND ${q}`) === rowsOf(`${p} OR ${q}`));
  (d1 && d2 ? L : REJ).push([PID['AND'], PID['OR'], 'dual', `NOT (p AND q) keeps the rows of (NOT p) OR (NOT q): ${d1}; NOT (p OR q) those of (NOT p) AND (NOT q): ${d2}; on ${PQ.length} pairs p, q`]);
  REJ.push([PID['AND'], PID['OR'], 'same rows (control)', `p AND q keeps the same rows as p OR q: ${dself}`]);
  // 6 completes / modifies / no change: a word against the verb whose line it is in. [point, verb, line, token index, clause indexes]
  const R6 = [
    ['FROM', 'SELECT', 'SELECT a FROM t WHERE a = 2 ORDER BY b DESC LIMIT 1', 2, [2, 3]], ['WHERE', 'SELECT', 'SELECT a FROM t WHERE a = 2 ORDER BY b DESC LIMIT 1', 4, [4, 5, 6, 7]],
    ['ORDER', 'SELECT', 'SELECT a FROM t WHERE a = 2 ORDER BY b DESC LIMIT 1', 8, [8, 9, 10, 11]], ['BY', 'SELECT', 'SELECT a FROM t WHERE a = 2 ORDER BY b DESC LIMIT 1', 9, [8, 9, 10, 11]],
    ['DESC', 'SELECT', 'SELECT a FROM t WHERE a = 2 ORDER BY b DESC LIMIT 1', 11, [11]], ['LIMIT', 'SELECT', 'SELECT a FROM t WHERE a = 2 ORDER BY b DESC LIMIT 1', 12, [12, 13]],
    [',', 'SELECT', 'SELECT a , b FROM t', 2, [2, 3]], ['AS (name)', 'SELECT', 'SELECT a AS k FROM t', 2, [2, 3]], ['(', 'SELECT', 'SELECT ( a ) FROM t', 1, [1, 3]], [')', 'SELECT', 'SELECT ( a ) FROM t', 3, [1, 3]], [';', 'SELECT', 'SELECT a FROM t ;', 4, [4]],
    ['INTO', 'INSERT', "INSERT INTO t ( a , b ) VALUES ( 4 , 'w' )", 1, [1, 2]], ['VALUES', 'INSERT', "INSERT INTO t ( a , b ) VALUES ( 4 , 'w' )", 8, [8, 9, 10, 11, 12, 13]],
    ['(', 'INSERT', "INSERT INTO t ( a , b ) VALUES ( 4 , 'w' )", 9, [9, 13]], [')', 'INSERT', "INSERT INTO t ( a , b ) VALUES ( 4 , 'w' )", 13, [9, 13]], [',', 'INSERT', "INSERT INTO t ( a , b ) VALUES ( 4 , 'w' )", 11, [11, 12]],
    ['SET', 'UPDATE', "UPDATE t SET b = 'q' WHERE a = 1", 2, [2, 3, 4, 5]], ['= (in SET)', 'UPDATE', "UPDATE t SET b = 'q' WHERE a = 1", 4, [4, 5]], ['WHERE', 'UPDATE', "UPDATE t SET b = 'q' WHERE a = 1", 6, [6, 7, 8, 9]],
    ['FROM', 'DELETE', 'DELETE FROM t WHERE a = 1', 1, [1, 2]], ['WHERE', 'DELETE', 'DELETE FROM t WHERE a = 1', 3, [3, 4, 5, 6]],
    ['TABLE', 'CREATE', 'CREATE TABLE u ( c INTEGER )', 1, [1]], ['INTEGER (column type)', 'CREATE', 'CREATE TABLE u ( c INTEGER )', 5, [5]], ['(', 'CREATE', 'CREATE TABLE u ( c INTEGER )', 3, [3, 6]],
    ['AS (in CAST, WITH)', 'WITH', 'WITH c AS ( SELECT a FROM t ) SELECT a FROM c', 2, [2]], ['AS (in CAST, WITH)', 'CAST', 'SELECT CAST ( b AS INTEGER ) FROM t', 4, [4]],
    ['INTEGER (in CAST)', 'CAST', 'SELECT CAST ( b AS INTEGER ) FROM t', 5, [4, 5]], ['(', 'CAST', 'SELECT CAST ( b AS INTEGER ) FROM t', 2, [2, 6]],
    ['TABLE', 'DROP', 'DROP TABLE u', 1, [1], 'CREATE TABLE u (c);']];
  const R6OUT = [];
  R6.forEach(([w, v, ln, ti, span, pre]) => {
    const toks = ln.split(' '), s = SETUP + (pre || '');
    const tokLine = toks.filter((_, i) => i !== ti).join(' '), clLine = toks.filter((_, i) => !span.includes(i)).join(' ');
    const p0 = prog(ln, s), pt = prog(tokLine, s), pc = prog(clLine, s);
    const r0 = run(ln, s), rc = run(clLine, s);
    let kind, why;
    if (pt.error && pc.error) { kind = 'completes'; why = `without "${toks[ti]}": refused (${pt.error}); without "${span.map(i => toks[i]).join(' ')}": refused (${pc.error})`; }
    else { const alt = !pt.error ? [tokLine, pt, run(tokLine, s)] : [clLine, pc, rc];
      if (same(alt[1], p0)) { kind = 'no change'; why = `"${alt[0]}" is the identical program`; }
      else { kind = 'modifies'; why = `"${alt[0]}" runs, and its program ${JSON.stringify(alt[2].rows) === JSON.stringify(r0.rows) ? 'differs (same rows here)' : 'and its rows differ'}`; } }
    R6OUT.push([w, v, ln, kind, why]);
    L.push([PID[w], PID[v], kind, `in "${ln}": ${why}`]);
  });
  // words inside a clause, from step 2's pairs: both lines run and the program changes (or not)
  const INSIDE = { WHERE: ['= (compare)', '>', '<', 'IS', 'NOT', 'AND', 'OR', 'IN', 'LIKE', '<>', '!=', '>=', '<='], SELECT: ['||', '* (times)', '* (all columns)', 'CAST', 'instr', 'count', 'max', 'group_concat', 'EXISTS', 'NULL', 'WITH', 'substr', '+', '-', '/', 'EXCEPT'] };
  Object.keys(INSIDE).forEach(v => INSIDE[v].forEach(w => { const pr = PAIR[pairOf[w]]; const a = prog(pr.with, SETUP + pr.pre), b = prog(pr.without, SETUP + pr.pre);
    const kind = a.error || b.error ? 'not measured' : same(a, b) ? 'no change' : 'modifies'; L.push([PID[w], PID[v], kind, `"${pr.with}" against "${pr.without}": ${kind === 'no change' ? 'identical program' : 'the program changes'}`]); }));
  // 7 same spelling
  Object.keys(SPLIT).forEach(w => L.push([PID[SPLIT[w][0]], PID[SPLIT[w][1]], 'same spelling', `both are "${w}"`]));
  const out = { sqlite: ver, points: P, effects: EFF, lines: L, rejected: REJ, removal: R6OUT };
  fs.writeFileSync(process.argv[4], JSON.stringify(out, null, 1));
  const byKind = {}; L.forEach(l => { byKind[l[2]] = (byKind[l[2]] || 0) + 1; }); const rk = {}; REJ.forEach(l => { rk[l[2]] = (rk[l[2]] || 0) + 1; });
  console.log('sqlite', ver, P.length, 'points (' + P.filter(p => p.told).length + ' told);', EFF.length, 'numbers;', L.length, 'lines', byKind, '| tested and rejected', rk);
});
