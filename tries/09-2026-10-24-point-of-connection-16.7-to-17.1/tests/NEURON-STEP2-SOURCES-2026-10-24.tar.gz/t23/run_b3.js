// Part B3: each told trigger's own bytecode, in the page's SQLite (sql.js 3.39.3). EXPLAIN lists a trigger's program after the
// statement that fires it, starting with Init whose P4 is "-- TRIGGER <name>". The told block is laid as in run_b.py.
// usage: node run_b3.js <sql-asm-memory-growth.js> <physics16.json> <out.json>
const fs = require('fs');
const initSqlJs = require(process.argv[2]);
const told = JSON.parse(fs.readFileSync(process.argv[3], 'utf8'));
initSqlJs().then(SQL => {
  const db = new SQL.Database();
  db.create_function('mother', (t, r, s) => null);
  db.create_function('satwork', (s, a, w, n) => 1);
  for (const s of told.sats) {
    db.exec(`ATTACH ':memory:' AS ${s}`);
    db.exec(`CREATE TABLE ${s}.corpus (word TEXT COLLATE NOCASE, hw TEXT, text TEXT, words TEXT); CREATE INDEX ${s}.cw ON corpus(word);
      CREATE TABLE ${s}.inbox (ask INTEGER PRIMARY KEY, word TEXT); CREATE TABLE ${s}.outbox (ask INTEGER, word TEXT, hw TEXT, text TEXT, words TEXT);
      CREATE TRIGGER ${s}.work AFTER INSERT ON inbox BEGIN INSERT INTO outbox SELECT NEW.ask, NEW.word, hw, text, words FROM corpus WHERE word = NEW.word;
        SELECT satwork('${s}', NEW.ask, NEW.word, (SELECT count(*) FROM outbox WHERE ask = NEW.ask)); DELETE FROM inbox WHERE ask = NEW.ask; END;`);
  }
  const st = told.statements;
  if (!st[st.length - 1].startsWith('INSERT INTO input')) throw new Error('last statement is not the teaching line');
  for (const s of st.slice(0, -1)) db.exec(s);
  const q = (sql) => { const r = db.exec(sql); return r.length ? r[0].values : []; };
  const trigs = [];
  for (const schema of ['main'].concat(told.sats))
    for (const [name, tbl, sql] of q(`SELECT name, tbl_name, sql FROM ${schema}.sqlite_master WHERE type = 'trigger'`)) {
      const m = sql.match(/CREATE TRIGGER (?:\w+\.)?\S+ (AFTER|INSTEAD OF|BEFORE) (INSERT|UPDATE|DELETE)(?: OF (\w+))? ON/);
      trigs.push({ schema, name, tbl, ev: m[2], col: m[3] || null });
    }
  const keys = [...new Set(trigs.map(t => JSON.stringify([t.schema, t.tbl, t.ev, t.col])))].sort();
  const progs = {};   // trigger name -> list of opcode lists (one per compile it appeared in)
  for (const k of keys) {
    const [schema, tbl, ev, col] = JSON.parse(k);
    const qt = schema === 'main' ? `"${tbl}"` : `${schema}."${tbl}"`;
    let sql;
    if (ev === 'INSERT') { const cols = q(`PRAGMA ${schema}.table_info("${tbl}")`).map(r => r[1]); sql = `EXPLAIN INSERT INTO ${qt} (${cols.join(', ')}) VALUES (${cols.map(() => 'NULL').join(', ')})`; }
    else if (ev === 'UPDATE') sql = `EXPLAIN UPDATE ${qt} SET ${col} = ${col}`;
    else sql = `EXPLAIN DELETE FROM ${qt}`;
    const rows = q(sql);
    let cur = null;
    for (const r of rows) {
      const [addr, op, p1, p2, p3, p4] = r;
      if (op === 'Init' && typeof p4 === 'string' && p4.startsWith('-- TRIGGER ')) { cur = { name: p4.slice(11).trim(), ops: [] }; (progs[cur.name] = progs[cur.name] || []).push(cur.ops); continue; }
      if (cur && op === 'Trace' && typeof p4 === 'string') { cur.stmt = p4.replace(/^-- /, ''); continue; }
      if (cur) cur.ops.push([op, op === 'Function' || op === 'PureFunc' ? String(p4) : null, /^(INSERT INTO event|UPDATE event)\b/.test(cur.stmt || '') ? 1 : 0]);
    }
  }
  const out = { sqlite: q('SELECT sqlite_version()')[0][0], triggers: {} };
  for (const t of trigs) {
    const list = progs[t.name] || [];
    const sig = list.map(o => JSON.stringify(o));
    const counts = {};
    const log = {};
    for (const [op, fn, ev] of (list[0] || [])) { const k = op === 'Function' || op === 'PureFunc' ? 'Function:' + fn.replace(/\(.*$/, '') : op; const c = ev ? log : counts; c[k] = (c[k] || 0) + 1; }
    out.triggers[t.schema + '.' + t.name] = { table: t.tbl, event: t.ev, compiles: list.length, same_every_compile: new Set(sig).size <= 1, ops: list[0] ? list[0].length : 0, counts, log };
  }
  fs.writeFileSync(process.argv[4], JSON.stringify(out, null, 1));
  const missing = trigs.filter(t => !progs[t.name]).map(t => t.name);
  console.log('sql.js', out.sqlite, trigs.length, 'triggers;', missing.length, 'never listed', missing.slice(0, 5),
              '; differing between compiles:', Object.entries(out.triggers).filter(([k, v]) => !v.same_every_compile).map(([k]) => k));
});
