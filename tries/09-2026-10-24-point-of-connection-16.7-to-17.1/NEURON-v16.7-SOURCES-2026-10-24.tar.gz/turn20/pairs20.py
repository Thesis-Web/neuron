# turn 20: the owner's opposite pairs on opposite lines.
#  1. pool20 = pool19 + closeness pulls for the new action words and the partners the map names (same floor as pool19)
#  2. the 13 pairs go on the 13 line pairs (a line and its opposite); quads stay empty
#  3. which line pair and which end: greedy + swaps on the CHOOSE split (sampled scorer, build pulls)
# usage: python3 -I pairs20.py <turn18 out> <turn19 out> <turn20 out>   (env PROCS, default 4)
import sys, os, json, time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'turn18'))
from lib18 import *
import multiprocessing as mp

src, o19, out = sys.argv[1:4]
PROCS = int(os.environ.get('PROCS', '4'))
os.makedirs(out, exist_ok=True)
j, z, L, WN = load(src)
words = j['words']; n = len(words); w2i = {w: i for i, w in enumerate(words)}
PZ = np.load(os.path.join(o19, 'pool19.npz')); m19 = json.load(open(os.path.join(o19, 'pool19.json')))
names, groups, hows = list(m19['name']), list(m19['group']), list(m19['how'])

# ---- closeness ("reach") with exactly the floor pool19 used: 1st percentile of all non-zero reach of its 32 words
OWNERW = 'action situation context perspective mood class tense plural singular modifier memory time state before after topic source correct incorrect'.split()
ACTS = 'read write compare add subtract move find split join clock hear say call spawn'.split()
NEWACT = 'delete erase update divide multiply equal inequality copy cut send'.split()
PARTNER = 'differ difference lose stay receive original different equality agree absent present future past now then why'.split()
Lb = {kn: L[(kn, 'train')] for kn in KINDS}
La = {kn: np.vstack([L[(kn, s)] for s in ('train', 'val', 'test') if (kn, s) in L]) for kn in KINDS}
def closeness(Lx, newwords):
    A = build_graph(n, {(k, 'b'): v for k, v in Lx.items()}, split='b')
    old = {w: ppr(A, [w2i[w]]) for w in OWNERW + ACTS if w in w2i}
    floor = np.percentile(np.concatenate([v[v > 0] for v in old.values()]), 1)
    out_ = {}
    for w in newwords:
        v = ppr(A, [w2i[w]]); s = np.where(v > 0, np.log10(np.maximum(v, floor) / floor), 0); out_[w] = s / s.max()
    return out_, floor
NEW = [w for w in NEWACT + PARTNER if w in w2i]
cb, fb = closeness(Lb, NEW); ca, fa = closeness(La, NEW)
print('floors', fb, fa)
Sb, Sa = list(PZ['build']), list(PZ['shown'])
# clearer names (owner: "I don't understand near:")
for k, nm in enumerate(names):
    if nm.startswith('near: '):
        w = nm[6:]; names[k] = "close to '%s'" % w
        hows[k] = 'how close the word sits to "%s" through your map\'s lines' % w
    if groups[k] == 'action':
        hows[k] = 'how close the word sits to "%s" through your map\'s lines' % nm.lower()
    if nm == 'tense: base verb':
        names[k] = 'tense: present (base form)'; hows[k] = 'the word is the base end of a "past" line (the present-tense form)'
    if nm in ("near: state", "near: time", "near: memory", "near: before", "near: after"):
        groups[k] = 'state, time, memory'
    if nm in ('near: perspective',):
        groups[k] = 'perspectives'
for w in NEW:
    if w in NEWACT:
        names.append(w.upper()); groups.append('action')
    else:
        names.append("close to '%s'" % w)
        groups.append('perspectives' if w == 'why' else ('state, time, memory' if w in ('now', 'then') else 'opposite partners from your map'))
    hows.append('how close the word sits to "%s" through your map\'s lines' % w)
    Sb.append(cb[w]); Sa.append(ca[w])
Sb, Sa = np.array(Sb), np.array(Sa)
NI = {nm: k for k, nm in enumerate(names)}
MISSING = {w: 'in your map as a word with no lines, so it cannot pull' for w in ('who', 'what', 'when', 'where', 'how')}
MISSING['diff'] = 'not in your map; "differ" and "difference" are'
MISSING['future (tense)'] = 'no future word forms in your map or WordNet'
np.savez_compressed(os.path.join(out, 'pool20.npz'), build=Sb, shown=Sa)
json.dump({'name': names, 'group': groups, 'how': hows, 'missing': MISSING}, open(os.path.join(out, 'pool20.json'), 'w'))
print('pool', len(names))

# ---- pairs: (pull A, pull B or None, who said it)
PAIRS = [('HEAR', 'SAY', 'you'), ('SPLIT', 'JOIN', 'you'), ('SUBTRACT', 'ADD', 'you'), ('READ', 'WRITE', 'you'), ('CALL', 'SEND', 'you'),
         ('FIND', 'MOVE', 'you (?)'), ('COMPARE', None, 'you: compare / diff (?); diff has no lines'), ('DELETE', 'SPAWN', 'you (?)'), ('CLOCK', None, 'you: clock / ???'),
         ('DIVIDE', 'MULTIPLY', 'your list, read as a pair'), ('EQUAL', 'INEQUALITY', 'your list, read as a pair'), ('COPY', 'CUT', 'your list, read as a pair'),
         ('tense: past form', 'tense: present (base form)', 'you: past / present (future has no data)')]
PI = [(NI[a], NI[b] if b else -1, who) for a, b, who in PAIRS]
SL = json.load(open(os.path.join(o19, 'search19_A.json')))['slots']
U = np.array([np.array(v, float) / np.linalg.norm(v) for _, _, v in SL])
LINEP = []
for s in range(30):
    if SL[s][0] == 'quad': continue
    t = [t for t in range(30) if SL[t][0] != 'quad' and np.allclose(U[t], -U[s])][0]
    if s < t: LINEP.append((s, t))
assert len(LINEP) == 13
PR = Proxy(L, n)

def assign_of(lay):
    """lay: list of (pair index, line pair index, flip)"""
    a = [-1] * 30
    for p, lp, fl in lay:
        s, t = LINEP[lp]
        if fl: s, t = t, s
        a[s] = PI[p][0]; a[t] = PI[p][1]
    return a
def place(a, pool):
    P = np.zeros((n, 3))
    for s, k in enumerate(a):
        if k >= 0: P += np.outer(pool[k], U[s])
    return P
def ev(lay): return PR(place(assign_of(lay), Sb)), lay

if __name__ == '__main__':
    t0 = time.time(); lay = []; curve = []
    for step in range(len(PI)):
        usedp = {x[0] for x in lay}; usedl = {x[1] for x in lay}
        jobs = [lay + [(p, lp, fl)] for p in range(len(PI)) if p not in usedp for lp in range(13) if lp not in usedl for fl in (0, 1)]
        with mp.Pool(PROCS) as pp: r = pp.map(ev, jobs, chunksize=8)
        r.sort(key=lambda x: x[0]); lay = r[0][1]; curve.append((r[0][0], PAIRS[lay[-1][0]][0], PAIRS[lay[-1][0]][1]))
        print('step', step + 1, round(r[0][0], 4), PAIRS[lay[-1][0]][:2], round(time.time() - t0), 's', flush=True)
    cur = r[0][0]
    for ps in range(10):
        cands = []
        for i in range(len(lay)):
            a = [list(x) for x in lay]; a[i][2] = 1 - a[i][2]; cands.append([tuple(x) for x in a])
            for k in range(i + 1, len(lay)):
                a = [list(x) for x in lay]; a[i][1], a[k][1] = a[k][1], a[i][1]; cands.append([tuple(x) for x in a])
        with mp.Pool(PROCS) as pp: r = pp.map(ev, cands, chunksize=8)
        r.sort(key=lambda x: x[0])
        print('pass', ps + 1, round(r[0][0], 4), 'was', round(cur, 4), flush=True)
        if r[0][0] > cur - 0.0005: break
        lay, cur = r[0][1], r[0][0]
    a = assign_of(lay)
    print('P done', round(cur, 4), [(SL[s][1], names[k]) for s, k in enumerate(a) if k >= 0], flush=True)
    json.dump({'assign': a, 'score': cur, 'curve': curve, 'slots': SL, 'pairs': [[names[x[0]], names[x[1]] if x[1] >= 0 else None, x[2]] for x in PI],
               'linepairs': LINEP}, open(os.path.join(out, 'search20_P.json'), 'w'))
