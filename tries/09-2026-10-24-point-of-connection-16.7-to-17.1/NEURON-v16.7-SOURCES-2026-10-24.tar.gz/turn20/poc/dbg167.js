const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const page = await browser.newPage({ viewport: { width: 400, height: 860 } });
  await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.startsWith('data:') || u.includes('cdnjs.cloudflare.com') || u.includes('fonts.g') ? r.continue() : r.abort(); });
  await page.goto('file://' + process.argv[2]); await page.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 180000 }); await page.waitForTimeout(2000);
  const wide = await page.evaluate(() => { const W = document.documentElement.clientWidth, out = []; document.querySelectorAll('body *').forEach(el => { const r = el.getBoundingClientRect(); if (r.right > W + 1 && r.width > 0) out.push([el.tagName, el.id, el.className, Math.round(r.right), Math.round(r.width)]); }); return out.slice(0, 15); });
  console.log(JSON.stringify(wide));
  const alone = await page.evaluate(() => { const o = []; const ps = window.__poc.positions(); Object.keys(ps).forEach(w => { const p = ps[w]; if (!p[0] && !p[1] && !p[2] && w !== 'origin') o.push(w); }); return o; });
  console.log('at 0,0,0:', JSON.stringify(alone));
  await browser.close();
})();
