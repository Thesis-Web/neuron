# turn 20: Point Of Connection 16.7 = the 16.4 page, unchanged in every part, plus the pull layout (default) and its side bar.
# Writes v167/ (a copy of v16/ with main/body/prose/build patched). Every patch anchor must occur exactly once.
# usage: python3 -I make167.py <poc dir>
import sys, os, shutil
P = sys.argv[1]
src, dst = os.path.join(P, 'v16'), os.path.join(P, 'v167')
if os.path.exists(dst): shutil.rmtree(dst)
shutil.copytree(src, dst)
rd = lambda f: open(os.path.join(dst, f), encoding='utf-8').read()
def patch(text, pairs, name):
    for a, b in pairs:
        assert text.count(a) == 1, (name, a[:80], text.count(a))
        text = text.replace(a, b)
    return text

# ---------------- main
PULLCODE = r'''
  // ---- 16.7 (owner, 10-24): every word starts at 0,0,0 and is pulled along 30 lines from origin: the 6 axes, 12 two-axis bisects,
  // 8 three-axis bisects and 4 quads. Its place is the sum of strength x direction. The strengths were measured from your map's lines
  // and WordNet before this page was built (turn20/out/pulls167.json); this page only adds them up. 16.4's springs stay, behind a switch.
  var PL = null;
  if (typeof PULLS !== 'undefined' && PULLS) PL = (function () {
    function bytes(s) { var b = atob(s), u = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; }
    var idx = {}; PULLS.words.forEach(function (w, i) { idx[w] = i; });
    var U = PULLS.slots.map(function (s) { var v = s[2], l = Math.hypot(v[0], v[1], v[2]); return [v[0] / l, v[1] / l, v[2] / l]; });
    var anti = U.map(function (u, s) { var q = PULLS.slots[s][0] === 'quad'; for (var t = 0; t < U.length; t++) { if (t === s || (PULLS.slots[t][0] === 'quad') !== q) continue; if (Math.abs(U[t][0] + u[0]) + Math.abs(U[t][1] + u[1]) + Math.abs(U[t][2] + u[2]) < 1e-6) return t; } return -1; });
    var partner = {}; PULLS.pairs.forEach(function (p) { if (p[1]) { partner[p[0]] = p[1]; partner[p[1]] = p[0]; } });
    var NI = {}; PULLS.name.forEach(function (n, k) { NI[n] = k; });
    var col = PULLS.slots.map(function (s, k) { var u = U[k], h = (Math.atan2(u[1], u[0]) * 180 / Math.PI + 360) % 360, l = u[2] > 0.3 ? 72 : u[2] < -0.3 ? 46 : 60;
      if (Math.abs(u[0]) < 1e-6 && Math.abs(u[1]) < 1e-6) return u[2] > 0 ? 'hsl(0,0%,92%)' : 'hsl(0,0%,62%)';
      return s[0] === 'quad' ? 'hsl(' + h.toFixed(0) + ',45%,' + (l + 12) + '%)' : 'hsl(' + h.toFixed(0) + ',78%,' + l + '%)'; });
    return { W: PULLS.words, N: PULLS.words.length, idx: idx, S: bytes(PULLS.shown), DEG: new Uint16Array(bytes(PULLS.deg).buffer), U: U, anti: anti, partner: partner, NI: NI, col: col, cur: 0, assign: PULLS.presets[0].assign.slice() };
  })();
  var LAYOUT = PL ? 'pulls' : 'springs', PMODE = 'sum', PUNIT = 10;   // 10 brain units = one full pull, so the axes' ticks every 10 read in whole pulls
  // sum: place = sum of strength x direction. marks (owner, 10-24): each line pulls the word toward the mark at its share on that line, weighted by the
  // pull's strength; where those pulls balance is sum(strength x share x direction) / sum(strength) = sum(share^2 x direction).
  function pullVec(i) { var x = 0, y = 0, z = 0, any = false, tot = 0;
    if (PMODE === 'marks') { for (var s0 = 0; s0 < PL.U.length; s0++) { var k0 = PL.assign[s0]; if (k0 >= 0) tot += PL.S[k0 * PL.N + i]; } if (!tot) return null; }
    for (var s = 0; s < PL.U.length; s++) { var k = PL.assign[s]; if (k < 0) continue; var v = PL.S[k * PL.N + i]; if (!v) continue; any = true; v = PMODE === 'marks' ? (v / tot) * (v / tot) * PUNIT : v / 255 * PUNIT; x += v * PL.U[s][0]; y += v * PL.U[s][1]; z += v * PL.U[s][2]; } return any ? new THREE.Vector3(x, y, z) : null; }
  function pullIndex(w) { if (!PL || w === undefined || w === null) return -1; w = String(w); if (w.indexOf('mem:') === 0) return -1; var i = PL.idx[w.toLowerCase()]; return i === undefined ? -1 : i; }
  function pullsOf(i) { var o = []; for (var s = 0; s < PL.U.length; s++) { var k = PL.assign[s]; if (k < 0) continue; var v = PL.S[k * PL.N + i] / 255; if (v > 0) o.push({ s: s, k: k, v: v }); } return o; }
  // a point with no pull data from your map (a brain-only word, a memory row) sits where its brain lines balance: the average place of the points it is tied to
  var PULLSTAT = { pulled: 0, balanced: 0, alone: 0 };
  function placeByPulls() {
    PULLSTAT = { pulled: 0, balanced: 0, alone: 0 };
    var free = [], nb = {};
    SPRINGS.forEach(function (sp) { (nb[sp.names[0]] = nb[sp.names[0]] || []).push(sp.b); (nb[sp.names[1]] = nb[sp.names[1]] || []).push(sp.a); });
    Object.keys(NODE).forEach(function (w) { var n = NODE[w]; n.unplaced = false;
      if (n.fixed) { n.pos.set(0, 0, 0); return; }
      var i = pullIndex(w), v = i >= 0 ? pullVec(i) : null;
      if (v) { n.pos.copy(v); PULLSTAT.pulled++; } else { n.pos.set(0, 0, 0); free.push(w); } });
    for (var it = 0; it < 400; it++) { var mv = 0;
      free.forEach(function (w) { var ps = nb[w]; if (!ps || !ps.length) return; var c = new THREE.Vector3(); ps.forEach(function (m) { c.add(m.pos); }); c.multiplyScalar(1 / ps.length); mv = Math.max(mv, c.distanceTo(NODE[w].pos)); NODE[w].pos.copy(c); });
      if (mv < 1e-5) break; }
    free.forEach(function (w) { if (NODE[w].pos.lengthSq() > 0) PULLSTAT.balanced++; else PULLSTAT.alone++; });
    pullStatus();
  }
  function pullCard(i, w) {
    if (i < 0) return '<span class="m">No pull data from your map for this point: it sits where its brain lines balance, the average place of the points it is tied to.</span>';
    var pl = pullsOf(i), tot = pl.reduce(function (a, b) { return a + b.v; }, 0) || 1; pl.sort(function (a, b) { return b.v - a.v; });
    var h = '<span class="mono">' + esc(w) + ' = ' + (pl.length ? pl.slice(0, 8).map(function (x) { return (x.v / tot * 100).toFixed(0) + '% ' + esc(PULLS.name[x.k]); }).join(' + ') + (pl.length > 8 ? ' + ' + (pl.length - 8) + ' more' : '') : 'no pull from the 30 lines in use') + '</span>';
    h += '<span class="m">' + PL.DEG[i] + ' line' + (PL.DEG[i] === 1 ? '' : 's') + ' in your map. Share = this pull\'s strength / the sum of its strengths over the pulls in use.</span>';
    if (pl.length) h += '<div class="tw"><table class="cells"><tr><th>pull</th><th>line</th><th>strength</th><th>share</th></tr>' + pl.map(function (x) { return '<tr><td>' + esc(PULLS.name[x.k]) + '</td><td><span class="pdir" style="--c:' + PL.col[x.s] + '">' + esc(PULLS.slots[x.s][1].replace(/-/g, '−')) + '</span></td><td>' + x.v.toFixed(2) + '</td><td>' + (x.v / tot * 100).toFixed(1) + '%</td></tr>'; }).join('') + '</table></div>';
    return h;
  }
'''
main = rd('main16.js')
main = patch(main, [
 ("  var SALT = window.__pocSalt || '', FROZEN = !!window.__pocFreeze, STEPPING = false, REST_ALL = 0, NOLIMIT = false;\n",
  "  var SALT = window.__pocSalt || '', FROZEN = !!window.__pocFreeze, STEPPING = false, REST_ALL = 0, NOLIMIT = false;\n" + PULLCODE),
 ("    placeNew();\n    ALLLINES = lines;", "    if (LAYOUT === 'pulls') placeByPulls(); else placeNew();\n    ALLLINES = lines;"),
 ("    if (FROZEN && !STEPPING) return;\n", "    if (FROZEN && !STEPPING) return;\n    if (LAYOUT === 'pulls') return;   // 16.7: in the pull layout nothing steps; every place is the formula\n"),
 ("  var reshapeLeft = 0; function reshape() { if (!hasGL) return; settle(40); reshapeLeft = 90; }",
  "  var reshapeLeft = 0; function reshape() { if (!hasGL || LAYOUT === 'pulls') return; settle(40); reshapeLeft = 90; }"),
 ("    $('spacing').addEventListener('input', function () { SP = parseFloat($('spacing').value); $('spv').textContent = '\\u00d7' + SP; drawAxes(true); });",
  "    $('spacing').addEventListener('input', function () { SP = parseFloat($('spacing').value); $('spv').textContent = '\\u00d7' + SP; drawAxes(true); if (PL) { drawPullMap(); drawPullGuides(); } });"),
 ("if (hit.length) { showNode(hit[0].object.userData.gate); return; } clearSel(); }",
  "if (hit.length) { showNode(hit[0].object.userData.gate); return; } if (!pickMap(e)) clearSel(); }"),
 ("axesGroup.children.forEach(function (c) { if (c.userData.px) sizeLabel(c); }); }",
  "axesGroup.children.forEach(function (c) { if (c.userData.px) sizeLabel(c); }); if (pullGroup) pullGroup.children.forEach(function (c) { if (c.userData.px) sizeLabel(c); }); }"),
 ("    if (n.ghost) { selEl.innerHTML = '<b>' + esc(w) + '</b><span class=\"m\">a word of your relation map, not yet born in this brain. Its place comes from your map\\'s lines alone. It has no meaning here yet.</span>'; return; }",
  "    if (n.ghost) { selEl.innerHTML = '<b>' + esc(w) + '</b><span class=\"m\">a word of your relation map, not yet born in this brain. ' + (LAYOUT === 'pulls' ? 'Its place is its pulls.' : 'Its place comes from your map\\'s lines alone.') + ' It has no meaning here yet.</span>' + (PL ? pullCard(pullIndex(w), w) : ''); return; }"),
 ("    selEl.innerHTML = h + '<span class=\"m\" id=\"rowsfor\">reading its DNA rows from SQLite…</span>';",
  "    if (PL) h += pullCard(pullIndex(w), LABEL[w] || w);\n    selEl.innerHTML = h + '<span class=\"m\" id=\"rowsfor\">reading its DNA rows from SQLite…</span>';"),
], 'main')

# the pull side bar, the map's words as faint points, the 30 lines; appended just before the camera code
SIDECODE = r'''
  // ---- 16.7: the pull side bar, your map's words as faint points, and the 30 pull lines (faint, as asked)
  var pullGroup = null, pullMapPts = null, pullMapPos = null;
  function slotName(s) { return PULLS.slots[s][1].replace(/-/g, '−'); }
  function drawPullMap() {
    if (!hasGL || !PL) return;
    if (!pullMapPts) {
      var g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(new Float32Array(PL.N * 3), 3)); g.setAttribute('color', new THREE.Float32BufferAttribute(new Float32Array(PL.N * 3), 3));
      pullMapPts = new THREE.Points(g, new THREE.PointsMaterial({ size: 2.2, sizeAttenuation: false, vertexColors: true, transparent: true, opacity: .45, depthWrite: false })); scene.add(pullMapPts);
    }
    var pa = pullMapPts.geometry.attributes.position, ca = pullMapPts.geometry.attributes.color, c = new THREE.Color(); pullMapPos = pa.array;
    for (var i = 0; i < PL.N; i++) { var v = pullVec(i), bs = -1, bv = 0; for (var s = 0; s < PL.U.length; s++) { var k = PL.assign[s]; if (k < 0) continue; var x = PL.S[k * PL.N + i]; if (x > bv) { bv = x; bs = s; } }
      if (v) pa.setXYZ(i, v.x * SP, v.y * SP, v.z * SP); else pa.setXYZ(i, 0, 0, 0); c.set(bs >= 0 ? PL.col[bs] : '#59606b'); ca.setXYZ(i, c.r, c.g, c.b); }
    pa.needsUpdate = true; ca.needsUpdate = true; pullMapPts.geometry.computeBoundingSphere();
    pullMapPts.visible = LAYOUT === 'pulls' && $('pmap').checked;
  }
  function drawPullGuides() {
    if (!hasGL || !PL) return;
    if (!pullGroup) { pullGroup = new THREE.Group(); scene.add(pullGroup); }
    while (pullGroup.children.length) { var c = pullGroup.children.pop(); if (c.geometry) c.geometry.dispose(); if (c.material) { if (c.material.map) c.material.map.dispose(); c.material.dispose(); } }
    pullGroup.visible = LAYOUT === 'pulls'; if (LAYOUT !== 'pulls') return;
    var rs = []; for (var i = 0; i < PL.N; i += 9) { var v = pullVec(i); if (v) rs.push(v.length()); } rs.sort(function (a, b) { return a - b; });
    var R = (rs[Math.floor(rs.length * .95)] || 10) * 1.3 * SP, op = +$('pop').value / 100, lab = $('plab').checked;
    PULLS.slots.forEach(function (s, k) {
      var u = PL.U[k], has = PL.assign[k] >= 0;
      var line = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, 0), new THREE.Vector3(u[0] * R, u[1] * R, u[2] * R)]), new THREE.LineBasicMaterial({ color: new THREE.Color(PL.col[k]), transparent: true, opacity: has ? op : op * .4, depthWrite: false }));
      pullGroup.add(line);
      if (lab && has) { var rr = R * (s[0] === 'quad' ? 1.1 : 1.03), sp = makeLabel(slotName(k) + ' ' + PULLS.name[PL.assign[k]], PL.col[k], 10, true); sp.material.opacity = .6; sp.position.set(u[0] * rr, u[1] * rr, u[2] * rr); pullGroup.add(sp); }
    });
  }
  function pickMap(e) {
    if (!PL || !pullMapPts || !pullMapPts.visible || !pullMapPos) return false;
    var rect = renderer.domElement.getBoundingClientRect(), mx = e.clientX - rect.left, my = e.clientY - rect.top, best = -1, bd = 10 * 10, v = new THREE.Vector3();
    for (var i = 0; i < PL.N; i++) { v.set(pullMapPos[3 * i], pullMapPos[3 * i + 1], pullMapPos[3 * i + 2]).project(camera); if (v.z > 1) continue; var sx = (v.x + 1) / 2 * rect.width, sy = (1 - v.y) / 2 * rect.height, d = (sx - mx) * (sx - mx) + (sy - my) * (sy - my); if (d < bd) { bd = d; best = i; } }
    if (best < 0) return false;
    var w = PL.W[best], k = key(w);
    if (k && NODE[k] && !NODE[k].ghost) { showNode(k); return true; }
    selEl.innerHTML = '<b>' + esc(w) + '</b><span class="m">a word of your relation map, drawn as a faint point; not in this brain yet.</span>' + pullCard(best, w);
    return true;
  }
  function pullStatus() {
    if (!PL) return;
    var p = PULLS.presets[PL.cur], same = PL.assign.every(function (k, s) { return k === p.assign[s]; }), o = pullIndex('origin'), ov = o >= 0 ? pullVec(o) : null;
    $('pstatus').innerHTML = '<div class="kv"><span>held-out test of this start</span><b>' + (same ? p.mean.toFixed(3) + ' (0 best, 0.5 chance)' : 'changed: not tested') + '</b></div>' +
      '<div class="kv"><span>brain points placed by pulls</span><b>' + PULLSTAT.pulled + '</b></div><div class="kv"><span>placed where their brain lines balance</span><b>' + PULLSTAT.balanced + '</b></div><div class="kv"><span>with nothing to pull them (at 0,0,0)</span><b>' + PULLSTAT.alone + '</b></div>' +
      '<div class="kv"><span>origin\'s own pulls would put it at</span><b>' + (ov ? [ov.x, ov.y, ov.z].map(function (x) { return x.toFixed(1); }).join(', ') : '0,0,0') + '</b></div>';
  }
  function pullRelayout() { if (ready) render(T, true); drawPullMap(); drawPullGuides(); pullStatus(); }
  function pullSyncSlots() { PULLS.slots.forEach(function (s, k) { var el = $('pslot' + k); if (el) el.value = String(PL.assign[k]); }); }
  if (PL) (function () {
    var ORDER = ['action', 'opposite partners from your map', 'tense', 'state, time, memory', 'perspectives', 'relationship', 'number', 'modifier', 'definition', 'class', 'source', 'depth', 'your word', 'topic'];
    var GN = { action: 'actions (closeness to the action word)', relationship: 'relationships (your map\'s lines)', 'your word': 'closeness to other words you named', topic: 'topic (WordNet files)', depth: 'depth (general / specific)', definition: 'definitions' };
    var opts = '<option value="-1">empty</option>';
    ORDER.forEach(function (g) { var ks = []; PULLS.name.forEach(function (nm, k) { if (PULLS.group[k] === g) ks.push(k); }); if (ks.length) opts += '<optgroup label="' + esc(GN[g] || g) + '">' + ks.map(function (k) { return '<option value="' + k + '">' + esc(PULLS.name[k]) + '</option>'; }).join('') + '</optgroup>'; });
    $('pstart').innerHTML = PULLS.presets.map(function (p, k) { return '<option value="' + k + '">' + esc(p.title) + ' (held-out ' + p.mean.toFixed(3) + ')</option>'; }).join('');
    var done = {}, h = '';
    [['axis', 'the 3 axes'], ['top', 'two-axis bisects with z'], ['bottom', ''], ['flat', 'flat two-axis bisects'], ['three-axis', 'three-axis bisects'], ['quad', 'quads (each lies on a flat line: +z and −z cancel)']].forEach(function (grp) {
      if (grp[1]) h += '<div class="psg">' + esc(grp[1]) + '</div>';
      PULLS.slots.forEach(function (s, k) { if (s[0] !== grp[0] || done[k]) return; var t = PL.anti[k]; done[k] = 1; if (t >= 0) done[t] = 1;
        h += '<div class="prow"><span class="pdir" style="--c:' + PL.col[k] + '">' + esc(slotName(k)) + '</span><select id="pslot' + k + '" data-s="' + k + '">' + opts + '</select>' +
          (t >= 0 ? '<span class="pdir" style="--c:' + PL.col[t] + '">' + esc(slotName(t)) + '</span><select id="pslot' + t + '" data-s="' + t + '">' + opts + '</select>' : '') + '</div>'; });
    });
    $('pslots').innerHTML = h; pullSyncSlots();
    $('pslots').addEventListener('change', function (e) { var s = e.target.getAttribute('data-s'); if (s === null) return; s = +s; var k = +e.target.value; PL.assign[s] = k;
      if ($('pkeep').checked && k >= 0 && PL.anti[s] >= 0) { var mate = PL.partner[PULLS.name[k]]; if (mate && PL.NI[mate] !== undefined) PL.assign[PL.anti[s]] = PL.NI[mate]; }
      pullSyncSlots(); pullRelayout(); });
    $('pstart').addEventListener('change', function () { PL.cur = +$('pstart').value; PL.assign = PULLS.presets[PL.cur].assign.slice(); pullSyncSlots(); pullRelayout(); userZoomed = false; fitLeft = 120; });
    $('preset0').addEventListener('click', function () { PL.assign = PULLS.presets[PL.cur].assign.slice(); pullSyncSlots(); pullRelayout(); });
    $('layout').addEventListener('change', function () { var lv = $('layout').value; LAYOUT = lv === 'springs' ? 'springs' : 'pulls'; PMODE = lv === 'marks' ? 'marks' : 'sum'; Object.keys(NODE).forEach(function (w) { NODE[w].unplaced = false; }); pullRelayout(); if (LAYOUT === 'springs') { settle(40); reshapeLeft = 90; } userZoomed = false; fitLeft = 120; });
    ['pop', 'plab'].forEach(function (id) { $(id).addEventListener('input', drawPullGuides); $(id).addEventListener('change', drawPullGuides); });
    $('pmap').addEventListener('change', function () { if (pullMapPts) pullMapPts.visible = LAYOUT === 'pulls' && $('pmap').checked; });
    var miss = PULLS.missing; $('pmissing').innerHTML = '<b>Not in the menus yet, because nothing can measure them:</b> ' + Object.keys(miss).map(function (w) { return esc(w) + ' (' + esc(miss[w]) + ')'; }).join('; ') + '.';
    var pairs = PULLS.pairs.map(function (p) { return esc(p[0]) + (p[1] ? ' ↔ ' + esc(p[1]) : ' ↔ (empty)') + ' <span class="m">' + esc(p[2]) + '</span>'; });
    $('ppairs').innerHTML = pairs.join('<br>');
    setTimeout(function () { drawPullMap(); drawPullGuides(); pullStatus(); }, 0);
  })();
'''
main = patch(main, [("  // ---- camera, pointer, frame\n", SIDECODE + "  // ---- camera, pointer, frame\n")], 'main2')
# test hooks: keep __poc, add pull hooks
main = patch(main, [("    screenOf: function (w) {", "    pulls: function () { return { layout: LAYOUT, assign: PL ? PL.assign.slice() : null, stat: PULLSTAT, status: $('pstatus').innerText, preset: PL ? PL.cur : null }; },\n    setSlot: function (s, k) { var el = $('pslot' + s); el.value = String(k); el.dispatchEvent(new Event('change', { bubbles: true })); return PL.assign.slice(); },\n    setLayout: function (v) { $('layout').value = v; $('layout').dispatchEvent(new Event('change')); return LAYOUT; },\n    pullPos: function (w) { var i = pullIndex(w), v = i >= 0 ? pullVec(i) : null; return v ? [v.x, v.y, v.z] : null; },\n    screenOf: function (w) {")], 'main3')
open(os.path.join(dst, 'main16.js'), 'w', encoding='utf-8').write(main)

# ---------------- body
body = rd('body16.html')
SIDE = '''    <section>
      <h2>Pulls: where every point sits (new in 16.7)</h2>
      <div class="row"><label for="layout" class="note">place points by</label><select id="layout"><option value="pulls" selected>pulls: sum of strength &times; direction</option><option value="marks">pulls: toward the share mark on each line (your way)</option><option value="springs">springs (16.4's way, kept to compare)</option></select></div>
      <div class="row"><label for="pstart" class="note">start from</label><select id="pstart"></select><button id="preset0" type="button">reset</button></div>
      <p class="pform">sum: place = &Sigma; strength &times; direction over the lines in use (10 on the axes = one full pull).<br>your way: each line pulls the word toward the mark at its share (60% verb &rarr; the 60 mark), weighted by strength; the balance is &Sigma; share&sup2; &times; direction. Nothing steps, nothing is capped, nothing is spaced.</p>
      <div id="pstatus"></div>
      <label class="chk"><input type="checkbox" id="pkeep" checked> keep pairs on opposite lines: choosing one end puts its partner on the opposite line</label>
      <div id="pslots"></div>
      <div class="row"><label for="pop" class="note">pull lines</label><input type="range" id="pop" min="2" max="60" value="14" aria-label="pull line strength"><label class="chk"><input type="checkbox" id="plab" checked> names</label></div>
      <label class="chk"><input type="checkbox" id="pmap" checked> every word of your map (27,606), placed by the same pulls, faint; click one to see its pulls</label>
      <details><summary>Your pairs, as placed</summary><p class="note" id="ppairs"></p></details>
      <p class="note" id="pmissing"></p>
      <details><summary>What the relationship pulls mean</summary>
        <p class="note">They come from your map's nine kinds of line. <b>alike</b>: same meaning (fast, quick). <b>opposite</b>: hot, cold. <b>is a kind of</b>: "hostel is a building", hostel belongs to the kind building; <b>kinds below it</b> counts the words that name this word as their kind (building has hostel, house, ...). <b>has parts</b>: "wheel has hub"; <b>is a part of</b> counts the wholes it is part of. <b>built on a stem</b>: cameras is built on camera, snatched on snatch; <b>is a stem</b>: other words are built on it. <b>prefix, suffix</b>: unlock has un, jewels has s. <b>past form</b>: navigate &rarr; navigated. <b>plural, singular</b>: children &rarr; child. These say how words are built and grouped, not what they do.</p>
      </details>
      <details><summary>How a strength and a share are made</summary>
        <p class="note">Each pull is measured for each word before the page is built, then divided by its largest value so the strongest word has 1. Closeness to a word (all the actions, and every "close to") starts at that word in your map and spreads along its lines: at every line a word passes on most of what it received, split over its lines, and keeps some back; a word's closeness is how much reaches it, on a log scale. One line away gets the most; many short routes get more than one long route. Class is the share of the word's nodes in your map with that class. A relationship count (alike lines, has a suffix, ...) is the log of how many such lines the word has. Tense: the word is the past end, or the present (base) end, of a "past" line. Topic is the share of the word's WordNet senses filed under that topic.</p>
        <p class="note">A word's share of a pull is that pull's strength divided by the sum of its strengths over the pulls in use. Nothing is typed in by hand. The choices that are mine: each pull scaled to 0 to 1, counts on a log scale, and how fast closeness fades (15% kept back per line).</p>
      </details>
    </section>
    <section>
      <h2>The graph's lines</h2>'''
body = patch(body, [
  ('    <section>\n      <h2>The graph\'s lines</h2>', SIDE),
  ('<label class="chk"><input type="checkbox" id="axes" checked> x, y and z axes over the graph, the scale in the brain\'s units, a tick every 10</label>',
   '<label class="chk"><input type="checkbox" id="axes" checked> x, y and z axes over the graph, a tick every 10 (in the pull layout, one full pull)</label>'),
  ('      <h2>Relationship kinds: on, off, pull, direction</h2>',
   '      <h2>Relationship kinds: on, off, pull, direction</h2>\n      <p class="note">In the pull layout these switch lines on and off, and decide which brain lines place the points that have no pull data. Pull and direction act only in the springs layout.</p>'),
  ('var TOLD = /*TOLD*/null, SAT = /*SAT*/null, SLICE = /*SLICE*/null, READINGS = /*READINGS*/null, MAP = /*MAPFULL*/null;',
   'var TOLD = /*TOLD*/null, SAT = /*SAT*/null, SLICE = /*SLICE*/null, READINGS = /*READINGS*/null, MAP = /*MAPFULL*/null, PULLS = /*PULLS*/null;'),
], 'body')
open(os.path.join(dst, 'body16.html'), 'w', encoding='utf-8').write(body)

# ---------------- prose: a 16.7 section first, then 16.4's prose unchanged
prose = rd('prose16.html')
P167 = open(os.path.join(P, 'prose167.html'), encoding='utf-8').read()
open(os.path.join(dst, 'prose16.html'), 'w', encoding='utf-8').write(P167 + prose)

# ---------------- build: 16.4's build plus the PULLS data, links and a little CSS
b = rd('build16.py')
b = patch(b, [
  ("LINKS = {'16.4': [", "LINKS = {'16.7': [('16.6 Thirty Pulls', '4Lfoq3EkHJ4wCRW4dr4uuk'), ('16.5 Six Pulls', 'Ab1Xhb1VsJ3tXRVA4VKDHi'), ('16.4', 'Sq4JLW46oPHRfVtH52qJn6'), ('16.3', 'Aw7meuyz9v9bRVpzm9s61p')], '16.4': ["),
  ("('/*MAPFULL*/null', rd(R + '/v16map/map-full.json')), ('/*MAIN*/', main)]",
   "('/*MAPFULL*/null', rd(R + '/v16map/map-full.json')), ('/*PULLS*/null', rd(R + '/pulls167.json')), ('/*MAIN*/', main)]"),
  ("  .atlas tr.det td { background: var(--panel); white-space: pre-wrap; max-width: none; }\\n</style>'",
   "  .atlas tr.det td { background: var(--panel); white-space: pre-wrap; max-width: none; }\\n  .pform { font-family: var(--mono); font-size: .78rem; background: var(--bg); border: 1px solid var(--line); border-radius: 4px; padding: 6px 8px; margin: 0; }\\n  .kv { display: flex; justify-content: space-between; gap: 8px; font-size: .8rem; border-bottom: 1px dotted var(--line); padding-block: 2px; } .kv span { color: var(--muted); } .kv b { font-weight: 500; font-family: var(--mono); font-size: .76rem; text-align: right; }\\n  .psg { font-family: var(--mono); font-size: .68rem; color: var(--muted); margin-top: 6px; }\\n  .prow { display: grid; grid-template-columns: 6.6em minmax(0, 1fr); gap: 3px 6px; align-items: center; padding-block: 3px; border-bottom: 1px dotted var(--line); }\\n  .prow select { width: 100%; font-size: 11.5px; padding: 2px 3px; min-width: 0; }\\n  .pdir { display: inline-block; font-family: var(--mono); font-size: .7rem; padding: 0 4px; border-radius: 3px; border-left: 6px solid var(--c); background: var(--bg); white-space: nowrap; }\\n  details summary { cursor: pointer; font-size: .82rem; color: var(--muted); }\\n  #layout, #pstart { max-width: 100%; min-width: 0; flex: 1 1 10em; }\\n</style>'"),
  ("open(D + '/point-of-connection-' + VER + '.html', 'w', encoding='utf-8').write(out)", "open(D + '/point-of-connection-' + VER + '.html', 'w', encoding='utf-8').write(out)"),
], 'build')
open(os.path.join(dst, 'build16.py'), 'w', encoding='utf-8').write(b)
print('v167 written')
