# Turn 20: your opposite pairs on opposite lines. Expected outputs, written BEFORE scoring (2026-10-24)

Owner, verbatim (message 16): "in order for this to work I need things that go together on opposite sides of the graph, hear/say, split/join, subtract/add, read/write, find maybe move????, compare maybe diff, find/??? , delete/ ??? maybe spawn , clock/??? , tense -- paste, present, future, ... I don't understand near:???? ... core actions DIVIDE MULTIPLY EQUAL INEQUALITY COPY CUT are missing, call/ send???"; "you didn't update the html side bars?"; "radically = 20% class: adverb + ... are these just invented??? or what is the process for coming up with the percentages?"
Earlier (messages 10-15): state, time, memory, perspectives (who what when where how why), delete/erase, diff, update missing from the lists.

## The 13 pairs (26 lines = 13 lines and their opposites; the 4 quads stay empty so no line carries two pulls)
Yours, as written: hear/say, split/join, subtract/add, read/write, call/send, find/move (?), compare/diff (?), delete/spawn (?), clock/(none).
Your list "DIVIDE MULTIPLY EQUAL INEQUALITY COPY CUT" read as three pairs (my reading, said to the owner): divide/multiply, equal/inequality, copy/cut.
Tense: past / present. The data has both ends of your map's "past" lines (past form, base form). Future has no word forms in your map or WordNet, so it gets no pull.
"diff" has no lines in your map, so compare's partner line stays empty; "differ" and "difference" are in the menus.
Each pull is closeness to the word through your map's lines (same as the action pulls of 16.6). Which line pair each pair sits on, and which end goes which way, is chosen on the choose split (sampled scorer); scores reported on held-back lines.

## Predictions
- Held-out mean rank share of the pairs layout: 0.15 (better than the 14 actions unpaired, 0.196, because a pair on opposite lines cancels what both words share, mostly how central a word is; worse than the six named pulls, 0.102).
- For each pair A/B: of the words closer to A than to B (by their two pulls), the share sitting on A's side along the A-B line: above 70% for every pair.
- Words at 0,0,0 (shown pulls): about 170 (the island words the actions graph already had).
- The word "origin" does not land at 0,0,0.
- Shuffled control near 0.5.
