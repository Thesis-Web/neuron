# Point Of Connection 16.7 (turn 20, 2026-10-24): sources
Page: NEURON-POINT-OF-CONNECTION-v16.7-2026-10-24.html, https://claude.ai/artifact/14L3pxNSuJ81ZzBiLEvSgD
16.7 = the 16.4 page (from NEURON-v16.4-SOURCES-2026-10-23.tar.gz, rebuilt byte-identical first) patched by poc/make167.py:
pull layout (default), share-mark layout (owner's way), springs (16.4) behind a switch; pull side bar; pulls167.json data. Nothing of 16.4 removed.
Rebuild: extract v16.4 sources into poc/ (v16, sqljs, ownerzip, v16map); put pulls167.json in poc/; python3 -I poc/make167.py poc; python3 -I poc/v167/build16.py poc/v167 poc 16.7
Pull data: turn20/pairs20.py (pool20 + your pairs on opposite lines), turn20/final20.py (held-out test, export pulls167.json; then the plain relationship names, see the rename in this turn's notes).
Needs turn18 (v16.5 tarball) and turn19 (v16.6 tarball) outputs.
