# turn 20: held-out score of the pairs layout (P), controls, pair-side check; exports the pull data the 16.7 page carries
# usage: python3 -I final20.py <turn18 out> <turn19 out> <turn20 out>
import sys, os, json, base64, time
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'turn18'))
from lib18 import *
import multiprocessing as mp

src, o19, out = sys.argv[1:4]
j, z, L, WN = load(src)
words = j['words']; n = len(words)
PZ = np.load(os.path.join(out, 'pool20.npz')); PB, PS = PZ['build'], PZ['shown']
meta = json.load(open(os.path.join(out, 'pool20.json')))
SP = json.load(open(os.path.join(out, 'search20_P.json')))
SL = SP['slots']; U = np.array([np.array(v, float) / np.linalg.norm(v) for _, _, v in SL])
t0 = time.time()
def log(*a): print(round(time.time() - t0), 's', *a, flush=True)
def place(a, pool):
    P = np.zeros((pool.shape[1], 3))
    for s, k in enumerate(a):
        if k >= 0: P += np.outer(pool[k], U[s])
    return P
P = place(SP['assign'], PB)
def job(w):
    if w == 'map': return w, score_graph(P, L, maxlines=2000)
    if w == 'wn': return w, score_graph(P, WN, kinds=WNKINDS, train_split='fit', choose_split='fit', report_split='score', maxlines=2000)
    return w, score_graph(P[np.random.default_rng(7).permutation(n)], L, maxlines=2000)
with mp.Pool(3) as pp: R = dict(pp.map(job, ['map', 'wn', 'shuffled']))
mean = float(np.mean([v['test'][v['best']]['median'] for v in R['map'].values()]))
pts = [k for k in KINDS if R['map'][k]['test'][R['map'][k]['best']]['median'] < 0.25 and R['map'][k]['test'][R['map'][k]['best']]['hit10'] >= 0.003 and R['shuffled'][k]['test'][R['shuffled'][k]['best']]['median'] >= 0.45]
log('P held-out mean', round(mean, 4), 'points out', pts, {k: (v['best'], round(v['test'][v['best']]['median'], 3)) for k, v in R['map'].items()})
log('P shuffled', {k: round(v['test'][v['best']]['median'], 3) for k, v in R['shuffled'].items()})
log('P wordnet', {k: (v['best'], round(v['test'][v['best']]['median'], 3)) for k, v in R['wn'].items()})
# pair-side check on the shown places: words closer to A than to B, share sitting on A's side of the A-B line
Pshow = place(SP['assign'], PS); side = []
a = SP['assign']
for s in range(30):
    if a[s] < 0 or SL[s][0] == 'quad': continue
    t = [t for t in range(30) if np.allclose(U[t], -U[s])][0]
    if a[t] < 0 or s > t: continue
    dA, dB = PS[a[s]], PS[a[t]]; m = np.abs(dA - dB) > 0.02
    proj = Pshow @ U[s]
    side.append([meta['name'][a[s]], meta['name'][a[t]], int(m.sum()), float((np.sign(proj[m]) == np.sign((dA - dB)[m])).mean())])
log('pair sides', side)
rad = np.linalg.norm(Pshow, axis=1); o = words.index('origin')
chk = {'at_origin': int((rad < 1e-9).sum()), 'origin_place': (Pshow[o] * 100).round(1).tolist(), 'origin_radius_pct': float((rad < rad[o]).mean()), 'pair_sides': side}
log('checks', chk)
F19 = json.load(open(os.path.join(o19, 'final19.json')))
def tests(r, sh):
    return {kn: {'best': v['best'], 'median': v['test'][v['best']]['median'], 'hit10': v['test'][v['best']]['hit10'],
                 'shuffled': sh[kn]['test'][sh[kn]['best']]['median']} for kn, v in r.items()}
PRE = [{'key': 'P', 'title': 'Your opposite pairs', 'assign': a, 'mean': mean, 'pts': pts, 'test': tests(R['map'], R['shuffled'])}]
for k, t in [('B', 'Relationships + actions'), ('C', 'The fourteen actions'), ('D', 'Six named pulls (16.5)'), ('A', 'Best 30 found')]:
    r = F19['res'][k]; m19 = float(np.mean([v['test'][v['best']]['median'] for v in r['map'].values()]))
    p19 = [kn for kn in KINDS if r['map'][kn]['test'][r['map'][kn]['best']]['median'] < 0.25 and r['map'][kn]['test'][r['map'][kn]['best']]['hit10'] >= 0.003 and r['shuffled'][kn]['test'][r['shuffled'][kn]['best']]['median'] >= 0.45]
    PRE.append({'key': k, 'title': t, 'assign': F19['search'][k]['assign'], 'mean': m19, 'pts': p19, 'test': tests(r['map'], r['shuffled'])})
json.dump({'res': R, 'mean': mean, 'pts': pts, 'chk': chk}, open(os.path.join(out, 'final20.json'), 'w'), default=lambda o: o.tolist() if hasattr(o, 'tolist') else str(o))
EXP = {'words': words, 'shown': base64.b64encode(np.where(PS > 0, np.maximum(1, np.round(PS * 255)), 0).astype(np.uint8).tobytes()).decode(),
       'name': meta['name'], 'group': meta['group'], 'how': meta['how'], 'missing': meta['missing'], 'slots': SL, 'presets': PRE,
       'pairs': SP['pairs'], 'deg': None}
import collections
deg = np.zeros(n, int)
for x, y, kn, spl in j['lines']: deg[x] += 1; deg[y] += 1
EXP['deg'] = base64.b64encode(np.minimum(deg, 65535).astype(np.uint16).tobytes()).decode()
json.dump(EXP, open(os.path.join(out, 'pulls167.json'), 'w'))
log('export', os.path.getsize(os.path.join(out, 'pulls167.json')))
