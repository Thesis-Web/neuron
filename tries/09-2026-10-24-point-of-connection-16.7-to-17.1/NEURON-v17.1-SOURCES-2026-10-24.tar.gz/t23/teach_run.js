// Types a list of lines into the page's real brain (worker16.js + host15.js + shared15.js + sql.js, run in node), one line at a
// time, as the prompt does, and reads back what the brain holds. usage: node teach_run.js <v16 dir> <sql-asm.js> <told.json> <sat.json> <lines.json> <out.json>
const fs = require('fs'), vm = require('vm');
const [D, ASM, TOLDF, SATF, LINESF, OUTF] = process.argv.slice(2);
const told = JSON.parse(fs.readFileSync(TOLDF, 'utf8')), sat = JSON.parse(fs.readFileSync(SATF, 'utf8'));
let lines = JSON.parse(fs.readFileSync(LINESF, 'utf8')); lines = lines.map(l => Array.isArray(l) ? l[1] : l);
const src = fs.readFileSync(ASM, 'utf8') + '\n' + fs.readFileSync(D + '/host15.js', 'utf8') + '\n' + fs.readFileSync(D + '/shared15.js', 'utf8') + '\n' + fs.readFileSync(D + '/worker16.js', 'utf8');
const ctx = { console: { log() {}, warn() {}, error() {} }, setTimeout, Uint8Array, Int8Array, Int16Array, Int32Array, Uint16Array, Uint32Array, Float32Array, Float64Array, ArrayBuffer, DataView, WebAssembly, TextDecoder, TextEncoder, performance, Date, Math, JSON };
ctx.self = ctx; let inbox = []; ctx.postMessage = (m) => inbox.push(m);
vm.createContext(ctx); vm.runInContext(src, ctx);
const send = (m) => { inbox = []; ctx.onmessage({ data: m }); return inbox; };
const q = (sql) => { const r = send({ type: 'query', id: 1, sql }); return r[0].rows; };
(async () => {
  send({ type: 'init', told, sat });
  for (let i = 0; i < 400 && !inbox.some(m => m.type === 'ready'); i++) await new Promise(r => setTimeout(r, 50));
  if (!inbox.some(m => m.type === 'ready')) throw new Error('brain not ready: ' + JSON.stringify(inbox.slice(-1)));
  const log = [];
  for (const line of lines) {
    const t = Date.now(), r = send({ type: 'lines', lines: [line] }), last = r[r.length - 1];
    log.push({ line: line.length > 90 ? line.slice(0, 87) + '...' : line, ms: Date.now() - t, type: last.type, output: last.output === undefined ? null : last.output, error: last.error || null });
  }
  const out = { log,
    place: q('SELECT id, word, x, y, z, t, ended FROM place ORDER BY id'),
    placeEvents: q("SELECT count(*) FROM event WHERE kind = 'place'")[0][0],
    defs: q("SELECT word, src, count(*) FROM definition WHERE src IN ('sqldoc', 'measured') GROUP BY word, src ORDER BY word"),
    formulas: q('SELECT word, origin FROM formula WHERE ended = 0'),
    placeStmts: q("SELECT count(*) FROM stmt WHERE text LIKE 'INSERT INTO place%'")[0][0],
    triggers: q("SELECT count(*) FROM sqlite_master WHERE type = 'trigger'")[0][0],
    gates: q('SELECT count(*) FROM encoder')[0][0] };
  fs.writeFileSync(OUTF, JSON.stringify(out, null, 1));
  const slow = log.slice().sort((a, b) => b.ms - a.ms).slice(0, 3).map(l => l.line.slice(0, 30) + ' ' + (l.ms / 1000).toFixed(1) + ' s');
  console.log(lines.length, 'lines;', log.filter(l => l.type !== 'done').length, 'not done;', 'total', (log.reduce((a, l) => a + l.ms, 0) / 1000).toFixed(0), 's; slowest:', slow.join(', '));
  console.log('place rows', out.place.length, '| place events', out.placeEvents, '| statements that wrote a place', out.placeStmts, '| formulas', JSON.stringify(out.formulas), '| gates', out.gates, '| triggers', out.triggers);
})().catch(e => { console.error('FAILED', e.stack || e); process.exit(1); });
