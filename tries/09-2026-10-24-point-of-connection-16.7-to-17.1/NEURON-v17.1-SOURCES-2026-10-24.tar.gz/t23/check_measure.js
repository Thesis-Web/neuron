// Does 16.4's "Meaning of a word, measured" count silicon, or the labels written in the log text?
// Runs the page's real worker code (worker16.js + host15.js + shared15.js + sql.js) in node, twice: with the told block as it is,
// and with every label WRITE in the told block's log text renamed WRITX (the brain's work unchanged). Then compares.
// usage: node check_measure.js <v16 dir> <sql-asm.js>
const fs = require('fs'), vm = require('vm');
const D = process.argv[2], told0 = JSON.parse(fs.readFileSync(D + '/physics16.json', 'utf8')), sat = JSON.parse(fs.readFileSync(D + '/sat15.json', 'utf8'));
const src = fs.readFileSync(process.argv[3], 'utf8') + '\n' + fs.readFileSync(D + '/host15.js', 'utf8') + '\n' + fs.readFileSync(D + '/shared15.js', 'utf8') + '\n' + fs.readFileSync(D + '/worker16.js', 'utf8');
function runWorker(told, lines, word) {
  return new Promise((res, rej) => {
    const msgs = [], ctx = { console, setTimeout, Uint8Array, Int8Array, Int16Array, Int32Array, Uint16Array, Uint32Array, Float32Array, Float64Array, ArrayBuffer, DataView, WebAssembly, TextDecoder, TextEncoder, performance, Date, Math, JSON };
    ctx.self = ctx; ctx.postMessage = (m) => { msgs.push(m); step(m); };
    vm.createContext(ctx); vm.runInContext(src, ctx);
    let stage = 0, out = {};
    function q(sql) { ctx.onmessage({ data: { type: 'query', id: 900 + stage, sql } }); }
    function step(m) {
      if (m.type === 'error') return rej(new Error(m.error));
      if (m.type === 'ready' && stage === 0) { stage = 1; out.before = counts(); ctx.onmessage({ data: { type: 'lines', lines } }); return; }
      if (m.type === 'done' && stage === 1) { stage = 2; out.after = counts(); out.output = m.output; ctx.onmessage({ data: { type: 'measure', id: 77, word } }); return; }
      if (m.type === 'measured' && stage === 2) { out.measured = m.result; res(out); }
    }
    function counts() { const c = {}; ctx.onmessage({ data: { type: 'query', id: 1, sql: "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT GLOB 'g[0-9]*'" } }); const names = msgs[msgs.length - 1].rows.map(r => r[0]);
      names.forEach(n => { ctx.onmessage({ data: { type: 'query', id: 2, sql: 'SELECT count(*) FROM "' + n + '"' } }); c[n] = msgs[msgs.length - 1].rows[0][0]; }); return c; }
    ctx.onmessage({ data: { type: 'init', told, sat } });
  });
}
(async () => {
  const told1 = JSON.parse(JSON.stringify(told0));
  let renamed = 0; told1.statements = told1.statements.map(s => s.replace(/'((?:[A-Z]+ )*)WRITE((?: [A-Z]+)*)'/g, (m0, a, b) => { renamed++; return "'" + a + 'WRITX' + b + "'"; }));
  const lines = ['cat sat', 'dog sat'];
  const A = await runWorker(told0, lines, 'dog'), B = await runWorker(told1, lines, 'dog');
  const tables = (o) => Object.keys(o.after).filter(k => k !== 'event').map(k => k + ' ' + (o.after[k] - (o.before[k] || 0))).join(', ');
  console.log('labels renamed in the told block:', renamed);
  console.log('measure "dog", told block as is   -> silicon:', JSON.stringify(A.measured.aggregate.silicon), '| graph:', JSON.stringify(A.measured.aggregate.graph));
  console.log('measure "dog", WRITE renamed WRITX -> silicon:', JSON.stringify(B.measured.aggregate.silicon), '| graph:', JSON.stringify(B.measured.aggregate.graph));
  console.log('rows the two brains wrote (every table but the log), identical:', tables(A) === tables(B));
  console.log('   ', tables(A));
  console.log('outputs:', JSON.stringify(A.output), JSON.stringify(B.output));
})().catch(e => { console.error('FAILED', e.message); process.exit(1); });
