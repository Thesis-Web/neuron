# The long form, for the kernel later: each measured SQL word's program in the page's SQLite, every step with SQLite's own
# description from its opcode page. SQLite is the crutch: the brain cannot run these steps; this file keeps them.
# usage: kernel_log.py <docs-raw dir> <a_js.json> <pairs23.json> <b3.json> <out.md>
import html, json, re, sys
RAW, AJS, PAIRS, B3, OUT = sys.argv[1:]
h = open(RAW + '/opcode.html', encoding='utf-8').read()
DOC = {}
for m in re.finditer(r'<a name="(\w+)"></a>\1\s*<td>(.*?)</td></tr>', h, re.S):
    t = html.unescape(re.sub(r'<[^>]+>', ' ', m.group(2))); DOC[m.group(1)] = re.sub(r'\s+', ' ', t).strip()
a = json.load(open(AJS)); pairs = {p['id']: p for p in json.load(open(PAIRS))['pairs']}; b3 = json.load(open(B3))['triggers']
used = {}
L = ['# The long form: what each SQL word runs inside SQLite (kernel log)', '',
     'SQLite is the crutch: the brain hands SQL text to mother, and SQLite turns it into these steps (its bytecode) and runs them in its C code.',
     'The brain cannot run these steps itself. This file keeps them, so a kernel built later knows what each word must do.',
     f"Programs from the page's SQLite ({a['sqlite']}), test table t (a INTEGER, b TEXT) with 3 rows. Step descriptions are SQLite's own, from sqlite.org/opcode.html (fetched 2026-10-24).",
     'Each line is: step name, then SQLite\'s registers P1 P2 P3, P4, P5, then the description.', '']
def first(s): return re.split(r'(?<=[.])\s', s, 1)[0] if s else '(no description on the opcode page)'
for pid, p in pairs.items():
    r = a['pairs'][pid]
    L.append(f"## {p['word']}{'' if p['told'] else ' (not told)'}")
    for side in ('with', 'without'):
        if side not in r: continue
        x = r[side]; L.append(f"{'With the word' if side == 'with' else 'Without it'}: `{x['sql']}`" + (f" (SQLite refuses it: {x['error']})" if 'error' in x else ''))
        if 'ops' in x:
            L.append('```')
            for o in x['ops']:
                used[o[0]] = used.get(o[0], 0) + 1
                L.append(f"{o[0]:<14} {o[1]!s:>4} {o[2]!s:>4} {o[3]!s:>4}  {str(o[4] or '')[:28]:<28} {o[5]!s:>3}  {first(DOC.get(o[0]))}")
            L.append('```')
    L.append('')
L.append('## The told physics: steps inside each told trigger (counts, page SQLite)')
L.append('Each trigger\'s whole program is in b3.json; here, how many of each step it holds, brain work and log (the event rows the page draws from) apart.')
for k, v in b3.items():
    if not k.startswith('main.') or '.miss_' in k: continue
    c = v['counts']; lg = v['log']
    for op in list(c) + list(lg): used.setdefault(op.split(':')[0], 0)
    L.append(f"- **{k[5:]}** ({v['table']}): " + ', '.join(f"{op} {n}" for op, n in sorted(c.items(), key=lambda t: -t[1])) + (f"; log: {sum(lg.values())} steps" if lg else ''))
L += ['', '## Every step used above, as SQLite describes it', '']
for op in sorted(u for u in used if u != 'Function'):
    L.append(f"- **{op}**: {DOC.get(op, '(no description on the opcode page)')}")
L.append(f"- **Function**: {DOC.get('Function', '')}")
open(OUT, 'w').write('\n'.join(L) + '\n')
print(len(DOC), 'opcode descriptions read;', len(used), 'steps used;', len(L), 'lines written; missing descriptions:', [u for u in used if u not in DOC and u != 'Function'])
