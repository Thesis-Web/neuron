import json
E = lambda s: str(s).replace('|', '\\|')
d=json.load(open('teach17.json')); sheet=json.load(open('sheet17.json')); B=json.load(open('shot171.out.json')); hw=json.load(open('homework.json'))
A=json.load(open('ctlA.out.json')); Bc=json.load(open('ctlB.out.json'))
log=d['log']; live=[r for r in d['place'] if r[6]==0]
dms=sorted(l['ms'] for l in log if l['line'].startswith('define ') and ' = ' not in l['line']); pms=sorted(l['ms'] for l in log if l['line'].startswith('place ') and ' = ' not in l['line'])
L=['# Teaching run results: define and place, typed at the prompt (2026-10-24)',
"Predictions frozen at 21:15 before the run: NEURON-TEACH-EXPECT-2026-10-24.md (sha256 3858b0c9181b...). The whole sheet (88 lines) was typed, one line at a time, into the page's real brain code (worker16.js, host15.js, sql.js 3.39.3) run in node; 10 of its lines were also typed in the page itself, in a real browser, through the prompt.",'',
"## The two taught lines (typed; the brain writes each as a formula row pointing at its teaching run)",'```',sheet[0][1],sheet[1][1],'```',
"Then \"define W\" and \"place W\" for each of the 40 told SQL words, in the told block's order, then the same for DROP, substr and EXCEPT, which were never told or taught.",'',
'## Predictions against the results','','| Prediction | Result | |','|---|---|---|',
"| P1 \"define W\" says W's first SQL doc line (41 words); no line: the line back with \"?\" | it said the doc line for every word that has one; for INTO, <, ( and the others it said the line back, without \"?\" (they are told words) | held; the form of the miss was wrong |",
f"| P2 \"place W\" writes one live place row, x, y, z = 10 x measured rows, structure, text; equal to the lab's places | {len(live)} live rows, all equal to the lab's places (largest difference 0); INSERT 10,0,0, DELETE -10,0,0, CREATE 0,10,0, group_concat and {E('||')} 0,0,10, all other told words 0,0,0 | held |",
"| P3 never told: DROP 0,-10,0; substr 0,0,-10; EXCEPT 0,0,0 | exactly (EXCEPT is stored as \"except\": a doc sentence gave the word birth in small letters first, and a gate keeps its first spelling) | held |",
f"| P4 no place row for a word not placed | {len(d['place'])} place rows, {d['placeStmts']} place statements sent by the formula's runs, {d['placeEvents']} place log rows | held |",
"| P5 placing again keeps the old row | not tested by teaching: \"place INSERT\" a second time, and \"place insert\" in small letters, were answered from memory (same gates) in 0.4 and 0.3 s and wrote nothing. The told rule itself works when rows are written directly: a second place of INSERT ended the first | not tested as designed |",
f"| P6 controls: \"place store\" 0,0,0; INSERT without its measured rows 0,0,0 | store {A['place'][0][2:5]}; INSERT without measured rows {Bc['place'][0][2:5]} | held |",
f"| P7 define is slow, place is fast | both slow: median {dms[len(dms)//2]/1000:.1f} s and {pms[len(pms)//2]/1000:.1f} s; first lines 1-3 s, last lines 15-66 s (define EXCEPT 66 s); the whole sheet {round(sum(l['ms'] for l in log)/60000)} minutes in node | WRONG: every new line lays new DNA rows, each a new trigger in a growing schema (1,984 triggers at the end) |",
'','## In the page (real browser, typed through the prompt by clicking sheet lines and pressing run)','','| Line | Seconds | The brain said |','|---|---|---|']
for l in B['lines']: L.append(f"| `{E(l['line'][:40])}` | {l['s']} | {E(l['said'][:80])} |")
L+=['', "Places the brain wrote into its own place table: " + '; '.join(f"{E(r[0])} {r[1]},{r[2]},{r[3]}" for r in B['brainPlaces']) + '. The stage drew exactly these, from that table.','',
'## What this shows, and what it does not',
'- Shows: the brain can be taught, at the prompt, a process that defines a word from its SQL docs source and places it from its measured source, and the same two taught words place words it was never told (DROP, substr, EXCEPT). Every place is a row the brain wrote through its own run.',
'- Does not show: the brain finding a meaning. The numbers it places by are ours (steps 2 and 3), served by the "measured" source like a dictionary. A word that source does not hold is placed at 0,0,0 (store). For the brain to place a new SQL word by itself, it has to measure the word itself: run it (BUILD lines through mother already return rows and changes) or ask SQLite for its program (EXPLAIN: the brain drops it today; a told change).',
'- The memory hop stops re-teaching: a line the brain has seen, in any spelling, is answered from memory and runs nothing.','',
'## Homework: the words the definitions use', f"The 76 SQL doc lines use {hw['distinct']} different words; {len(hw['sql'])} are SQL words. None has a meaning in the brain. The most used: " + ', '.join(f"{t} ({n})" for t, n in [x for x in hw['counts'] if x[0] not in hw['sql']][:30]) + '.','',
'## The SQL docs source: the rule and its misses',"- Rule: the first two sentences on the word's own SQLite doc page that hold the word (text from p, li, dd, td; filters drop navigation, contents entries, syntax fragments and lines that are mostly symbols; a symbol word's line must say operator, equals or not-equal).",
'- Misses: "-" got the ' + E('||') + ' sentence (a dash in the prose); "/" got the precedence table\'s introduction; "*" got a line using it as "all columns"; INTO, <, >, <=, >= and the punctuation have no line.','',
"## Told changes in 17.1 (four statements; everything else is 16.4's told block byte for byte)","- CREATE TABLE place (id, word, x, y, z, t, ended); its trigger ends a word's older place (kept as history) and writes one log row with no action labels.",
'- The measured source: a gate for it, and the told source line asks it too.',"- Not changed: 16.4's state trigger still writes \"A formula wrote it\" in its log text (true there: only taught formulas write state); yours to change."]
open('RESULTS-TEACH.md','w').write('\n'.join(L)+'\n'); print(len(L),'lines')
