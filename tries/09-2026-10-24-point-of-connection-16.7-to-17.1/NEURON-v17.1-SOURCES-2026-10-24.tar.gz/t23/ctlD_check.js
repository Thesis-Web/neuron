// read back what the brain's own statements did, from the same kind of brain, after the same lines
const fs = require('fs'), vm = require('vm'); const [D, ASM] = process.argv.slice(2);
const src = fs.readFileSync(ASM, 'utf8') + '\n' + fs.readFileSync(D + '/host15.js', 'utf8') + '\n' + fs.readFileSync(D + '/shared15.js', 'utf8') + '\n' + fs.readFileSync(D + '/worker16.js', 'utf8');
const ctx = { console: { log() {}, warn() {}, error() {} }, setTimeout, Uint8Array, Int8Array, Int16Array, Int32Array, Uint16Array, Uint32Array, Float32Array, Float64Array, ArrayBuffer, DataView, WebAssembly, TextDecoder, TextEncoder, performance, Date, Math, JSON };
ctx.self = ctx; let inbox = []; ctx.postMessage = (m) => inbox.push(m); vm.createContext(ctx); vm.runInContext(src, ctx);
const send = (m) => { inbox = []; ctx.onmessage({ data: m }); return inbox; }; const q = (sql) => send({ type: 'query', id: 1, sql })[0].rows;
(async () => { send({ type: 'init', told: JSON.parse(fs.readFileSync('physics17.json', 'utf8')), sat: JSON.parse(fs.readFileSync('sat17.json', 'utf8')) });
  for (let i = 0; i < 400 && !inbox.some(m => m.type === 'ready'); i++) await new Promise(r => setTimeout(r, 50));
  for (const l of JSON.parse(fs.readFileSync('ctlD.json', 'utf8'))) send({ type: 'lines', lines: [l] });
  console.log('table things in the brain:', JSON.stringify(q("SELECT sql FROM sqlite_master WHERE name = 'things'")), '| its rows:', JSON.stringify(q('SELECT * FROM things')));
  console.log('statements the runs sent to mother:', JSON.stringify(q("SELECT text FROM stmt WHERE text LIKE '%things%' ORDER BY id")));
  console.log('how the lines ran (run kind, recalled from memory):', JSON.stringify(q("SELECT line, recalled FROM run WHERE kind = 'line' ORDER BY id")));
})(); 
