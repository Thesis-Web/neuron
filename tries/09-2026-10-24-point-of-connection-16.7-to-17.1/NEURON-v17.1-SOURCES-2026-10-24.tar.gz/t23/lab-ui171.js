  // ---- MEASURED (17, 2026-10-24): the bare core, SQL words added one at a time, each placed only by numbers measured in SQLite.
  // The numbers and the lines were measured by rel.js in this same SQLite (sql.js 3.39.3) and are held in a lab database of their
  // own, beside the brain in the worker (not attached to it). The page solves each place with LabPlace and writes it into the lab's
  // place table; the stage, the table and the selection read the places back from SQLite. Nothing here touches the brain's tables.
  /*LABPLACE*/
  var MVIEW = false, LABREADY = false, LABBUSY = false, LABAGAIN = false, LABSTATUS = '';
  var LP = {}, LORDER = [], LEFF = {}, LHOW = {}, LTESTS = [], ADDED = [], LPOS = {}, LOWN = {}, LLASTSOLVE = null;
  var MKINDS = [['inverse', 0xd97b4f, 'A then B puts the database or the value back exactly'], ['complement', 0xe0573f, 'together they keep every row of t, and never the same row'],
    ['negation', 0xc24f8a, 'NOT A compiles to the identical program as B'], ['negates', 0xb59ae0, 'NOT, to each compare word it turns into another one'],
    ['same program', 0x4f9bd9, 'two spellings, one identical program'], ['dual', 0x4fb7a8, 'NOT (p AND q) keeps the rows of (NOT p) OR (NOT q), and the other way'],
    ['completes', 0xf28c4b, 'take it out and SQLite refuses the line'], ['modifies', 0xa8a070, 'take it or its clause out: the line still runs, and it changes'],
    ['no change', 0x8b95a2, 'take it out: the identical program'], ['same spelling', 0xd8d4c8, 'one spelling that measured two different jobs']];
  var MKCOL = {}, MKON = {}; MKINDS.forEach(function (k) { MKCOL[k[0]] = k[1]; MKON[k[0]] = false; });
  var EFFS = { rows: ['writes a row', 'removes a row'], structure: ['spawns a table', 'destroys a table'], text: ['joins text', 'cuts text'], read: ['read steps', ''], test: ['test steps', ''], number: ['arithmetic steps', ''], gather: ['gather and sort steps', ''], write: ['write steps', ''] };
  var AXES = ['rows', 'structure', 'text'], LRULE = 'share', LPULL = 0.5;
  // 17.1: the places can also come from the brain's own place table, written by the taught place formula's runs
  var LFROM = 'lab', BPOS = {}, BLIST = [];
  (function () {
    LAB.points.forEach(function (p) { LP[p.id] = p; LEFF[p.id] = {}; LHOW[p.id] = {}; });
    LORDER = LAB.points.slice().sort(function (a, b) { return a.ord - b.ord; }).map(function (p) { return p.id; });
    LAB.effects.forEach(function (e) { LEFF[e[0]][e[1]] = e[2]; LHOW[e[0]][e[1]] = e[3]; });
    LAB.lines.forEach(function (l) { LTESTS.push([l[0], l[1], l[2], l[3], 1]); });
    LAB.rejected.forEach(function (l) { LTESTS.push([l[0], l[1], l[2], l[3], 0]); });
  })();
  function lname(id) { return id === 'origin' ? 'origin' : LP[id].label; }
  function eligible(id) { return LP[id].told || $('mnottold').checked; }
  function axName(a, sign) { if (!MVIEW) return (sign > 0 ? '+' : '-') + a; var k = AXES[{ x: 0, y: 1, z: 2 }[a]], t = EFFS[k][sign > 0 ? 0 : 1]; return (sign > 0 ? '+' : '-') + a + (t ? ' ' + k + ': ' + t : ''); }
  // the lab database: made once, the first time the brain is ready; a restart of the brain leaves it as it is
  function labInit() {
    if (LABREADY || LABBUSY || !ready) return; LABBUSY = true; LABSTATUS = 'laying the lab database beside the brain';
    var own = function (ax) { return "10 * coalesce((SELECT e.value FROM effect e WHERE e.point = p.id AND e.kind = (SELECT kind FROM axis WHERE axis = '" + ax + "')), 0)"; };
    var ops = [['CREATE TABLE point (id INTEGER PRIMARY KEY, word TEXT, label TEXT, told INTEGER, ord INTEGER)'], ['CREATE TABLE effect (point INTEGER, kind TEXT, value REAL, how TEXT)'],
      ['CREATE TABLE line (a INTEGER, b INTEGER, kind TEXT, how TEXT, held INTEGER)'], ['CREATE TABLE axis (axis TEXT PRIMARY KEY, kind TEXT)'], ['CREATE TABLE added (point INTEGER PRIMARY KEY, n INTEGER)'],
      ['CREATE TABLE place (point INTEGER PRIMARY KEY, x REAL, y REAL, z REAL, rule TEXT, pull REAL)'],
      ['CREATE VIEW own AS SELECT p.id AS point, ' + own('x') + ' AS x, ' + own('y') + ' AS y, ' + own('z') + ' AS z FROM point p'],
      ['INSERT INTO point VALUES (?, ?, ?, ?, ?)', LAB.points.map(function (p) { return [p.id, p.word, p.label, p.told, p.ord]; }), 'many'],
      ['INSERT INTO effect VALUES (?, ?, ?, ?)', LAB.effects.map(function (e) { return [e[0], e[1], e[2], e[3]]; }), 'many'],
      ['INSERT INTO line VALUES (?, ?, ?, ?, ?)', LTESTS.map(function (l) { return [l[0], l[1], l[2], l[3], l[4]]; }), 'many'],
      ['SELECT (SELECT count(*) FROM point), (SELECT count(*) FROM effect), (SELECT count(*) FROM line WHERE held = 1), (SELECT count(*) FROM line WHERE held = 0)']];
    ask({ type: 'lab', ops: ops }).then(function (r) { var c = r[r.length - 1][0]; LABREADY = true; LABBUSY = false; LABSTATUS = 'lab database: ' + c[0] + ' points, ' + c[1] + ' measured numbers, ' + c[2] + ' lines, ' + c[3] + ' tested pairs that are not lines'; labUpdate(); });
  }
  // a change: the axes and the added points go into SQLite, the own places come back from its view, the solve runs, the places go back in, and are read back
  function labUpdate() {
    if (LFROM === 'brain') { if (!ready) return; ask({ type: 'query', sql: 'SELECT word, x, y, z FROM place WHERE ended = 0 ORDER BY id' }).then(function (rows) { BPOS = {}; BLIST = []; rows.forEach(function (r) { var k = 'b:' + r[0]; if (!BPOS[k]) BLIST.push(k); BPOS[k] = [r[1], r[2], r[3]]; }); labPanel(); drawAxes(true); }); return; }
    if (!LABREADY) { labInit(); return; }
    if (LABBUSY) { LABAGAIN = true; return; } LABBUSY = true;
    var ops = [['DELETE FROM axis'], ['INSERT INTO axis VALUES (?, ?)', [['x', AXES[0]], ['y', AXES[1]], ['z', AXES[2]]], 'many'], ['DELETE FROM added'],
      ['INSERT INTO added VALUES (?, ?)', ADDED.map(function (id, i) { return [id, i]; }), 'many'], ['SELECT o.point, o.x, o.y, o.z FROM own o JOIN added a ON a.point = o.point ORDER BY a.n']];
    ask({ type: 'lab', ops: ops }).then(function (r) {
      LOWN = {}; r[r.length - 1].forEach(function (x) { LOWN[x[0]] = [x[1], x[2], x[3]]; });
      var on = {}; ADDED.forEach(function (id) { on[id] = 1; });
      var lines = LTESTS.filter(function (l) { return l[4] && MKON[l[2]] && on[l[0]] && on[l[1]]; });
      var sol = LabPlace.solve(ADDED.map(function (id) { return { id: id }; }), LOWN, lines, LPULL, LRULE); LLASTSOLVE = { iterations: sol.iterations, lines: lines.length };
      return ask({ type: 'lab', ops: [['DELETE FROM place'], ['INSERT INTO place VALUES (?, ?, ?, ?, ?, ?)', ADDED.map(function (id) { var x = sol.place[id]; return [id, x[0], x[1], x[2], LRULE, LPULL]; }), 'many'], ['SELECT point, x, y, z FROM place']] });
    }).then(function (r) {
      LPOS = {}; r[r.length - 1].forEach(function (x) { LPOS[x[0]] = [x[1], x[2], x[3]]; });
      LABBUSY = false; if (LABAGAIN) { LABAGAIN = false; labUpdate(); return; }
      labPanel(); labLines = true; drawAxes(true);
    });
  }
  // the stage: origin and the added points, at their places from SQLite, times the drawing's spacing
  var labGroup = hasGL ? new THREE.Group() : null, labDots = {}, labLabels = {}, labLineGroup = hasGL ? new THREE.Group() : null, labLines = false;
  if (hasGL) { scene.add(labGroup); scene.add(labLineGroup); labGroup.visible = labLineGroup.visible = false; }
  function items() {
    if (LFROM === 'brain') return [{ key: 'origin', label: 'origin', pos: [0, 0, 0] }].concat(BLIST.map(function (k) { return { key: k, label: k.slice(2), pos: BPOS[k] }; }));
    return [{ key: 'origin', label: 'origin', pos: [0, 0, 0] }].concat(ADDED.filter(function (id) { return LPOS[id]; }).map(function (id) { return { key: id, label: lname(id), pos: LPOS[id] }; }));
  }
  function colOf(key) { return key === 'origin' ? 0xfff1a8 : String(key).indexOf('b:') === 0 ? 0xf28c4b : LP[key].told ? 0xbfe3ff : 0x8b95a2; }
  function labDot(id) {
    if (labDots[id] || !hasGL) return labDots[id];
    var col = colOf(id), m = new THREE.Mesh(dotGeo, new THREE.MeshBasicMaterial({ color: col, transparent: true, opacity: .95 }));
    m.userData = { base: id === 'origin' ? 2.4 : 1.2, lab: id }; labGroup.add(m); labDots[id] = m; return m;
  }
  function labStacks() {
    // points on the same spot share one name on the stage: "the first + n more"; their places are not changed
    var spots = {}; items().forEach(function (it) { var k = it.pos.map(function (v) { return Math.round(v * 100); }).join(','); (spots[k] = spots[k] || []).push(it); });
    return spots;
  }
  function labFrame() {
    if (!hasGL) return;
    labGroup.visible = labLineGroup.visible = MVIEW; if (!MVIEW) return;
    var on = {}, its = items(); its.forEach(function (it) { on[it.key] = 1; });
    Object.keys(labDots).forEach(function (id) { labDots[id].visible = !!on[id]; });
    var spots = labStacks(), names = {};
    Object.keys(spots).forEach(function (k) { var g = spots[k]; names[g[0].key] = g[0].label + (g.length > 1 ? ' + ' + (g.length - 1) + ' more' : ''); });
    its.forEach(function (it) {
      var id = it.key, p = it.pos, m = labDot(id);
      m.position.set(p[0] * SP, p[1] * SP, p[2] * SP); m.scale.setScalar(m.userData.base * 3.5 * 0.728 * camera.position.distanceTo(m.position) / stageH());
      var want = names[id] || null, lb = labLabels[id];
      if (lb && lb.userData.text !== want) { labGroup.remove(lb); lb.material.map.dispose(); lb.material.dispose(); lb = labLabels[id] = null; }
      if (want && !lb) { lb = labLabels[id] = makeLabel(want, '#' + ('000000' + colOf(id).toString(16)).slice(-6), id === 'origin' ? 14 : 12); lb.userData.text = want; labGroup.add(lb); }
      if (lb) { lb.visible = true; sizeLabel(lb); lb.position.copy(m.position); }
    });
    Object.keys(labLabels).forEach(function (id) { if (labLabels[id] && !names[id]) labLabels[id].visible = false; });
    // the lines that are on, between added points, faint
    while (labLineGroup.children.length) { var c = labLineGroup.children.pop(); c.geometry.dispose(); c.material.dispose(); }
    var segs = {}; if (LFROM === 'lab') LTESTS.forEach(function (l) { if (!l[4] || !MKON[l[2]] || !on[l[0]] || !on[l[1]] || !LPOS[l[0]] || !LPOS[l[1]]) return; (segs[l[2]] = segs[l[2]] || []).push(new THREE.Vector3(LPOS[l[0]][0] * SP, LPOS[l[0]][1] * SP, LPOS[l[0]][2] * SP), new THREE.Vector3(LPOS[l[1]][0] * SP, LPOS[l[1]][1] * SP, LPOS[l[1]][2] * SP)); });
    Object.keys(segs).forEach(function (k) { labLineGroup.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(segs[k]), new THREE.LineBasicMaterial({ color: MKCOL[k], transparent: true, opacity: .45 }))); });
  }
  // the measured view frames its farthest point and the whole axes, names included
  function labRadii() { return [Math.max(labMaxR(), (axesL || 20) * 1.05) * SP]; }
  function labMaxR() { var r = 0; items().forEach(function (it) { r = Math.max(r, Math.hypot(it.pos[0], it.pos[1], it.pos[2])); }); return r; }
  function setMView(v) {
    MVIEW = v; $('mview').checked = v;
    if (hasGL) { dotGroup.visible = labelGroup.visible = relGroup.visible = runGroup.visible = memGroup.visible = hopGroup.visible = !v; if (v) flash.visible = false; }
    if (v) labUpdate(); clearSel(); drawAxes(true); userZoomed = false; fitLeft = 120;
    if (!v) render(T, true);
  }
  // the tab: added words, the last one's numbers, the kinds of line, the axes
  function fmt3(p) { return p ? p.map(function (v) { return (Math.abs(v) < .05 ? 0 : v).toFixed(1); }).join(', ') : ''; }
  function labPanel() {
    if (LFROM === 'brain') {
      var b0 = BLIST.filter(function (k) { return BPOS[k].every(function (v) { return Math.abs(v) < .05; }); }).length;
      $('msum').innerHTML = BLIST.length + ' words placed by the brain itself (its place table, live rows); ' + b0 + ' sit at 0,0,0. <span class="m">Each place was written by the taught place formula\'s own run, through mother; nothing here is the lab\'s.</span>';
      $('mlist').innerHTML = BLIST.map(function (k, i) { return '<div data-l="' + esc(k) + '"><span>' + (i + 1) + '</span><span>' + esc(k.slice(2)) + '</span><span>' + fmt3(BPOS[k]) + '</span></div>'; }).join('') || '<div><span></span><span class="m">the brain\'s place table is empty: teach place, then place a word</span><span></span></div>';
      $('mlast').innerHTML = ''; return;
    }
    var at0 = ADDED.filter(function (id) { return LPOS[id] && LPOS[id].every(function (v) { return Math.abs(v) < .05; }); }).length;
    var total = LORDER.filter(eligible).length;
    $('msum').innerHTML = ADDED.length + ' of ' + total + ' points added; ' + at0 + ' sit at 0,0,0. ' + (LLASTSOLVE ? LLASTSOLVE.lines + ' line(s) on' + (LLASTSOLVE.lines ? ', solved in ' + LLASTSOLVE.iterations + ' rounds' : '') + '.' : '') + ' <span class="m">' + esc(LABSTATUS) + '</span>';
    $('mlist').innerHTML = ADDED.map(function (id, i) { return '<div data-l="' + id + '"' + (i === ADDED.length - 1 ? ' class="last"' : '') + '><span>' + (i + 1) + '</span><span>' + esc(lname(id)) + (LP[id].told ? '' : ' <span class="m">(not told)</span>') + '</span><span>' + fmt3(LPOS[id]) + '</span></div>'; }).join('') || '<div><span></span><span class="m">none yet: origin alone</span><span></span></div>';
    var last = ADDED[ADDED.length - 1];
    $('mlast').innerHTML = last === undefined ? '' : '<b>' + esc(lname(last)) + '</b>: ' + AXES.map(function (k) { return k + ' ' + (LEFF[last][k] > 0 ? '+' : '') + (LEFF[last][k] || 0) + ' <span class="m">(' + esc(LHOW[last][k] || '') + ')</span>'; }).join('; ') + '. Place ' + fmt3(LPOS[last]) + '.';
    MKINDS.forEach(function (k) { var c = $('mk-' + k[0].replace(/ /g, '_')); if (c) c.textContent = LTESTS.filter(function (l) { return l[4] && l[2] === k[0] && eligible(l[0]) && eligible(l[1]); }).length; });
    if (!$('labt').hidden) labTable();
  }
  function labDetail(id) {
    var h = '<b>' + esc(lname(id)) + '</b><span class="m">' + (LP[id].told ? 'a told SQL word' + (LP[id].label !== LP[id].word ? ', one of the jobs of "' + esc(LP[id].word) + '"' : '') : 'not a told word: measured for comparison') + '</span>';
    h += '<span class="mono">place, read from SQLite (lab.place): ' + (LPOS[id] ? fmt3(LPOS[id]) : 'not added') + '; its own place (the lab\'s own view): ' + (LOWN[id] ? fmt3(LOWN[id]) : '') + '</span>';
    Object.keys(EFFS).forEach(function (k) { h += '<span class="mono">' + k + ' ' + (LEFF[id][k] > 0 ? '+' : '') + (LEFF[id][k] || 0) + ' <span class="m">' + esc(LHOW[id][k] || '') + '</span></span>'; });
    var mine = LTESTS.filter(function (l) { return l[0] === id || l[1] === id; });
    mine.filter(function (l) { return l[4]; }).forEach(function (l) { var o = l[0] === id ? l[1] : l[0]; h += '<span class="mono"><span style="color:#' + ('000000' + MKCOL[l[2]].toString(16)).slice(-6) + '">' + esc(l[2]) + '</span> ' + esc(lname(o)) + (MKON[l[2]] ? '' : ' <span class="m">(off)</span>') + ' <span class="m">' + esc(l[3]) + '</span></span>'; });
    var rej = mine.filter(function (l) { return !l[4]; }); if (rej.length) h += '<span class="mono"><span class="m">tested and not a line: ' + rej.map(function (l) { return esc(l[2]) + ' with ' + esc(lname(l[0] === id ? l[1] : l[0])); }).join('; ') + '</span></span>';
    return h;
  }
  function showLab(id) {
    if (String(id).indexOf('b:') === 0) { var w = id.slice(2); selEl.innerHTML = '<b>' + esc(w) + '</b><span class="m">a place in the brain\'s own place table</span><span class="mono">x, y, z ' + fmt3(BPOS[id]) + '</span><span class="m" id="bplace">reading its rows…</span>';
      ask({ type: 'query', sql: "SELECT (SELECT group_concat(id || ': ' || x || ', ' || y || ', ' || z || ' at clock ' || t || CASE WHEN ended = 1 THEN ' (ended)' ELSE '' END, '; ') FROM place WHERE word = ?), (SELECT count(*) FROM definition WHERE word = ? AND src = 'sqldoc'), (SELECT count(*) FROM definition WHERE word = ? AND src = 'measured')", params: [w, w, w] }).then(function (r) { var el = $('bplace'); if (el) { el.className = 'mono'; el.innerHTML = 'place rows: ' + esc(r[0][0] || '') + '<br>definition rows it holds: ' + r[0][1] + ' from the SQL docs, ' + r[0][2] + ' from measured'; } }); return; }
    if (id === 'origin') { selEl.innerHTML = '<b>origin</b><span class="m">the one told place, 0, 0, 0. Every measured point starts its own place from here.</span>'; return; }
    var p = LPOS[id], same = p ? ADDED.filter(function (j) { return j !== id && LPOS[j] && LPOS[j].every(function (v, k) { return Math.abs(v - p[k]) < .005; }); }) : [];
    selEl.innerHTML = labDetail(id) + (same.length ? '<span class="mono"><span class="m">on the same spot: ' + esc(same.map(lname).join(', ')) + '</span></span>' : '');
  }
  function labTable() {
    var q = $('lfind').value.trim().toLowerCase(), n = 0, order = {}; ADDED.forEach(function (id, i) { order[id] = i + 1; });
    var h = '<thead><tr><th>label</th><th>told</th><th>added</th><th>x</th><th>y</th><th>z</th>' + Object.keys(EFFS).map(function (k) { return '<th>' + k + '</th>'; }).join('') + '<th>lines</th></tr></thead><tbody>';
    LORDER.forEach(function (id) {
      if (q && lname(id).toLowerCase().indexOf(q) < 0) return; n++;
      var lc = {}; LTESTS.forEach(function (l) { if (l[4] && (l[0] === id || l[1] === id)) lc[l[2]] = (lc[l[2]] || 0) + 1; });
      h += '<tr class="arow" data-l="' + id + '"><td>' + esc(lname(id)) + '</td><td>' + (LP[id].told ? 'yes' : 'no') + '</td><td class="n">' + (order[id] || '') + '</td>' + (LPOS[id] ? LPOS[id].map(function (v) { return '<td class="n">' + (Math.abs(v) < .05 ? 0 : v).toFixed(1) + '</td>'; }).join('') : '<td colspan="3" class="m">not added</td>') +
        Object.keys(EFFS).map(function (k) { return '<td class="n">' + (LEFF[id][k] || 0) + '</td>'; }).join('') + '<td style="white-space:nowrap">' + Object.keys(lc).sort().map(function (k) { return esc(k) + ' ' + lc[k]; }).join('<br>') + '</td></tr>';
      if (LABOPEN === id) h += '<tr class="det"><td colspan="' + (7 + Object.keys(EFFS).length) + '"><div class="sel">' + labDetail(id) + '</div></td></tr>';
    });
    $('ltable').innerHTML = h + '</tbody>'; $('lshown').textContent = n + ' shown';
    $('lsum').innerHTML = esc(LABSTATUS) + '. <span class="m">x, y, z are read from the lab\'s place table in SQLite; the numbers from its effect table; a line from its line table. Axes now: x ' + AXES[0] + ', y ' + AXES[1] + ', z ' + AXES[2] + '; rule ' + (LRULE === 'share' ? 'in proportion' : 'each line pulls 1') + ', pull ' + LPULL + '.</span>';
  }
  var LABOPEN = null;
  (function () {
    var h = ''; MKINDS.forEach(function (k) { var id = k[0].replace(/ /g, '_'); h += '<input type="checkbox" data-mk="' + k[0] + '" aria-label="' + k[0] + ' on or off"><span class="sw" style="background:#' + ('000000' + k[1].toString(16)).slice(-6) + '"></span><span title="' + esc(k[2]) + '">' + k[0] + ' <span class="m">' + esc(k[2]) + '</span></span><span class="n" id="mk-' + id + '">0</span>'; });
    $('mkinds').innerHTML = h;
    var opts = Object.keys(EFFS).map(function (k) { return '<option value="' + k + '">' + k + ': ' + EFFS[k][0] + (EFFS[k][1] ? ' / ' + EFFS[k][1] : '') + '</option>'; }).join('');
    ['max', 'may', 'maz'].forEach(function (s, i) { $(s).innerHTML = opts; $(s).value = AXES[i]; $(s).addEventListener('change', function () { AXES[i] = $(s).value; labUpdate(); }); });
    $('tabg').addEventListener('click', function () { $('tabg').setAttribute('aria-selected', 'true'); $('tabm').setAttribute('aria-selected', 'false'); $('panelg').hidden = false; $('panelm').hidden = true; });
    $('tabm').addEventListener('click', function () { $('tabm').setAttribute('aria-selected', 'true'); $('tabg').setAttribute('aria-selected', 'false'); $('panelm').hidden = false; $('panelg').hidden = true; if (!LABREADY) labInit(); });
    $('mview').addEventListener('change', function () { setMView($('mview').checked); });
    $('madd').addEventListener('click', function () { var next = LORDER.filter(function (id) { return eligible(id) && ADDED.indexOf(id) < 0; })[0]; if (next === undefined) return; ADDED.push(next); if (!MVIEW) setMView(true); else labUpdate(); });
    $('mall').addEventListener('click', function () { LORDER.forEach(function (id) { if (eligible(id) && ADDED.indexOf(id) < 0) ADDED.push(id); }); if (!MVIEW) setMView(true); else labUpdate(); });
    $('mback').addEventListener('click', function () { ADDED.pop(); labUpdate(); });
    $('mnone').addEventListener('click', function () { ADDED = []; labUpdate(); });
    $('mnottold').addEventListener('change', function () { ADDED = ADDED.filter(eligible); labUpdate(); });
    $('mkinds').addEventListener('change', function (e) { var k = e.target.getAttribute('data-mk'); if (k) { MKON[k] = e.target.checked; labUpdate(); } });
    $('mrule').addEventListener('change', function () { LRULE = $('mrule').value; $('mpull').disabled = LRULE !== 'share'; labUpdate(); });
    $('mpull').addEventListener('input', function () { LPULL = parseFloat($('mpull').value); $('mpullv').textContent = LPULL.toFixed(2); labUpdate(); });
    $('mfit').addEventListener('click', function () { userZoomed = false; fitLeft = 120; });
    $('mlist').addEventListener('click', function (e) { var d = e.target.closest('[data-l]'); if (!d) return; var v = d.getAttribute('data-l'); showLab(v.indexOf('b:') === 0 ? v : +v); });
    $('mfrom').addEventListener('change', function () { LFROM = $('mfrom').value; if (!MVIEW) setMView(true); else labUpdate(); userZoomed = false; fitLeft = 120; });
    $('tsheet').innerHTML = SHEET.map(function (r, i) { return '<div data-t="' + i + '"><span>' + (i + 1) + '</span><span>' + esc(r[0]) + '</span><span class="m">to the prompt</span></div>'; }).join('');
    $('tsheet').addEventListener('click', function (e) { var d = e.target.closest('[data-t]'); if (!d) return; $('line').value = SHEET[+d.getAttribute('data-t')][1]; $('line').focus(); Array.prototype.forEach.call($('tsheet').children, function (c) { c.classList.toggle('last', c === d); }); });
    $('mtable').addEventListener('click', function () { $('labt').hidden = false; if (!LABREADY) labInit(); labTable(); });
    $('lclose').addEventListener('click', function () { $('labt').hidden = true; });
    $('lfind').addEventListener('input', function () { LABOPEN = null; labTable(); });
    $('ltable').addEventListener('click', function (ev) { var tr = ev.target.closest('tr.arow'); if (!tr) return; var id = +tr.getAttribute('data-l'); LABOPEN = LABOPEN === id ? null : id; labTable(); });
  })();
  var LABHOOK = { state: function () { return { view: MVIEW, ready: LABREADY, busy: LABBUSY, added: ADDED.map(lname), axes: AXES.slice(), rule: LRULE, pull: LPULL, kinds: Object.keys(MKON).filter(function (k) { return MKON[k]; }), solve: LLASTSOLVE, status: LABSTATUS }; },
    brainPlaces: function () { return ask({ type: 'query', sql: 'SELECT word, x, y, z, t, ended FROM place ORDER BY id' }); },
    setFrom: function (v) { $('mfrom').value = v; $('mfrom').dispatchEvent(new Event('change')); },
    places: function () { return ask({ type: 'lab', ops: [['SELECT p.label, pl.x, pl.y, pl.z FROM place pl JOIN point p ON p.id = pl.point ORDER BY p.ord']] }).then(function (r) { return r[0]; }); },
    drawn: function () { var o = {}; Object.keys(labDots).forEach(function (id) { var m = labDots[id]; if (m.visible) o[id === 'origin' ? 'origin' : id.indexOf('b:') === 0 ? id.slice(2) : lname(+id)] = [m.position.x, m.position.y, m.position.z]; }); return o; },
    labels: function () { return Object.keys(labLabels).filter(function (id) { return labLabels[id] && labLabels[id].visible; }).map(function (id) { return labLabels[id].userData.text; }); },
    lineSegs: function () { var n = 0; labLineGroup.children.forEach(function (c) { n += c.geometry.attributes.position.count / 2; }); return n; },
    screenOf: function (label) { var id = label === 'origin' ? 'origin' : LAB.points.filter(function (p) { return p.label === label; })[0].id, m = labDots[id]; if (!m) return null; var v = m.position.clone().project(camera), r = $('c').getBoundingClientRect(); return [r.left + (v.x + 1) / 2 * r.width, r.top + (1 - v.y) / 2 * r.height]; },
    axesLabels: function () { return axesGroup.children.filter(function (c) { return c.type === 'Sprite' && c.userData.text; }).map(function (c) { return c.userData.text; }); } };
