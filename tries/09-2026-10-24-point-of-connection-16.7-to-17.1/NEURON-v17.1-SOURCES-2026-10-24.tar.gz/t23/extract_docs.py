# The SQL docs source: for each word, the first two sentences on its own SQLite doc page that hold the word as a token.
# Text is read only from <p>, <li>, <dd> and <td> blocks (not syntax pictures, not code blocks). The page each word is read
# from is fixed below (my choice, printed with every line). usage: extract_docs.py <docs-raw dir> <out.json>
import html.parser, json, re, sys
RAW = sys.argv[1]
PAGE = {}
for w in ['SELECT', 'FROM', 'WHERE', 'ORDER', 'BY', 'DESC', 'LIMIT', 'EXCEPT']: PAGE[w] = 'lang_select'
for w in ['INSERT', 'INTO', 'VALUES']: PAGE[w] = 'lang_insert'
for w in ['UPDATE', 'SET']: PAGE[w] = 'lang_update'
PAGE['DELETE'] = 'lang_delete'
for w in ['CREATE', 'TABLE']: PAGE[w] = 'lang_createtable'
PAGE['INTEGER'] = 'datatype3'; PAGE['DROP'] = 'lang_droptable'
for w in ['AND', 'OR', 'NOT', 'IN', 'LIKE', 'EXISTS', 'NULL', 'CAST', 'IS', '=', '<', '>', '<>', '!=', '<=', '>=', '||', '*', '+', '-', '/']: PAGE[w] = 'lang_expr'
for w in ['WITH', 'AS']: PAGE[w] = 'lang_with'
for w in ['instr', 'substr']: PAGE[w] = 'lang_corefunc'
for w in ['count', 'max', 'group_concat']: PAGE[w] = 'lang_aggfunc'
NONE = ['(', ')', ',', ';']   # punctuation: no page defines it as a word

class Text(html.parser.HTMLParser):
    # flat blocks: every start or end of p, li, dd or td closes the block being read (the docs leave some of these open)
    KEEP = {'p', 'li', 'dd', 'td'}; SKIP = {'script', 'style', 'svg', 'pre', 'code'}
    def __init__(self): super().__init__(); self.out = []; self.cur = None; self.skip = 0
    def flush(self):
        if self.cur is not None:
            s = re.sub(r'\s+', ' ', ''.join(self.cur)).strip()
            if s: self.out.append(s)
        self.cur = None
    def handle_starttag(self, t, a):
        if t in self.SKIP: self.skip += 1
        elif t in self.KEEP: self.flush(); self.cur = []
    def handle_endtag(self, t):
        if t in self.SKIP: self.skip = max(0, self.skip - 1)
        elif t in self.KEEP: self.flush()
    def handle_data(self, d):
        if self.cur is not None and not self.skip: self.cur.append(d)
def sentences(page):
    p = Text(); p.feed(open(f'{RAW}/{page}.html', encoding='utf-8', errors='replace').read())
    out = []
    for block in p.out:
        for s in re.split(r'(?<=[.!?])\s+(?=[A-Z"(])', block):
            s = s.strip()
            if 25 <= len(s) <= 400 and not s.startswith('|'): out.append(s)
    return out
# filters (added after the first run picked page headers, contents entries and the operator table): a line is kept only if it is
# a sentence: not navigation or a contents entry, not ending in a section number, not a syntax fragment, at least 6 words of
# which 60% are plain words; for a symbol word, the line must also say operator, equals or not-equal.
def sentence(s):
    if re.search(r'Table Of Contents|Purchase Search|Changelog', s): return False
    if re.search(r'\d+(\.\d+)*\.?$', s.replace(' (sqlite.org', '')): return False
    if re.search(r'\[expr\]|\(\.\.\.\)|;\s*$|^\w+\([A-Z,]*\)\w', s): return False
    toks = s.split(); alpha = [t for t in toks if re.fullmatch(r'[A-Za-z][A-Za-z\-\'",.:;()]*', t)]
    return len(toks) >= 6 and len(alpha) >= .6 * len(toks)
def has(word, s):
    if not sentence(s): return False
    if not re.fullmatch(r'[A-Za-z_]+', word) and not re.search(r'operator|[Ee]quals|not-equal', s): return False
    if re.fullmatch(r'[A-Za-z_]+', word): return re.search(r'(?<![A-Za-z_])' + re.escape(word) + r'(?![A-Za-z_])', s) is not None
    return re.search(r'(?:^|[\s"(\'])' + re.escape(word) + r'(?:$|[\s")\',.])', s) is not None
def words(s):
    s = re.sub(r'\([^)]*\)', ' ', s).lower()
    return ' '.join(t for t in re.findall(r'[a-z]+', s))
cache, rows, table = {}, [], []
for w, page in PAGE.items():
    sents = cache.setdefault(page, sentences(page))
    got = [s for s in sents if has(w, s)][:2]
    for s in got: rows.append([w, w, s + ' (sqlite.org/' + page + '.html)', words(s)])
    table.append([w, page, len(got)])
for w in NONE: table.append([w, '-', 0])
json.dump({'rows': rows, 'table': table}, open(sys.argv[2], 'w'), indent=1)
print(len(rows), 'lines for', sum(1 for t in table if t[2]), 'of', len(table), 'words; none for:', [t[0] for t in table if not t[2]])
haz = [(r[0], t) for r in rows for t in ('define', 'place', 'source') if t in r[3].split()]
print('lines holding a word that will have a formula (define, place, source):', haz)
