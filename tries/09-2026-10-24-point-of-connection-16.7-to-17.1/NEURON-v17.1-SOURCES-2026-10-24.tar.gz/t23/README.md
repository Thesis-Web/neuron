# Step 2 sources (2026-10-24, turn 23): what each told word does to the silicon

Files:
- EXPECT23.md: plan and predictions, frozen at 19:06 before any run (sha256 0d4136a0c60f...).
- RESULTS23.md: results, written by report23.py from the measurement files.
- pairs23.py -> pairs23.json: the test lines (with / without each word) and controls.
- run_a.py (Python SQLite) and run_a.js (the page's sql.js): EXPLAIN + run each line -> a_py.json, a_js.json.
- diff_a.py: with-minus-without diffs, controls, build comparison -> a_diff.json.
- run_b.py: SQLite authorizer on every told trigger -> b.json; with one trigger removed (control) -> b_ctl.json.
- run_b2.py: the source teaching line in a bare brain with the real host; what mother is handed; hop triggers -> b2.json.
- run_b3.js: each trigger's own bytecode in the page's SQLite, brain work vs log -> b3.json.
- report23.py: writes RESULTS23.md.
- draft/: the reference draft rebuilt from the session that wrote it (original.md), today's (current.md); `diff original.md current.md`.
- turn16/OWNER-VERBATIM.txt: the owner's words, messages 1-30, plus the owner's two edits to the draft. GROUNDING.md.

Rerun (needs NEURON-v16.4-SOURCES-2026-10-23.tar.gz extracted to X, for physics16.json, host15.py and sql.js):
    python3 -I pairs23.py pairs23.json
    python3 -I run_a.py pairs23.json a_py.json
    node run_a.js X/sqljs/sql-asm-memory-growth.js pairs23.json a_js.json
    python3 -I diff_a.py pairs23.json a_js.json a_py.json a_diff.json
    python3 -I run_b.py X/v16/physics16.json b.json
    python3 -I run_b.py X/v16/physics16.json b_ctl.json agree_go
    python3 -I run_b2.py X/v16 X/v16/physics16.json b2.json
    node run_b3.js X/sqljs/sql-asm-memory-growth.js X/v16/physics16.json b3.json
    python3 -I report23.py .
Nothing here writes outside this folder. Nothing touches ~/neuron/v1.

## Step 3 and Point Of Connection 17 (added later the same day)
- EXPECT-REL.md: predictions, frozen at 20:02 (sha256 111bd3a7a5fb...). RESULTS-REL.md: results.
- rel.js: each point's measured numbers and every line kind, as tests, in the page's SQLite -> lab.json.
    node rel.js X/sqljs/sql-asm-memory-growth.js pairs23.json lab.json
- lab17.js: the placement rule (shared by the page and the node check). expect17.js -> expect17.json: places the page must read back.
- lab-ui17.js: the measured tab's code. make17.py: builds 17 from 16.4's sources (exact, checked replacements; nothing removed).
    python3 -I make17.py X .        (X = NEURON-v16.4-SOURCES-2026-10-23.tar.gz extracted; writes X/v17/point-of-connection-17.html)
- shot17.js: the browser check (shot17.out.json is its last run). wide17.js: what overflows at phone width.
- v17-patched/: the four 16.4 files after make17.py's changes, to diff against 16.4's.
- undo.py, EXPECT-UNDO.md, RESULTS-UNDO.md: the undo test.

## 17.1: the teaching process (same day)
- check_measure.js: 16.4's "measure a word" against a told block with WRITE renamed WRITX in its log text (its "silicon" follows the label).
- extract_docs.py -> sqldoc_new.json: the SQL docs source by one stated rule, from docs-raw/ (sqlite.org pages fetched 2026-10-24).
- gen_physics17.py -> physics17.json (TOLD-BLOCK-17.1.sql): 16.4's told block + the place table and trigger + the measured source.
- sat17.json: the sources, with the SQL docs source rebuilt and the measured source added. sheet17.json: the teaching sheet (88 lines).
- teach_run.js: types lines into the page's real brain code in node. teach17.json: the full sheet's run. ctlA/B/C: the controls.
- lab-ui171.js, make171.py: page 17.1 (python3 -I make171.py X . ; writes X/v171/point-of-connection-17.1.html). shot171.js: browser check.
- kernel_log.py -> KERNEL-LONG-FORM.md: each SQL word's program in SQLite, every step in SQLite's own words.
- EXPECT-TEACH.md (frozen 21:15), RESULTS-TEACH.md, homework.json (the words the definitions use).
