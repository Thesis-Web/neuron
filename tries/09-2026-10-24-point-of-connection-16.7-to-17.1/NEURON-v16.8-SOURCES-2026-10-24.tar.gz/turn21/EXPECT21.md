# Turn 21 predictions, written before the calibration runs (2026-10-24)
Diagnosis measured first (origin's pulls; action words vs their own lines) - see turn21 log.
Fixes tested, each for a measured cause:
- F1 strength: a pull counts only above the word's own average over the pulls in use (relative strength, clipped at 0).
- F2 order: no unpaired line (CLOCK and COMPARE, whose opposite lines are empty, are left out).
Predictions: F1 brings origin within 1.5 of 0,0,0 (from 5.3) and the action words' median angle under 40 degrees (from 58);
F1+F2 brings origin under 1.0. The sampled score gets worse by less than 0.03, or better. Your share-mark formula with F1 beats it without F1.
