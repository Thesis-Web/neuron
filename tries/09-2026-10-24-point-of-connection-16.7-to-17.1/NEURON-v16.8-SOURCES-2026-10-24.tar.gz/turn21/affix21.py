# turn 21: what each prefix/suffix does, measured from the owner's map (never assigned):
#   for every word w with an affix line (w -> affix) and a stem line (w -> stem): class of stem -> class of w,
#   and the other lines between w and its stem (past, singular, opposite, alike, is)
# usage: python3 -I affix21.py <turn18 out> <out json>
import sys, os, json, collections
sys.path.append(os.path.expanduser('~/.local/lib/python3.10/site-packages'))
import numpy as np
src, outp = sys.argv[1], sys.argv[2]
d = json.load(open(os.path.join(src, 'data18.json'))); W = d['words']; cn = d['clsNames']
z = np.load(os.path.join(src, 'data18.npz')); cls = z['cls']
lines = d['lines']
aff = collections.defaultdict(list); stem = collections.defaultdict(set); rel = collections.defaultdict(set)
for a, b, kn, spl in lines:
    if kn in ('suffix', 'prefix'): aff[(kn, W[b])].append(a)
    if kn == 'stem': stem[a].add(b)
    rel[(a, b)].add(kn); rel[(b, a)].add(kn + '<')
OWNER = ['ly', 'ing', 'tion', 'sion', 'ed', 'ful', 'less', 'able', 'ible', 'or', 'un', 're', 'mis', 'pre', 'per', 'dis', 'pro', "'s", "s'", 'be', 'con', 'com', 'ex', 'in', 'im', 'sub', 'trans']
C = lambda i: cn[cls[i]] if cls[i] >= 0 else '?'
res = {}
for (kn, a), ws in sorted(aff.items(), key=lambda x: -len(x[1])):
    ch = collections.Counter(); rl = collections.Counter(); n = 0; ex = []
    for w in ws:
        for s in stem.get(w, ()):
            n += 1; ch[C(s) + ' → ' + C(w)] += 1
            for r in rel[(w, s)] - {'stem'}: rl[r] += 1
            if len(ex) < 6: ex.append(W[s] + ' → ' + W[w])
    res[kn + ':' + a] = {'words': len(ws), 'with_stem': n, 'class_change': ch.most_common(4), 'other_lines': rl.most_common(4), 'examples': ex}
json.dump(res, open(outp, 'w'))
for a in OWNER:
    hit = [k for k in res if k.split(':', 1)[1] == a]
    if not hit: print(f'{a:6s} not an affix in your map'); continue
    for k in hit:
        r = res[k]; tot = r['with_stem'] or 1
        print(f"{k:12s} words {r['words']:4d} with stem {r['with_stem']:4d} | " + ', '.join(f'{c} {v*100//tot}%' for c, v in r['class_change'][:3]) + ' | other lines: ' + (', '.join(f'{c} {v}' for c, v in r['other_lines'][:3]) or '-') + ' | e.g. ' + '; '.join(r['examples'][:3]))
print('affixes in your map not in the list above:', [k for k in res if k.split(':', 1)[1] not in OWNER][:30])
