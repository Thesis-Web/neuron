# turn 21: the fixed layout (no unpaired lines; beginning / end where CLOCK was; only above-average strength), held-out test
# for both formulas, and the page data (pulls168.json = pulls167.json + the two new pulls + the new start)
# usage: python3 -I fixed21.py <scratchpad>
import sys, os, json, base64
S = sys.argv[1]
sys.path.insert(0, os.path.join(S, 'turn18'))
from lib18 import *
import multiprocessing as mp
j, z, L, WN = load(S + '/turn18/out'); W = j['words']; n = len(W); wi = {w: i for i, w in enumerate(W)}
PZ = np.load(S + '/turn20/out/pool20.npz'); PB, PS = PZ['build'], PZ['shown']; NM = json.load(open(S + '/turn20/out/pool20.json'))['name']
SP = json.load(open(S + '/turn20/out/search20_P.json')); SL = SP['slots']; A0 = SP['assign']; U = np.array([np.array(v, float) / np.linalg.norm(v) for _, _, v in SL])
OW = 'action situation context perspective mood class tense plural singular modifier memory time state before after topic source correct incorrect read write compare add subtract move find split join clock hear say call spawn'.split()
def close(Lx, words):
    A = build_graph(n, {(k, 'b'): v for k, v in Lx.items()}, split='b')
    old = {w: ppr(A, [wi[w]]) for w in OW if w in wi}; fl = np.percentile(np.concatenate([v[v > 0] for v in old.values()]), 1)
    out = {}
    for w in words:
        v = ppr(A, [wi[w]]); s = np.where(v > 0, np.log10(np.maximum(v, fl) / fl), 0); out[w] = s / s.max()
    return out
Lb = {kn: L[(kn, 'train')] for kn in KINDS}; La = {kn: np.vstack([L[(kn, s)] for s in ('train', 'val', 'test') if (kn, s) in L]) for kn in KINDS}
cb = close(Lb, ['beginning', 'end']); ca = close(La, ['beginning', 'end'])
PB2 = np.vstack([PB, cb['beginning'], cb['end']]); PS2 = np.vstack([PS, ca['beginning'], ca['end']])
kb, ke = len(NM), len(NM) + 1
clock = [s for s, k in enumerate(A0) if k >= 0 and NM[k] == 'CLOCK'][0]
anti = [t for t in range(30) if SL[t][0] != 'quad' and np.allclose(U[t], -U[clock])][0]
a3 = [k if (k < 0 or NM[k] not in ('CLOCK', 'COMPARE')) else -1 for k in A0]; a3[clock] = kb; a3[anti] = ke
def place(a, pool, marks):
    idx = [(s, k) for s, k in enumerate(a) if k >= 0]; M = np.array([pool[k] for s, k in idx]); M = np.clip(M - M.mean(0), 0, None)
    Us = U[[s for s, k in idx]]
    if marks: t = M.sum(0); t[t == 0] = 1; sh = M / t; return (sh ** 2).T @ Us
    return M.T @ Us
def norm(P): r = np.linalg.norm(P, axis=1); return P / np.median(r[r > 0])
def job(args):
    marks, what = args; P = norm(place(a3, PB2, marks))
    if what == 'map': return args, score_graph(P, L, maxlines=2000)
    return args, score_graph(P[np.random.default_rng(7).permutation(n)], L, maxlines=2000)
with mp.Pool(4) as pp: R = dict(pp.map(job, [(False, 'map'), (False, 'shuffled'), (True, 'map'), (True, 'shuffled')]))
out = {}
for marks in (False, True):
    r, sh = R[(marks, 'map')], R[(marks, 'shuffled')]
    mean = float(np.mean([v['test'][v['best']]['median'] for v in r.values()]))
    pts = [k for k in KINDS if r[k]['test'][r[k]['best']]['median'] < 0.25 and r[k]['test'][r[k]['best']]['hit10'] >= 0.003 and sh[k]['test'][sh[k]['best']]['median'] >= 0.45]
    out['marks' if marks else 'sum'] = {'mean': mean, 'pts': pts, 'test': {k: {'best': v['best'], 'median': v['test'][v['best']]['median'], 'hit10': v['test'][v['best']]['hit10'], 'shuffled': sh[k]['test'][sh[k]['best']]['median']} for k, v in r.items()}}
    print('fixed layout', 'share marks' if marks else 'sum', 'held-out mean', round(mean, 4), 'points out', pts, flush=True)
json.dump(out, open(S + '/turn21/out/fixed21.json', 'w'))
E = json.load(open(S + '/turn20/poc/pulls167.json'))
q = np.where(PS2[[kb, ke]] > 0, np.maximum(1, np.round(PS2[[kb, ke]] * 255)), 0).astype(np.uint8)
S0 = np.frombuffer(base64.b64decode(E['shown']), np.uint8)
E['shown'] = base64.b64encode(np.concatenate([S0, q.ravel()]).tobytes()).decode()
E['name'] += ["close to 'beginning'", "close to 'end'"]; E['group'] += ['opposite partners from your map', 'opposite partners from your map']
E['how'] += ['how close the word sits to "beginning" through your map\'s lines', 'how close the word sits to "end" through your map\'s lines']
E['pairs'] = E['pairs'] + [["close to 'beginning'", "close to 'end'", "your map: origin is alike beginning, opposite end"]]
E['presets'] = [{'key': 'F', 'title': 'Your pairs, balanced: beginning / end, no unpaired line', 'assign': a3, 'mean': out['marks']['mean'], 'mean_sum': out['sum']['mean'], 'pts': out['marks']['pts'], 'test': out['marks']['test'], 'rel': True, 'mode': 'marks'}] + E['presets']
json.dump(E, open(S + '/turn20/poc/pulls168.json', 'w'))
print('pulls168.json written')
