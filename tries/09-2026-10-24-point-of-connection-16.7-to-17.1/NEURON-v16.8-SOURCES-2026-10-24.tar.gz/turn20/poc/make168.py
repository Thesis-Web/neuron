# turn 21: Point Of Connection 16.8 = 16.7 (itself 16.4 + pulls) plus: a strength switch (as measured / above the word's own average),
# the balanced start (beginning / end, no unpaired line), a bare-core button, and the turn-21 notes. Every anchor must occur once.
# usage: python3 -I make168.py <poc dir>
import sys, os, shutil
P = sys.argv[1]
src, dst = os.path.join(P, 'v167'), os.path.join(P, 'v168')
if os.path.exists(dst): shutil.rmtree(dst)
shutil.copytree(src, dst, ignore=shutil.ignore_patterns('point-of-connection-*.html', 'poc16-main.js'))
rd = lambda f: open(os.path.join(dst, f), encoding='utf-8').read()
def patch(text, pairs, name):
    for a, b in pairs:
        assert text.count(a) == 1, (name, a[:90], text.count(a))
        text = text.replace(a, b)
    return text

main = rd('main16.js')
main = patch(main, [
 ("  var LAYOUT = PL ? 'pulls' : 'springs', PMODE = 'sum', PUNIT = 10;",
  "  var LAYOUT = PL ? 'pulls' : 'springs', PMODE = PL && PULLS.presets[0].mode === 'marks' ? 'marks' : 'sum', PREL = !!(PL && PULLS.presets[0].rel), PUNIT = 10;\n"
  "  // PREL (16.8): a pull counts only by how much it is above the word's own average pull over the pulls in use, so a word pulled\n"
  "  // equally by everything stays in the middle and each word's shares differ (turn 21: the action words land near their own lines)"),
 ("  function pullVec(i) { var x = 0, y = 0, z = 0, any = false, tot = 0;\n    if (PMODE === 'marks') { for (var s0 = 0; s0 < PL.U.length; s0++) { var k0 = PL.assign[s0]; if (k0 >= 0) tot += PL.S[k0 * PL.N + i]; } if (!tot) return null; }\n    for (var s = 0; s < PL.U.length; s++) { var k = PL.assign[s]; if (k < 0) continue; var v = PL.S[k * PL.N + i]; if (!v) continue; any = true; v = PMODE === 'marks' ? (v / tot) * (v / tot) * PUNIT : v / 255 * PUNIT; x += v * PL.U[s][0]; y += v * PL.U[s][1]; z += v * PL.U[s][2]; } return any ? new THREE.Vector3(x, y, z) : null; }",
  "  function strengthsOf(i) { var o = [], tot = 0; for (var s = 0; s < PL.U.length; s++) { var k = PL.assign[s]; if (k < 0) continue; var v = PL.S[k * PL.N + i] / 255; o.push({ s: s, k: k, v: v }); tot += v; }\n"
  "    if (PREL && o.length) { var m = tot / o.length; o.forEach(function (x) { x.v = Math.max(0, x.v - m); }); }\n"
  "    return o.filter(function (x) { return x.v > 0; }); }\n"
  "  function pullVec(i) { var o = strengthsOf(i); if (!o.length) return null; var tot = o.reduce(function (a, b) { return a + b.v; }, 0), x = 0, y = 0, z = 0;\n"
  "    o.forEach(function (p) { var v = PMODE === 'marks' ? (p.v / tot) * (p.v / tot) * PUNIT : p.v * PUNIT; x += v * PL.U[p.s][0]; y += v * PL.U[p.s][1]; z += v * PL.U[p.s][2]; });\n"
  "    return new THREE.Vector3(x, y, z); }"),
 ("  function pullsOf(i) { var o = []; for (var s = 0; s < PL.U.length; s++) { var k = PL.assign[s]; if (k < 0) continue; var v = PL.S[k * PL.N + i] / 255; if (v > 0) o.push({ s: s, k: k, v: v }); } return o; }",
  "  function pullsOf(i) { return strengthsOf(i); }"),
 ("    h += '<span class=\"m\">' + PL.DEG[i] + ' line' + (PL.DEG[i] === 1 ? '' : 's') + ' in your map. Share = this pull\\'s strength / the sum of its strengths over the pulls in use.</span>';",
  "    h += '<span class=\"m\">' + PL.DEG[i] + ' line' + (PL.DEG[i] === 1 ? '' : 's') + ' in your map. Share = this pull\\'s strength / the sum of its strengths over the pulls in use' + (PREL ? ', counting only the part of each pull above the word\\'s own average' : '') + '.</span>';"),
 ("    $('pstatus').innerHTML = '<div class=\"kv\"><span>held-out test of this start</span><b>' + (same ? p.mean.toFixed(3) + ' (0 best, 0.5 chance)' : 'changed: not tested') + '</b></div>' +",
  "    $('pstatus').innerHTML = '<div class=\"kv\"><span>held-out test of this start</span><b>' + (same ? p.mean.toFixed(3) + (p.mean_sum !== undefined ? ' with your way, ' + p.mean_sum.toFixed(3) + ' with the sum' : '') + ' (0 best, 0.5 chance)' : 'changed: not tested') + '</b></div>' +"),
 ("    $('pstart').addEventListener('change', function () { PL.cur = +$('pstart').value; PL.assign = PULLS.presets[PL.cur].assign.slice(); pullSyncSlots(); pullRelayout(); userZoomed = false; fitLeft = 120; });",
  "    $('pstart').addEventListener('change', function () { PL.cur = +$('pstart').value; var pp = PULLS.presets[PL.cur]; PL.assign = pp.assign.slice(); PREL = !!pp.rel; $('pstrength').value = PREL ? 'rel' : 'raw'; if (LAYOUT === 'pulls') { PMODE = pp.mode === 'marks' ? 'marks' : 'sum'; $('layout').value = PMODE === 'marks' ? 'marks' : 'pulls'; } pullSyncSlots(); pullRelayout(); userZoomed = false; fitLeft = 120; });\n"
  "    $('pstrength').addEventListener('change', function () { PREL = $('pstrength').value === 'rel'; pullRelayout(); });\n"
  "    $('pstrength').value = PREL ? 'rel' : 'raw'; $('layout').value = PMODE === 'marks' ? 'marks' : 'pulls';\n"
  "    // bare core (owner, 10-24): only what the brain holds; every word of your map hidden, its lines too\n"
  "    var bare = false; $('barecore').addEventListener('click', function () { bare = !bare; ['mapall', 'bgmap', 'pmap'].forEach(function (id) { $(id).checked = !bare; }); $('barecore').setAttribute('aria-pressed', String(bare)); $('barecore').textContent = bare ? 'show your map\\'s words again' : 'bare core: only what the brain holds'; if (pullMapPts) pullMapPts.visible = LAYOUT === 'pulls' && $('pmap').checked; render(T, true); reshape(); userZoomed = false; fitLeft = 120; });"),
 ("    pulls: function () { return { layout: LAYOUT,", "    pulls: function () { return { prel: PREL, pmode: PMODE, layout: LAYOUT,"),
 ("    setLayout: function (v) {", "    bare: function () { $('barecore').click(); return $('barecore').getAttribute('aria-pressed'); },\n    setLayout: function (v) {"),
], 'main')
open(os.path.join(dst, 'main16.js'), 'w', encoding='utf-8').write(main)

body = rd('body16.html')
body = patch(body, [
 ('      <div class="row"><label for="pstart" class="note">start from</label>',
  '      <div class="row"><button id="barecore" type="button" aria-pressed="false">bare core: only what the brain holds</button></div>\n'
  '      <div class="row"><label for="pstrength" class="note">strength</label><select id="pstrength"><option value="rel" selected>only the part above the word\'s own average</option><option value="raw">as measured</option></select></div>\n'
  '      <div class="row"><label for="pstart" class="note">start from</label>'),
], 'body')
open(os.path.join(dst, 'body16.html'), 'w', encoding='utf-8').write(body)

prose = rd('prose16.html')
open(os.path.join(dst, 'prose16.html'), 'w', encoding='utf-8').write(open(os.path.join(P, 'prose168.html'), encoding='utf-8').read() + prose)

b = rd('build16.py')
b = patch(b, [
 ("LINKS = {'16.7': [", "LINKS = {'16.8': [('16.7', '14L3pxNSuJ81ZzBiLEvSgD'), ('16.6 Thirty Pulls', '4Lfoq3EkHJ4wCRW4dr4uuk'), ('16.5 Six Pulls', 'Ab1Xhb1VsJ3tXRVA4VKDHi'), ('16.4', 'Sq4JLW46oPHRfVtH52qJn6')], '16.7': ["),
 ("('/*PULLS*/null', rd(R + '/pulls167.json'))", "('/*PULLS*/null', rd(R + '/pulls168.json'))"),
], 'build')
open(os.path.join(dst, 'build16.py'), 'w', encoding='utf-8').write(b)
print('v168 written')
