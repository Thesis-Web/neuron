# turn 22: Point Of Connection 16.9 = 16.8 plus a closeness switch: through every line (16.8), or opposite lines flip the side
# (the new default: what arrives across an odd number of opposite lines pulls toward the opposite line), and the re-ordered start.
# usage: python3 -I make169.py <poc dir>
import sys, os, shutil
P = sys.argv[1]
src, dst = os.path.join(P, 'v168'), os.path.join(P, 'v169')
if os.path.exists(dst): shutil.rmtree(dst)
shutil.copytree(src, dst, ignore=shutil.ignore_patterns('point-of-connection-*.html', 'poc16-main.js'))
rd = lambda f: open(os.path.join(dst, f), encoding='utf-8').read()
def patch(text, pairs, name):
    for a, b in pairs:
        assert text.count(a) == 1, (name, a[:90], text.count(a))
        text = text.replace(a, b)
    return text
main = rd('main16.js')
main = patch(main, [
 ("  function strengthsOf(i) { var o = [], tot = 0; for (var s = 0; s < PL.U.length; s++) { var k = PL.assign[s]; if (k < 0) continue; var v = PL.S[k * PL.N + i] / 255; o.push({ s: s, k: k, v: v }); tot += v; }",
  "  // CLOSE (16.9, turn 22): 'all' = closeness spreads through every line (16.8: a word came out close to its own opposite, whose line cancelled its pull);\n"
  "  // 'two' = closeness spreads through every line, and each opposite line crossed flips the side: what arrives flipped pulls toward the opposite line\n"
  "  var CLOSE = PL && PULLS.presets[0].close === 'two' ? 'two' : 'all', TWO = null;\n"
  "  if (PL && PULLS.two) TWO = (function () { function b64(s) { var x = atob(s), u = new Uint8Array(x.length); for (var i = 0; i < x.length; i++) u[i] = x.charCodeAt(i); return u; } var idx = {}; PULLS.two.words.forEach(function (w, j) { idx[w] = j; }); return { idx: idx, same: b64(PULLS.two.same), flip: b64(PULLS.two.flip) }; })();\n"
  "  function wordOf(nm) { if (/[A-Z]/.test(nm) && nm === nm.toUpperCase()) return nm.toLowerCase(); var m = /^close to '(.*)'$/.exec(nm); return m ? m[1] : null; }\n"
  "  function strengthsOf(i) { var o = [], tot = 0; for (var s = 0; s < PL.U.length; s++) { var k = PL.assign[s]; if (k < 0) continue;\n"
  "      var w = CLOSE === 'two' && TWO ? wordOf(PULLS.name[k]) : null, jj = w !== null ? TWO.idx[w] : undefined;\n"
  "      if (jj !== undefined) { var va = TWO.same[jj * PL.N + i] / 255, vb = TWO.flip[jj * PL.N + i] / 255; o.push({ s: s, k: k, v: va, sg: 1 }); o.push({ s: s, k: k, v: vb, sg: -1 }); tot += va + vb; continue; }\n"
  "      var v = PL.S[k * PL.N + i] / 255; o.push({ s: s, k: k, v: v, sg: 1 }); tot += v; }"),
 ("    o.forEach(function (p) { var v = PMODE === 'marks' ? (p.v / tot) * (p.v / tot) * PUNIT : p.v * PUNIT; x += v * PL.U[p.s][0]; y += v * PL.U[p.s][1]; z += v * PL.U[p.s][2]; });",
  "    o.forEach(function (p) { var v = (PMODE === 'marks' ? (p.v / tot) * (p.v / tot) * PUNIT : p.v * PUNIT) * (p.sg || 1); x += v * PL.U[p.s][0]; y += v * PL.U[p.s][1]; z += v * PL.U[p.s][2]; });"),
 ("return (x.v / tot * 100).toFixed(0) + '% ' + esc(PULLS.name[x.k]); }).join(' + ')",
  "return (x.v / tot * 100).toFixed(0) + '% ' + esc(PULLS.name[x.k]) + (x.sg < 0 ? ' (flipped)' : ''); }).join(' + ')"),
 ("return '<tr><td>' + esc(PULLS.name[x.k]) + '</td><td><span class=\"pdir\" style=\"--c:' + PL.col[x.s] + '\">' + esc(PULLS.slots[x.s][1].replace(/-/g, '−')) + '</span></td>",
  "return '<tr><td>' + esc(PULLS.name[x.k]) + (x.sg < 0 ? ' <span class=\"m\">flipped: reached across an opposite line</span>' : '') + '</td><td><span class=\"pdir\" style=\"--c:' + PL.col[x.s] + '\">' + (x.sg < 0 ? 'opposite of ' : '') + esc(PULLS.slots[x.s][1].replace(/-/g, '−')) + '</span></td>"),
 ("PREL = !!pp.rel; $('pstrength').value = PREL ? 'rel' : 'raw';",
  "PREL = !!pp.rel; $('pstrength').value = PREL ? 'rel' : 'raw'; CLOSE = pp.close === 'two' ? 'two' : 'all'; $('pclose').value = CLOSE;"),
 ("    $('pstrength').addEventListener('change', function () { PREL = $('pstrength').value === 'rel'; pullRelayout(); });",
  "    $('pstrength').addEventListener('change', function () { PREL = $('pstrength').value === 'rel'; pullRelayout(); });\n"
  "    $('pclose').addEventListener('change', function () { CLOSE = $('pclose').value; pullRelayout(); }); $('pclose').value = CLOSE;"),
 ("    pulls: function () { return { prel: PREL,", "    pulls: function () { return { close: CLOSE, prel: PREL,"),
], 'main')
open(os.path.join(dst, 'main16.js'), 'w', encoding='utf-8').write(main)
body = rd('body16.html')
body = patch(body, [
 ('      <div class="row"><label for="pstrength" class="note">strength</label>',
  '      <div class="row"><label for="pclose" class="note">closeness</label><select id="pclose"><option value="two" selected>opposite lines flip the side (16.9)</option><option value="all">through every line (16.8)</option></select></div>\n'
  '      <div class="row"><label for="pstrength" class="note">strength</label>'),
], 'body')
open(os.path.join(dst, 'body16.html'), 'w', encoding='utf-8').write(body)
prose = rd('prose16.html')
open(os.path.join(dst, 'prose16.html'), 'w', encoding='utf-8').write(open(os.path.join(P, 'prose169.html'), encoding='utf-8').read() + prose)
b = rd('build16.py')
b = patch(b, [
 ("LINKS = {'16.8': [", "LINKS = {'16.9': [('16.8', 'YK3kx7RPaMjdhWpjXqiDgg'), ('16.7', '14L3pxNSuJ81ZzBiLEvSgD'), ('16.6 Thirty Pulls', '4Lfoq3EkHJ4wCRW4dr4uuk'), ('16.4', 'Sq4JLW46oPHRfVtH52qJn6')], '16.8': ["),
 ("('/*PULLS*/null', rd(R + '/pulls168.json'))", "('/*PULLS*/null', rd(R + '/pulls169.json'))"),
], 'build')
open(os.path.join(dst, 'build16.py'), 'w', encoding='utf-8').write(b)
print('v169 written')
