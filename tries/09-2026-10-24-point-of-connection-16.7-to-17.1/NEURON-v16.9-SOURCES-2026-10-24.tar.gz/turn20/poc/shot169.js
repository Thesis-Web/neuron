// 16.9 check: the 16.4 parts still work (prompt, premade run), the pull layout places points, the switches work
// usage: node shot167.js <html> <shot prefix> <expected.json>
const { chromium } = require('/home/exnulla/boxstead/node_modules/playwright-core');
const fs = require('fs');
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const errs = [], R = {}, X = JSON.parse(fs.readFileSync(process.argv[4], 'utf8'));
  const open = async (opts) => { const page = await browser.newPage(opts); page.on('pageerror', e => errs.push(e.message)); page.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text()); });
    await page.route('**/*', r => { const u = r.request().url(); return u.startsWith('file:') || u.startsWith('blob:') || u.startsWith('data:') || u.includes('cdnjs.cloudflare.com') || u.includes('fonts.g') ? r.continue() : r.abort(); });
    await page.goto('file://' + process.argv[2]); await page.waitForFunction(() => window.__poc && window.__poc.ready(), null, { timeout: 180000 }); return page; };
  const page = await open({ viewport: { width: 1600, height: 950 } });
  await page.waitForTimeout(3000);
  R.pulls = await page.evaluate(() => window.__poc.pulls());
  R.presetButtons = await page.evaluate(() => document.querySelectorAll('#presets button').length);
  R.promptThere = await page.evaluate(() => !!document.getElementById('line') && !!document.getElementById('run'));
  let md = 0; for (const [w, p] of X.pos) { const q = await page.evaluate(w => window.__poc.pullPos(w), w); if (!q) { md = 999; continue; } md = Math.max(md, Math.hypot(q[0] - p[0], q[1] - p[1], q[2] - p[2])); } R.pullPosMaxDiff = md;
  R.nodeMove = await page.evaluate(() => window.__poc.nodePos('MOVE')); R.pullMove = await page.evaluate(() => window.__poc.pullPos('move'));
  await page.screenshot({ path: process.argv[3] + '-load.png' });
  // a premade run, through the prompt's own button row
  const ev0 = await page.evaluate(() => window.__poc.events());
  await page.evaluate(() => { const b = [...document.querySelectorAll('#presets button')].find(x => x.textContent.startsWith('the same line twice')); b.click(); });
  await page.waitForFunction(() => !window.__poc.busy(), null, { timeout: 240000 }); await page.waitForTimeout(2000);
  R.eventsBeforeAfter = [ev0, await page.evaluate(() => window.__poc.events())]; R.lastOutput = await page.evaluate(() => window.__poc.lastOutput());
  R.afterRun = await page.evaluate(() => window.__poc.pulls());
  // typed line through the prompt
  await page.fill('#line', 'dog ran'); await page.click('#run');
  await page.waitForFunction(() => !window.__poc.busy(), null, { timeout: 240000 }); await page.waitForTimeout(1500);
  R.afterTyped = await page.evaluate(() => window.__poc.events());
  R.card = await page.evaluate(() => window.__poc.card('cat')); R.card = R.card.slice(0, 600);
  await page.screenshot({ path: process.argv[3] + '-run.png' });
  R.bare = await page.evaluate(() => window.__poc.bare()); await page.waitForTimeout(1500); R.bareStat = await page.evaluate(() => window.__poc.pulls()); await page.screenshot({ path: process.argv[3] + '-bare.png' });
  await page.evaluate(() => window.__poc.bare()); await page.waitForTimeout(800);
  R.setSlot = await page.evaluate(() => window.__poc.setSlot(0, -1)); await page.waitForTimeout(800);
  R.afterSlot = await page.evaluate(() => window.__poc.pulls().stat);
  R.marks = await page.evaluate(() => window.__poc.setLayout('marks')); await page.waitForTimeout(1500); await page.screenshot({ path: process.argv[3] + '-marks.png' });
  R.springs = await page.evaluate(() => window.__poc.setLayout('springs')); await page.waitForTimeout(3000); R.springStat = await page.evaluate(() => window.__poc.springCount());
  await page.screenshot({ path: process.argv[3] + '-springs.png' });
  R.back = await page.evaluate(() => window.__poc.setLayout('pulls')); await page.waitForTimeout(800);
  R.atlas = await page.evaluate(async () => { const a = await window.__poc.atlas(); return { rows: a.rows.length, origin: a.rows.filter(r => r.key === 'origin').map(r => r.pos) }; });
  R.overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  const phone = await open({ viewport: { width: 400, height: 860 }, deviceScaleFactor: 2 }); await phone.waitForTimeout(2000);
  R.phoneOverflow = await phone.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth); await phone.screenshot({ path: process.argv[3] + '-phone.png' });
  R.errors = errs; console.log(JSON.stringify(R, null, 1)); await browser.close();
})();
