# Turn 22 prediction, before the run (2026-10-24)
Cause measured: closeness spreads through opposite lines, so each action word is close to its own opposite, whose line cancels its own pull.
Fix tested: closeness that does not travel through opposite lines (all other kinds as before), same floor rule, same start (balanced pairs), both formulas.
Predictions: the action words' own share rises from 28-39% to above 50% median; add's angle to its own line drops from 74 to under 30 degrees;
their median distance from 0,0,0 rises above the 90th percentile of words. The held-out-style sampled score moves by less than 0.03.

## Added before the signed-closeness run
Signed closeness: spreads through every line, but each opposite line crossed flips the side; what arrives an even number of crossings away pulls toward the pull's own line, an odd number toward the opposite line.
Predictions: words exactly at 0,0,0 drop back to about the island count (152); the action words keep a median own share above 45% and angle under 15 degrees; add stays under 30 degrees.
