# turn 22: two-sided closeness. From a pull's word, spread through your map's lines; crossing an opposite line flips the side.
# A word's pull toward the line = what arrives on the same side; toward the opposite line = what arrives flipped.
# usage: python3 -I signed22.py <scratchpad>
import sys, os, json
S = sys.argv[1]; sys.path.insert(0, os.path.join(S, 'turn18'))
from lib18 import *
j, z, L, WN = load(S + '/turn18/out'); W = j['words']; n = len(W); wi = {w: i for i, w in enumerate(W)}
NW = json.load(open(S + '/turn22/out/noopp_words.json'))['words']
def graphs(Lx):
    P = build_graph(n, {(k, 'x'): v for k, v in Lx.items() if k != 'opposite'}, kinds=[k for k in KINDS if k != 'opposite'], split='x')
    N = build_graph(n, {('opposite', 'x'): Lx['opposite']}, kinds=['opposite'], split='x')
    return P, N
def two_side(P, N, seed, alpha=0.15, iters=60):
    d = np.asarray(P.sum(1)).ravel() + np.asarray(N.sum(1)).ravel(); d[d == 0] = 1
    PT = (sp.diags(1 / d) @ P).T.tocsr(); NT = (sp.diags(1 / d) @ N).T.tocsr()
    e = np.zeros(n); e[seed] = 1; x0 = e.copy(); x1 = np.zeros(n)
    for _ in range(iters):
        y0 = (1 - alpha) * (PT @ x0 + NT @ x1) + alpha * e
        y1 = (1 - alpha) * (PT @ x1 + NT @ x0)
        x0, x1 = y0, y1
    return x0, x1
out = {}
for tag, Lx in (('build', {kn: L[(kn, 'train')] for kn in KINDS}), ('shown', {kn: np.vstack([L[(kn, s)] for s in ('train', 'val', 'test') if (kn, s) in L]) for kn in KINDS})):
    P, N = graphs(Lx)
    R = {w: two_side(P, N, wi[w]) for w in NW}
    allnz = np.concatenate([np.r_[a[a > 0], b[b > 0]] for a, b in R.values()]); fl = np.percentile(allnz, 1)
    same, flip = [], []
    for w in NW:
        a, b = R[w]
        sa = np.where(a > 0, np.log10(np.maximum(a, fl) / fl), 0); sb = np.where(b > 0, np.log10(np.maximum(b, fl) / fl), 0)
        m = sa.max(); same.append(sa / m); flip.append(sb / m)
    out[tag + '_same'] = np.array(same); out[tag + '_flip'] = np.array(flip)
    print(tag, 'done; words reached (same side or flipped) from "add":', int(((out[tag + '_same'][NW.index('add')] > 0) | (out[tag + '_flip'][NW.index('add')] > 0)).sum()), flush=True)
np.savez_compressed(S + '/turn22/out/signed22.npz', **out)
