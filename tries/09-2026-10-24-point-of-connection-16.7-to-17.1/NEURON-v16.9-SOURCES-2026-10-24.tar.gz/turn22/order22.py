# turn 22: with closeness that does not travel through opposite lines, is the order of the lines wrong?
# Re-place the same pairs on the 13 line pairs (which pair where, which end which way) on the CHOOSE split, share marks,
# above-average strength. Compare with the order 16.8 uses. usage: python3 -I order22.py <scratchpad>
import sys, os, json, time
S = sys.argv[1]; sys.path.insert(0, os.path.join(S, 'turn18'))
from lib18 import *
import multiprocessing as mp
j, z, L, WN = load(S + '/turn18/out'); W = j['words']; n = len(W); wi = {w: i for i, w in enumerate(W)}
E = json.load(open(S + '/turn20/poc/pulls168.json')); NM = E['name']; SL = E['slots']; U = np.array([np.array(v, float) / np.linalg.norm(v) for _, _, v in SL]); A0 = E['presets'][0]['assign']
PZ = np.load(S + '/turn20/out/pool20.npz'); PB0 = PZ['build']
NW = json.load(open(S + '/turn22/out/noopp_words.json'))['words']; NZ = np.load(S + '/turn22/out/noopp22.npz'); NB = NZ['build']
def word_of(nm):
    if nm.isupper(): return nm.lower()
    if nm.startswith("close to '"): return nm[10:-1]
def pull(k):
    w = word_of(NM[k]); return NB[NW.index(w)] if w else PB0[k]
LINEP = []
for s in range(30):
    if SL[s][0] == 'quad': continue
    t = [t for t in range(30) if SL[t][0] != 'quad' and np.allclose(U[t], -U[s])][0]
    if s < t: LINEP.append((s, t))
pairs = []; seen = set()
for s, k in enumerate(A0):
    if k < 0 or s in seen: continue
    t = [t for t in range(30) if SL[t][0] != 'quad' and np.allclose(U[t], -U[s])][0]; seen |= {s, t}
    pairs.append((k, A0[t]))
PULL = {k: pull(k) for p in pairs for k in p if k >= 0}
PR = Proxy(L, n)
def assign_of(lay):
    a = [-1] * 30
    for p, lp, fl in lay:
        s, t = LINEP[lp]
        if fl: s, t = t, s
        a[s] = pairs[p][0]; a[t] = pairs[p][1]
    return a
def place(a):
    idx = [(s, k) for s, k in enumerate(a) if k >= 0]; M = np.clip(np.array([PULL[k] for s, k in idx]) - np.array([PULL[k] for s, k in idx]).mean(0), 0, None)
    t = M.sum(0); t[t == 0] = 1; sh = M / t; P = (sh ** 2).T @ U[[s for s, k in idx]]; r = np.linalg.norm(P, axis=1); return P / np.median(r[r > 0])
def ev(lay): return PR(place(assign_of(lay))), lay
# the 16.8 order, as a layout
cur_lay = []
for p, (ka, kb) in enumerate(pairs):
    s = A0.index(ka); lp = [i for i, (x, y) in enumerate(LINEP) if s in (x, y)][0]; cur_lay.append((p, lp, 0 if LINEP[lp][0] == s else 1))
base = ev(cur_lay)[0]; print('16.8 order, corrected closeness: sampled', round(base, 4), flush=True)
lay = []; t0 = time.time()
for step in range(len(pairs)):
    up = {x[0] for x in lay}; ul = {x[1] for x in lay}
    jobs = [lay + [(p, lp, fl)] for p in range(len(pairs)) if p not in up for lp in range(13) if lp not in ul for fl in (0, 1)]
    with mp.Pool(4) as pp: r = pp.map(ev, jobs, chunksize=8)
    r.sort(key=lambda x: x[0]); lay = r[0][1]
cur = r[0][0]
for ps in range(8):
    cands = []
    for i in range(len(lay)):
        a = [list(x) for x in lay]; a[i][2] = 1 - a[i][2]; cands.append([tuple(x) for x in a])
        for k in range(i + 1, len(lay)):
            a = [list(x) for x in lay]; a[i][1], a[k][1] = a[k][1], a[i][1]; cands.append([tuple(x) for x in a])
    with mp.Pool(4) as pp: r = pp.map(ev, cands, chunksize=8)
    r.sort(key=lambda x: x[0])
    if r[0][0] > cur - 0.0005: break
    lay, cur = r[0][1], r[0][0]
a = assign_of(lay)
print('best order found, corrected closeness: sampled', round(cur, 4), 'vs 16.8 order', round(base, 4), round(time.time() - t0), 's')
print([(SL[s][1], NM[k]) for s, k in enumerate(a) if k >= 0])
json.dump({'assign': a, 'score': cur, 'base_order_score': base, 'base_assign': A0}, open(S + '/turn22/out/order22.json', 'w'))
