# turn 22: two-sided closeness in the 30-line graph: metrics for the 16.8 order, then the order re-searched (choose split)
# usage: python3 -I signed_order22.py <scratchpad>
import sys, os, json, time
S = sys.argv[1]; sys.path.insert(0, os.path.join(S, 'turn18'))
from lib18 import *
import multiprocessing as mp
j, z, L, WN = load(S + '/turn18/out'); W = j['words']; n = len(W); wi = {w: i for i, w in enumerate(W)}
E = json.load(open(S + '/turn20/poc/pulls168.json')); NM = E['name']; SL = E['slots']; U = np.array([np.array(v, float) / np.linalg.norm(v) for _, _, v in SL]); A0 = E['presets'][0]['assign']
PZ = np.load(S + '/turn20/out/pool20.npz'); PB0, PS0 = PZ['build'], PZ['shown']
NW = json.load(open(S + '/turn22/out/noopp_words.json'))['words']; G = dict(np.load(S + '/turn22/out/signed22.npz'))
def word_of(nm):
    if nm.isupper(): return nm.lower()
    if nm.startswith("close to '"): return nm[10:-1]
def entries(a, tag):
    """(direction, strength vector) for every pull in use: the same side along the line, the flipped side along the opposite direction"""
    out = []
    for s, k in enumerate(a):
        if k < 0: continue
        w = word_of(NM[k])
        if w: out.append((U[s], G[tag + '_same'][NW.index(w)])); out.append((-U[s], G[tag + '_flip'][NW.index(w)]))
        else: out.append((U[s], (PB0 if tag == 'build' else PS0)[k]))
    return out
def place(a, tag, marks=True, rel=True):
    en = entries(a, tag); D = np.array([d for d, v in en]); M = np.array([v for d, v in en])
    if rel: M = np.clip(M - M.mean(0), 0, None)
    if marks: t = M.sum(0); t[t == 0] = 1; M = (M / t) ** 2
    return M.T @ D
def norm(P): r = np.linalg.norm(P, axis=1); return P / np.median(r[r > 0])
PR = Proxy(L, n)
def metrics(a, marks):
    P = place(a, 'shown', marks); r = np.linalg.norm(P, axis=1)
    en_idx = [(s, k) for s, k in enumerate(a) if k >= 0]
    ang = []; own = []
    for s, k in en_idx:
        if not NM[k].isupper() or NM[k].lower() not in wi: continue
        i = wi[NM[k].lower()]; ang.append(np.degrees(np.arccos(np.clip(P[i] @ U[s] / max(r[i], 1e-12), -1, 1))))
    i = wi['add']; sa = [s for s, k in en_idx if NM[k] == 'ADD'][0]; add = np.degrees(np.arccos(np.clip(P[i] @ U[sa] / max(r[i], 1e-12), -1, 1)))
    return {'at_origin': int((r < 1e-12).sum()), 'angle_median': float(np.median(ang)), 'add_angle': float(add), 'origin_x_median': float(r[wi['origin']] / np.median(r)),
            'sampled': PR(norm(place(a, 'build', marks)))}
LINEP = []
for s in range(30):
    if SL[s][0] == 'quad': continue
    t = [t for t in range(30) if SL[t][0] != 'quad' and np.allclose(U[t], -U[s])][0]
    if s < t: LINEP.append((s, t))
pairs = []; seen = set()
for s, k in enumerate(A0):
    if k < 0 or s in seen: continue
    t = [t for t in range(30) if SL[t][0] != 'quad' and np.allclose(U[t], -U[s])][0]; seen |= {s, t}; pairs.append((k, A0[t]))
def assign_of(lay):
    a = [-1] * 30
    for p, lp, fl in lay:
        s, t = LINEP[lp]
        if fl: s, t = t, s
        a[s] = pairs[p][0]; a[t] = pairs[p][1]
    return a
def ev(lay): return PR(norm(place(assign_of(lay), 'build'))), lay
if __name__ == '__main__':
    for marks in (True, False): print('16.8 order, two-sided closeness,', 'share marks' if marks else 'sum', {k: round(v, 3) for k, v in metrics(A0, marks).items()}, flush=True)
    t0 = time.time(); lay = []
    for step in range(len(pairs)):
        up = {x[0] for x in lay}; ul = {x[1] for x in lay}
        jobs = [lay + [(p, lp, fl)] for p in range(len(pairs)) if p not in up for lp in range(13) if lp not in ul for fl in (0, 1)]
        with mp.Pool(4) as pp: r = pp.map(ev, jobs, chunksize=8)
        r.sort(key=lambda x: x[0]); lay = r[0][1]
    cur = r[0][0]
    for ps in range(8):
        cands = []
        for i in range(len(lay)):
            a = [list(x) for x in lay]; a[i][2] = 1 - a[i][2]; cands.append([tuple(x) for x in a])
            for k in range(i + 1, len(lay)):
                a = [list(x) for x in lay]; a[i][1], a[k][1] = a[k][1], a[i][1]; cands.append([tuple(x) for x in a])
        with mp.Pool(4) as pp: r = pp.map(ev, cands, chunksize=8)
        r.sort(key=lambda x: x[0])
        if r[0][0] > cur - 0.0005: break
        lay, cur = r[0][1], r[0][0]
    a = assign_of(lay)
    for marks in (True, False): print('best order, two-sided closeness,', 'share marks' if marks else 'sum', {k: round(v, 3) for k, v in metrics(a, marks).items()}, flush=True)
    print('order:', [(SL[s][1], NM[k]) for s, k in enumerate(a) if k >= 0], round(time.time() - t0), 's')
    json.dump({'assign': a}, open(S + '/turn22/out/signed_order22.json', 'w'))
