# turn 22: held-out test of the 16.9 default (two-sided closeness, re-searched order, above-average strength) for both formulas,
# and the page data pulls169.json. usage: python3 -I held22.py <scratchpad>
import sys, os, json, base64
S = sys.argv[1]; sys.path.insert(0, os.path.join(S, 'turn22'))
sys.argv = [sys.argv[0], S]
from signed_order22 import *
a = json.load(open(S + '/turn22/out/signed_order22.json'))['assign']
def job(args):
    marks, what = args; P = norm(place(a, 'build', marks))
    if what == 'shuffled': P = P[np.random.default_rng(7).permutation(n)]
    return args, score_graph(P, L, maxlines=2000)
if __name__ == '__main__':
    with mp.Pool(4) as pp: R = dict(pp.map(job, [(True, 'map'), (True, 'shuffled'), (False, 'map'), (False, 'shuffled')]))
    out = {}
    for marks in (True, False):
        r, sh = R[(marks, 'map')], R[(marks, 'shuffled')]
        mean = float(np.mean([v['test'][v['best']]['median'] for v in r.values()]))
        pts = [k for k in KINDS if r[k]['test'][r[k]['best']]['median'] < 0.25 and r[k]['test'][r[k]['best']]['hit10'] >= 0.003 and sh[k]['test'][sh[k]['best']]['median'] >= 0.45]
        out['marks' if marks else 'sum'] = {'mean': mean, 'pts': pts, 'test': {k: {'best': v['best'], 'median': v['test'][v['best']]['median'], 'hit10': v['test'][v['best']]['hit10'], 'shuffled': sh[k]['test'][sh[k]['best']]['median']} for k, v in r.items()}}
        print('16.9 default', 'share marks' if marks else 'sum', 'held-out mean', round(mean, 4), 'points out', pts, flush=True)
    E = json.load(open(S + '/turn20/poc/pulls168.json'))
    q = lambda M: base64.b64encode(np.where(M > 0, np.maximum(1, np.round(M * 255)), 0).astype(np.uint8).tobytes()).decode()
    E['two'] = {'words': NW, 'same': q(G['shown_same']), 'flip': q(G['shown_flip'])}
    for p in E['presets']: p.setdefault('close', 'all')
    E['presets'] = [{'key': 'G', 'title': 'Your pairs, re-ordered; opposite lines flip the side', 'assign': a, 'mean': out['marks']['mean'], 'mean_sum': out['sum']['mean'], 'pts': out['marks']['pts'], 'test': out['marks']['test'], 'rel': True, 'mode': 'marks', 'close': 'two'}] + E['presets']
    json.dump(E, open(S + '/turn20/poc/pulls169.json', 'w')); json.dump(out, open(S + '/turn22/out/held22.json', 'w'))
    print('pulls169.json written', os.path.getsize(S + '/turn20/poc/pulls169.json'))
