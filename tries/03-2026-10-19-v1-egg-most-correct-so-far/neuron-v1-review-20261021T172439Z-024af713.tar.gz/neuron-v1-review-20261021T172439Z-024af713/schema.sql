CREATE TABLE g1(shard INTEGER, arrival INTEGER, remainder INTEGER, trigger INTEGER, run INTEGER, pos INTEGER, rest TEXT, cur TEXT);

CREATE TABLE g10(shard INTEGER, arrival INTEGER, remainder INTEGER, trigger INTEGER, run INTEGER, pos INTEGER);

CREATE TABLE g11(id INTEGER PRIMARY KEY, source TEXT, entry TEXT, sense TEXT, class TEXT, text TEXT, example TEXT, origin TEXT, first_use TEXT, synonyms TEXT, antonyms TEXT, times INTEGER, first_at TEXT, last_at TEXT, ended_at TEXT);

CREATE TABLE g12(shard INTEGER, arrival INTEGER, remainder INTEGER, trigger INTEGER, run INTEGER, pos INTEGER);

CREATE TABLE g13(id INTEGER PRIMARY KEY, source TEXT, entry TEXT, sense TEXT, class TEXT, text TEXT, example TEXT, origin TEXT, first_use TEXT, synonyms TEXT, antonyms TEXT, times INTEGER, first_at TEXT, last_at TEXT, ended_at TEXT);

CREATE TABLE g14(shard INTEGER, arrival INTEGER, remainder INTEGER, trigger INTEGER, run INTEGER, pos INTEGER);

CREATE TABLE g15(id INTEGER PRIMARY KEY, source TEXT, entry TEXT, sense TEXT, class TEXT, text TEXT, example TEXT, origin TEXT, first_use TEXT, synonyms TEXT, antonyms TEXT, times INTEGER, first_at TEXT, last_at TEXT, ended_at TEXT);

CREATE TABLE g16(shard INTEGER, arrival INTEGER, remainder INTEGER, trigger INTEGER, run INTEGER, pos INTEGER);

CREATE TABLE g17(id INTEGER PRIMARY KEY, source TEXT, entry TEXT, sense TEXT, class TEXT, text TEXT, example TEXT, origin TEXT, first_use TEXT, synonyms TEXT, antonyms TEXT, times INTEGER, first_at TEXT, last_at TEXT, ended_at TEXT);

CREATE TABLE g18(shard INTEGER, arrival INTEGER, remainder INTEGER, trigger INTEGER, run INTEGER, pos INTEGER);

CREATE TABLE g19(id INTEGER PRIMARY KEY, source TEXT, entry TEXT, sense TEXT, class TEXT, text TEXT, example TEXT, origin TEXT, first_use TEXT, synonyms TEXT, antonyms TEXT, times INTEGER, first_at TEXT, last_at TEXT, ended_at TEXT);

CREATE TABLE g2(shard INTEGER, arrival INTEGER, remainder INTEGER, trigger INTEGER, run INTEGER, pos INTEGER, word TEXT, gate INTEGER);

CREATE TABLE g20(shard INTEGER, arrival INTEGER, remainder INTEGER, trigger INTEGER, run INTEGER, pos INTEGER);

CREATE TABLE g21(id INTEGER PRIMARY KEY, source TEXT, entry TEXT, sense TEXT, class TEXT, text TEXT, example TEXT, origin TEXT, first_use TEXT, synonyms TEXT, antonyms TEXT, times INTEGER, first_at TEXT, last_at TEXT, ended_at TEXT);

CREATE TABLE g22(shard INTEGER, arrival INTEGER, remainder INTEGER, trigger INTEGER, run INTEGER, pos INTEGER);

CREATE TABLE g23(id INTEGER PRIMARY KEY, source TEXT, entry TEXT, sense TEXT, class TEXT, text TEXT, example TEXT, origin TEXT, first_use TEXT, synonyms TEXT, antonyms TEXT, times INTEGER, first_at TEXT, last_at TEXT, ended_at TEXT);

CREATE TABLE g24(shard INTEGER, arrival INTEGER, remainder INTEGER, trigger INTEGER, run INTEGER, pos INTEGER);

CREATE TABLE g25(id INTEGER PRIMARY KEY, source TEXT, entry TEXT, sense TEXT, class TEXT, text TEXT, example TEXT, origin TEXT, first_use TEXT, synonyms TEXT, antonyms TEXT, times INTEGER, first_at TEXT, last_at TEXT, ended_at TEXT);

CREATE TABLE g3(shard INTEGER, arrival INTEGER, remainder INTEGER, trigger INTEGER, run INTEGER, pos INTEGER, word TEXT, said TEXT);

CREATE TABLE g4(shard INTEGER, arrival INTEGER, remainder INTEGER, trigger INTEGER, run INTEGER, pos INTEGER, said TEXT);

CREATE TABLE g5(shard INTEGER, arrival INTEGER, remainder INTEGER, trigger INTEGER, run INTEGER, pos INTEGER);

CREATE TABLE g6(shard INTEGER, arrival INTEGER, remainder INTEGER, trigger INTEGER, run INTEGER, pos INTEGER);

CREATE TABLE g7(id INTEGER PRIMARY KEY, source TEXT, entry TEXT, sense TEXT, class TEXT, text TEXT, example TEXT, origin TEXT, first_use TEXT, synonyms TEXT, antonyms TEXT, times INTEGER, first_at TEXT, last_at TEXT, ended_at TEXT);

CREATE TABLE g8(shard INTEGER, arrival INTEGER, remainder INTEGER, trigger INTEGER, run INTEGER, pos INTEGER);

CREATE TABLE g9(id INTEGER PRIMARY KEY, source TEXT, entry TEXT, sense TEXT, class TEXT, text TEXT, example TEXT, origin TEXT, first_use TEXT, synonyms TEXT, antonyms TEXT, times INTEGER, first_at TEXT, last_at TEXT, ended_at TEXT);

CREATE TABLE input(id INTEGER PRIMARY KEY, text TEXT NOT NULL, time TEXT DEFAULT CURRENT_TIMESTAMP, answer TEXT);

CREATE TABLE label(gate INTEGER PRIMARY KEY, word TEXT NOT NULL UNIQUE);

CREATE TABLE shards(n INTEGER NOT NULL);

CREATE TABLE x(a);

CREATE TRIGGER g1 AFTER INSERT ON g1 WHEN NEW.rest IS NOT NULL BEGIN INSERT INTO g1(run, pos, rest, cur) SELECT NEW.run, NEW.pos, substr(NEW.rest, 2), NEW.cur || substr(NEW.rest, 1, 1) WHERE NEW.rest <> '' AND substr(NEW.rest, 1, 1) GLOB '[A-Za-z0-9_]'; INSERT INTO g2(run, pos, word) SELECT NEW.run, NEW.pos + 1, NEW.cur WHERE NEW.cur <> '' AND NOT (NEW.rest <> '' AND substr(NEW.rest, 1, 1) GLOB '[A-Za-z0-9_]'); INSERT INTO g2(run, pos, word) SELECT NEW.run, NEW.pos + 1 + (NEW.cur <> ''), substr(NEW.rest, 1, 1) WHERE NEW.rest <> '' AND NOT substr(NEW.rest, 1, 1) GLOB '[A-Za-z0-9_]'; INSERT INTO g1(run, pos, rest, cur) SELECT NEW.run, NEW.pos + 1 + (NEW.cur <> ''), substr(NEW.rest, 2), '' WHERE NEW.rest <> '' AND NOT substr(NEW.rest, 1, 1) GLOB '[A-Za-z0-9_]'; SELECT mother('INSERT INTO g' || (SELECT gate FROM g2 WHERE run = NEW.run AND pos = 1) || '(run, pos, arrival, remainder) VALUES (' || NEW.run || ', 1, 0, ' || coalesce((SELECT gate FROM g2 WHERE run = NEW.run AND pos = 2), 'NULL') || ')') WHERE NEW.rest = '' AND EXISTS (SELECT 1 FROM g2 WHERE run = NEW.run AND pos = 1); DELETE FROM g1 WHERE run = NEW.run AND NEW.rest = ''; END;

CREATE TRIGGER g10 AFTER INSERT ON g10 BEGIN UPDATE shards SET n = n + 1; UPDATE g10 SET shard = (SELECT n FROM shards) WHERE rowid = NEW.rowid; INSERT INTO g4(run, pos, arrival, remainder) SELECT NEW.run, NEW.pos, 10, NEW.remainder WHERE NEW.remainder IS NOT NULL; END;

CREATE TRIGGER g12 AFTER INSERT ON g12 BEGIN UPDATE shards SET n = n + 1; UPDATE g12 SET shard = (SELECT n FROM shards) WHERE rowid = NEW.rowid; INSERT INTO g4(run, pos, arrival, remainder) SELECT NEW.run, NEW.pos, 12, NEW.remainder WHERE NEW.remainder IS NOT NULL; END;

CREATE TRIGGER g14 AFTER INSERT ON g14 BEGIN UPDATE shards SET n = n + 1; UPDATE g14 SET shard = (SELECT n FROM shards) WHERE rowid = NEW.rowid; INSERT INTO g4(run, pos, arrival, remainder) SELECT NEW.run, NEW.pos, 14, NEW.remainder WHERE NEW.remainder IS NOT NULL; END;

CREATE TRIGGER g16 AFTER INSERT ON g16 BEGIN UPDATE shards SET n = n + 1; UPDATE g16 SET shard = (SELECT n FROM shards) WHERE rowid = NEW.rowid; INSERT INTO g4(run, pos, arrival, remainder) SELECT NEW.run, NEW.pos, 16, NEW.remainder WHERE NEW.remainder IS NOT NULL; END;

CREATE TRIGGER g18 AFTER INSERT ON g18 BEGIN UPDATE shards SET n = n + 1; UPDATE g18 SET shard = (SELECT n FROM shards) WHERE rowid = NEW.rowid; INSERT INTO g4(run, pos, arrival, remainder) SELECT NEW.run, NEW.pos, 18, NEW.remainder WHERE NEW.remainder IS NOT NULL; END;

CREATE TRIGGER g2 AFTER INSERT ON g2 WHEN NEW.word IS NOT NULL BEGIN UPDATE shards SET n = n + 1; UPDATE g2 SET shard = (SELECT n FROM shards) WHERE rowid = NEW.rowid; INSERT INTO g3(run, pos, word) SELECT NEW.run, NEW.pos, NEW.word WHERE NOT EXISTS (SELECT 1 FROM label WHERE word = NEW.word); UPDATE g2 SET gate = (SELECT gate FROM label WHERE word = NEW.word) WHERE rowid = NEW.rowid; END;

CREATE TRIGGER g20 AFTER INSERT ON g20 BEGIN UPDATE shards SET n = n + 1; UPDATE g20 SET shard = (SELECT n FROM shards) WHERE rowid = NEW.rowid; INSERT INTO g4(run, pos, arrival, remainder) SELECT NEW.run, NEW.pos, 20, NEW.remainder WHERE NEW.remainder IS NOT NULL; END;

CREATE TRIGGER g22 AFTER INSERT ON g22 BEGIN UPDATE shards SET n = n + 1; UPDATE g22 SET shard = (SELECT n FROM shards) WHERE rowid = NEW.rowid; INSERT INTO g4(run, pos, arrival, remainder) SELECT NEW.run, NEW.pos, 22, NEW.remainder WHERE NEW.remainder IS NOT NULL; END;

CREATE TRIGGER g24 AFTER INSERT ON g24 BEGIN UPDATE shards SET n = n + 1; UPDATE g24 SET shard = (SELECT n FROM shards) WHERE rowid = NEW.rowid; INSERT INTO g4(run, pos, arrival, remainder) SELECT NEW.run, NEW.pos, 24, NEW.remainder WHERE NEW.remainder IS NOT NULL; END;

CREATE TRIGGER g3 AFTER INSERT ON g3 WHEN NEW.word IS NOT NULL BEGIN UPDATE shards SET n = n + 1; UPDATE g3 SET shard = (SELECT n FROM shards) WHERE rowid = NEW.rowid; INSERT INTO label(word) VALUES (NEW.word); INSERT INTO label(word) VALUES (NEW.word || '.definition'); UPDATE g3 SET said = mother('CREATE TABLE g' || (SELECT gate FROM label WHERE word = NEW.word) || '(shard INTEGER, arrival INTEGER, remainder INTEGER, trigger INTEGER, run INTEGER, pos INTEGER); CREATE TRIGGER g' || (SELECT gate FROM label WHERE word = NEW.word) || ' AFTER INSERT ON g' || (SELECT gate FROM label WHERE word = NEW.word) || ' BEGIN UPDATE shards SET n = n + 1; UPDATE g' || (SELECT gate FROM label WHERE word = NEW.word) || ' SET shard = (SELECT n FROM shards) WHERE rowid = NEW.rowid; INSERT INTO g4(run, pos, arrival, remainder) SELECT NEW.run, NEW.pos, ' || (SELECT gate FROM label WHERE word = NEW.word) || ', NEW.remainder WHERE NEW.remainder IS NOT NULL; END; CREATE TABLE g' || (SELECT gate FROM label WHERE word = NEW.word || '.definition') || '(id INTEGER PRIMARY KEY, source TEXT, entry TEXT, sense TEXT, class TEXT, text TEXT, example TEXT, origin TEXT, first_use TEXT, synonyms TEXT, antonyms TEXT, times INTEGER, first_at TEXT, last_at TEXT, ended_at TEXT); INSERT INTO g' || (SELECT gate FROM label WHERE word = NEW.word) || '(trigger) VALUES (' || (SELECT gate FROM label WHERE word = NEW.word || '.definition') || ');') WHERE rowid = NEW.rowid; UPDATE input SET answer = (SELECT said FROM g3 WHERE rowid = NEW.rowid) WHERE id = NEW.run AND (SELECT said FROM g3 WHERE rowid = NEW.rowid) LIKE 'error:%'; END;

CREATE TRIGGER g4 AFTER INSERT ON g4 WHEN NEW.remainder IS NOT NULL BEGIN UPDATE shards SET n = n + 1; UPDATE g4 SET shard = (SELECT n FROM shards) WHERE rowid = NEW.rowid; UPDATE g4 SET said = mother('INSERT INTO g' || NEW.remainder || '(run, pos, arrival, remainder) VALUES (' || NEW.run || ', ' || (NEW.pos + 1) || ', ' || NEW.arrival || ', ' || coalesce((SELECT gate FROM g2 WHERE run = NEW.run AND pos = NEW.pos + 2), 'NULL') || ')') WHERE rowid = NEW.rowid; UPDATE input SET answer = (SELECT said FROM g4 WHERE rowid = NEW.rowid) WHERE id = NEW.run AND (SELECT said FROM g4 WHERE rowid = NEW.rowid) LIKE 'error:%'; END;

CREATE TRIGGER g5 AFTER INSERT ON g5 BEGIN UPDATE shards SET n = n + 1; UPDATE g5 SET shard = (SELECT n FROM shards) WHERE rowid = NEW.rowid; INSERT INTO g4(run, pos, arrival, remainder) SELECT NEW.run, NEW.pos, 5, NEW.remainder WHERE NEW.remainder IS NOT NULL; UPDATE input SET answer = mother((SELECT group_concat(word, '') FROM (SELECT word FROM g2 WHERE run = NEW.run AND pos > 1 AND pos < NEW.pos ORDER BY pos))) WHERE id = NEW.run AND NEW.remainder IS NULL AND (SELECT word FROM g2 WHERE run = NEW.run AND pos = 1) = 'BUILD'; END;

CREATE TRIGGER g6 AFTER INSERT ON g6 BEGIN UPDATE shards SET n = n + 1; UPDATE g6 SET shard = (SELECT n FROM shards) WHERE rowid = NEW.rowid; INSERT INTO g4(run, pos, arrival, remainder) SELECT NEW.run, NEW.pos, 6, NEW.remainder WHERE NEW.remainder IS NOT NULL; END;

CREATE TRIGGER g8 AFTER INSERT ON g8 BEGIN UPDATE shards SET n = n + 1; UPDATE g8 SET shard = (SELECT n FROM shards) WHERE rowid = NEW.rowid; INSERT INTO g4(run, pos, arrival, remainder) SELECT NEW.run, NEW.pos, 8, NEW.remainder WHERE NEW.remainder IS NOT NULL; END;

CREATE TRIGGER input AFTER INSERT ON input BEGIN INSERT INTO g1(run, pos, rest, cur) VALUES (NEW.id, 0, NEW.text, ''); END;
