# Recorded validation

Full Neuron acceptance: **NOT_DEMONSTRATED**. These are bounded implementation checks, not proof of general understanding or growth through free-form conversation.

## Normal build

- C: `cc -O2 -g -std=c11 -Wall -Wextra -Werror -D_POSIX_C_SOURCE=200809L -D_XOPEN_SOURCE=700`, linked to SQLite, libcurl, OpenSSL crypto, libm.
- Result: **27/27 checks passed**, 176 actual input invocations.
- Harness duration: 8.771 seconds. This includes process startup, storage and auditing; it is not a hop-speed benchmark.
- Platform: Linux. Direct WSL execution: **not performed**.
- Seed SHA-256: `1cba1c2b2ecdff55c0af3871ab118245ca12615a92be6ae877eb1ce0a412a776`.
- Normal binary SHA-256: `4a35e68cab028779e8a9a9bfad2265918af27b6c4ab290a471d02e247807b103`. The release ships source, not this binary; the installer builds for its target.

## Instrumented build

Clang AddressSanitizer + UndefinedBehaviorSanitizer, `-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer`, leak detection enabled, undefined behavior configured to halt.

Result: **27/27 checks passed**, 176 inputs, no sanitizer error reported during these checks. This does not establish absence of all memory or concurrency defects. Full report: `sanitizer-verification.json`.

## Particularly relevant observations

- Twelve varied affine coefficient/input families were inferred from examples and used on additional inputs.
- A numeric repeat used 15 total descendant steps versus 21, while evaluation and confidence branches remained present.
- A composed process used 35 descendant steps before self-observation-based specialization and 21 afterward on another input. This is not a C/Go/Python comparative benchmark.
- A changed dependency challenged and invalidated an old specialization; a later revised answer changed from 39 to 85 while the old result remained in history.
- Nonlinear examples outside the search space were rejected rather than presented as understood.
- Changing an arrival-specific DNA revision changed real execution. Equally specific candidates faulted.
- Changing a stored excitation pointer affected the real branch; a missing required finding did not become a successful answer.
- SELECT returned integer, real, NULL, text and binary values, not merely 'ok'.
- A failing multi-statement action rolled back its preceding CREATE within that action.
- Exact local source bytes, quotes, original memories and historical positions survived the exercised transformations.
- Six specified local access paths used indexes. This is not an all-queries, all-scale performance proof.

## What was not exercised

Live HTTPS endpoints, a WSL kernel/environment, destructive crash/power-loss recovery, concurrent writers, arbitrary reading/learning, semantic geometry, QKV, full hippocampal reconstruction, calibrated belief, autonomy over an unbounded lifetime, billions of gates, and energy measurement.

Test-only interventions are explicitly marked and confined to fresh disposable databases. They are evidence about mechanisms, not learned behavior. The external verifier never opens the installed working brain. No test observations are included in the installed seed.

The full machine-readable reports and literal input/output transcript are included. The seed generator reproduced `seed.sql` and `docs/CODE-MAP.json` byte-for-byte. Installation checks are recorded separately in `installation-verification.json` once performed.
