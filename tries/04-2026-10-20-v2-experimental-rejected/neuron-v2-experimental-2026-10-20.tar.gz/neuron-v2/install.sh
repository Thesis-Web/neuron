#!/usr/bin/env bash
# Installs only a new, separate V2 directory. Never migrates, resets, or opens V1.
set -Eeuo pipefail
umask 077
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
DEST="${1:-$HOME/neuron/v2}"
(( $# <= 1 )) || { echo 'Usage: bash install.sh [new-install-directory]' >&2; exit 2; }
[[ "$DEST" = /* ]] || DEST="$PWD/$DEST"
[[ ! -e "$DEST" && ! -L "$DEST" ]] || { printf 'Refusing to overwrite existing path: %s\n' "$DEST" >&2; exit 2; }
for tool in cc make tar sha256sum mktemp; do
    command -v "$tool" >/dev/null || {
        printf 'Missing %s. On Ubuntu/Debian WSL, install dependencies with:\n' "$tool" >&2
        echo 'sudo apt-get update && sudo apt-get install -y build-essential libsqlite3-dev libcurl4-openssl-dev libssl-dev' >&2
        exit 2
    }
done
if [[ -f "$HERE/MANIFEST.sha256" ]]; then
    (cd "$HERE" && sha256sum --check --quiet MANIFEST.sha256)
else
    echo 'Release manifest missing; refusing an unverified installation.' >&2
    exit 2
fi
PARENT="$(dirname -- "$DEST")"
mkdir -p -- "$PARENT"
STAGE="$(mktemp -d -- "$PARENT/.neuron-v2-install.XXXXXX")"
cleanup() {
    local rc=$?
    if [[ -n "${STAGE:-}" && -d "$STAGE" ]]; then
        # This directory was uniquely created by this installer, never user data.
        rm -rf -- "$STAGE"
    fi
    exit "$rc"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
case "$STAGE/" in "$HERE/"*) echo 'Destination must be outside the unpacked package.' >&2; exit 2 ;; esac
tar -C "$HERE" --exclude='./neuron' --exclude='./brain.db*' --exclude='./.git' --exclude='./__pycache__' -cf - . |
    tar -C "$STAGE" -xf -
if ! make -C "$STAGE" -B neuron; then
    echo 'Compilation failed. Required Ubuntu/Debian packages:' >&2
    echo 'build-essential libsqlite3-dev libcurl4-openssl-dev libssl-dev' >&2
    exit 1
fi
"$STAGE/neuron" "$STAGE/brain.db" --init "$STAGE/seed.sql"
"$STAGE/neuron" "$STAGE/brain.db" --version
chmod 700 "$STAGE"
[[ ! -e "$DEST" && ! -L "$DEST" ]] || { echo 'Destination appeared during installation; refusing to replace it.' >&2; exit 2; }
mv -T -n -- "$STAGE" "$DEST"
[[ ! -d "$STAGE" ]] || { echo 'Destination was not moved; installation refused.' >&2; exit 2; }
STAGE=''
printf '\nInstalled experimental V2 in: %s\n' "$DEST"
printf 'Start: cd %q && ./talk\n' "$DEST"
printf 'This is a bounded research candidate, not demonstrated conversational general understanding.\n'
printf 'V1 has not been opened or modified. Read README.md before teaching it.\n'
