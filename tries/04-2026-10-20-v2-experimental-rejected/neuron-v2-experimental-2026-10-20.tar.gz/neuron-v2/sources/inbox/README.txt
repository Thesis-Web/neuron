Put local NUL-free UTF-8 source text here. This file is guidance, not taught knowledge.
No source is automatically ingested. Use: source file:FILENAME
Only explicit JSON {"examples":[[x,y],...]} is interpreted by observe.
Other source prose can be captured/quoted but is not semantically understood.
Do not place credentials in this directory.
