# Executed ONLY by the seed compiler. All emitted bodies execute in graph DNA.
# Learning a shorter process from the brain's own pure composition runs.

# A content fingerprint for the transitive LEAF dependency closure. It does not
# change merely because a composition has been optimized; changed leaf evidence
# does change it. No global graph sweep is used for this dependency operation.
def dep_expression(cap):
    return f"""(WITH RECURSIVE closure(cap) AS (VALUES({cap}) UNION SELECT d.child FROM dependency d JOIN closure c ON d.parent=c.cap)
    SELECT sha256(coalesce(json_group_array(json_array(c.cap,b.epoch,b.dna,b.state)),'[]'))
    FROM (SELECT cap FROM closure ORDER BY cap) c JOIN capability k ON k.id=c.cap JOIN binding b ON b.capability=c.cap WHERE k.kind='learned')"""

P['learn.fit'] = setpad(deps=f"CASE WHEN (SELECT kind FROM capability WHERE id={ctx('cap')})='composition' THEN {dep_expression(ctx('cap'))} ELSE '' END") + P['learn.fit']
# Sparse observations do not disable the working long-form composition.
P['learn.check'] = P['learn.check'].replace(
    f"state={ctx('model_state')},epoch=epoch+1 WHERE capability={ctx('cap')};",
    f"state=CASE WHEN (SELECT kind FROM capability WHERE id={ctx('cap')})='composition' AND {ctx('model_state')}<>'validated-examples' THEN 'told-composition' ELSE {ctx('model_state')} END,epoch=epoch+1 WHERE capability={ctx('cap')};")
P['learn.install'] += f"""
UPDATE binding SET basis=coalesce({ctx('deps')},'') WHERE capability={ctx('cap')};
INSERT INTO excitation(dna,target,role,provenance)
 SELECT b.dna,e.target,e.role,{ctx('evaluation')} FROM binding b JOIN dna new ON new.id=b.dna JOIN excitation e ON e.dna=new.previous WHERE b.capability={ctx('cap')};
{event('EXECUTABLE_REVISION',f"json_object('capability',{ctx('cap')},'dna',(SELECT dna FROM binding WHERE capability={ctx('cap')}),'previous',(SELECT d.previous FROM binding b JOIN dna d ON d.id=b.dna WHERE b.capability={ctx('cap')}),'basis',{ctx('deps')},'origin',:origin)")}
"""

proc('dependency.refresh', f"""
WITH RECURSIVE scope(cap) AS (VALUES({ctx('cap')}) UNION SELECT d.child FROM dependency d JOIN scope s ON d.parent=s.cap)
INSERT INTO event(kind,actor,detail)
 SELECT 'SPECIALIZATION_INVALIDATED','neuron',json_object('capability',b.capability,'old_dna',b.dna,'old_basis',b.basis,'new_basis',{dep_expression('b.capability')})
 FROM scope s JOIN capability c ON c.id=s.cap JOIN binding b ON b.capability=s.cap
 WHERE c.kind='composition' AND b.basis<>'' AND b.basis<>{dep_expression('b.capability')};
WITH RECURSIVE scope(cap) AS (VALUES({ctx('cap')}) UNION SELECT d.child FROM dependency d JOIN scope s ON d.parent=s.cap)
UPDATE binding SET dna=(SELECT min(d.id) FROM dna d JOIN capability c ON c.gate=d.gate WHERE c.id=binding.capability AND d.program=@C(composition.enter)),
 state='told-composition',basis='',model=NULL,epoch=epoch+1
 WHERE capability IN(SELECT cap FROM scope) AND (SELECT kind FROM capability WHERE id=capability)='composition' AND basis<>'' AND basis<>{dep_expression('binding.capability')};
WITH RECURSIVE scope(cap) AS (VALUES({ctx('cap')}) UNION SELECT d.child FROM dependency d JOIN scope s ON d.parent=s.cap)
DELETE FROM active_dna WHERE gate IN(SELECT c.gate FROM capability c JOIN scope s ON s.cap=c.id JOIN binding b ON b.capability=c.id WHERE b.dna<>active_dna.dna);
WITH RECURSIVE scope(cap) AS (VALUES({ctx('cap')}) UNION SELECT d.child FROM dependency d JOIN scope s ON d.parent=s.cap)
INSERT OR IGNORE INTO active_dna(dna,gate,arrival_key,head_key,head_mode)
 SELECT b.dna,c.gate,-1,-1,'any' FROM scope s JOIN capability c ON c.id=s.cap JOIN binding b ON b.capability=c.id WHERE b.dna IS NOT NULL;
""")
# Root resolves only its dependency closure, prior to asking execution/confidence branches.
P['apply.prepare'] = P['apply.prepare'].replace(seq('apply.start'),seq('dependency.refresh','apply.start'))
P['apply.evaluate'] = setpad(deps=dep_expression(ctx('cap'))) + P['apply.evaluate']
# Numeric composition processes are explicitly pure; an observation is recorded
# only after their actual execution, never from a cached answer.
P['apply.collect'] += f"""
INSERT INTO event(kind,actor,detail)
 SELECT 'SELF_OBSERVATION','neuron',json_object('capability',{ctx('cap')},'x',{ctx('x')},'value',json_extract(result,'$.value'),'run',:run,'dependencies',{ctx('deps')})
 FROM run WHERE id=:run AND json_extract(result,'$.state')='DERIVED' AND (SELECT kind FROM capability WHERE id={ctx('cap')})='composition'
 AND NOT EXISTS(SELECT 1 FROM current_example WHERE capability={ctx('cap')} AND context={ctx('deps')} AND x={ctx('x')} AND y=json_extract(run.result,'$.value'));
INSERT INTO example(capability,x,y,evidence,context)
 SELECT {ctx('cap')},{ctx('x')},json_extract(result,'$.value'),(SELECT max(id) FROM event),{ctx('deps')}
 FROM run WHERE id=:run AND json_extract(result,'$.state')='DERIVED' AND (SELECT kind FROM capability WHERE id={ctx('cap')})='composition'
 AND NOT EXISTS(SELECT 1 FROM current_example WHERE capability={ctx('cap')} AND context={ctx('deps')} AND x={ctx('x')} AND y=json_extract(run.result,'$.value'));
INSERT OR IGNORE INTO task(subject,gate,evidence)
 SELECT {ctx('cap')},{g('learn.fit')},:origin WHERE (SELECT kind FROM capability WHERE id={ctx('cap')})='composition';
"""
# Preserve per-occurrence evidence without duplicating a relationship's content.
P['relation.remember'] = f"""
INSERT OR IGNORE INTO assertion(subject,predicate,object,epistemic,evidence) VALUES({aid(1)},{aid(2)},{aid(3)},'CLAIM',:origin);
{setpad(assertion=f"(SELECT id FROM assertion WHERE subject={aid(1)} AND predicate={aid(2)} AND object={aid(3)} AND epistemic='CLAIM' AND source IS NULL)")}
INSERT INTO assertion_evidence(assertion,event) VALUES({ctx('assertion')},:origin);
{result(f"json_object('state','CLAIM','assertion',{ctx('assertion')},'evidence',:origin)")}
"""
# No scanning the event history to recover a source observation. One lesson
# event and explicit source JSON indices identify every imported observation.
P['source.observations'] = f"""
{event('SOURCE_LESSON',f"json_object('source',{ctx('source')},'capability',{ctx('cap')},'path','$.examples','requested_by',:origin)")}
{setpad(lesson_event='last_insert_rowid()')}
INSERT INTO example(capability,x,y,evidence,source,source_index,previous)
 SELECT {ctx('cap')},finite_real(json_extract(j.value,'$[0]')),finite_real(json_extract(j.value,'$[1]')),
 {ctx('lesson_event')},{ctx('source')},j.key,(SELECT id FROM example WHERE capability={ctx('cap')} AND x=finite_real(json_extract(j.value,'$[0]')) ORDER BY id DESC LIMIT 1)
 FROM json_each({ctx('lesson')},'$.examples') j
 WHERE NOT EXISTS(SELECT 1 FROM example e WHERE e.capability={ctx('cap')} AND e.source={ctx('source')} AND e.source_index=j.key);
UPDATE binding SET state='pending',epoch=epoch+1 WHERE capability={ctx('cap')};
{schedule_fit(ctx('cap'))}
{result(f"json_object('state','OBSERVATION','capability',{ctx('cap')},'source',{ctx('source')},'learning','queued','truth','source-claims-not-automatically-facts')")}
UPDATE run SET pad=json_remove(pad,'$.lesson') WHERE id=:run;
"""
# Archive at END, after its gate has entered the physical execution trace.
# This avoids leaving an unarchived END trace after every completed run.
P['run.end'] = P.pop('memory.store') + '\n' + P['run.end']

# Geometric projection is based on actual coordinate-version rows. No missing
# position is replaced by 0, and no directional similarity becomes a fact.
proc('geometry.shape',f"""
{setpad(target=f'CAST(finite_real({arg(1)}) AS INTEGER)')}
{setpad(record=f"(SELECT CAST(o.bytes AS TEXT) FROM run_receipt rr JOIN memory m ON m.id=rr.memory JOIN object o ON o.id=m.body WHERE rr.run={ctx('target')})")}
WITH points AS (
 SELECT j.key AS ordinal,json_extract(j.value,'$[0]') AS gate,
 (SELECT p.id FROM position p WHERE p.gate=json_extract(j.value,'$[0]') AND p.context=0 ORDER BY p.id DESC LIMIT 1) AS position
 FROM json_each({ctx('record')},'$.route') j)
UPDATE run SET pad=json_set(pad,'$.points',json((SELECT json_group_array(json_object('ordinal',ordinal,'gate',points.gate,'position_version',points.position,'x',p.x,'y',p.y,'z',p.z)) FROM points LEFT JOIN position p ON p.id=points.position))) WHERE id=:run;
INSERT INTO shape_projection(run,state,signature,path,evidence)
 SELECT {ctx('target')},CASE WHEN {ctx('record')} IS NULL THEN 'UNKNOWN' WHEN EXISTS(SELECT 1 FROM json_each({ctx('points')}) WHERE json_extract(value,'$.position_version') IS NULL) THEN 'INCOMPLETE' ELSE 'HYPOTHESIS' END,
 CASE WHEN NOT EXISTS(SELECT 1 FROM json_each({ctx('points')}) WHERE json_extract(value,'$.position_version') IS NULL) AND {ctx('record')} IS NOT NULL THEN sha256({ctx('points')}) END,{ctx('points')},:origin
 WHERE EXISTS(SELECT 1 FROM run WHERE id={ctx('target')})
 ON CONFLICT(run) DO UPDATE SET state=excluded.state,signature=excluded.signature,path=excluded.path,evidence=excluded.evidence;
{result(f"json_object('state',coalesce((SELECT state FROM shape_projection WHERE run={ctx('target')}),'UNKNOWN'),'target_run',{ctx('target')},'positions',json({ctx('points')}),'semantic_geometry','not-validated','evidence',:origin)")}
""")
command('shape','geometry.shape',1,1,'shape RUN_ID')

# Do not let a shortcut validate itself. Only observations produced by the
# retained, two-child long form may teach its replacement.
P['apply.collect']=P['apply.collect'].replace(
    f"(SELECT kind FROM capability WHERE id={ctx('cap')})='composition'",
    f"(SELECT kind FROM capability WHERE id={ctx('cap')})='composition' AND (SELECT state FROM binding WHERE capability={ctx('cap')})='told-composition'")
P['math.result']=P['math.result'].replace("'basis','validated-examples-not-universal-proof'", "'basis','validated-examples-not-universal-proof','epistemic','HYPOTHESIS','execution','deterministic-model-evaluation'")

proc('language.alias',f"""
{setpad(existing=f'(SELECT entry FROM command WHERE atom={aid(2)})',conflict=f'EXISTS(SELECT 1 FROM command WHERE atom={aid(1)})')}
INSERT INTO command(atom,entry,min_args,max_args,usage,provenance)
 SELECT {aid(1)},entry,min_args,max_args,{arg(1)}||' : '||usage,:origin FROM command WHERE atom={aid(2)} AND NOT {ctx('conflict')};
INSERT OR IGNORE INTO label(atom,gate,sense) SELECT {aid(1)},{ctx('existing')},'instruction' WHERE {ctx('existing')} IS NOT NULL AND NOT {ctx('conflict')};
{result(f"json_object('state',CASE WHEN {ctx('existing')} IS NOT NULL AND NOT {ctx('conflict')} THEN 'TOLD' ELSE 'UNKNOWN' END,'label',{arg(1)},'existing_action',{arg(2)},'gate',{ctx('existing')},'evidence',:origin,'scope','exact-instruction-alias-not-natural-language-learning')")}
""")
command('alias','language.alias',2,2,'alias NEW_WORD EXISTING_COMMAND')

# Revision/side-effect dependency of this finite numeric process family. These
# are explicit graph dependencies, not an untracked cache hidden in the host.
def spine_stamp():
    gates = "(SELECT value FROM json_each((SELECT value FROM meta WHERE key='numeric-spine')))"
    ds = f"(SELECT json_group_array(json_array(gate,dna)) FROM (SELECT gate,dna FROM active_dna WHERE gate IN{gates} ORDER BY gate,dna))"
    es = f"(SELECT json_group_array(json_array(id,dna,target,role)) FROM (SELECT id,dna,target,role FROM excitation WHERE dna IN(SELECT dna FROM active_dna WHERE gate IN{gates}) ORDER BY id))"
    return f"sha256(json_array(json({ds}),json({es})))"
def pure_family(cap):
    return f"""(WITH RECURSIVE closure(cap) AS (VALUES({cap}) UNION SELECT d.child FROM dependency d JOIN closure c ON d.parent=c.cap)
    SELECT NOT EXISTS(SELECT 1 FROM excitation e WHERE e.dna IN(SELECT b.dna FROM binding b JOIN closure c ON b.capability=c.cap)
    OR e.dna IN(SELECT a.dna FROM active_dna a WHERE a.gate IN(SELECT value FROM json_each((SELECT value FROM meta WHERE key='numeric-spine'))))))"""
# The fingerprint records the currently operative primitives as well as the
# formula's versions. A changed multiply shard cannot leave an old cached answer valid.
P['apply.evaluate']=P['apply.evaluate'].replace(
    setpad(signature=f"sha256(json_array({ctx('cap')},{ctx('x')},{ctx('fingerprint')}))"),
    setpad(signature=f"sha256(json_array({ctx('cap')},{ctx('x')},{ctx('fingerprint')},{spine_stamp()}))",pure=pure_family(ctx('cap'))))
P['apply.evaluate']=P['apply.evaluate'].replace(
    f"(SELECT result FROM cache WHERE signature={ctx('signature')})",
    f"(SELECT result FROM cache WHERE signature={ctx('signature')} AND {ctx('pure')}=1)")
P['apply.collect']=P['apply.collect'].replace("AND json_extract(result,'$.state')='DERIVED';",f"AND json_extract(result,'$.state')='DERIVED' AND {ctx('pure')}=1;")
# Only original pure computations can be observations for a replacement.
P['apply.collect']=P['apply.collect'].replace(
    f"(SELECT state FROM binding WHERE capability={ctx('cap')})='told-composition'",
    f"(SELECT state FROM binding WHERE capability={ctx('cap')})='told-composition' AND {ctx('pure')}=1")
# A primitive revision must also invalidate any learned composition shortcut.
for name in ['learn.fit','dependency.refresh','apply.evaluate']:
    # Substitute all leaf dependency fingerprints in these bodies. Avoid adding
    # runtime special cases in C; the dependency is a graph-owned expression.
    for expr in [dep_expression(ctx('cap')),dep_expression('b.capability'),dep_expression('binding.capability')]:
        P[name]=P[name].replace(expr,f"sha256(json_array({expr},{spine_stamp()}))")

# Generated code is content-addressed by the bytes the SQL-atom run emits,
# rather than by a convenient name for the recipe.
P['sql.table']=P['sql.table'].replace(
    f"sha256('table:'||{ctx('table_name')})",
    f"(SELECT sha256(group_concat(text,'')) FROM (SELECT CASE WHEN ca.pos=t.hole THEN {ctx('quoted_identifier')} ELSE a.text END AS text FROM sql_template t JOIN code_atom ca ON ca.code=t.code JOIN spelling sp ON sp.gate=ca.gate JOIN atom a ON a.id=sp.atom WHERE t.name='create-user-table' ORDER BY ca.pos))")

# An unresolved negative correction cannot be erased by re-fitting only the old
# favorable examples. A later example at the challenged input (or a later yes)
# provides new evidence; neither silently rewrites the original feedback.
P['learn.check']=setpad(unresolved=f"""(SELECT count(*) FROM feedback f JOIN run r ON r.id=f.run
 WHERE f.id=(SELECT max(n.id) FROM feedback n WHERE n.run=f.run) AND f.verdict='incorrect'
 AND json_extract(r.result,'$.capability')={ctx('cap')}
 AND NOT EXISTS(SELECT 1 FROM example e WHERE e.capability={ctx('cap')} AND e.x=json_extract(r.result,'$.x') AND e.evidence>=f.evidence))""")+P['learn.check']
P['learn.check']=P['learn.check'].replace(
    f"WHEN {ctx('fails')}>0 THEN 'rejected'",f"WHEN {ctx('fails')}>0 OR {ctx('unresolved')}>0 THEN 'rejected'")

# Reuse an already constructed physical SQL procedure; a second occurrence is
# not a second definition of the same procedure.
P['sql.table']=P['sql.table'].replace(
    "INSERT INTO gate(born,kind) VALUES(:origin,'process');",
    f"INSERT INTO gate(born,kind) SELECT :origin,'process' WHERE NOT EXISTS(SELECT 1 FROM dna WHERE program={ctx('generated_code')});")
P['sql.table']=P['sql.table'].replace(
    setpad(generated_gate='last_insert_rowid()'),
    setpad(generated_gate=f"coalesce((SELECT gate FROM dna WHERE program={ctx('generated_code')} ORDER BY id LIMIT 1),last_insert_rowid())"))
P['sql.table']=P['sql.table'].replace(
    f"INSERT INTO dna(gate,program,provenance) VALUES({ctx('generated_gate')},{ctx('generated_code')},:origin);",
    f"INSERT INTO dna(gate,program,provenance) SELECT {ctx('generated_gate')},{ctx('generated_code')},:origin WHERE NOT EXISTS(SELECT 1 FROM dna WHERE gate={ctx('generated_gate')} AND program={ctx('generated_code')});")
P['sql.table']=P['sql.table'].replace(
    f"INSERT INTO active_dna(dna,gate,arrival_key,head_key,head_mode) VALUES(last_insert_rowid(),{ctx('generated_gate')},-1,-1,'any');",
    f"INSERT OR IGNORE INTO active_dna(dna,gate,arrival_key,head_key,head_mode) SELECT id,gate,-1,-1,'any' FROM dna WHERE gate={ctx('generated_gate')} AND program={ctx('generated_code')};")

# A failed required branch makes the parent's compilation incomplete.
for name in ['apply.join','ask.join']:
    P[name]+= """
UPDATE run SET result=json_set(result,'$.state','INCOMPLETE','$.failed_branches',json((SELECT json_group_array(json_object('run',id,'role',role,'result',json(result))) FROM run child WHERE child.parent=:run AND child.state='fault')))
 WHERE id=:run AND EXISTS(SELECT 1 FROM run child WHERE child.parent=:run AND child.state='fault');
"""

# Position at execution time, not current position during later recollection.
P['run.end']=P['run.end'].replace("json_array(gate,dna)) FROM (SELECT gate,dna FROM trace", "json_array(gate,dna,position)) FROM (SELECT gate,dna,position FROM trace")
P['geometry.place']=P['geometry.place'].replace(
    f"(SELECT gate FROM capability WHERE name={aid(1)})",
    f"(SELECT min(gate) FROM label WHERE atom={aid(1)} HAVING count(DISTINCT gate)=1)")
command('coordinates','geometry.place',4,4,'coordinates UNAMBIGUOUS_GATE_LABEL X Y Z')
P['geometry.shape']=P['geometry.shape'].replace(
    "(SELECT p.id FROM position p WHERE p.gate=json_extract(j.value,'$[0]') AND p.context=0 ORDER BY p.id DESC LIMIT 1) AS position",
    "json_extract(j.value,'$[2]') AS position")
# Replace the final output with a pointer to a matching step, preserving the
# projected positions and incomplete cases.
a=P['geometry.shape'].rfind('UPDATE run SET result=')
P['geometry.shape']=P['geometry.shape'][:a]+prepend(seq('geometry.match'))
proc('geometry.match',f"""
WITH pts AS (SELECT key AS ord,json_extract(value,'$.x') AS x,json_extract(value,'$.y') AS y,json_extract(value,'$.z') AS z FROM json_each({ctx('points')})),
 delta AS (SELECT ord,x-lag(x) OVER(ORDER BY ord) AS dx,y-lag(y) OVER(ORDER BY ord) AS dy,z-lag(z) OVER(ORDER BY ord) AS dz FROM pts)
UPDATE run SET pad=json_set(pad,'$.shape',json((SELECT json_group_array(json_array(dx,dy,dz)) FROM delta WHERE ord>0))) WHERE id=:run;
UPDATE shape_projection SET signature=sha256({ctx('shape')}) WHERE run={ctx('target')} AND state='HYPOTHESIS';
{event('SHAPE_PROJECTION',f"json_object('target_run',{ctx('target')},'positions',json({ctx('points')}),'deltas',json({ctx('shape')}),'source','recorded-coordinate-versions')")}
{result(f"json_object('state',coalesce((SELECT state FROM shape_projection WHERE run={ctx('target')}),'UNKNOWN'),'target_run',{ctx('target')},'positions',json({ctx('points')}),'translation_invariant_deltas',json({ctx('shape')}),'same_shape_candidates',json((SELECT json_group_array(run) FROM shape_projection WHERE signature=(SELECT signature FROM shape_projection WHERE run={ctx('target')}) AND run<>{ctx('target')})),'semantic_equivalence','NOT_INFERRED')")}
""")
