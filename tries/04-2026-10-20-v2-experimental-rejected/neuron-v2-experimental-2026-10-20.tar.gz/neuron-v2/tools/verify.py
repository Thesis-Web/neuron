#!/usr/bin/env python3
"""External reproducible live audit. Not imported by or used by Neuron.
Every normal test drives the compiled binary's text input, then reads its rows.
Perturbation tests make explicit isolated-copy edits to test architectural claims.
No model calls. No tests or data are installed into the working brain.
"""
from __future__ import annotations
import hashlib, json, math, os, random, re, shutil, sqlite3, subprocess, sys, tempfile, time, traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
BIN=Path(os.environ.get('NEURON_BIN',str(ROOT/'neuron'))).resolve()
LOG=[]; RESULTS=[]; START=time.perf_counter()

def demand(value,detail):
    if not value:raise AssertionError(detail)

class Brain:
    def __init__(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='neuron-v2-audit-')
        self.dir=Path(self.tmp.name);self.path=self.dir/'brain.db'
        (self.dir/'sources/inbox').mkdir(parents=True)
        p=subprocess.run([str(BIN),str(self.path),'--init',str(ROOT/'seed.sql')],capture_output=True,text=True,timeout=20)
        demand(p.returncode==0,p.stderr)
    def close(self):self.tmp.cleanup()
    def sql(self,q,args=()):
        with sqlite3.connect(self.path) as c:return c.execute(q,args).fetchall()
    def one(self,q,args=()):
        rows=self.sql(q,args);return rows[0][0] if rows else None
    def say(self,line,allow_fault=False):
        start=time.perf_counter()
        p=subprocess.run([str(BIN),str(self.path),'--say',line],capture_output=True,text=True,timeout=20)
        objects=[json.loads(x) for x in p.stdout.splitlines() if x.strip()]
        LOG.append({'input':line,'seconds':time.perf_counter()-start,'returncode':p.returncode,'outputs':objects,'stderr':p.stderr})
        demand(p.returncode in (0,3),f'process failure: {line}\n{p.stderr}')
        if not allow_fault:
            demand(p.returncode==0,f'fault: {line}: {objects}\n{p.stderr}')
            demand(not any(x.get('reason') and 'state' not in x for x in objects),str(objects))
        demand(objects,'no output: '+line)
        roots=self.sql("SELECT id FROM run WHERE role='input' ORDER BY id DESC LIMIT 1")
        rid=roots[0][0]
        root=next((x for x in reversed(objects) if x.get('run')==rid),objects[-1])
        return root
    def teach(self,name,a,b,xs=(-3,2,7)):
        for x in xs:self.say(f'example {name} {x} {a*x+b}')
        return self.one('SELECT c.id FROM capability c JOIN atom a ON a.id=c.name WHERE a.text=?',(name,))
    def inject(self,gate,body,arrival=None,head=None,head_mode='any',replace=True):
        """Test-only mutation of an isolated database; not claimed as learning."""
        with sqlite3.connect(self.path) as c:
            event=c.execute("INSERT INTO event(kind,actor,detail) VALUES('AUDIT_PERTURBATION','external-auditor','{}')").lastrowid
            dg=hashlib.sha256(body.encode()).hexdigest()
            code=c.execute('INSERT INTO code(digest,provenance) VALUES(?,?)',(dg,event)).lastrowid
            tokens=re.findall(r'[A-Za-z_][A-Za-z_0-9]*|[0-9]+|\s+|[^\w\s]|\w',body)
            demand(''.join(tokens)==body,'bad perturbation lexer')
            for pos,text in enumerate(tokens):
                c.execute('INSERT OR IGNORE INTO atom(text) VALUES(?)',(text,))
                atom=c.execute('SELECT id FROM atom WHERE text=?',(text,)).fetchone()[0]
                old=c.execute('SELECT gate FROM spelling WHERE atom=?',(atom,)).fetchone()
                if old:g=old[0]
                else:
                    g=c.execute("INSERT INTO gate(born,kind) VALUES(?,'sql-atom')",(event,)).lastrowid
                    c.execute('INSERT INTO spelling VALUES(?,?)',(g,atom))
                c.execute('INSERT INTO code_atom VALUES(?,?,?)',(code,pos,g))
            dna=c.execute('INSERT INTO dna(gate,arrival,head,head_mode,program,provenance) VALUES(?,?,?,?,?,?)',(gate,arrival,head,head_mode,code,event)).lastrowid
            if replace:c.execute('DELETE FROM active_dna WHERE gate=? AND arrival_key=? AND head_key=? AND head_mode=?',(gate,arrival if arrival is not None else -1,head if head is not None else -1,head_mode))
            c.execute('INSERT INTO active_dna VALUES(?,?,?,?,?)',(dna,gate,arrival if arrival is not None else -1,head if head is not None else -1,head_mode))
        return dna
    def gate(self,name):return self.one('SELECT l.gate FROM label l JOIN atom a ON a.id=l.atom WHERE a.text=?',(name,))
    def route(self,run):
        text=self.one('SELECT CAST(o.bytes AS TEXT) FROM run_receipt r JOIN memory m ON m.id=r.memory JOIN object o ON o.id=m.body WHERE r.run=?',(run,))
        return json.loads(text)['route'] if text else []
    def descendant_steps(self,root):return self.one('SELECT sum(steps) FROM run WHERE root=?',(root,))


def case(fn):
    start=time.perf_counter();b=Brain()
    try:
        detail=fn(b) or {}
        demand(b.sql('PRAGMA foreign_key_check')==[],'foreign-key corruption')
        demand(b.one('PRAGMA integrity_check')=='ok','SQLite integrity failure')
        RESULTS.append({'test':fn.__name__,'status':'PASS','seconds':time.perf_counter()-start,'evidence':detail})
        print('PASS',fn.__name__,flush=True)
    except Exception:
        RESULTS.append({'test':fn.__name__,'status':'FAIL','traceback':traceback.format_exc()})
        print('FAIL',fn.__name__,traceback.format_exc(),flush=True)
    finally:b.close()


def fresh_seed_is_not_pretaught_experience(b):
    demand(b.one('SELECT count(*) FROM example')==0,'seed examples')
    demand(b.one('SELECT count(*) FROM model')==0,'seed models')
    demand(b.one('SELECT count(*) FROM capability')==0,'seed acquired capabilities')
    out=b.say('Who are you?')
    demand(out['state']=='UNKNOWN','canned or invented identity')
    demand(b.one('SELECT count(*) FROM gate')>0,'invalid gate count')
    return {'unknown_input':out,'seed_has_no_examples_models_or_capabilities':True}

def source_and_executable_content_hashes(b):
    programs=b.sql('SELECT id,digest FROM code')
    for code,digest in programs:
        body=''.join(row[0] for row in b.sql('SELECT a.text FROM code_atom p JOIN spelling s ON s.gate=p.gate JOIN atom a ON a.id=s.atom WHERE p.code=? ORDER BY p.pos',(code,)))
        demand(hashlib.sha256(body.encode()).hexdigest()==digest,f'code hash {code}')
    for digest,body in b.sql('SELECT sha256,bytes FROM object'):
        demand(hashlib.sha256(body).hexdigest()==digest,'object content hash')
    return {'code_programs_verified':len(programs)}

def candidate_is_not_executable_truth(b):
    b.say('example unnamed 1 5');b.say('example unnamed 4 11')
    out=b.say('run unnamed 9')
    demand(out['state']=='UNKNOWN','two fitting points improperly accepted')
    demand(b.one("SELECT state FROM binding")=='candidate','candidate standing')
    b.say('example unnamed 8 19')
    out=b.say('run unnamed 9')
    demand(out['value']==21 and out['epistemic']=='HYPOTHESIS','held-out adoption or epistemic state')
    return {'answer_after_holdout':out}

def independent_varied_affine_inputs(b):
    rng=random.Random(71216028);trials=[]
    for i in range(12):
        a=rng.randint(-12,12);offset=rng.randint(-50,50)
        xs=rng.sample(range(-20,21),3);name=f'probe_{i}'
        b.teach(name,a,offset,xs)
        x=rng.randint(35,120);out=b.say(f'run {name} {x}')
        demand(math.isclose(out['value'],a*x+offset,rel_tol=1e-10,abs_tol=1e-10),str(out))
        trials.append({'a':a,'b':offset,'training_x':xs,'new_x':x,'result':out['value']})
    return {'trials':trials,'domain':'finite affine functions only'}

def duplicate_input_reuses_but_still_fires_questions(b):
    b.teach('m',3,-4);one=b.say('run m 31');two=b.say('run m 31')
    demand(one['reuse']=='executed' and two['reuse']=='cache','no actual reuse')
    roles=b.sql('SELECT role FROM run WHERE parent=? ORDER BY role',(two['run'],))
    demand(roles==[('confidence',),('evaluate',)],str(roles))
    demand(b.one('SELECT count(*) FROM trace')==0,'unarchived steps left behind')
    demand(b.descendant_steps(two['run'])<b.descendant_steps(one['run']),'cache did not reduce work')
    return {'long_steps':b.descendant_steps(one['run']),'cache_steps':b.descendant_steps(two['run']),'questions_preserved':roles}

def self_observation_changes_own_executable_structure(b):
    b.teach('f',2,1);b.say('compose ff f f')
    cap=b.one("SELECT id FROM capability WHERE kind='composition'")
    original=b.one('SELECT dna FROM binding WHERE capability=?',(cap,))
    long=b.say('run ff 4');b.say('run ff 5');b.say('run ff 8')
    current=b.one('SELECT dna FROM binding WHERE capability=?',(cap,))
    demand(current!=original,'no generated executable revision')
    shorter=b.say('run ff 11')
    demand(shorter['value']==47,'shorter result')
    demand(b.descendant_steps(shorter['run'])<b.descendant_steps(long['run']),'not actually shorter')
    count=b.one('SELECT count(*) FROM example WHERE capability=?',(cap,))
    b.say('run ff 12');b.say('run ff 13')
    demand(b.one('SELECT count(*) FROM example WHERE capability=?',(cap,))==count,'shortcut used to validate itself')
    demand(b.one('SELECT count(*) FROM dna WHERE id=?',(original,))==1,'old executable erased')
    return {'old_dna':original,'new_dna':current,'long_total_steps':b.descendant_steps(long['run']),'short_total_steps':b.descendant_steps(shorter['run']),'source_observations':count}

def changed_dependency_invalidates_specialization_and_cache(b):
    b.teach('f',2,1,(1,2,7));b.say('compose ff f f')
    for x in [4,5,8]:b.say(f'run ff {x}')
    old=b.say('run ff 9');b.say('run ff 9')
    b.say('example f 1 4')
    bad=b.say('run ff 9');demand(bad['state']=='UNKNOWN','stale shortcut answered')
    b.say('example f 2 7');b.say('example f 7 22')
    new=b.say('run ff 9');demand(new['value']==85,'long form not restored with new dependency')
    demand(new['signature']!=old['signature'],'cache version missing')
    demand(b.one("SELECT count(*) FROM event WHERE kind='SPECIALIZATION_INVALIDATED'")>0,'no invalidation evidence')
    oldrecord=b.say('why '+str(old['run']))
    demand(oldrecord['record']['result']['value']==39,'history rewritten')
    return {'before':old['value'],'during':bad['state'],'after':new['value'],'historical_result_preserved':True}

def negative_feedback_cannot_be_laundered_by_old_examples(b):
    b.teach('f',2,1);pred=b.say('run f 11');b.say(f'no {pred["run"]}')
    demand(b.say('run f 11')['state']=='UNKNOWN','ignored rejection')
    b.say('example f -3 -5')
    demand(b.say('run f 11')['state']=='UNKNOWN','old examples erased negative evidence')
    corr=b.say(f'correct {pred["run"]} 23')
    demand(corr['state']=='OBSERVATION','correction not recorded')
    out=b.say('run f 11');demand(out['value']==23,'corrected evidence did not reconnect')
    return {'corrected_run':pred['run'],'later_answer':out['value'],'negative_feedback_retained':b.one('SELECT count(*) FROM feedback')}

def nonlinear_counterexample_remains_rejected(b):
    for x in [1,2,3]:b.say(f'example square {x} {x*x}')
    out=b.say('run square 4');demand(out['state']=='UNKNOWN','invented out-of-family solution')
    demand(b.one('SELECT state FROM binding')=='rejected','counterexample ignored')
    return {'response':out,'search_space':'no quadratic capability claimed'}

def relations_have_shared_content_and_distinct_evidence(b):
    a=b.say('remember sparrow kind bird');a2=b.say('remember sparrow kind bird')
    demand(a['assertion']==a2['assertion'],'duplicate relation content')
    demand(b.one('SELECT count(*) FROM assertion_evidence')==2,'lost recurrence evidence')
    d=b.say('remember bird kind animal')
    b.say(f'support {a["assertion"]}');b.say(f'support {d["assertion"]}');b.say('rule kind transitive')
    out=b.say('ask sparrow kind');paths=out['derived']['derivations']
    demand(any(x['object']=='animal' and x['proof']==[a['assertion'],d['assertion']] for x in paths),'missing path evidence')
    b.say(f'reject {d["assertion"]}');after=b.say('ask sparrow kind')
    demand(after['derived']['derivations']==[],'rejected support still used')
    return {'before':paths,'after_rejection':after['derived']['derivations']}

def contradicting_claims_are_not_silently_resolved(b):
    b.say('remember sky color blue');b.say('remember sky color green')
    out=b.say('ask sky color');objects={x['object'] for x in out['direct']['claims']}
    demand(objects=={'blue','green'},'picked a convenient claim')
    demand(all(x['epistemic']=='CLAIM' for x in out['direct']['claims']),'upgraded user statement')
    return {'unreconciled_claims':sorted(objects)}

def raw_source_is_preserved_and_not_executed(b):
    body='{"examples":[[2,7],[3,10],[8,25]],"instruction":"DROP TABLE event;", "note":"café — source"}\n'
    (b.dir/'sources/inbox/reference.json').write_text(body)
    src=b.say('source file:reference.json')
    demand(src['sha256']==hashlib.sha256(body.encode()).hexdigest(),'source byte mismatch')
    demand(src['semantic_status']=='UNINTERPRETED','capture misrepresented as understanding')
    b.say(f'observe calibration {src["source"]}')
    out=b.say('run calibration 11');demand(out['value']==34,'source observation fit')
    demand(b.one('SELECT count(*) FROM event')>0,'source instruction executed')
    rows=b.sql('SELECT source,source_index FROM example ORDER BY id')
    demand(rows==[(src['source'],0),(src['source'],1),(src['source'],2)],str(rows))
    quote=b.say(f'quote {src["source"]} 0 20')
    demand(quote['excerpt']==body[:20],'quote not exact')
    for invalid in (b'prefix\x00suffix', b'\xff'):
        (b.dir/'sources/inbox/invalid.bin').write_bytes(invalid)
        rejected=b.say('source file:invalid.bin')
        demand(rejected['state']=='UNAVAILABLE','non-text source was silently truncated')
    repeat=b.say('source file:reference.json')
    demand(repeat['source']==src['source'],'duplicate source identity')
    return {'source':src,'source_example_spans':rows,'prediction':out['value'],'raw_bytes_retained':True}

def unstructured_source_is_not_falsely_read_as_lesson(b):
    (b.dir/'sources/inbox/prose.txt').write_text('Here is a textbook, not a JSON table of observations.')
    src=b.say('source file:prose.txt');out=b.say(f'observe story {src["source"]}')
    demand(out['state']=='UNKNOWN','pretended to understand the textbook')
    return out

def source_files_cannot_escape_inbox(b):
    outside=b.dir/'do-not-read.txt';outside.write_text('private-test-fixture')
    (b.dir/'sources/inbox/link').symlink_to(outside)
    a=b.say('source file:../../do-not-read.txt');s=b.say('source file:link')
    demand(a['state']=='UNAVAILABLE' and s['state']=='UNAVAILABLE','inbox escape')
    demand('private-test-fixture' not in json.dumps([a,s]),'read private fixture')
    n=b.say('source https://127.0.0.1/private')
    demand(n['state']=='UNAVAILABLE','unapproved host')
    return {'traversal':a['state'],'symlink':s['state'],'network_host':n['state']}

def sql_is_built_from_shared_atoms_and_executes(b):
    out=b.say('table notebook')
    demand(out['state']=='OBSERVATION','table build failed')
    code=out['program_code'];words=b.sql('SELECT a.text FROM code_atom c JOIN spelling s ON s.gate=c.gate JOIN atom a ON a.id=s.atom WHERE c.code=? ORDER BY c.pos',(code,))
    text=''.join(x[0] for x in words)
    demand('CREATE' in [x[0] for x in words] and 'TABLE' in [x[0] for x in words] and 'INTEGER' in [x[0] for x in words],'not separated atoms')
    demand(b.one("SELECT name FROM sqlite_schema WHERE name='u_notebook'")=='u_notebook','no physical effect')
    demand(b.one('SELECT digest FROM code WHERE id=?',(code,))==hashlib.sha256(text.encode()).hexdigest(),'generated code not content addressed')
    gates=b.one('SELECT count(*) FROM gate');again=b.say('table notebook',allow_fault=True)
    demand('already exists' in json.dumps(again),'duplicate create falsely successful')
    demand(b.one('SELECT count(*) FROM gate')==gates,'same code allocated another gate')
    return {'program':text,'code':code,'second_request':'recorded failure, no duplicate program gate'}

def quoted_names_cannot_inject_sql(b):
    name='sneaky"; DROP TABLE event; --'
    out=b.say('table '+json.dumps(name))
    demand(out['created_table']=='u_'+name,'identifier damaged')
    demand(b.one('SELECT count(*) FROM event')>0,'SQL injection')
    return {'quoted_identifier_created':True,'event_history_intact':True}

def invalid_numbers_never_become_zero(b):
    n=b.one('SELECT count(*) FROM capability');b.say('example counterfeit nonsense 9',allow_fault=True)
    demand(b.one('SELECT count(*) FROM capability')==n,'failed step left partial capability')
    demand(b.one("SELECT count(*) FROM example WHERE x=0")==0,'invalid turned into zero')
    b.say('example counterfeit 2 NaN',allow_fault=True)
    demand(b.one('SELECT count(*) FROM capability')==n,'NaN left partial data')
    b.say('remember "unterminated',allow_fault=True)
    demand(b.one("SELECT count(*) FROM event WHERE kind='FAULT'")==3,'missing fault evidence')
    return {'faults_recorded':3,'partial_semantic_changes':0}

def memory_consolidation_retains_exact_history(b):
    b.teach('f',4,-2);out=b.say('run f 6')
    ids=b.sql('SELECT id,sha256,bytes FROM object');original={i:(h,bytes(v)) for i,h,v in ids}
    receipt=b.one('SELECT memory FROM run_receipt WHERE run=?',(out['run'],))
    s=b.say('sleep');rec=b.say(f'recall {receipt}')
    demand(rec['record']['result']['value']==22,'recall changed result')
    now={i:(h,bytes(v)) for i,h,v in b.sql('SELECT id,sha256,bytes FROM object')}
    demand(all(now[i]==v for i,v in original.items()),'source destructively compressed')
    demand(s['loss']=='none','unexpected loss flag')
    demand(b.one('SELECT count(*) FROM trace')==0,'trace was not interned')
    return {'exact_objects_unchanged':len(original),'recall':receipt,'highlight_retains_exact_pointer':True}

def alias_changes_the_graph_not_the_executable(b):
    before=hashlib.sha256(BIN.read_bytes()).hexdigest()
    a=b.say('alias keep remember');b.say('keep wheel part bicycle')
    out=b.say('ask wheel part')
    demand(a['state']=='TOLD' and out['direct']['claims'][0]['object']=='bicycle','alias failed')
    demand(before==hashlib.sha256(BIN.read_bytes()).hexdigest(),'external executable changed')
    return {'new_label':'keep','meaning':'explicit told instruction alias only','binary_unchanged':True}

def dna_arrival_selection_changes_behavior_and_invalidates_cache(b):
    b.teach('f',2,1);b.teach('g',3,2)
    old=b.say('run f 13');b.say('run f 13')
    fgate=b.one('SELECT gate FROM capability c JOIN atom a ON a.id=c.name WHERE a.text=?',('f',))
    mult=b.gate('math.multiply')
    dna=b.inject(mult,"UPDATE run SET pad=json_set(pad,'$.value',finite_real(json_extract(:ctx,'$.x')*json_extract(:ctx,'$.a')+10)) WHERE id=:run;",arrival=fgate)
    changed=b.say('run f 13');other=b.say('run g 13')
    demand(changed['value']==37 and changed['reuse']=='executed','DNA ignored or old cache reused')
    demand(other['value']==41,'arrival-specific behavior leaked')
    used=b.one("SELECT count(*) FROM object WHERE CAST(bytes AS TEXT) LIKE ?",(f'%[{mult},{dna},%',))
    demand(used>0,'selected DNA absent from receipt')
    return {'old':old['value'],'changed':changed['value'],'other_arrival':other['value'],'new_dna':dna}

def equal_specificity_is_a_fault_not_first_match(b):
    b.teach('f',2,1);fg=b.one('SELECT gate FROM capability');mult=b.gate('math.multiply');add=b.gate('math.add')
    a=b.inject(mult,"SELECT 101;",arrival=fg)
    h=b.inject(mult,"SELECT 202;",head=add,head_mode='exact')
    out=b.say('run f 14',allow_fault=True)
    demand(b.one("SELECT count(*) FROM event WHERE kind='FAULT' AND detail LIKE '%ambiguous%'")>0,'ambiguous DNA silently selected')
    demand(out.get('value') is None,'ambiguous result fabricated')
    return {'conflicting_dna':[a,h],'root':out}

def excitation_pointer_is_operational(b):
    b.teach('f',2,1)
    target=b.gate('apply.confidence');dna=b.inject(target,"INSERT INTO u_missing VALUES(1);")
    out=b.say('run f 17',allow_fault=True)
    demand(out['state']=='INCOMPLETE','failed required reasoning branch concealed')
    demand(out['failed_branches'][0]['role']=='confidence','wrong failed branch')
    return {'target_gate':target,'changed_dna':dna,'result_state':out['state']}

def failed_sql_step_rolls_back_its_prefix(b):
    gate=b.gate('system.status')
    b.inject(gate,"CREATE TABLE u_atomic(x); INSERT INTO u_missing VALUES(1);")
    b.say('status',allow_fault=True)
    demand(b.one("SELECT count(*) FROM sqlite_schema WHERE name='u_atomic'")==0,'partial CREATE committed')
    demand(b.one("SELECT count(*) FROM event WHERE kind='FAULT'")==1,'missing failure record')
    return {'table_after_failed_step':'absent','fault_record':'retained'}

def immutable_events_and_source_are_enforced(b):
    gate=b.gate('system.status');initial=b.one('SELECT count(*) FROM event')
    b.inject(gate,'DELETE FROM event;');b.say('status',allow_fault=True)
    demand(b.one('SELECT count(*) FROM event')>initial,'ledger deleted')
    demand('not authorized' in b.one("SELECT detail FROM event WHERE kind='FAULT' ORDER BY id DESC LIMIT 1"),'wrong fault')
    return {'delete_refused':True}

def physical_sql_read_results_are_not_discarded(b):
    # The first stored action reads rows. A following stored action consumes
    # those rows from the physical return channel and chooses to emit them.
    gate=b.gate('system.status'); child=b.gate('command.work')
    b.inject(child,"UPDATE run SET result=json_object('state','OBSERVATION','sql_rows',json(last_result)) WHERE id=:run;")
    b.inject(gate,f"SELECT 42,1.25,NULL,'kept',X'00ff'; UPDATE run SET rest=(SELECT json_group_array(value) FROM (SELECT {child} AS value UNION ALL SELECT value FROM json_each(rest))) WHERE id=:run;")
    out=b.say('status')
    demand(out['sql_rows']==[[42,1.25,None,'kept',{'blob_hex':'00ff'}]],'bridge discarded rows')
    return {'retained_rows':out['sql_rows']}


def geometry_records_versions_and_matches_without_claiming_meaning(b):
    b.teach('f',2,1)
    labels=['f','math.multiply','math.add','math.result','run.end']
    for n,label in enumerate(labels):b.say(f'coordinates {label} {n} {n%2} 0')
    first=b.say('run f 29')
    child=b.one("SELECT id FROM run WHERE root=? AND role='formula'",(first['run'],))
    shape1=b.say(f'shape {child}')
    demand(shape1['state']=='HYPOTHESIS','complete geometry not projected')
    versions=[p['position_version'] for p in shape1['positions']]
    for n,label in enumerate(labels):b.say(f'coordinates {label} {n+100} {n%2+50} 0')
    second=b.say('run f 30');child2=b.one("SELECT id FROM run WHERE root=? AND role='formula'",(second['run'],))
    shape2=b.say(f'shape {child2}')
    demand(child in shape2['same_shape_candidates'],'translation-invariant shape match absent')
    demand(shape2['semantic_equivalence']=='NOT_INFERRED','shape was promoted to meaning')
    old=b.say(f'shape {child}')
    demand([p['position_version'] for p in old['positions']]==versions,'historical shape silently moved')
    return {'first_run':child,'second_run':child2,'shape':shape2['translation_invariant_deltas'],'old_versions_preserved':True}

def working_queries_use_local_indexes(b):
    queries=[
      "SELECT id FROM task WHERE state='pending' ORDER BY id LIMIT 1",
      'SELECT * FROM active_dna WHERE gate=12',
      'SELECT * FROM assertion WHERE subject=4 AND predicate=7',
      'SELECT * FROM example WHERE capability=1 AND context=\'\' AND x=2 ORDER BY id DESC LIMIT 1',
      "SELECT * FROM cache WHERE signature='not-present'",
      "SELECT * FROM shape_projection WHERE signature='not-present'"]
    plans=[]
    for q in queries:
        plan=b.sql('EXPLAIN QUERY PLAN '+q);text=' '.join(str(r) for r in plan)
        demand('SEARCH' in text and 'SCAN ' not in text,q+': '+text)
        plans.append({'query':q,'plan':plan})
    return {'plans':plans,'claim':'these access paths only; not all corpus operations are scan-free'}

TESTS=[fresh_seed_is_not_pretaught_experience,source_and_executable_content_hashes,candidate_is_not_executable_truth,
 independent_varied_affine_inputs,duplicate_input_reuses_but_still_fires_questions,self_observation_changes_own_executable_structure,
 changed_dependency_invalidates_specialization_and_cache,negative_feedback_cannot_be_laundered_by_old_examples,
 nonlinear_counterexample_remains_rejected,relations_have_shared_content_and_distinct_evidence,contradicting_claims_are_not_silently_resolved,
 raw_source_is_preserved_and_not_executed,unstructured_source_is_not_falsely_read_as_lesson,source_files_cannot_escape_inbox,
 sql_is_built_from_shared_atoms_and_executes,quoted_names_cannot_inject_sql,invalid_numbers_never_become_zero,
 memory_consolidation_retains_exact_history,alias_changes_the_graph_not_the_executable,
 dna_arrival_selection_changes_behavior_and_invalidates_cache,equal_specificity_is_a_fault_not_first_match,
 excitation_pointer_is_operational,failed_sql_step_rolls_back_its_prefix,immutable_events_and_source_are_enforced,
 physical_sql_read_results_are_not_discarded,geometry_records_versions_and_matches_without_claiming_meaning,working_queries_use_local_indexes]
if __name__=='__main__':
    for test in TESTS:case(test)
    output=Path(os.environ.get('NEURON_AUDIT_OUT',str(ROOT/'evidence')));output.mkdir(parents=True,exist_ok=True)
    report={'status':'PASS' if all(x['status']=='PASS' for x in RESULTS) else 'FAIL',
      'full_neuron_acceptance':'NOT_DEMONSTRATED','tests':RESULTS,'passed':sum(x['status']=='PASS' for x in RESULTS),'total':len(RESULTS),
      'prompt_count':len(LOG),'seconds':time.perf_counter()-START,'seed_sha256':hashlib.sha256((ROOT/'seed.sql').read_bytes()).hexdigest(),
      'binary_sha256':hashlib.sha256(BIN.read_bytes()).hexdigest(),'platform':sys.platform,'python_audit_only':sys.version.split()[0],
      'network':'not used by standard audit','wsl_native_execution':'not run in this environment'}
    (output/'verification.json').write_text(json.dumps(report,indent=2))
    (output/'live-transcript.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in LOG))
    print(json.dumps({k:report[k] for k in ['status','passed','total','prompt_count','seconds','full_neuron_acceptance']},indent=2))
    sys.exit(0 if report['status']=='PASS' else 1)
