#!/usr/bin/env python3
"""Build-time only. Hand-lays the declared seed, never runs in the brain.

This is an explicit new V2 experimental design, not recovered historical law.
The delivered seed.sql is sufficient to install without running Python.
All cognition implemented by this experiment is in the resulting DNA/code rows.
"""
from pathlib import Path
import hashlib, json, re, sqlite3
ROOT = Path(__file__).resolve().parents[1]
P = {}
COMMANDS = []
def proc(name, body):
    P[name] = body.strip()
    return name

def arg(i):
    return f"(SELECT text FROM atom WHERE id=json_extract(:ctx,'$.args[{i}]'))"

def aid(i): return f"json_extract(:ctx,'$.args[{i}]')"
def ctx(k): return f"json_extract(:ctx,'$.{k}')"
def g(name): return f"@G({name})"
def seq(*names): return 'json_array('+','.join(g(n) for n in names)+')'
def prepend(expr, condition='1'):
    return f"UPDATE run SET rest=(SELECT json_group_array(value) FROM (SELECT value FROM json_each({expr}) UNION ALL SELECT value FROM json_each(run.rest))) WHERE id=:run AND ({condition});"
def setpad(**fields):
    args=','.join("'$."+k+"',"+v for k,v in fields.items())
    return f"UPDATE run SET pad=json_set(pad,{args}) WHERE id=:run;"
def result(expr): return f"UPDATE run SET result={expr} WHERE id=:run;"
def command(word, entry, low, high, usage): COMMANDS.append((word,entry,low,high,usage))
def fork(target, role, pad='pad', condition='1'):
    return f"INSERT INTO run(parent,root,origin,role,rest,pad,depth) SELECT id,root,origin,'{role}',{seq(target,'run.end')},{pad},depth+1 FROM run WHERE id=:run AND ({condition});"

def event(kind,detail):return f"INSERT INTO event(kind,actor,detail) VALUES('{kind}','neuron',{detail});"

def schedule_fit(cap):
    return f"INSERT OR IGNORE INTO task(subject,gate,evidence) VALUES({cap},{g('learn.fit')},:origin);"

proc('input.receive',f"""
{setpad(lex="json(lex((SELECT CAST(bytes AS TEXT) FROM object WHERE id=(SELECT body FROM input WHERE run=:run))))")}
INSERT OR IGNORE INTO atom(text) SELECT json_extract(value,'$.text') FROM json_each({ctx('lex')});
INSERT INTO input_token(run,pos,atom,start,length,kind)
 SELECT :run,j.key,a.id,json_extract(j.value,'$.start'),json_extract(j.value,'$.length'),json_extract(j.value,'$.kind')
 FROM json_each({ctx('lex')}) j JOIN atom a ON a.text=json_extract(j.value,'$.text');
UPDATE run SET pad=json_object('args',json((SELECT json_group_array(atom) FROM
 (SELECT atom FROM input_token WHERE run=:run AND kind<>'space' ORDER BY pos))),'task_budget',16) WHERE id=:run;
""")
proc('input.dispatch',f"""
{setpad(entry=f"(SELECT entry FROM command WHERE atom={aid(0)} AND json_array_length({ctx('args')})-1 BETWEEN min_args AND max_args)")}
{prepend(f'json_array({ctx("entry")})',f'{ctx("entry")} IS NOT NULL')}
UPDATE run SET result=json_object('state','UNKNOWN','uninterpreted_input',(SELECT body FROM input WHERE run=:run),
 'supported_syntax',coalesce((SELECT usage FROM command WHERE atom={aid(0)}),'help'),'authority','no-meaning-invented')
 WHERE id=:run AND {ctx('entry')} IS NULL;
""")
proc('output.emit',"""
INSERT INTO outbox(run,value) SELECT id,json_set(result,'$.run',id) FROM run WHERE id=:run AND result<>'{}';
""")
proc('memory.store',f"""
{setpad(memory_body="json_object('input',(SELECT body FROM input WHERE run=:run),'result',json((SELECT result FROM run WHERE id=:run)),'route',json((SELECT json_group_array(json_array(gate,dna)) FROM (SELECT gate,dna FROM trace WHERE run=:run ORDER BY step))))")}
INSERT OR IGNORE INTO object(sha256,bytes) VALUES(sha256({ctx('memory_body')}),CAST({ctx('memory_body')} AS BLOB));
INSERT OR IGNORE INTO memory(signature,body,kind,born) SELECT sha256({ctx('memory_body')}),id,'run',:origin FROM object WHERE sha256=sha256({ctx('memory_body')});
{setpad(memory="(SELECT id FROM memory WHERE signature=sha256(json_extract(:ctx,'$.memory_body')))")}
{event('RUN_END',f"json_object('run',:run,'memory',{ctx('memory')},'result_state',json_extract((SELECT result FROM run WHERE id=:run),'$.state'))")}
INSERT INTO occurrence(event,memory,run) VALUES(last_insert_rowid(),{ctx('memory')},:run);
INSERT INTO run_receipt(run,memory,ended) VALUES(:run,{ctx('memory')},(SELECT max(id) FROM event));
INSERT INTO memory_state(memory,tier,last_event) VALUES({ctx('memory')},'active',(SELECT max(id) FROM event))
 ON CONFLICT(memory) DO UPDATE SET uses=uses+1,last_event=excluded.last_event;
DELETE FROM trace WHERE run=:run;
UPDATE run SET pad=json_remove(pad,'$.memory_body','$.lex','$.fetched') WHERE id=:run;
""")
proc('run.end',"""
INSERT INTO landing(parent,child,result) SELECT parent,id,result FROM run WHERE id=:run AND parent IS NOT NULL;
UPDATE task SET state='done' WHERE run=:run;
UPDATE run SET state='done',rest='[]' WHERE id=:run;
""")
proc('work.choose',f"""
{setpad(task="(SELECT id FROM task WHERE state='pending' ORDER BY id LIMIT 1)")}
INSERT INTO run(parent,root,origin,role,rest,pad,depth)
 SELECT r.id,r.root,t.evidence,'learning',json_array(t.gate,{g('output.emit')},{g('run.end')}),json_object('cap',t.subject),r.depth+1
 FROM run r JOIN task t ON t.id={ctx('task')} WHERE r.id=:run AND coalesce({ctx('task_budget')},0)>0;
UPDATE task SET state='running',run=last_insert_rowid() WHERE id={ctx('task')} AND coalesce({ctx('task_budget')},0)>0;
{prepend(seq('work.choose'),f"{ctx('task')} IS NOT NULL AND coalesce({ctx('task_budget')},0)>0")}
UPDATE run SET state='waiting',pad=json_set(pad,'$.task_budget',json_extract(pad,'$.task_budget')-1)
 WHERE id=:run AND {ctx('task')} IS NOT NULL AND coalesce({ctx('task_budget')},0)>0;
""")
proc('command.work',result("json_object('state','OBSERVATION','action','drain-pending-work')"))
command('work','command.work',0,0,'work')
proc('command.help',result("json_object('state','DOCUMENTATION','syntax',json((SELECT json_group_array(usage) FROM command)))"))
command('help','command.help',0,0,'help')

# A name has no executable meaning until evidence or an explicit told program gives it one.
# The following helper is itself emitted into the graph; Python does not run it.
def ensure_cap(name_id):
    return f"""
INSERT INTO gate(born,kind) SELECT :origin,'learned' WHERE NOT EXISTS(SELECT 1 FROM capability WHERE name={name_id});
INSERT INTO capability(name,gate,kind,born) SELECT {name_id},last_insert_rowid(),'learned',:origin WHERE NOT EXISTS(SELECT 1 FROM capability WHERE name={name_id});
INSERT OR IGNORE INTO label(atom,gate,sense) SELECT name,gate,'operation' FROM capability WHERE name={name_id};
INSERT OR IGNORE INTO binding(capability,state) SELECT id,'unknown' FROM capability WHERE name={name_id};
INSERT OR IGNORE INTO definition(gate,source,body,state) SELECT c.gate,:origin,o.id,'UNKNOWN-action-pending-evidence' FROM capability c,object o WHERE c.name={name_id} AND o.sha256=@H(learned-definition) AND NOT EXISTS(SELECT 1 FROM definition d WHERE d.gate=c.gate);
"""
proc('example.record', f"""
{ensure_cap(aid(1))}
{setpad(cap=f'(SELECT id FROM capability WHERE name={aid(1)})', x=f'finite_real({arg(2)})', y=f'finite_real({arg(3)})')}
INSERT INTO example(capability,x,y,evidence,previous) VALUES({ctx('cap')},{ctx('x')},{ctx('y')},:origin,
 (SELECT id FROM example WHERE capability={ctx('cap')} AND x={ctx('x')} ORDER BY id DESC LIMIT 1));
UPDATE binding SET state='pending',epoch=epoch+1 WHERE capability={ctx('cap')};
{schedule_fit(ctx('cap'))}
{result(f"json_object('state','OBSERVATION','capability',{ctx('cap')},'x',{ctx('x')},'y',{ctx('y')},'evidence',:origin,'learning','queued')")}
""")
command('example','example.record',3,3,'example NAME X Y')

proc('learn.fit', f"""
{setpad(train_a=f"(SELECT id FROM current_example WHERE capability={ctx('cap')} AND context=coalesce({ctx('deps')},'') ORDER BY id LIMIT 1)", train_b=f"(SELECT id FROM current_example WHERE capability={ctx('cap')} AND context=coalesce({ctx('deps')},'') ORDER BY id LIMIT 1 OFFSET 1)")}
{setpad(a=f"(SELECT (b.y-a.y)/(b.x-a.x) FROM example a,example b WHERE a.id={ctx('train_a')} AND b.id={ctx('train_b')})")}
{setpad(b=f"(SELECT y-{ctx('a')}*x FROM example WHERE id={ctx('train_a')})")}
INSERT INTO model(capability,a,b,train_a,train_b,evidence,previous,context)
 SELECT {ctx('cap')},finite_real({ctx('a')}),finite_real({ctx('b')}),{ctx('train_a')},{ctx('train_b')},:origin,(SELECT id FROM model WHERE capability={ctx('cap')} ORDER BY id DESC LIMIT 1),coalesce({ctx('deps')},'')
 WHERE {ctx('train_b')} IS NOT NULL AND NOT EXISTS(SELECT 1 FROM model WHERE capability={ctx('cap')} AND train_a={ctx('train_a')} AND train_b={ctx('train_b')});
{setpad(model=f"(SELECT id FROM model WHERE capability={ctx('cap')} AND train_a={ctx('train_a')} AND train_b={ctx('train_b')} ORDER BY id DESC LIMIT 1)")}
{prepend(seq('learn.check'))}
""")
proc('learn.check', f"""
INSERT OR IGNORE INTO model_check(model,example,predicted,error,pass,evidence)
 SELECT m.id,e.id,m.a*e.x+m.b,abs((m.a*e.x+m.b)-e.y),abs((m.a*e.x+m.b)-e.y)<=1e-9*max(1,abs(e.y)),:origin
 FROM model m JOIN current_example e ON e.capability=m.capability
 WHERE m.id={ctx('model')} AND e.context=m.context AND e.id NOT IN(m.train_a,m.train_b);
{setpad(holds=f"(SELECT count(*) FROM model_check c JOIN current_example e ON e.id=c.example WHERE c.model={ctx('model')} AND e.context=coalesce({ctx('deps')},''))", fails=f"(SELECT count(*) FROM model_check c JOIN current_example e ON e.id=c.example WHERE c.model={ctx('model')} AND e.context=coalesce({ctx('deps')},'') AND c.pass=0)")}
{setpad(model_state=f"CASE WHEN {ctx('model')} IS NULL THEN 'unknown' WHEN {ctx('fails')}>0 THEN 'rejected' WHEN {ctx('holds')}>0 THEN 'validated-examples' ELSE 'candidate' END")}
{event('MODEL_EVALUATED',f"json_object('capability',{ctx('cap')},'model',{ctx('model')},'state',{ctx('model_state')},'held_out',{ctx('holds')},'failed',{ctx('fails')},'search_space','a*x+b','evidence',:origin)")}
{setpad(evaluation='last_insert_rowid()')}
INSERT INTO model_state(model,state,evidence) SELECT {ctx('model')},{ctx('model_state')},{ctx('evaluation')} WHERE {ctx('model')} IS NOT NULL
 ON CONFLICT(model) DO UPDATE SET state=excluded.state,evidence=excluded.evidence;
UPDATE binding SET model={ctx('model')},state={ctx('model_state')},epoch=epoch+1 WHERE capability={ctx('cap')};
{prepend(seq('learn.install'), f"{ctx('model_state')}='validated-examples'")}
{result(f"json_object('state',{ctx('model_state')},'capability',{ctx('cap')},'model',{ctx('model')},'held_out',{ctx('holds')},'failed',{ctx('fails')},'search_space','a*x+b','evaluation',{ctx('evaluation')})")}
""")
proc('learn.install', f"""
INSERT INTO dna(gate,program,provenance,parameters,previous)
 SELECT c.gate,@C(learned.enter),{ctx('evaluation')},json_object('model',m.id,'a',m.a,'b',m.b,'cap',c.id),b.dna
 FROM capability c JOIN binding b ON b.capability=c.id JOIN model m ON m.id=b.model WHERE c.id={ctx('cap')};
UPDATE binding SET dna=last_insert_rowid() WHERE capability={ctx('cap')};
DELETE FROM active_dna WHERE gate=(SELECT gate FROM capability WHERE id={ctx('cap')});
INSERT INTO active_dna(dna,gate,arrival_key,head_key,head_mode) SELECT b.dna,c.gate,-1,-1,'any' FROM binding b JOIN capability c ON c.id=b.capability WHERE c.id={ctx('cap')};
INSERT INTO definition(gate,source,body,state) SELECT c.gate,{ctx('evaluation')},o.id,'DERIVED-limited-model' FROM capability c, object o WHERE c.id={ctx('cap')} AND o.sha256=@H(affine-definition);
""")
proc('learned.enter', f"""
{setpad(a="json_extract(:params,'$.a')",b="json_extract(:params,'$.b')",model="json_extract(:params,'$.model')")}
{prepend(seq('math.multiply','math.add','math.result'),"EXISTS(SELECT 1 FROM binding WHERE capability=json_extract(:params,'$.cap') AND model=json_extract(:params,'$.model') AND state='validated-examples')")}
UPDATE run SET result=json_object('state','UNKNOWN','reason','model-not-current'),rest=json_array({g('run.end')})
 WHERE id=:run AND NOT EXISTS(SELECT 1 FROM binding WHERE capability=json_extract(:params,'$.cap') AND model=json_extract(:params,'$.model') AND state='validated-examples');
""")
proc('math.multiply',setpad(value=f"finite_real({ctx('x')}*{ctx('a')})"))
proc('math.add',setpad(value=f"finite_real({ctx('value')}+{ctx('b')})"))
proc('math.result',result(f"json_object('state','DERIVED','value',{ctx('value')},'model',{ctx('model')},'basis','validated-examples-not-universal-proof')"))

proc('apply.prepare', f"""
{setpad(cap=f'(SELECT id FROM capability WHERE name={aid(1)})',x=f'finite_real({arg(2)})')}
{prepend(seq('apply.start'), f"{ctx('cap')} IS NOT NULL")}
UPDATE run SET result=json_object('state','UNKNOWN','name',{arg(1)},'reason','no-capability') WHERE id=:run AND {ctx('cap')} IS NULL;
""")
command('run','apply.prepare',2,2,'run NAME X')
proc('apply.start',f"""
{prepend(seq('apply.join'))}
UPDATE run SET state='waiting' WHERE id=:run;
""")
# Actual excitation pointers will attach two independent child runs here.
proc('apply.evaluate', f"""
WITH RECURSIVE closure(cap) AS (VALUES({ctx('cap')}) UNION SELECT d.child FROM dependency d JOIN closure c ON d.parent=c.cap)
UPDATE run SET pad=json_set(pad,'$.fingerprint',(SELECT sha256(json_group_array(json_array(cap,b.epoch,b.dna,b.state))) FROM (SELECT cap FROM closure ORDER BY cap) JOIN binding b ON b.capability=cap),
 '$.valid',(SELECT count(*)=0 FROM closure c JOIN binding b ON b.capability=c.cap WHERE b.state NOT IN('validated-examples','told-composition'))) WHERE id=:run;
{setpad(signature=f"sha256(json_array({ctx('cap')},{ctx('x')},{ctx('fingerprint')}))")}
{setpad(cached=f"(SELECT result FROM cache WHERE signature={ctx('signature')})")}
UPDATE run SET result=json_set(json({ctx('cached')}),'$.reuse','cache') WHERE id=:run AND {ctx('cached')} IS NOT NULL AND {ctx('valid')}=1;
UPDATE run SET result=json_object('state','UNKNOWN','reason','missing-or-challenged-dependency','capability',{ctx('cap')}) WHERE id=:run AND {ctx('valid')}=0;
INSERT INTO run(parent,root,origin,role,rest,pad,depth)
 SELECT r.id,r.root,r.origin,'formula',json_array(c.gate,{g('run.end')}),json_object('x',{ctx('x')}),r.depth+1
 FROM run r JOIN capability c ON c.id={ctx('cap')} WHERE r.id=:run AND {ctx('cached')} IS NULL AND {ctx('valid')}=1;
{prepend(seq('apply.collect'), f"{ctx('cached')} IS NULL AND {ctx('valid')}=1")}
UPDATE run SET state='waiting' WHERE id=:run AND {ctx('cached')} IS NULL AND {ctx('valid')}=1;
""")
proc('apply.collect', f"""
{setpad(found="(SELECT l.result FROM landing l JOIN run c ON c.id=l.child WHERE l.parent=:run AND c.role='formula' ORDER BY c.id DESC LIMIT 1)")}
{result(f"json_set(json(coalesce({ctx('found')},json_object('state','UNKNOWN','reason','formula-did-not-land'))),'$.signature',{ctx('signature')},'$.reuse','executed')")}
INSERT OR IGNORE INTO cache(signature,result,evidence)
 SELECT {ctx('signature')},result,:origin FROM run WHERE id=:run AND json_extract(result,'$.state')='DERIVED';
""")
proc('apply.confidence',f"""
{result(f"json_object('state','OBSERVATION','observations',(SELECT count(*) FROM current_example WHERE capability={ctx('cap')}),'confirmed',(SELECT count(*) FROM feedback f JOIN run r ON r.id=f.run WHERE f.verdict='correct' AND json_extract(r.result,'$.capability')={ctx('cap')}),'rejected',(SELECT count(*) FROM feedback f JOIN run r ON r.id=f.run WHERE f.verdict='incorrect' AND json_extract(r.result,'$.capability')={ctx('cap')}),'calibrated_probability',json('null'))")}
""")
proc('apply.join',f"""
{setpad(answer="(SELECT l.result FROM landing l JOIN run c ON c.id=l.child WHERE l.parent=:run AND c.role='evaluate' ORDER BY c.id DESC LIMIT 1)", confidence="(SELECT l.result FROM landing l JOIN run c ON c.id=l.child WHERE l.parent=:run AND c.role='confidence' ORDER BY c.id DESC LIMIT 1)")}
{result(f"json_set(json(coalesce({ctx('answer')},json_object('state','UNKNOWN','reason','evaluation-did-not-land'))),'$.capability',{ctx('cap')},'$.x',{ctx('x')},'$.confidence',json(coalesce({ctx('confidence')},'{{}}')))")}
""")

# Composition changes graph structure, rather than adding an external handler.
proc('composition.create',f"""
{setpad(first=f'(SELECT id FROM capability WHERE name={aid(2)})',second=f'(SELECT id FROM capability WHERE name={aid(3)})',exists=f'(SELECT id FROM capability WHERE name={aid(1)})')}
{setpad(valid=f"{ctx('first')} IS NOT NULL AND {ctx('second')} IS NOT NULL AND {ctx('exists')} IS NULL")}
INSERT INTO gate(born,kind) SELECT :origin,'composition' WHERE {ctx('valid')};
INSERT INTO capability(name,gate,kind,born) SELECT {aid(1)},last_insert_rowid(),'composition',:origin WHERE {ctx('valid')};
{setpad(cap=f'(SELECT id FROM capability WHERE name={aid(1)})')}
INSERT INTO dependency(parent,child,pos,evidence) SELECT {ctx('cap')},{ctx('first')},0,:origin WHERE {ctx('valid')};
INSERT INTO dependency(parent,child,pos,evidence) SELECT {ctx('cap')},{ctx('second')},1,:origin WHERE {ctx('valid')};
INSERT INTO dna(gate,program,provenance,parameters) SELECT gate,@C(composition.enter),:origin,json_object('cap',id) FROM capability WHERE id={ctx('cap')} AND {ctx('valid')};
INSERT INTO binding(capability,dna,state,epoch) SELECT {ctx('cap')},last_insert_rowid(),'told-composition',1 WHERE {ctx('valid')};
INSERT INTO active_dna(dna,gate,arrival_key,head_key,head_mode) SELECT b.dna,c.gate,-1,-1,'any' FROM binding b JOIN capability c ON c.id=b.capability WHERE c.id={ctx('cap')} AND {ctx('valid')};
INSERT INTO label(atom,gate,sense) SELECT name,gate,'operation' FROM capability WHERE id={ctx('cap')} AND {ctx('valid')};
INSERT INTO definition(gate,source,body,state) SELECT c.gate,:origin,o.id,'TOLD-composition' FROM capability c,object o WHERE c.id={ctx('cap')} AND o.sha256=@H(composition-definition) AND {ctx('valid')};
{result(f"json_object('state',CASE WHEN {ctx('valid')} THEN 'TOLD' ELSE 'UNKNOWN' END,'capability',{ctx('cap')},'first',{ctx('first')},'second',{ctx('second')},'reason',CASE WHEN {ctx('valid')} THEN 'composition-created' ELSE 'missing-dependency-or-name-exists' END)")}
""")
command('compose','composition.create',3,3,'compose NEW_NAME FIRST SECOND')
proc('composition.enter',f"""
{setpad(comp="json_extract(:params,'$.cap')")}
INSERT INTO run(parent,root,origin,role,rest,pad,depth)
 SELECT r.id,r.root,r.origin,'first',json_array(c.gate,{g('run.end')}),json_object('x',{ctx('x')}),r.depth+1
 FROM run r JOIN dependency d ON d.parent={ctx('comp')} AND d.pos=0 JOIN capability c ON c.id=d.child WHERE r.id=:run;
{prepend(seq('composition.middle'))}
UPDATE run SET state='waiting' WHERE id=:run;
""")
proc('composition.middle',f"""
{setpad(first_result="(SELECT l.result FROM landing l JOIN run c ON c.id=l.child WHERE l.parent=:run AND c.role='first' ORDER BY c.id DESC LIMIT 1)")}
INSERT INTO run(parent,root,origin,role,rest,pad,depth)
 SELECT r.id,r.root,r.origin,'second',json_array(c.gate,{g('run.end')}),json_object('x',json_extract({ctx('first_result')},'$.value')),r.depth+1
 FROM run r JOIN dependency d ON d.parent={ctx('comp')} AND d.pos=1 JOIN capability c ON c.id=d.child
 WHERE r.id=:run AND json_extract({ctx('first_result')},'$.state')='DERIVED';
{prepend(seq('composition.finish'),f"json_extract({ctx('first_result')},'$.state')='DERIVED'")}
UPDATE run SET state='waiting' WHERE id=:run AND json_extract({ctx('first_result')},'$.state')='DERIVED';
UPDATE run SET result=json_object('state','UNKNOWN','reason','first-process-not-derived') WHERE id=:run AND coalesce(json_extract({ctx('first_result')},'$.state'),'')<>'DERIVED';
""")
proc('composition.finish',result("coalesce((SELECT l.result FROM landing l JOIN run c ON c.id=l.child WHERE l.parent=:run AND c.role='second' ORDER BY c.id DESC LIMIT 1),json_object('state','UNKNOWN','reason','second-process-did-not-land'))"))

proc('feedback.record',f"""
{setpad(target=f'CAST(finite_real({arg(1)}) AS INTEGER)',verdict=f"CASE WHEN {arg(0)}='yes' THEN 'correct' ELSE 'incorrect' END")}
INSERT INTO feedback(run,verdict,evidence) SELECT id,{ctx('verdict')},:origin FROM run WHERE id={ctx('target')} AND state='done';
UPDATE binding SET state='challenged',epoch=epoch+1 WHERE capability=(SELECT json_extract(result,'$.capability') FROM run WHERE id={ctx('target')}) AND {ctx('verdict')}='incorrect';
{result(f"json_object('state',CASE WHEN EXISTS(SELECT 1 FROM feedback WHERE run={ctx('target')} AND evidence=:origin) THEN 'OBSERVATION' ELSE 'UNKNOWN' END,'target_run',{ctx('target')},'verdict',{ctx('verdict')},'evidence',:origin)")}
""")
command('yes','feedback.record',1,1,'yes RUN_ID')
command('no','feedback.record',1,1,'no RUN_ID')
proc('feedback.correct',f"""
{setpad(target=f'CAST(finite_real({arg(1)}) AS INTEGER)',y=f'finite_real({arg(2)})')}
{setpad(cap=f"(SELECT json_extract(result,'$.capability') FROM run WHERE id={ctx('target')} AND state='done')",x=f"(SELECT json_extract(result,'$.x') FROM run WHERE id={ctx('target')} AND state='done')")}
INSERT INTO feedback(run,verdict,evidence) SELECT id,'incorrect',:origin FROM run WHERE id={ctx('target')} AND {ctx('cap')} IS NOT NULL AND {ctx('x')} IS NOT NULL;
INSERT INTO example(capability,x,y,evidence,previous) SELECT {ctx('cap')},{ctx('x')},{ctx('y')},:origin,(SELECT id FROM example WHERE capability={ctx('cap')} AND x={ctx('x')} ORDER BY id DESC LIMIT 1) WHERE {ctx('cap')} IS NOT NULL AND {ctx('x')} IS NOT NULL;
UPDATE binding SET state='pending',epoch=epoch+1 WHERE capability={ctx('cap')};
INSERT OR IGNORE INTO task(subject,gate,evidence) SELECT {ctx('cap')},{g('learn.fit')},:origin WHERE {ctx('cap')} IS NOT NULL AND {ctx('x')} IS NOT NULL;
{result(f"json_object('state',CASE WHEN {ctx('cap')} IS NOT NULL AND {ctx('x')} IS NOT NULL THEN 'OBSERVATION' ELSE 'UNKNOWN' END,'target_run',{ctx('target')},'capability',{ctx('cap')},'x',{ctx('x')},'corrected_y',{ctx('y')})")}
""")
command('correct','feedback.correct',2,2,'correct RUN_ID EXPECTED_VALUE')

proc('relation.remember', f"""
INSERT INTO assertion(subject,predicate,object,epistemic,evidence) VALUES({aid(1)},{aid(2)},{aid(3)},'CLAIM',:origin);
{result("json_object('state','CLAIM','assertion',last_insert_rowid(),'evidence',:origin)")}
""")
command('remember','relation.remember',3,3,'remember SUBJECT RELATION OBJECT')
proc('relation.judge',f"""
{setpad(assertion=f'CAST(finite_real({arg(1)}) AS INTEGER)',standing=f"CASE WHEN {arg(0)}='support' THEN 'supported' ELSE 'rejected' END")}
INSERT INTO judgment(assertion,state,evidence) SELECT id,{ctx('standing')},:origin FROM assertion WHERE id={ctx('assertion')};
{result(f"json_object('state',CASE WHEN EXISTS(SELECT 1 FROM assertion WHERE id={ctx('assertion')}) THEN 'OBSERVATION' ELSE 'UNKNOWN' END,'assertion',{ctx('assertion')},'standing',{ctx('standing')},'evidence',:origin)")}
""")
command('support','relation.judge',1,1,'support ASSERTION_ID')
command('reject','relation.judge',1,1,'reject ASSERTION_ID')
proc('relation.rule',f"""
INSERT INTO relation_rule(predicate,rule,evidence) SELECT {aid(1)},'transitive',:origin WHERE {arg(2)}='transitive'
 ON CONFLICT(predicate) DO UPDATE SET rule=excluded.rule,evidence=excluded.evidence;
{result(f"json_object('state',CASE WHEN {arg(2)}='transitive' THEN 'TOLD-rule' ELSE 'UNKNOWN' END,'relation',{arg(1)},'rule',{arg(2)},'evidence',:origin)")}
""")
command('rule','relation.rule',2,2,'rule RELATION transitive')
proc('ask.start',f"""
{setpad(subject=aid(1),predicate=aid(2))}
{prepend(seq('ask.join'))}
UPDATE run SET state='waiting' WHERE id=:run;
""")
command('ask','ask.start',2,2,'ask SUBJECT RELATION')
proc('ask.direct',result(f"""json_object('state','OBSERVATION','claims',json((SELECT json_group_array(json_object('assertion',a.id,'object',o.text,'standing',a.standing,'epistemic',a.epistemic,'source',a.source,'evidence',a.evidence)) FROM live_assertion a JOIN atom o ON o.id=a.object WHERE a.subject={ctx('subject')} AND a.predicate={ctx('predicate')} AND a.standing<>'rejected')))"""))
proc('ask.derive', f"""
WITH RECURSIVE path(at,proof,visited,depth) AS (
 SELECT {ctx('subject')},json_array(),','||{ctx('subject')}||',',0 WHERE EXISTS(SELECT 1 FROM relation_rule WHERE predicate={ctx('predicate')} AND rule='transitive')
 UNION ALL
 SELECT a.object,json_insert(p.proof,'$[#]',a.id),p.visited||a.object||',',p.depth+1 FROM path p JOIN live_assertion a ON a.subject=p.at AND a.predicate={ctx('predicate')} AND a.standing='supported'
 WHERE p.depth<16 AND instr(p.visited,','||a.object||',')=0)
UPDATE run SET result=json_object('state','INFERENCE','rule_evidence',(SELECT evidence FROM relation_rule WHERE predicate={ctx('predicate')}),'derivations',json((SELECT json_group_array(json_object('object',a.text,'proof',json(p.proof),'depth',p.depth)) FROM path p JOIN atom a ON a.id=p.at WHERE p.depth>1))) WHERE id=:run;
""")
proc('ask.join',f"""
{setpad(direct="(SELECT l.result FROM landing l JOIN run c ON c.id=l.child WHERE l.parent=:run AND c.role='direct' ORDER BY c.id DESC LIMIT 1)",derived="(SELECT l.result FROM landing l JOIN run c ON c.id=l.child WHERE l.parent=:run AND c.role='derive' ORDER BY c.id DESC LIMIT 1)")}
{result(f"json_object('state',CASE WHEN coalesce(json_array_length(json_extract({ctx('direct')},'$.claims')),0)+coalesce(json_array_length(json_extract({ctx('derived')},'$.derivations')),0)=0 THEN 'UNKNOWN' ELSE 'EVIDENCE' END,'subject',(SELECT text FROM atom WHERE id={ctx('subject')}),'relation',(SELECT text FROM atom WHERE id={ctx('predicate')}),'direct',json(coalesce({ctx('direct')},'{{}}')),'derived',json(coalesce({ctx('derived')},'{{}}')))")}
""")

proc('source.capture',f"""
{setpad(locator=arg(1),fetched=f'json(source_get({arg(1)}))')}
{prepend(seq('source.store'),f"json_extract({ctx('fetched')},'$.ok')=1")}
UPDATE run SET result=json_object('state','UNAVAILABLE','locator',{ctx('locator')},'reason',json_extract({ctx('fetched')},'$.error')) WHERE id=:run AND json_extract({ctx('fetched')},'$.ok')=0;
""")
command('source','source.capture',1,1,'source file:FILENAME_OR_APPROVED_HTTPS_URL')
proc('source.store',f"""
INSERT OR IGNORE INTO object(sha256,bytes) VALUES(sha256(json_extract({ctx('fetched')},'$.body')),CAST(json_extract({ctx('fetched')},'$.body') AS BLOB));
{setpad(body=f"(SELECT id FROM object WHERE sha256=sha256(json_extract({ctx('fetched')},'$.body')))")}
{event('SOURCE_CAPTURE',f"json_object('locator',{ctx('locator')},'body',{ctx('body')},'requested_by',:origin)")}
INSERT OR IGNORE INTO source(locator,body,event,media) VALUES({ctx('locator')},{ctx('body')},last_insert_rowid(),'uninterpreted-bytes');
{result(f"json_object('state','OBSERVATION','source',(SELECT id FROM source WHERE locator={ctx('locator')} AND body={ctx('body')}),'sha256',(SELECT sha256 FROM object WHERE id={ctx('body')}),'bytes',json_extract({ctx('fetched')},'$.bytes'),'semantic_status','UNINTERPRETED')")}
UPDATE run SET pad=json_remove(pad,'$.fetched') WHERE id=:run;
""")
proc('source.quote',result(f"""json_object('state',CASE WHEN EXISTS(SELECT 1 FROM source WHERE id=CAST(finite_real({arg(1)}) AS INTEGER)) THEN 'EXACT_SOURCE_EXCERPT' ELSE 'UNKNOWN' END,'source',CAST(finite_real({arg(1)}) AS INTEGER),'character_offset',CAST(finite_real({arg(2)}) AS INTEGER),'excerpt',(SELECT substr(CAST(o.bytes AS TEXT),CAST(finite_real({arg(2)}) AS INTEGER)+1,min(4096,max(0,CAST(finite_real({arg(3)}) AS INTEGER)))) FROM source s JOIN object o ON o.id=s.body WHERE s.id=CAST(finite_real({arg(1)}) AS INTEGER)))"""))
command('quote','source.quote',3,3,'quote SOURCE_ID CHARACTER_OFFSET LENGTH')
# Source lessons are explicit structured observations, not arbitrary prose magically understood.
proc('source.observe',f"""
{ensure_cap(aid(1))}
{setpad(cap=f'(SELECT id FROM capability WHERE name={aid(1)})',source=f'CAST(finite_real({arg(2)}) AS INTEGER)')}
{setpad(lesson=f"(SELECT CAST(o.bytes AS TEXT) FROM source s JOIN object o ON o.id=s.body WHERE s.id={ctx('source')})")}
{setpad(lesson_ok=f"CASE WHEN json_valid({ctx('lesson')}) THEN json_type({ctx('lesson')},'$.examples')='array' ELSE 0 END")}
{prepend(seq('source.observations'),f"{ctx('lesson_ok')}=1")}
UPDATE run SET result=json_object('state','UNKNOWN','reason','source-is-not-an-explicit-examples-JSON-document') WHERE id=:run AND coalesce({ctx('lesson_ok')},0)<>1;
""")
command('observe','source.observe',2,2,'observe NAME SOURCE_ID')
proc('source.observations',f"""
INSERT INTO event(kind,actor,detail)
 SELECT 'SOURCE_OBSERVATION','neuron',json_object('source',{ctx('source')},'path','$.examples['||key||']','pair',json(value)) FROM json_each({ctx('lesson')},'$.examples');
INSERT INTO example(capability,x,y,evidence,source,previous)
 SELECT {ctx('cap')},finite_real(json_extract(e.detail,'$.pair[0]')),finite_real(json_extract(e.detail,'$.pair[1]')),e.id,{ctx('source')},
 (SELECT id FROM example WHERE capability={ctx('cap')} AND x=finite_real(json_extract(e.detail,'$.pair[0]')) ORDER BY id DESC LIMIT 1)
 FROM event e WHERE e.kind='SOURCE_OBSERVATION' AND json_extract(e.detail,'$.source')={ctx('source')}
 AND NOT EXISTS(SELECT 1 FROM example x WHERE x.evidence=e.id AND x.capability={ctx('cap')});
UPDATE binding SET state='pending',epoch=epoch+1 WHERE capability={ctx('cap')};
{schedule_fit(ctx('cap'))}
{result(f"json_object('state','OBSERVATION','capability',{ctx('cap')},'source',{ctx('source')},'learning','queued','truth','source-claims-not-automatically-facts')")}
UPDATE run SET pad=json_remove(pad,'$.lesson') WHERE id=:run;
""")

proc('memory.sleep',f"""
{event('CONSOLIDATION',"json_object('run',:run,'policy','exact originals retained; reference highlights only')")}
{setpad(consolidation='last_insert_rowid()')}
UPDATE memory_state SET tier='persistent' WHERE tier='active' AND uses>=2;
UPDATE memory_state SET tier='long-term' WHERE tier='active' AND uses<2;
INSERT OR IGNORE INTO object(sha256,bytes)
 SELECT sha256(json_object('memory',m.id,'first',json_extract(CAST(o.bytes AS TEXT),'$.route[0]'),'last',json_extract(CAST(o.bytes AS TEXT),'$.route[#-1]'),'outcome',json_extract(CAST(o.bytes AS TEXT),'$.result'),'exact_body',m.body)),
 CAST(json_object('memory',m.id,'first',json_extract(CAST(o.bytes AS TEXT),'$.route[0]'),'last',json_extract(CAST(o.bytes AS TEXT),'$.route[#-1]'),'outcome',json_extract(CAST(o.bytes AS TEXT),'$.result'),'exact_body',m.body) AS BLOB)
 FROM memory_state ms JOIN memory m ON m.id=ms.memory JOIN object o ON o.id=m.body WHERE ms.tier='long-term' AND NOT EXISTS(SELECT 1 FROM highlight h WHERE h.memory=m.id);
INSERT OR IGNORE INTO highlight(memory,summary,evidence)
 SELECT m.id,h.id,{ctx('consolidation')} FROM memory_state ms JOIN memory m ON m.id=ms.memory JOIN object o ON o.id=m.body JOIN object h
 ON h.sha256=sha256(json_object('memory',m.id,'first',json_extract(CAST(o.bytes AS TEXT),'$.route[0]'),'last',json_extract(CAST(o.bytes AS TEXT),'$.route[#-1]'),'outcome',json_extract(CAST(o.bytes AS TEXT),'$.result'),'exact_body',m.body)) WHERE ms.tier='long-term';
{result("json_object('state','DERIVED','active',(SELECT count(*) FROM memory_state WHERE tier='active'),'persistent',(SELECT count(*) FROM memory_state WHERE tier='persistent'),'long_term',(SELECT count(*) FROM memory_state WHERE tier='long-term'),'loss','none','reconstructive_fidelity','not-claimed')")}
""")
command('sleep','memory.sleep',0,0,'sleep')
proc('memory.recall',f"""
{setpad(memory=f'CAST(finite_real({arg(1)}) AS INTEGER)')}
UPDATE memory_state SET uses=uses+1,last_event=:origin WHERE memory={ctx('memory')};
{result(f"json_object('state',CASE WHEN EXISTS(SELECT 1 FROM memory WHERE id={ctx('memory')}) THEN 'EXACT_RECORD' ELSE 'UNKNOWN' END,'memory',{ctx('memory')},'record',json((SELECT CAST(o.bytes AS TEXT) FROM memory m JOIN object o ON o.id=m.body WHERE m.id={ctx('memory')})),'highlight',json((SELECT CAST(o.bytes AS TEXT) FROM highlight h JOIN object o ON o.id=h.summary WHERE h.memory={ctx('memory')})))")}
""")
command('recall','memory.recall',1,1,'recall MEMORY_ID')
proc('memory.history',result("json_object('state','OBSERVATION','events',json((SELECT json_group_array(json_object('event',id,'time',at,'kind',kind,'detail',json(detail))) FROM (SELECT * FROM event ORDER BY id DESC LIMIT 20))))"))
command('history','memory.history',0,0,'history')
proc('memory.why',result(f"""json_object('state',CASE WHEN EXISTS(SELECT 1 FROM run_receipt WHERE run=CAST(finite_real({arg(1)}) AS INTEGER)) THEN 'EXACT_RECORD' ELSE 'UNKNOWN' END,'target_run',CAST(finite_real({arg(1)}) AS INTEGER),'record',json((SELECT CAST(o.bytes AS TEXT) FROM run_receipt rr JOIN memory m ON m.id=rr.memory JOIN object o ON o.id=m.body WHERE rr.run=CAST(finite_real({arg(1)}) AS INTEGER))))"""))
command('why','memory.why',1,1,'why RUN_ID')
proc('system.status',result("""json_object('state','OBSERVATION','gates',(SELECT count(*) FROM gate),'dna_versions',(SELECT count(*) FROM dna),'capabilities',(SELECT count(*) FROM capability),'models',(SELECT count(*) FROM model),'memories',(SELECT count(*) FROM memory),'events',(SELECT count(*) FROM event),'pending',(SELECT count(*) FROM task WHERE state='pending'),'faulted_runs',(SELECT count(*) FROM run WHERE state='fault'),'arbitrary_natural_language','NOT_IMPLEMENTED','semantic_geometry','UNPROVEN')"""))
command('status','system.status',0,0,'status')

# Physical run geometry: no invented universal language formula. Positions are
# explicit hypotheses; shape query uses preserved coordinate versions.
proc('geometry.place',f"""
{setpad(target=f'(SELECT gate FROM capability WHERE name={aid(1)})')}
INSERT INTO position(gate,x,y,z,evidence) SELECT {ctx('target')},finite_real({arg(2)}),finite_real({arg(3)}),finite_real({arg(4)}),:origin WHERE {ctx('target')} IS NOT NULL;
{result(f"json_object('state',CASE WHEN {ctx('target')} IS NOT NULL THEN 'HYPOTHESIS' ELSE 'UNKNOWN' END,'gate',{ctx('target')},'coordinate_version',last_insert_rowid(),'basis','owner-supplied-not-derived-semantic-placement')")}
""")
command('place','geometry.place',4,4,'place CAPABILITY X Y Z')

# The table builder composes NEW executable SQL from shared atoms, including
# separate CREATE/TABLE/INTEGER/etc gates. It never executes the user's input.
proc('sql.table',f"""
{setpad(table_name=f"'u_'||{arg(1)}",quoted_identifier=f"'\"u_'||replace({arg(1)},'\"','\"\"')||'\"'")}
INSERT OR IGNORE INTO atom(text) VALUES({ctx('quoted_identifier')});
INSERT INTO gate(born,kind) SELECT :origin,'sql-atom' WHERE NOT EXISTS(SELECT 1 FROM spelling s JOIN atom a ON a.id=s.atom WHERE a.text={ctx('quoted_identifier')});
INSERT INTO spelling(gate,atom) SELECT last_insert_rowid(),id FROM atom WHERE text={ctx('quoted_identifier')} AND NOT EXISTS(SELECT 1 FROM spelling s WHERE s.atom=atom.id);
{setpad(identifier_gate=f"(SELECT s.gate FROM spelling s JOIN atom a ON a.id=s.atom WHERE a.text={ctx('quoted_identifier')})")}
{setpad(sql_digest=f"sha256('table:'||{ctx('table_name')})")}
INSERT OR IGNORE INTO code(digest,provenance) VALUES({ctx('sql_digest')},:origin);
{setpad(generated_code=f"(SELECT id FROM code WHERE digest={ctx('sql_digest')})")}
INSERT INTO code_atom(code,pos,gate)
 SELECT {ctx('generated_code')},ca.pos,CASE WHEN ca.pos=t.hole THEN {ctx('identifier_gate')} ELSE ca.gate END
 FROM sql_template t JOIN code_atom ca ON ca.code=t.code WHERE t.name='create-user-table' AND NOT EXISTS(SELECT 1 FROM code_atom old WHERE old.code={ctx('generated_code')});
INSERT INTO gate(born,kind) VALUES(:origin,'process');
{setpad(generated_gate='last_insert_rowid()')}
INSERT INTO dna(gate,program,provenance) VALUES({ctx('generated_gate')},{ctx('generated_code')},:origin);
INSERT INTO active_dna(dna,gate,arrival_key,head_key,head_mode) VALUES(last_insert_rowid(),{ctx('generated_gate')},-1,-1,'any');
{prepend(f"json_array({ctx('generated_gate')},{g('sql.verify')})")}
""")
command('table','sql.table',1,1,'table NAME')
proc('sql.verify',result(f"json_object('state',CASE WHEN EXISTS(SELECT 1 FROM sqlite_schema WHERE type='table' AND name={ctx('table_name')}) THEN 'OBSERVATION' ELSE 'UNKNOWN' END,'created_table',{ctx('table_name')},'program_gate',{ctx('generated_gate')},'program_code',{ctx('generated_code')},'origin','composed-by-stored-graph')"))


# Further root processes are defined here rather than in the C executor.
exec((ROOT/'tools'/'seed_extensions.py').read_text(), globals())

# Build database deterministically. DDL and primitives are provided once;
# all operational source is tokenized into reusable atom gates.
if __name__=='__main__':
    con=sqlite3.connect(':memory:')
    con.executescript((ROOT/'schema.sql').read_text())
    seed_event=con.execute("INSERT INTO event(at,kind,actor,detail) VALUES('2026-10-20T00:00:00Z','SEED','builder',?)",(json.dumps({'state':'TOLD','scope':'experimental V2 seed, not a proof of general understanding'}),)).lastrowid
    atoms={}; gates={}; programs={}; spell={}; hashes={}
    def atom(text):
        if text not in atoms:atoms[text]=con.execute('INSERT INTO atom(text) VALUES(?)',(text,)).lastrowid
        return atoms[text]
    def obj(text):
        h=hashlib.sha256(text.encode()).hexdigest()
        con.execute('INSERT OR IGNORE INTO object(sha256,bytes) VALUES(?,?)',(h,text.encode()))
        return con.execute('SELECT id FROM object WHERE sha256=?',(h,)).fetchone()[0],h
    definitions={
      'learned-definition':'Unknown executable meaning. This named capability has observations; no action is claimed until a model survives held-out observations. Seed learning domain: finite scalar affine functions.',
      'affine-definition':'Derived executable candidate f(x)=a*x+b. Coefficients estimated from two distinct observations and checked on other observations. Validated examples are not a universal mathematical or semantic proof. Numerical tolerance: 1e-9 times max(1,abs(y)).',
      'composition-definition':'Told process composition: apply FIRST, then apply SECOND to its result. Its dependencies retain separate identities and current evidence. This is not claimed as an autonomously discovered composition.'
    }
    for name,text in definitions.items():_,h=obj(text);hashes[name]=h
    for name,body in P.items():
        gate=con.execute("INSERT INTO gate(born,kind) VALUES(?,'process')",(seed_event,)).lastrowid;gates[name]=gate
        con.execute('INSERT INTO label(atom,gate,sense) VALUES(?,?,?)',(atom(name),gate,'internal-process'))
        programs[name]=con.execute('INSERT INTO code(digest,provenance) VALUES(?,?)',(f'pending:{name}',seed_event)).lastrowid
    def resolve(s):
        s=re.sub(r'@G\(([^)]+)\)',lambda m:str(gates[m[1]]),s)
        s=re.sub(r'@C\(([^)]+)\)',lambda m:str(programs[m[1]]),s)
        s=re.sub(r'@H\(([^)]+)\)',lambda m:"'"+hashes[m[1]]+"'",s)
        return s
    def code_parts(code,body):
        tokens=re.findall(r'[A-Za-z_][A-Za-z_0-9]*|[0-9]+|\s+|[^\w\s]|\w',body)
        assert ''.join(tokens)==body
        for i,t in enumerate(tokens):
            if t not in spell:
                gate=con.execute("INSERT INTO gate(born,kind) VALUES(?,'sql-atom')",(seed_event,)).lastrowid;spell[t]=gate
                con.execute('INSERT INTO spelling(gate,atom) VALUES(?,?)',(gate,atom(t)))
            con.execute('INSERT INTO code_atom(code,pos,gate) VALUES(?,?,?)',(code,i,spell[t]))
        return tokens
    code_map=[]
    for name,body in P.items():
        body=resolve(body);h=hashlib.sha256(body.encode()).hexdigest()
        con.execute('UPDATE code SET digest=? WHERE id=?',(h,programs[name]))
        tokens=code_parts(programs[name],body)
        dna=con.execute('INSERT INTO dna(gate,program,provenance) VALUES(?,?,?)',(gates[name],programs[name],seed_event)).lastrowid
        con.execute("INSERT INTO active_dna VALUES(?,?, -1,-1,'any')",(dna,gates[name]))
        did,dh=obj('TOLD V2 seed process '+name+'. Its exact executable action is the immutable code token sequence '+h+'. No natural-language meaning or autonomous learning is asserted by its label.')
        con.execute('INSERT INTO definition VALUES(?,?,?,?)',(gates[name],seed_event,did,'TOLD'))
        code_map.append({'name':name,'gate':gates[name],'dna':dna,'code':programs[name],'atoms':len(tokens),'sha256':h,'SQL':body})
    # Pointer-driven fork connections, exercised by the running kernel.
    for parent,child,role in [('apply.start','apply.evaluate','evaluate'),('apply.start','apply.confidence','confidence'),('ask.start','ask.direct','direct'),('ask.start','ask.derive','derive')]:
        # Excitation targets need their own explicit end sequence.
        # A wrapper is an executable graph gate, not a C dispatch case.
        name='fork.'+parent+'.'+child;gate=con.execute("INSERT INTO gate(born,kind) VALUES(?,'process')",(seed_event,)).lastrowid
        body=resolve(prepend(seq(child,'run.end')))
        code=con.execute('INSERT INTO code(digest,provenance) VALUES(?,?)',(hashlib.sha256(body.encode()).hexdigest(),seed_event)).lastrowid
        code_parts(code,body);dna=con.execute('INSERT INTO dna(gate,program,provenance) VALUES(?,?,?)',(gate,code,seed_event)).lastrowid
        con.execute("INSERT INTO active_dna VALUES(?,?, -1,-1,'any')",(dna,gate));con.execute('INSERT INTO label VALUES(?,?,?)',(atom(name),gate,'internal-process'))
        parentdna=con.execute('SELECT dna FROM active_dna WHERE gate=?',(gates[parent],)).fetchone()[0]
        con.execute('INSERT INTO excitation(dna,target,role,provenance) VALUES(?,?,?,?)',(parentdna,gate,role,seed_event))
    template='CREATE TABLE IDENTIFIER (id INTEGER PRIMARY KEY, value TEXT NOT NULL);'
    code=con.execute('INSERT INTO code(digest,provenance) VALUES(?,?)',(hashlib.sha256(template.encode()).hexdigest(),seed_event)).lastrowid
    tokens=code_parts(code,template);con.execute('INSERT INTO sql_template VALUES(?,?,?,?)',('create-user-table',code,tokens.index('IDENTIFIER'),seed_event))
    for word,entry,low,high,usage in COMMANDS:
        con.execute('INSERT INTO command VALUES(?,?,?,?,?,?)',(atom(word),gates[entry],low,high,usage,seed_event))
        con.execute('INSERT OR IGNORE INTO label VALUES(?,?,?)',(atom(word),gates[entry],'instruction'))
    entry=[gates[n] for n in ['input.receive','input.dispatch','work.choose','output.emit','run.end']]
    con.executemany('INSERT INTO meta VALUES(?,?)',[('input-entry',json.dumps(entry)),('numeric-spine',json.dumps([gates[n] for n in ['learned.enter','math.multiply','math.add','math.result','composition.enter','composition.middle','composition.finish']])),('runtime-turn','0'),('version','0.2.0-experimental'),('seed-origin','2026-10-20'),('full-baby-acceptance','NOT_DEMONSTRATED')])
    con.commit()
    errors=con.execute('PRAGMA foreign_key_check').fetchall();assert not errors,errors
    # sqlite3 iterdump places INSERTs before some referenced tables: disable FK
    # only during the trusted, brand-new seed initialization; verify at install.
    dump='PRAGMA foreign_keys=OFF;\n'+'\n'.join(con.iterdump())+'\nPRAGMA foreign_keys=ON;\n'
    (ROOT/'seed.sql').write_text(dump)
    (ROOT/'docs'/'CODE-MAP.json').write_text(json.dumps(code_map,indent=2))
    print(json.dumps({'seed_bytes':len(dump),'processes':len(P),'sql_atoms':len(spell),'commands':len(COMMANDS),'gates':con.execute('SELECT count(*) FROM gate').fetchone()[0]},indent=2))
