/* Neuron V2 physical executor. No vocabulary dispatch, inference, fitting,
 * correction, belief, summarization, or command handlers live here.
 * All of those (where implemented) are versioned graph programs in brain.db.
 * This file implements SQL execution, lexical byte transport, scheduling,
 * atom emission, immutable-evidence enforcement and bounded source I/O. */
#define _POSIX_C_SOURCE 200809L
#define _XOPEN_SOURCE 700
#include <sqlite3.h>
#include <curl/curl.h>
#include <openssl/evp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <ctype.h>
#include <math.h>
#include <errno.h>
#include <signal.h>
#include <limits.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#define BYTE_CAP (2u*1024u*1024u)
#define STEP_CAP 12000
#define SQL_FUEL 4000
static sqlite3 *db;
static volatile sig_atomic_t interrupted;
static int graph_mode, fuel;
static char source_root[PATH_MAX];
static const char *immutable[] = {
    "atom","label","run_receipt","assertion_evidence","object","event","gate","definition","code","code_atom","spelling","dna","input","input_token","memory","occurrence","source","assertion","judgment","example","model","model_check","feedback","position","excitation",NULL
};
static void sig(int x) {
    (void)x;
    interrupted=1;
}
static void die(const char *s) {
    fprintf(stderr,"physical error: %s\n",s);
    exit(1);
}
static void sql(const char *s) {
    char *e=NULL;
    if(sqlite3_exec(db,s,NULL,NULL,&e)!=SQLITE_OK){
        fprintf(stderr,"%s\n",s);
        die(e?e:sqlite3_errmsg(db));
    }
}
static sqlite3_stmt *prep(const char *s) {
    sqlite3_stmt *p=NULL;
    if(sqlite3_prepare_v2(db,s,-1,&p,NULL)!=SQLITE_OK)die(sqlite3_errmsg(db));
    return p;
}
static char *dupcol(sqlite3_stmt *p,int n) {
    const unsigned char *v=sqlite3_column_text(p,n);
    return strdup(v?(const char*)v:"");
}
static sqlite3_int64 number(const char *s) {
    sqlite3_stmt *p=prep(s);
    sqlite3_int64 n=0;
    if(sqlite3_step(p)==SQLITE_ROW)n=sqlite3_column_int64(p,0);
    sqlite3_finalize(p);
    return n;
}
static void done(sqlite3_stmt *p) {
    if(sqlite3_step(p)!=SQLITE_DONE)die(sqlite3_errmsg(db));
    sqlite3_finalize(p);
}
static int progress(void *p) {
    (void)p;
    return interrupted || --fuel<=0;
}
static void jstring(sqlite3_str *s,const char *p,size_t n) {
    sqlite3_str_appendchar(s,1,'"');
    for(size_t i=0; i<n; i++) {
        unsigned char c=(unsigned char)p[i];
        if(c=='"'||c=='\\'){
            sqlite3_str_appendchar(s,1,'\\');
            sqlite3_str_appendchar(s,1,(char)c);
        } else if(c<32)sqlite3_str_appendf(s,"\\u%04x",c);
        else sqlite3_str_appendchar(s,1,(char)c);
    }
    sqlite3_str_appendchar(s,1,'"');
}
static char *hash(const void *v,size_t n) {
    unsigned char b[EVP_MAX_MD_SIZE];
    unsigned int z=0;
    if(!EVP_Digest(v,n,b,&z,EVP_sha256(),NULL)||z!=32)die("SHA256 failed");
    char *s=malloc(65);
    if(!s)die("memory");
    for(unsigned i=0; i<z; i++)snprintf(s+2*i,3,"%02x",b[i]);
    return s;
}
static void hashfn(sqlite3_context *c,int n,sqlite3_value **v) {
    (void)n;
    const void *b=sqlite3_value_blob(v[0]);
    int len=sqlite3_value_bytes(v[0]);
    char *h=hash(b,(size_t)len);
    sqlite3_result_text(c,h,-1,free);
}
/* Lossless raw input is retained separately. This lexer only frames whitespace,
 * unquoted words and double-quoted string arguments, with byte offsets. */
static void lexfn(sqlite3_context *c,int n,sqlite3_value **v) {
    (void)n;
    const char *t=(const char*)sqlite3_value_text(v[0]);
    if(!t){
        sqlite3_result_error(c,"input must be text",-1);
        return;
    }
    size_t len=(size_t)sqlite3_value_bytes(v[0]),i=0;
    if(len>65536){
        sqlite3_result_error(c,"input exceeds 65536 bytes",-1);
        return;
    }
    sqlite3_str *r=sqlite3_str_new(db);
    sqlite3_str_appendall(r,"[");
    int comma=0;
    while(i<len){
        size_t start=i;
        const char *kind;
        sqlite3_str *w=sqlite3_str_new(db);
        if(isspace((unsigned char)t[i])){
            kind="space";
            while(i<len&&isspace((unsigned char)t[i]))sqlite3_str_appendchar(w,1,t[i++]);
        } else if(t[i]=='"'){
            kind="string";
            i++;
            int closed=0;
            while(i<len){
                char a=t[i++];
                if(a=='"'){
                    closed=1;
                    break;
                }
                if(a=='\\'){
                    if(i==len)break;
                    a=t[i++];
                    if(a=='n')a='\n';
                    else if(a=='t')a='\t';
                    else if(a=='r')a='\r';
                    else if(a!='"'&&a!='\\'){
                        sqlite3_free(sqlite3_str_finish(w));
                        sqlite3_free(sqlite3_str_finish(r));
                        sqlite3_result_error(c,"unsupported quoted escape",-1);
                        return;
                    }
                }
                sqlite3_str_appendchar(w,1,a);
            }
            if(!closed){
                sqlite3_free(sqlite3_str_finish(w));
                sqlite3_free(sqlite3_str_finish(r));
                sqlite3_result_error(c,"unclosed quoted argument",-1);
                return;
            }
            if(i<len&&!isspace((unsigned char)t[i])){
                sqlite3_free(sqlite3_str_finish(w));
                sqlite3_free(sqlite3_str_finish(r));
                sqlite3_result_error(c,"space required after quoted argument",-1);
                return;
            }
        }else{
            kind="word";
            while(i<len&&!isspace((unsigned char)t[i]))sqlite3_str_appendchar(w,1,t[i++]);
        }
        char *word=sqlite3_str_finish(w);
        if(comma++)sqlite3_str_appendall(r,",");
        sqlite3_str_appendall(r,"{\"text\":");
        jstring(r,word?word:"",word?strlen(word):0);
        sqlite3_str_appendf(r,",\"start\":%llu,\"length\":%llu,\"kind\":\"%s\"}",(unsigned long long)start,(unsigned long long)(i-start),kind);
        sqlite3_free(word);
    }
    sqlite3_str_appendall(r,"]");
    sqlite3_result_text(c,sqlite3_str_finish(r),-1,sqlite3_free);
}
/* Strict finite numeric conversion. SQL CAST('nonsense' AS REAL) is not allowed
 * to turn an unknown observation into zero. */
static void realfn(sqlite3_context *c,int n,sqlite3_value **v) {
    (void)n;
    const char *s=(const char*)sqlite3_value_text(v[0]);
    char *e=NULL;
    errno=0;
    double x=s?strtod(s,&e):NAN;
    if(!s||e==s||*e||errno||!isfinite(x))sqlite3_result_error(c,"finite numeric argument required",-1);
    else sqlite3_result_double(c,x);
}
struct bytes {
    char *p;
    size_t n;
};
static size_t receive(char *p,size_t a,size_t b,void *ctx){
    struct bytes *s=ctx;
    size_t n=a*b;
    if(n>BYTE_CAP-s->n)return 0;
    char *q=realloc(s->p,s->n+n+1);
    if(!q)return 0;
    s->p=q;
    memcpy(s->p+s->n,p,n);
    s->n+=n;
    s->p[s->n]=0;
    return n;
}
static int utf8_text(const char *s,size_t n) {
    size_t i=0;
    while(i<n){
        unsigned char c=(unsigned char)s[i++];
        if(c==0)return 0;
        if(c<0x80)continue;
        unsigned int v=0,min=0;
        size_t more=0;
        if(c>=0xC2&&c<=0xDF){
            v=c&0x1F;
            more=1;
            min=0x80;
        } else if(c>=0xE0&&c<=0xEF){
            v=c&0x0F;
            more=2;
            min=0x800;
        } else if(c>=0xF0&&c<=0xF4){
            v=c&0x07;
            more=3;
            min=0x10000;
        } else return 0;
        if(more>n-i)return 0;
        while(more--){
            unsigned char b=(unsigned char)s[i++];
            if((b&0xC0)!=0x80)return 0;
            v=(v<<6)|(b&0x3F);
        }
        if(v<min||v>0x10FFFF||(v>=0xD800&&v<=0xDFFF))return 0;
    }
    return 1;
}
static int allowed_host(const char *host){
    const char *hosts[]={
        "sqlite.org","www.sqlite.org","www.gutenberg.org","gutenberg.org","nsm-approach.net","www.nsm-approach.net",NULL
    };
    for(int i=0; hosts[i]; i++)if(!strcmp(host,hosts[i]))return 1;
    return 0;
}
static void sourcefn(sqlite3_context *c,int n,sqlite3_value **v){
    (void)n;
    const char *u=(const char*)sqlite3_value_text(v[0]);
    struct bytes s={
        0
    };
    const char *err=NULL;
    char *owned=NULL;
    if(!u)err="source locator required";
    else if(!strncmp(u,"file:",5)){
        char request[PATH_MAX],real[PATH_MAX];
        if(!source_root[0])err="source inbox unavailable";
        else if(strlen(u+5)>PATH_MAX/2)err="path too long";
        else {
            int z=snprintf(request,sizeof(request),"%s/%s",source_root,u+5);
            if(z<0||(size_t)z>=sizeof(request)||!realpath(request,real))err="source file missing";
            else if(strncmp(real,source_root,strlen(source_root))||real[strlen(source_root)]!='/')err="source outside approved inbox";
            else {
                FILE *f=fopen(real,"rb");
                if(!f)err="source unreadable";
                else {
                    char buf[8192];
                    size_t k;
                    while((k=fread(buf,1,sizeof(buf),f))){
                        if(receive(buf,1,k,&s)!=k){
                            err="source exceeds size cap";
                            break;
                        }
                    }
                    if(ferror(f))err="source read error";
                    fclose(f);
                }
            }
        }
    }else if(!strncmp(u,"https://",8)){
        CURLU *url=curl_url();
        char *host=NULL,*port=NULL,*user=NULL,*pass=NULL;
        if(curl_url_set(url,CURLUPART_URL,u,0)!=CURLUE_OK||curl_url_get(url,CURLUPART_HOST,&host,0)!=CURLUE_OK)err="invalid HTTPS source";
        else if(!allowed_host(host))err="host not approved; copy the document into sources/inbox instead";
        else if(curl_url_get(url,CURLUPART_USER,&user,0)==CURLUE_OK||curl_url_get(url,CURLUPART_PASSWORD,&pass,0)==CURLUE_OK)err="credentials in URLs are forbidden";
        else if(curl_url_get(url,CURLUPART_PORT,&port,0)==CURLUE_OK&&strcmp(port,"443"))err="nonstandard port forbidden";
        if(!err){
            CURL *h=curl_easy_init();
            if(!h)err="curl initialization failed";
            else{
                curl_easy_setopt(h,CURLOPT_URL,u);
                curl_easy_setopt(h,CURLOPT_FOLLOWLOCATION,0L);
                curl_easy_setopt(h,CURLOPT_TIMEOUT,20L);
                curl_easy_setopt(h,CURLOPT_CONNECTTIMEOUT,6L);
                curl_easy_setopt(h,CURLOPT_NOSIGNAL,1L);
                curl_easy_setopt(h,CURLOPT_PROXY,"");
                curl_easy_setopt(h,CURLOPT_NETRC,CURL_NETRC_IGNORED);
                curl_easy_setopt(h,CURLOPT_USERAGENT,"Neuron-V2-source-reader/0.2");
                curl_easy_setopt(h,CURLOPT_WRITEFUNCTION,receive);
                curl_easy_setopt(h,CURLOPT_WRITEDATA,&s);
                CURLcode r=curl_easy_perform(h);
                long status=0;
                curl_easy_getinfo(h,CURLINFO_RESPONSE_CODE,&status);
                if(r!=CURLE_OK){
                    owned=strdup(curl_easy_strerror(r));
                    err=owned;
                }else if(status!=200)err="source did not return HTTP 200 (redirects are not followed)";
                curl_easy_cleanup(h);
            }
        }
        curl_free(host);
        curl_free(port);
        curl_free(user);
        curl_free(pass);
        curl_url_cleanup(url);
    }else err="only file:inbox-path or approved HTTPS sources are supported";
    if(!err&&!utf8_text(s.p?s.p:"",s.n))err="source is not NUL-free UTF-8 text; no truncation or interpretation performed";
    sqlite3_str *r=sqlite3_str_new(db);
    sqlite3_str_appendf(r,"{\"ok\":%s,",err?"false":"true");
    if(err){
        sqlite3_str_appendall(r,"\"error\":");
        jstring(r,err,strlen(err));
    } else {
        sqlite3_str_appendall(r,"\"body\":");
        jstring(r,s.p?s.p:"",s.n);
        sqlite3_str_appendf(r,",\"bytes\":%llu",(unsigned long long)s.n);
    }
    sqlite3_str_appendall(r,"}");
    sqlite3_result_text(c,sqlite3_str_finish(r),-1,sqlite3_free);
    free(s.p);
    free(owned);
}
static int auth(void *p,int action,const char *a,const char *b,const char *d,const char *t){
    (void)p;
    (void)d;
    (void)t;
    if(!graph_mode)return SQLITE_OK;
    if(action==SQLITE_ATTACH||action==SQLITE_DETACH||action==SQLITE_PRAGMA||action==SQLITE_TRANSACTION||action==SQLITE_SAVEPOINT||action==SQLITE_CREATE_VTABLE||action==SQLITE_DROP_VTABLE)return SQLITE_DENY;
    if(action==SQLITE_FUNCTION&&b&&(!strcmp(b,"load_extension")||!strcmp(b,"writefile")||!strcmp(b,"readfile")))return SQLITE_DENY;
    if(action==SQLITE_UPDATE||action==SQLITE_DELETE){
        for(int i=0; immutable[i]; i++)if(a&&!strcmp(a,immutable[i]))return SQLITE_DENY;
    }
    if(action==SQLITE_DROP_TABLE||action==SQLITE_ALTER_TABLE||action==SQLITE_DROP_TRIGGER||action==SQLITE_DROP_INDEX||action==SQLITE_CREATE_TRIGGER){
        if(!a||strncmp(a,"u_",2))return SQLITE_DENY;
    }
    if(action==SQLITE_CREATE_TABLE&&(!a||strncmp(a,"u_",2)))return SQLITE_DENY;
    return SQLITE_OK;
}
static void register_functions(void){
    sqlite3_create_function(db,"sha256",1,SQLITE_UTF8|SQLITE_DETERMINISTIC,NULL,hashfn,NULL,NULL);
    sqlite3_create_function(db,"lex",1,SQLITE_UTF8|SQLITE_DETERMINISTIC,NULL,lexfn,NULL,NULL);
    sqlite3_create_function(db,"finite_real",1,SQLITE_UTF8|SQLITE_DETERMINISTIC,NULL,realfn,NULL,NULL);
    sqlite3_create_function(db,"source_get",1,SQLITE_UTF8,NULL,sourcefn,NULL,NULL);
}
static sqlite3_int64 blob(const char *s,size_t n){
    char *h=hash(s,n);
    sqlite3_stmt *p=prep("INSERT INTO object(sha256,bytes) VALUES(?,?) ON CONFLICT(sha256) DO NOTHING");
    sqlite3_bind_text(p,1,h,-1,SQLITE_TRANSIENT);
    sqlite3_bind_blob64(p,2,s,n,SQLITE_TRANSIENT);
    done(p);
    p=prep("SELECT id FROM object WHERE sha256=?");
    sqlite3_bind_text(p,1,h,-1,SQLITE_TRANSIENT);
    sqlite3_step(p);
    sqlite3_int64 id=sqlite3_column_int64(p,0);
    sqlite3_finalize(p);
    free(h);
    return id;
}
static sqlite3_int64 record(const char *kind,const char *actor,const char *detail){
    sqlite3_stmt *p=prep("INSERT INTO event(kind,actor,detail) VALUES(?,?,?)");
    sqlite3_bind_text(p,1,kind,-1,SQLITE_TRANSIENT);
    sqlite3_bind_text(p,2,actor,-1,SQLITE_TRANSIENT);
    sqlite3_bind_text(p,3,detail,-1,SQLITE_TRANSIENT);
    done(p);
    return sqlite3_last_insert_rowid(db);
}
static char *program(sqlite3_int64 id){
    sqlite3_stmt *p=prep("SELECT a.text FROM code_atom ca JOIN spelling s ON s.gate=ca.gate JOIN atom a ON a.id=s.atom WHERE ca.code=? ORDER BY ca.pos");
    sqlite3_bind_int64(p,1,id);
    sqlite3_str *s=sqlite3_str_new(db);
    int count=0;
    while(sqlite3_step(p)==SQLITE_ROW){
        sqlite3_str_appendall(s,(const char*)sqlite3_column_text(p,0));
        count++;
    }
    sqlite3_finalize(p);
    if(!count){
        sqlite3_free(sqlite3_str_finish(s));
        return NULL;
    }
    return sqlite3_str_finish(s);
}
static void bind_name(sqlite3_stmt *s,const char *name,sqlite3_int64 v){
    int n=sqlite3_bind_parameter_index(s,name);
    if(n)sqlite3_bind_int64(s,n,v);
}
static void bind_text(sqlite3_stmt *s,const char *name,const char *v){
    int n=sqlite3_bind_parameter_index(s,name);
    if(n)sqlite3_bind_text(s,n,v,-1,SQLITE_TRANSIENT);
}
static char *execute(const char *text,sqlite3_int64 run,sqlite3_int64 gate,sqlite3_int64 dna,sqlite3_int64 origin,sqlite3_int64 arrival,sqlite3_int64 head,const char *params,char **error){
    const char *cur=text,*tail=NULL;
    sqlite3_str *rows=sqlite3_str_new(db);
    sqlite3_str_appendall(rows,"[");
    int rowcount=0;
    graph_mode=1;
    fuel=SQL_FUEL;
    sqlite3_progress_handler(db,1000,progress,NULL);
    while(*cur){
        sqlite3_stmt *s=NULL;
        int rc=sqlite3_prepare_v2(db,cur,-1,&s,&tail);
        if(rc!=SQLITE_OK){
            *error=strdup(sqlite3_errmsg(db));
            break;
        }
        cur=tail;
        if(!s)continue;
        /* The context is refreshed for each statement, so preceding writes are visible. */ sqlite3_stmt *p=NULL;
        sqlite3_prepare_v2(db,"SELECT pad FROM run WHERE id=?",-1,&p,NULL);
        sqlite3_bind_int64(p,1,run);
        sqlite3_step(p);
        char *ctx=dupcol(p,0);
        sqlite3_finalize(p);
        bind_name(s,":run",run);
        bind_name(s,":gate",gate);
        bind_name(s,":dna",dna);
        bind_name(s,":origin",origin);
        bind_name(s,":arrival",arrival);
        bind_name(s,":head",head);
        bind_text(s,":params",params);
        bind_text(s,":ctx",ctx);
        free(ctx);
        while((rc=sqlite3_step(s))==SQLITE_ROW){
            if(rowcount++>4096){
                *error=strdup("SQL result row cap");
                break;
            }
            if(rowcount>1)sqlite3_str_appendall(rows,",");
            sqlite3_str_appendall(rows,"[");
            for(int k=0; k<sqlite3_column_count(s); k++){
                if(k)sqlite3_str_appendall(rows,",");
                int typ=sqlite3_column_type(s,k);
                if(typ==SQLITE_NULL)sqlite3_str_appendall(rows,"null");
                else if(typ==SQLITE_INTEGER)sqlite3_str_appendf(rows,"%lld",sqlite3_column_int64(s,k));
                else if(typ==SQLITE_FLOAT){
                    double d=sqlite3_column_double(s,k);
                    if(!isfinite(d)){
                        *error=strdup("nonfinite SQL result");
                        break;
                    }
                    sqlite3_str_appendf(rows,"%!.17g",d);
                }else if(typ==SQLITE_BLOB){
                    const unsigned char *data=sqlite3_column_blob(s,k);
                    int len=sqlite3_column_bytes(s,k);
                    sqlite3_str_appendall(rows,"{\"blob_hex\":\"");
                    for(int j=0; j<len; j++)sqlite3_str_appendf(rows,"%02x",data[j]);
                    sqlite3_str_appendall(rows,"\"}");
                }else jstring(rows,(const char*)sqlite3_column_text(s,k),(size_t)sqlite3_column_bytes(s,k));
            }
            sqlite3_str_appendall(rows,"]");
            if(*error)break;
        }
        if(rc!=SQLITE_DONE&&!*error)*error=strdup(sqlite3_errmsg(db));
        sqlite3_finalize(s);
        if(*error)break;
    }
    sqlite3_progress_handler(db,0,NULL,NULL);
    graph_mode=0;
    sqlite3_str_appendall(rows,"]");
    return sqlite3_str_finish(rows);
}
static void fault(sqlite3_int64 id,const char *message){
    sqlite3_str *s=sqlite3_str_new(db);
    sqlite3_str_appendf(s,"{\"run\":%lld,\"reason\":",id);
    jstring(s,message,strlen(message));
    sqlite3_str_appendall(s,"}");
    char *detail=sqlite3_str_finish(s);
    sql("BEGIN IMMEDIATE");
    record("FAULT","physical-executor",detail);
    sqlite3_stmt *p=prep("UPDATE run SET state='fault',result=json_object('state','FAULT','reason',?) WHERE id=?");
    sqlite3_bind_text(p,1,message,-1,SQLITE_TRANSIENT);
    sqlite3_bind_int64(p,2,id);
    done(p);
    p=prep("INSERT INTO outbox(run,value) VALUES(?,?)");
    sqlite3_bind_int64(p,1,id);
    sqlite3_bind_text(p,2,detail,-1,SQLITE_TRANSIENT);
    done(p);
    p=prep("UPDATE task SET state='fault' WHERE run=?");
    sqlite3_bind_int64(p,1,id);
    done(p);
    sql("COMMIT");
    sqlite3_free(detail);
}
static int step(void){
    /* WAIT is scheduling physics: resume only after every child terminates. */ sql("UPDATE run SET state='ready' WHERE state='waiting' AND NOT EXISTS(SELECT 1 FROM run child WHERE child.parent=run.id AND child.state IN ('ready','waiting','paused'))");
    sqlite3_stmt *p=prep("SELECT id,origin,coalesce(arrival,0),json_extract(rest,'$[0]'),coalesce(json_extract(rest,'$[1]'),0),depth FROM run WHERE state='ready' ORDER BY turn,id LIMIT 1");
    if(sqlite3_step(p)!=SQLITE_ROW){
        sqlite3_finalize(p);
        return 0;
    }
    sqlite3_int64 id=sqlite3_column_int64(p,0),origin=sqlite3_column_int64(p,1),arrival=sqlite3_column_int64(p,2),gate=sqlite3_column_int64(p,3),head=sqlite3_column_int64(p,4);
    int depth=sqlite3_column_int(p,5);
    sqlite3_finalize(p);
    if(depth>24){
        fault(id,"branch depth limit reached; no work discarded");
        return 1;
    }
    if(gate<=0){
        fault(id,"run exhausted its remainder without a graph END");
        return 1;
    }
    p=prep("SELECT d.id,d.program,d.parameters,(d.arrival IS NOT NULL)+(d.head_mode<>'any') AS specificity FROM active_dna a JOIN dna d ON d.id=a.dna WHERE a.gate=? AND (d.arrival IS NULL OR d.arrival=?) AND (d.head_mode='any' OR (d.head_mode='end' AND ?=0) OR (d.head_mode='exact' AND d.head=?)) ORDER BY specificity DESC,d.id");
    sqlite3_bind_int64(p,1,gate);
    sqlite3_bind_int64(p,2,arrival);
    sqlite3_bind_int64(p,3,head);
    sqlite3_bind_int64(p,4,head);
    if(sqlite3_step(p)!=SQLITE_ROW){
        sqlite3_finalize(p);
        fault(id,"no applicable DNA; unknown is not a fabricated continuation");
        return 1;
    }
    sqlite3_int64 dna=sqlite3_column_int64(p,0),code=sqlite3_column_int64(p,1);
    char *params=dupcol(p,2);
    int specificity=sqlite3_column_int(p,3);
    if(sqlite3_step(p)==SQLITE_ROW&&sqlite3_column_int(p,3)==specificity){
        sqlite3_finalize(p);
        free(params);
        fault(id,"ambiguous equally specific DNA");
        return 1;
    }
    sqlite3_finalize(p);
    char *text=program(code);
    if(!text){
        free(params);
        fault(id,"empty executable code");
        return 1;
    }
    char *digest=hash(text,strlen(text));
    p=prep("SELECT digest FROM code WHERE id=?");
    sqlite3_bind_int64(p,1,code);
    sqlite3_step(p);
    char *expected=dupcol(p,0);
    sqlite3_finalize(p);
    int valid=!strcmp(digest,expected);
    free(digest);
    free(expected);
    if(!valid){
        free(params);
        sqlite3_free(text);
        fault(id,"executable atom sequence failed its content hash");
        return 1;
    }
    sql("BEGIN IMMEDIATE; UPDATE meta SET value=CAST(value AS INTEGER)+1 WHERE key='runtime-turn'");
    p=prep("UPDATE run SET current=?,rest=json_remove(rest,'$[0]'),steps=steps+1,turn=(SELECT CAST(value AS INTEGER) FROM meta WHERE key='runtime-turn') WHERE id=?");
    sqlite3_bind_int64(p,1,gate);
    sqlite3_bind_int64(p,2,id);
    done(p);
    p=prep("INSERT INTO trace(run,step,gate,dna,position) SELECT id,steps,?, ?, (SELECT p.id FROM position p WHERE p.gate=run.current AND p.context=0 ORDER BY p.id DESC LIMIT 1) FROM run WHERE id=?");
    sqlite3_bind_int64(p,1,gate);
    sqlite3_bind_int64(p,2,dna);
    sqlite3_bind_int64(p,3,id);
    done(p);
    char *error=NULL,*rows=execute(text,id,gate,dna,origin,arrival,head,params,&error);
    sqlite3_free(text);
    free(params);
    if(error){
        sql("ROLLBACK");
        sqlite3_free(rows);
        fault(id,error);
        free(error);
        return 1;
    }
    p=prep("UPDATE run SET arrival=?,last_result=? WHERE id=?");
    sqlite3_bind_int64(p,1,gate);
    sqlite3_bind_text(p,2,rows?rows:"[]",-1,SQLITE_TRANSIENT);
    sqlite3_bind_int64(p,3,id);
    done(p);
    sqlite3_free(rows);
    /* Excitations are persisted pointers, not host-language command handlers. */ p=prep("INSERT INTO run(parent,root,origin,role,rest,pad,depth) SELECT r.id,r.root,r.origin,e.role,json_array(e.target),r.pad,r.depth+1 FROM excitation e JOIN run r ON r.id=? WHERE e.dna=?");
    sqlite3_bind_int64(p,1,id);
    sqlite3_bind_int64(p,2,dna);
    done(p);
    sql("COMMIT");
    return 1;
}
static void drain(void){
    int n=0;
    while(!interrupted&&n++<STEP_CAP&&step()){
    }
    if(interrupted||n>STEP_CAP){
        sql("UPDATE run SET state='paused' WHERE state='ready'");
        fprintf(stderr,"execution paused at physical bound; use --resume; nothing is claimed complete\n");
    }
}
static void print_outputs(sqlite3_int64 after){
    sqlite3_stmt *p=prep("SELECT id,run,value FROM outbox WHERE id>? ORDER BY id");
    sqlite3_bind_int64(p,1,after);
    while(sqlite3_step(p)==SQLITE_ROW){
        printf("%s\n",sqlite3_column_text(p,2));
    }
    sqlite3_finalize(p);
    fflush(stdout);
}
static int input_line(const char *s){
    if(strlen(s)>65536){
        fprintf(stderr,"input exceeds 65536 bytes\n");
        return 3;
    }
    sqlite3_int64 after=number("SELECT coalesce(max(id),0) FROM outbox");
    sql("BEGIN IMMEDIATE");
    sqlite3_int64 body=blob(s,strlen(s));
    char *detail=sqlite3_mprintf("{\"body\":%lld,\"channel\":\"terminal\"}",body);
    sqlite3_int64 origin=record("INPUT","owner",detail);
    sqlite3_free(detail);
    sqlite3_stmt *p=prep("INSERT INTO run(origin,role,rest) VALUES(?,'input',(SELECT value FROM meta WHERE key='input-entry'))");
    sqlite3_bind_int64(p,1,origin);
    done(p);
    sqlite3_int64 id=sqlite3_last_insert_rowid(db);
    p=prep("UPDATE run SET root=id WHERE id=?");
    sqlite3_bind_int64(p,1,id);
    done(p);
    p=prep("INSERT INTO input(run,body) VALUES(?,?)");
    sqlite3_bind_int64(p,1,id);
    sqlite3_bind_int64(p,2,body);
    done(p);
    sql("COMMIT");
    drain();
    print_outputs(after);
    p=prep("SELECT count(*) FROM run WHERE root=? AND state<>'done'");
    sqlite3_bind_int64(p,1,id);
    sqlite3_step(p);
    int failed=sqlite3_column_int(p,0);
    sqlite3_finalize(p);
    return failed?3:0;
}
static void inbox_path(const char *path){
    char real[PATH_MAX];
    if(!realpath(path,real))die("database path cannot be resolved");
    char *end=strrchr(real,'/');
    if(!end)die("database directory");
    *end=0;
    char p[PATH_MAX];
    int n=snprintf(p,sizeof(p),"%s/sources/inbox",real);
    if(n>0&&(size_t)n<sizeof(p)&&realpath(p,source_root))return;
    source_root[0]=0;
}
int main(int argc,char **argv){
    if(argc<3){
        fprintf(stderr,"usage: neuron DATABASE --init SEED.sql | --say TEXT | --talk | --resume | --version\n");
        return 2;
    }
    signal(SIGINT,sig);
    signal(SIGTERM,sig);
    curl_global_init(CURL_GLOBAL_DEFAULT);
    int status=0;
    if(!strcmp(argv[2],"--init")){
        if(argc!=4){
            die("--init requires seed SQL path");
        }
        int fd=open(argv[1],O_CREAT|O_EXCL|O_WRONLY,0600);
        if(fd<0)die("refusing to initialize an existing database");
        close(fd);
        if(sqlite3_open(argv[1],&db)!=SQLITE_OK){
            die("open failed");
        }
        register_functions();
        FILE *f=fopen(argv[3],"rb");
        if(!f)die("seed missing");
        if(fseek(f,0,SEEK_END))die("seed seek");
        long len=ftell(f);
        if(len<=0||len>16000000)die("seed size");
        rewind(f);
        char *s=malloc((size_t)len+1);
        if(!s)die("memory");
        if(fread(s,1,(size_t)len,f)!=(size_t)len)die("seed read");
        s[len]=0;
        fclose(f);
        sql(s);
        free(s);
        if(number("SELECT count(*) FROM pragma_foreign_key_check")!=0)die("seed foreign-key verification failed");
        if(number("SELECT count(*) FROM pragma_integrity_check WHERE integrity_check<>'ok'")!=0)die("seed database verification failed");
        sql("PRAGMA wal_checkpoint(TRUNCATE)");
        sqlite3_close(db);
        puts("initialized experimental Neuron V2 seed; not a claim of autonomous general understanding");
        return 0;
    }
    if(sqlite3_open_v2(argv[1],&db,SQLITE_OPEN_READWRITE,NULL)!=SQLITE_OK)die("open failed (initialize first)");
    sqlite3_busy_timeout(db,3000);
    sql("PRAGMA foreign_keys=ON; PRAGMA trusted_schema=OFF; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL");
    register_functions();
    inbox_path(argv[1]);
    sqlite3_set_authorizer(db,auth,NULL);
    sqlite3_limit(db,SQLITE_LIMIT_LENGTH,8*1024*1024);
    sqlite3_limit(db,SQLITE_LIMIT_SQL_LENGTH,2*1024*1024);
    if(!strcmp(argv[2],"--version"))printf("Neuron V2 experimental / SQLite %s / generic C physical executor\n",sqlite3_libversion());
    else if(!strcmp(argv[2],"--say")){
        if(argc!=4)die("--say requires one quoted input");
        status=input_line(argv[3]);
    } else if(!strcmp(argv[2],"--resume")){
        sqlite3_int64 after=number("SELECT coalesce(max(id),0) FROM outbox");
        sql("UPDATE run SET state='ready' WHERE state='paused'");
        drain();
        print_outputs(after);
    } else if(!strcmp(argv[2],"--talk")){
        char *line=NULL;
        size_t cap=0;
        while(!interrupted){
            if(isatty(STDIN_FILENO)){
                printf("neuron> ");
                fflush(stdout);
            }
            ssize_t n=getline(&line,&cap,stdin);
            if(n<0)break;
            while(n>0&&(line[n-1]=='\n'||line[n-1]=='\r'))line[--n]=0;
            if(n)input_line(line);
        }
        free(line);
    } else {
        die("unknown transport option");
    }
    sqlite3_close(db);
    curl_global_cleanup();
    return status;
}
