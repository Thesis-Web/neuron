# Neuron V2 — experimental developmental substrate

**Release: 0.2.0-experimental · prepared for James on October 20, 2026**

## Read this before installing

This package is a working, locally validated **partial implementation**, not a completed or certified Neuron baby. **Full-Neuron acceptance: NOT_DEMONSTRATED.** In particular, you cannot currently grow the full system by ordinary conversation. It accepts the explicit instructions below, not unrestricted English. Its learner discovers scalar affine functions (`a*x+b`) and can shorten compositions of those functions from its own observed runs. That is a deliberately bounded demonstration, not general understanding, unrestricted reasoning, or an established path to autonomous maturation.

The unmet requirements are explicit in [BUILD-STATUS.md](BUILD-STATUS.md). The package does not substitute those demonstrations for the owner's full acceptance criterion.

What is real: stored DNA determines executable behavior; arrival/head conditions select DNA; stored excitation pointers start internal runs; learning installs new DNA; corrections change subsequent behavior; exact source/history objects remain addressable; the graph composes and executes a particular SQL construction from shared atoms. There is no LLM call or Python cognitive engine at runtime.

## Install separately from V1

For Ubuntu/Debian WSL, install the build dependencies yourself:

```bash
sudo apt-get update
sudo apt-get install -y build-essential libsqlite3-dev libcurl4-openssl-dev libssl-dev
```

Use SQLite **3.38 or newer with JSON support**. The released source compiles locally; no precompiled Linux binary or pre-taught database is distributed. The installer checks the file manifest, refuses an existing target, builds C, initializes a fresh database, and installs to a new directory. It does not open, migrate, remove, or alter V1. It installs no system service and does not invoke a model.

From the extracted package:

```bash
bash install.sh "$HOME/neuron/v2"
cd "$HOME/neuron/v2"
./talk
```

Exit the foreground terminal with Ctrl-D or Ctrl-C. For one input:

```bash
./say 'status'
./say 'help'
```

Outputs are structured JSON records, not prewritten conversational responses. `UNKNOWN`, `INCOMPLETE`, and faults remain explicit. `./resume` resumes work stopped by the step budget. No daemon continues work after the program exits. The user installation was not tested inside WSL here; source compilation, execution, and clean installation were tested on native Linux. Exact results are in `evidence/`.

## Try the connected loop

These instructions illustrate the supported domain; they are not samples secretly installed in the working brain.

```text
example scale 2 7
example scale 3 10
example scale 8 25
run scale 12
run scale 12
history
```

The first two distinct inputs propose an affine model. The third is a held-out observation, not a fitting input. An accepted fit is still a hypothesis outside the observed examples. The run at 12 yields 37 by executable DNA; repetition can reuse the versioned numeric result while retaining the evaluation/confidence branches.

Each answer contains a `run` identifier. Use the actual number it reports:

```text
yes RUN_ID
no RUN_ID
correct RUN_ID EXPECTED_NUMBER
why RUN_ID
```

`yes` and `no` are observations about an outcome, not universal truth. A negative judgment challenges future use until it is appropriately resolved. All previous examples, judgments, DNA versions, and outcomes remain historical evidence.

Composition is explicit teaching of a process, not discovery of that composition:

```text
example shift 1 6
example shift 3 8
example shift 9 14
compose chain scale shift
run chain 4
run chain 5
run chain 6
run chain 7
```

The original composition really executes its children. Distinct long-form runs provide self-observations. The learner can derive and install a shorter affine process for that composition. Dependency changes invalidate that specialization; old traces remain. This transformation is confined to pure numeric processes, not arbitrary effectful programs.

## Source input

Create or copy a text source into `sources/inbox/` under the installation. Source capture accepts bounded NUL-free UTF-8 text; it does not parse PDFs or execute instructions from documents.

```text
source file:lesson.json
quote SOURCE_ID 0 100
observe source_function SOURCE_ID
```

Replace `SOURCE_ID` with the returned ID. The `observe` instruction understands only an explicit JSON observation format:

```json
{"examples": [[2, 7], [3, 10], [8, 25]]}
```

Each observation links back to the exact captured object and array position. A textbook or dictionary can be preserved and quoted, but **its prose is not automatically understood or converted into executable meaning**. It is reported as unsupported lesson input rather than pretending to learn it.

The source transport also implements direct HTTPS GET to a small explicit allowlist: SQLite, Project Gutenberg, and the NSM approach domains (with and without `www`). It does not follow redirects, inherit proxy credentials, or read API keys. HTTPS capture has **not** been exercised against a live endpoint in this environment. A network failure is returned as unavailable, never replaced with invented data. Local source ingestion was exercised.

## All supported instructions

| Instruction | What it actually does |
|---|---|
| `help`, `status`, `work` | Inspect available syntax/state; execute pending bounded graph work. |
| `example NAME X Y` | Record a provenance-bearing scalar observation; schedule model fitting. |
| `run NAME X` | Execute an acquired numeric capability with evidence/confidence branches. |
| `compose NEW FIRST SECOND` | Lay an explicit composition of two existing numeric capabilities. |
| `yes RUN_ID`, `no RUN_ID`, `correct RUN_ID VALUE` | Record confirmation/challenge/corrective observation. |
| `remember SUBJECT RELATION OBJECT` | Retain a claim and its occurrence evidence; not declare a fact. |
| `support ASSERTION_ID`, `reject ASSERTION_ID` | Append a judgment without deleting the claim. |
| `rule RELATION transitive`, `ask SUBJECT RELATION` | Supply an explicit transitivity rule; recall/infer with proof IDs. |
| `source LOCATOR`, `quote ID OFFSET LENGTH`, `observe NAME ID` | Capture/quote exact text; consume the restricted lesson format. |
| `sleep`, `recall MEMORY_ID`, `history`, `why RUN_ID` | Classify memories and retain reference highlights; recall/inspect history. |
| `table NAME` | Build executable SQL from atom references; create a `u_` table with the fixed demonstrated schema. |
| `alias NEW_WORD EXISTING_COMMAND` | Add a told action alias in graph state; not infer a language meaning. |
| `place CAPABILITY X Y Z`, `coordinates GATE_LABEL X Y Z` | Append an explicitly supplied coordinate hypothesis. |
| `shape RUN_ID` | Compare historical path displacements when coordinates exist; no semantic equivalence assumed. |

Names containing spaces need double quotes. The parser supports double-quoted arguments and `\n`, `\t`, `\r`, `\"`, `\\`. Commands are explicit and case-sensitive. There is no arbitrary shell, general SQL prompt, automatic credential access, or unrestricted network tool.

## Independent verification

Optional: install Python 3 for the external verifier only. Python is not a runtime dependency.

```bash
./verify
```

The verifier uses separate temporary databases, never the working `brain.db`. It includes explicitly labelled perturbations to prove that changing DNA or excitation pointers changes actual execution. Such interventions are **not claimed as autonomous learning**. Reports are saved in a separate directory printed by the verifier. See `evidence/VALIDATION.md` for the shipped results.

Do not run two interactive instances against the same database. The seed and source are experimental, not a production security boundary. Keep the installation separate from valuable data. The physical boundary limits some operations, but it does not implement Nexus, general safety, or immutable moral cognition.

## Files and inspection

- `src/kernel.c`: physical executor and source/lexical transport; 718 lines in this release.
- `schema.sql`, `seed.sql`: inspectable persistence and complete pre-generated told seed.
- `docs/CODE-MAP.json`: exact SQL and hashes for the 51 seed processes.
- `tools/build_seed.py`, `tools/seed_extensions.py`: **build-time-only**, reproducible seed laying. All their supplied processes are told, not learned.
- `tools/verify.py`: external live audit; no test examples enter your installed brain.
- `docs/ARCHITECTURE.md`: implementation boundary, decisions, and tradeoffs.
- `BUILD-STATUS.md`: actual coverage against the requested system.
- `MANIFEST.sha256`: release-file integrity; not a semantic correctness certificate.

The upload of V1 was treated as evidence and left unchanged. This is a fresh V2 design candidate, not a migration or an assertion that the old architecture was completely recovered.
