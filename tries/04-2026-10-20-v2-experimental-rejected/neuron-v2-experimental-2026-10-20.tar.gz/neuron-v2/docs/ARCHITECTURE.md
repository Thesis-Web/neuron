# V2 implementation and boundary

## 1. What this representation does

A gate has a stable integer identity. Optional three-dimensional position records are separate, versioned hypotheses. A DNA revision identifies a gate, optional arrival selector, optional remainder-head selector, a code object, bound parameters, and provenance. Code objects are ordered references to reusable SQL-fragment gates. A physical SQL executor emits the fragments and executes the result. The context of a run is refreshed between statements.

There is no duplicate `next INTEGER` per DNA row. The remaining process sequence already carries the continuation. Shards can prepend process gates or initiate children. The active selector index points to immutable DNA revisions; older DNA and program content remain addressable. A more-specific arrival/head match outranks a less-specific one; equally specific matches produce a fault. This selection policy is a new, inspectable seed decision, not a claim that all Neuron cognition must use it.

The programs are stored code, not merely visit records. The external audit changes applicable DNA and observes the resulting computation change. It also changes a stored excitation destination and observes the affected branch fail. Those checks distinguish operative DNA from passive rows.

## 2. No hidden cognitive command handler in C

C implements SQL execution and binding, content hashing, UTF-8 source transport, lexical framing, durable run stepping, atomic step transactions, fair bounded scheduling, and a small execution boundary. It does not recognize `example`, `remember`, `table`, or `correct` as cognitive commands. The command table and the associated code live in the graph.

This does **not** make the kernel merely a one-line SQL pipe. Its physical duties are visible in `src/kernel.c`. It also does not prove that every stored process has the owner's intended fine-grained neuronal morphology. Some told SQL programs are substantial, and the command grammar is explicit. Moving those programs into the database is a narrower achievement than a learned, meaning-grounded universal language.

Build-time Python emits the seed. It has no runtime role. The generated `seed.sql` installs without executing Python. Regeneration was checked byte-for-byte for both the seed and code map.

## 3. Connected execution and learning

An input is retained as exact source bytes, then framed into losslessly referenced tokens. A graph-owned dispatch program checks declared arity and selects the explicit instruction. An unsupported utterance produces UNKNOWN rather than a canned answer. Output is structured result data.

An execution run can start child question runs using `excitation` edges. Landings return structured findings. A parent waiting for required children does not claim success when a child fails. Runtime budgets can stop work visibly; `resume` can continue it.

`example` records data and schedules an internal fit. The fit proposes a scalar affine model from two distinct inputs, evaluates separate retained examples, records checks, and installs new executable DNA only after the finite validation conditions are met. Model installation is a graph program. The physical executor contains no affine fitting formula. Values must be finite; unsupported numeric strings cannot silently become zero. The numerical tolerance is `1e-9 * max(1, abs(expected))`.

A composition runs its original children before specialization. Prior long-form executions supply independent observations for that composition. Its learner may discover a shorter affine process and replace the active DNA pointer. The former route remains executable history. New inputs then use the new parameterized process. This is narrowly self-applied optimization, not open-ended algorithm invention.

## 4. Correction and reuse

An exact repeated numeric run can reuse a cached result under a versioned dependency fingerprint; evaluation and confidence branches still run. Any changed relevant capability revision or numeric-spine execution context invalidates the old shortcut. A specialized composition can return to its original child process, collect observations under the new context, and specialize again. Old observations from a different context do not validate the new context.

Negative feedback is recorded and challenges the applicable capability. Reprocessing old favorable examples cannot erase that challenge. Corrections append new observations linked to the old run. Confirmation counts are not advertised as calibrated probabilities.

This cache policy applies only to the explicitly pure numeric family. It must not be generalized to effectful SQL or arbitrary changing-world questions without additional applicability and effect accounting.

## 5. Sources, claims, relationships

`source` captures exact accepted UTF-8 source content once by SHA-256, with locator and capture event. `quote` emits source excerpts. `observe` recognizes only the explicit examples-array lesson representation. A dictionary paragraph is data, not executable code; this release has no semantic compiler capable of learning its meaning.

`remember` stores canonical claim content and separate evidence occurrences. `support`/`reject` append judgments. An explicitly supplied transitive relation can be followed with proof assertion IDs. Conflicting claims remain separate. This is small symbolic inference, not evidence that the system understands arbitrary relationships.

## 6. Memory and geometry

A completed run interns its exact route and result into a canonical object, adds a memory/occurrence link, and lands. Temporary trace rows are cleared only after the completed route is stored. Repeated content can share one object; different events remain different occurrences. Faulted/interrupted runs retain their available live state. Exact raw input and source content is not replaced by a summary.

`sleep` produces reference highlights and updates tier projections. It does not reproduce the owner's proposed reconstructive hippocampus, forget exact originals, or demonstrate a compression ratio. Some active cohorts and aggregate inspections still involve scans; only specified hot lookup plans have been checked for indexed access.

Positions are never invented to produce a pleasing plot. They must be explicitly supplied. A route records the coordinate versions actually available during its execution. `shape` compares translation-invariant displacement sequences and reports missing geometry as INCOMPLETE. Matching shape does not imply matching meaning or correct transfer. Later coordinate changes do not overwrite historical path geometry.

## 7. Actual SQL construction

`table NAME` uses a graph-stored template and shared SQL-atom references to construct a new executable program for:

```
CREATE TABLE "u_NAME" (id INTEGER PRIMARY KEY, value TEXT NOT NULL);
```

The runtime identifier is safely quoted. The generated code is hashed, given a gate and DNA, executed through the same machinery, and inspected for its real effect. A repeated creation honestly reports the database's existing-table failure, rather than relabelling it success. No raw caller SQL is reassembled and blindly advertised as neuronal composition.

The template itself is told. This proves this particular compositional construction path, not autonomous discovery of arbitrary schemas or complete SQL competence.

## 8. Physical limits and safety

A run action is one transaction. Failure rolls that step back; it does not roll back all earlier steps in the input. Every error must be interpreted against its timeline, not assumed to imply no earlier effect.

Limits: 65,536 input bytes; 2 MiB source body; 12,000 graph steps per invocation; maximum run depth 24; approximately four million SQLite VM instructions per action; bounded result rows and SQL/object sizes. These are explicit physical limits, not hidden reasoning heuristics. The application is intended for one foreground process per database. There is no concurrency correctness claim for multiple clients.

The runtime authorizer forbids mutation of specified immutable evidence tables, extension loading, ATTACH/DETACH, PRAGMAs, direct transaction control, and certain filesystem functions. Physical user-created tables require the `u_` prefix. A local file locator must resolve inside the installation's source inbox. HTTPS is direct, allowlisted, certificate-verified, port 443, no redirects, bounded time/size, no proxy or netrc inheritance. Only NUL-free UTF-8 source text is accepted.

These controls do not constitute an OS sandbox, proof of general noninterference, Nexus, or an unalterable moral system. Anyone with normal file write access can modify the database outside the runtime. Do not provide production credentials or mix this test installation with valuable data.

## 9. Scale and implementation choices

A fixed set of tables stores many logical neurons, avoiding a separate SQLite B-tree per gate/definition. This does not make storage free: indexes, receipts, event history, code, source bytes, and pointers all have costs. The installed seed starts with 564 gates and no acquired numeric capabilities. No billion-node scaling claim is made.

This release is CPU-executed code using normal SQLite page caching and the operating system's memory hierarchy. It does not eagerly materialize every historical object into a host-language graph. It contains no QKV model. No hardware energy or comparative speed benchmark was conducted.

## 10. Provenance

Review basis: owner's current request and corrections; supplied October 18–19 NOW/interview/blueprint as contextual material; uploaded V1 source and audit. V1 archive SHA-256:

`7dcb86e5851a21ba95db4eac3083947528ee4fc1fe50eb4db40031d4a3f1d9de`

Physical API references checked during construction: official SQLite CREATE TABLE, JSON functions, SQLite 3.38 release notes, and C authorizer/prepare/step documentation. These justify SQLite mechanics, not the Neuron thesis. The release's graph programs and decisions remain assistant-authored told structure.
