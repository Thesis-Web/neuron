# V2 build status — read before treating this as Neuron

**Full requested outcome: NOT_DEMONSTRATED.**

The owner asked for a connected baby capable of developing through prompted learning, self-directed understanding, source reading, correction, and self-construction. This release implements a bounded connected subset. Passing its checks does not establish the rest. It is not asserted that the rest can be obtained solely by talking to this release without further engineering.

| Requirement | Actual delivered status |
|---|---|
| DNA controls execution | Demonstrated in this representation. Immutable DNA revisions point to SQL-atom programs; arrival/head selectors are operative. Interventions alter behavior. |
| Trigger pointers cause internal work | Demonstrated. Real stored excitation edges start evaluation/confidence or recall/inference branches and return landings. |
| Meaning carried by every component of unrestricted input | **Not implemented.** The frontend is a small declared instruction grammar, not human-language executable meanings. |
| Self-construction | Bounded. Learned numeric DNA, told compositions, aliases, and a fixed SQL table template can be created through graph programs. Not arbitrary self-engineering. |
| Learning not merely storing supplied answers | Bounded. Coefficients are inferred and checked on held-out examples; a pure composition can specialize from its own prior executions. Search space is only affine functions. |
| General learning/understanding/reasoning | **Not demonstrated.** No ability to derive arbitrary new algorithms or interpret arbitrary text. |
| Correct/incorrect and revision | Demonstrated within numeric/claim domains, with retained evidence and stale-specialization invalidation. Not a general epistemic calculus. |
| Relationships and proof | Explicit claims, judgments, dependency links, and a told transitivity rule work. Human synonymy, contextual meaning, and semantic relation discovery are absent. |
| History and memories | Exact immutable source/route objects, occurrences, DNA versions, and event timeline work in the exercised paths. No whole-brain historical snapshot per event. |
| Hippocampus | Partial. Reference highlights and memory-tier records retaining exact originals. No demonstrated approximate reconstruction, learned consolidation policy, or quantified compression benefit. |
| Encoder/decoder | Explicit instruction framing and structured JSON rendering. **Not general conversational language generation or understanding.** |
| Source access | Local exact UTF-8 capture, provenance, excerpts, structured observations demonstrated. HTTPS path implemented but live endpoint behavior untested. No autonomous dictionary/textbook comprehension. |
| SQL atoms | Hand-laid shared SQL fragments include CREATE, TABLE, INTEGER, spaces, punctuation, and other used syntax. They compose actual SQL. This is not a learned universal meaning graph. |
| Reuse and formula substitution | Pure numeric reuse and parameter binding work. Effectful processes are not universally shortcut-safe and are not optimized by this learner. |
| Apply new processes to old work | Explicit dependency invalidation/re-specialization works. Discovering unrelated older processes that could benefit from a newly learned concept is **not implemented**. |
| Geometry and shape | Versioned explicit coordinates and translated-path matching work. Automatic meaning-derived placement, relationship tug-of-war, and cognition through geometry are **not implemented**. |
| QKV guessing | Not implemented. No substitute global prediction model is hidden in the code. |
| Self-directed operation | Bounded graph task processing after inputs or explicit work/resume. No continuous autonomous life or self-generated curriculum. |
| Source verification of truth | Observations remain observations; learned fits remain hypotheses. No claim that sourced text is automatically true. |
| Billions of nodes / performance / energy | **Not measured.** No 1–2 microsecond, 7–100x, constant-cost, or low-energy claim. |
| Full baby acceptance | **Not met by the evidence.** This package is a partial experimental substrate, not the completed one-turn solution. |

## Why it is still supplied

The user requested an installable artifact rather than another proposal. This package contains source, a fresh seed, installation tooling, and reproducible execution evidence. Its meaningful result is narrower than the requested whole: stored structure now causes behavior and can change through a small actual learning/correction loop. It is supplied for that limited result, not with a promise that unresolved developmental capabilities will emerge automatically.

## Authority and epistemic status

The current owner corrections govern intended behavior. October 18–19 project files were used for context, not as proof that their formulas or design choices were right. Every concrete V2 choice in this release is a **new assistant-authored experimental decision**, not a recovered or owner-ratified architecture rule. Hand-laid code is labelled told. Affine predictions are hypotheses. Test-only database edits are audit interventions. Earlier performance reports remain owner observations, not reproduced benchmarks here.
